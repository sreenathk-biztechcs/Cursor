# -*- coding: utf-8 -*-

import base64
import json
import logging
import re
import time
from datetime import datetime

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from ..services.content_filter import ContentFilter
from ..services.timeline_builder import TimelineBuilder
from ..services.claude_service import ClaudeService
from ..services.google_docs_service import GoogleDocsService

_logger = logging.getLogger(__name__)

try:
    import PyPDF2  # type: ignore
except Exception:  # pylint: disable=broad-except
    PyPDF2 = None

try:
    import docx  # type: ignore
except Exception:  # pylint: disable=broad-except
    docx = None


class LivingDocumentEngine(models.AbstractModel):
    _name = 'living.document.engine'
    _description = 'Living Document Processing Engine'

    # -------------------------
    # Public API
    # -------------------------
    def generate_document(self, lead, mode='odoo', include_existing=True, workspace_id=None):
        lead = lead.exists()
        if not lead:
            return False
        existing_doc = bool(lead.x_living_doc_id or lead.x_google_doc_id)
        existing_status = lead.x_living_doc_status
        if existing_doc or existing_status not in (False, 'none'):
            # Idempotent behavior for concurrent/background runs: if a document
            # already exists, do not fail the job. This prevents false "error"
            # states when two async paths race to create the same living doc.
            vals = {}
            if existing_status in ('none', 'creating', 'error', False):
                vals['x_living_doc_status'] = 'active'
            if not lead.x_living_doc_mode:
                vals['x_living_doc_mode'] = mode
            if vals:
                lead.sudo().write(vals)

            # Avoid invalidate_recordset() here: it flushes and can raise
            # SerializationFailure under concurrent writes.
            lead = lead.sudo().browse(lead.id)
            if include_existing:
                try:
                    self.update_document(lead)
                except Exception:  # pylint: disable=broad-except
                    _logger.exception(
                        'Living doc exists for lead %s; create call switched to update and failed.',
                        lead.id,
                    )
            return True

        log = self.env['living.doc.log'].sudo()
        t0 = time.monotonic()
        log.create_log(lead, 'trigger', status='success', message='Generate living document requested', data={'mode': mode})

        lead.sudo().write(
            {
                'x_living_doc_status': 'creating',
                'x_living_doc_mode': mode,
                'x_living_doc_error': False,
            }
        )

        folder = self._ensure_lead_folder(lead, workspace_id=workspace_id)

        initial_summary = {
            'executive_summary': '',
            'requirements': [],
            'decisions': [],
            'open_questions': [],
            'action_items': [],
            'communication_count': 0,
            'last_communication_date': '',
        }
        initial_doc = self._format_document(lead, initial_summary, timeline_entries=[], changes={})

        # Create Odoo document and/or Google doc with minimal content.
        if mode in ('odoo', 'both'):
            doc = self._create_or_replace_odoo_document(lead, folder, initial_doc, creating=True)
            lead.sudo().write({'x_living_doc_id': doc.id})

        if mode in ('google', 'both'):
            gdoc_id, rev_id = self._create_google_doc(lead, initial_doc)
            lead.sudo().write({'x_google_doc_id': gdoc_id, 'x_google_doc_revision_id': rev_id or False})

        lead.sudo().write({'x_living_doc_status': 'active'})
        log.create_log(
            lead,
            'complete',
            status='success',
            message='Living document created (content generation scheduled)',
            processing_time_ms=int((time.monotonic() - t0) * 1000),
        )

        # Try an immediate first pass so document is useful right after creation.
        # If anything fails, fall back to async cron path.
        try:
            if include_existing:
                self.update_document(lead)
            else:
                lead._schedule_living_doc_update(force_immediate=True, reason='generate_document')
        except Exception:  # pylint: disable=broad-except
            _logger.exception('Initial immediate living doc update failed; scheduling async fallback.')
            lead._schedule_living_doc_update(force_immediate=True, reason='generate_document_fallback')
        if not include_existing:
            # If user opted out, mark as processed to avoid backfilling.
            lead.sudo().write({'x_last_processed_message_id': self._get_latest_message_id(lead) or 0})
        return True

    def update_document(self, lead):
        lead = lead.exists()
        if not lead:
            return False
        if lead.x_living_doc_status != 'active' or lead.x_living_doc_status == 'paused':
            return False

        log = self.env['living.doc.log'].sudo()
        t0 = time.monotonic()
        log.create_log(lead, 'extraction', status='success', message='Extracting new messages')

        new_timeline = TimelineBuilder.get_new_messages(lead, self.env)
        if not new_timeline:
            log.create_log(
                lead,
                'complete',
                status='skipped',
                message='No new messages since last processed message id %s' % (lead.x_last_processed_message_id or 0),
                processing_time_ms=int((time.monotonic() - t0) * 1000),
            )
            return True

        latest_new_id = new_timeline[-1]['id']

        filtered = ContentFilter.filter_sensitive(new_timeline)
        log.create_log(lead, 'filtering', status='success', message='Filtered sensitive content', data={'count': len(filtered)})

        claude = self._get_claude()

        # Attachment extraction + summarization (exclude living doc itself)
        # Scan all lead+ticket attachments each run so the living doc is always complete.
        attachment_summaries = {}
        try:
            all_timeline_for_attachments = TimelineBuilder.get_all_messages(lead, self.env)
            attachment_entries = self._collect_attachment_entries(lead, all_timeline_for_attachments)
            if attachment_entries:
                att_tokens_total = 0
                att_model = None
                # Chunk attachment summaries so every attachment is processed.
                for chunk in self._chunk(attachment_entries, size=12):
                    summaries_json, att_tokens, model_used = claude.summarize_attachments(chunk)
                    att_model = model_used or att_model
                    att_tokens_total += int(att_tokens or 0)
                    for item in (summaries_json or {}).get('attachments') or []:
                        if isinstance(item, dict) and item.get('id'):
                            attachment_summaries[int(item['id'])] = item.get('summary') or ''
                log.create_log(
                    lead,
                    'ai_clean',
                    status='success',
                    message='AI summarized attachments (full scan)',
                    data={'count': len(attachment_summaries), 'scanned': len(attachment_entries)},
                    ai_model=att_model,
                    ai_tokens=att_tokens_total,
                )
        except Exception:  # pylint: disable=broad-except
            _logger.exception('Attachment summarization failed; continuing without attachment summaries.')

        # AI clean in chunks to keep token usage bounded (especially for long threads).
        cleaned_all = []
        tokens_clean = 0
        model_clean = None
        t_clean = time.monotonic()
        for chunk in self._chunk(filtered, size=20 if len(filtered) > 50 else len(filtered)):
            cleaned, tokens, model_used = claude.clean_messages(chunk)
            cleaned_all.extend(cleaned or [])
            tokens_clean += int(tokens or 0)
            model_clean = model_used
        log.create_log(
            lead,
            'ai_clean',
            status='success',
            message='AI cleaned messages',
            data={'count': len(cleaned_all)},
            processing_time_ms=int((time.monotonic() - t_clean) * 1000),
            ai_model=model_clean,
            ai_tokens=tokens_clean,
        )

        # AI structure (chunk if needed; then merge lists)
        t_struct = time.monotonic()
        tokens_struct = 0
        model_struct = None
        structured_merged = {'requirements': [], 'questions': [], 'decisions': [], 'action_items': [], 'issues': []}
        struct_chunks = list(self._chunk(cleaned_all, size=20 if len(cleaned_all) > 50 else len(cleaned_all)))
        for chunk in struct_chunks:
            structured, tokens, model_used = claude.structure_messages(chunk)
            model_struct = model_used
            tokens_struct += int(tokens or 0)
            for k in structured_merged:
                structured_merged[k].extend((structured or {}).get(k) or [])
        structured_merged = self._normalize_ids(structured_merged)
        log.create_log(
            lead,
            'ai_structure',
            status='success',
            message='AI structured messages',
            data=structured_merged,
            processing_time_ms=int((time.monotonic() - t_struct) * 1000),
            ai_model=model_struct,
            ai_tokens=tokens_struct,
        )

        previous_summary = lead._get_last_summary()
        # Two-way sync (Odoo side): if user edited the Odoo living doc file manually,
        # merge that content back into previous_summary before asking Claude to update.
        try:
            if lead.x_living_doc_id and lead.x_living_doc_mode in ('odoo', 'both'):
                raw = lead.x_living_doc_id.attachment or (lead.x_living_doc_id.attachment_id.datas if lead.x_living_doc_id.attachment_id else False)
                if raw:
                    text = base64.b64decode(raw).decode('utf-8', errors='ignore')
                    parsed = self._parse_markdown_summary(text)
                    if parsed:
                        previous_summary = {**previous_summary, **parsed}
        except Exception:  # pylint: disable=broad-except
            _logger.exception('Failed to merge manual Odoo document edits into summary cache.')
        timeline_for_ai = self._timeline_for_ai(lead)
        t_sum = time.monotonic()
        new_summary, tokens_sum, model_sum = claude.generate_summary(structured_merged, previous_summary, timeline_for_ai)
        log.create_log(
            lead,
            'ai_summary',
            status='success',
            message='AI generated summary',
            data=new_summary,
            processing_time_ms=int((time.monotonic() - t_sum) * 1000),
            ai_model=model_sum,
            ai_tokens=tokens_sum,
        )

        t_chg = time.monotonic()
        changes, tokens_chg, model_chg = claude.detect_changes(previous_summary, new_summary)
        log.create_log(
            lead,
            'ai_changes',
            status='success',
            message='AI detected changes',
            data=changes,
            processing_time_ms=int((time.monotonic() - t_chg) * 1000),
            ai_model=model_chg,
            ai_tokens=tokens_chg,
        )

        # Build concise communication timeline via AI (avoid raw transcript dump).
        timeline_digest = ''
        try:
            timeline_payload = self._timeline_for_ai(lead)
            digest_json, tokens_tl, model_tl = claude.summarize_timeline(timeline_payload)
            timeline_digest = (digest_json or {}).get('timeline_summary') or ''
            log.create_log(
                lead,
                'ai_summary',
                status='success',
                message='AI summarized communication timeline',
                data={'has_timeline_summary': bool(timeline_digest)},
                ai_model=model_tl,
                ai_tokens=tokens_tl,
            )
        except Exception:  # pylint: disable=broad-except
            _logger.exception('Timeline summarization failed; using fallback compact timeline.')

        # Build doc content.
        all_timeline = TimelineBuilder.get_all_messages(lead, self.env)
        doc_md = self._format_document(
            lead,
            new_summary,
            timeline_entries=all_timeline,
            changes=changes,
            attachment_summaries=attachment_summaries,
            timeline_digest=timeline_digest,
        )
        log.create_log(lead, 'doc_format', status='success', message='Formatted document', data={'length': len(doc_md)})

        # Upload to Odoo doc / Google doc (full replace). Handle targets
        # independently so one target failure doesn't silently block all sync.
        upload_errors = []
        odoo_uploaded = False
        google_uploaded = False

        if lead.x_living_doc_mode in ('odoo', 'both'):
            try:
                folder = lead.x_living_doc_id.workspace_id if lead.x_living_doc_id else self._ensure_lead_folder(lead)
                self._create_or_replace_odoo_document(lead, folder, doc_md, creating=False)
                odoo_uploaded = True
                log.create_log(lead, 'doc_upload', status='success', message='Uploaded to Odoo Documents')
            except Exception as exc:  # pylint: disable=broad-except
                upload_errors.append("Odoo upload failed: %s" % str(exc))
                log.create_log(
                    lead,
                    'doc_upload',
                    status='error',
                    message='Odoo document upload failed: %s' % str(exc),
                )
                _logger.exception('Living doc Odoo upload failed for lead %s', lead.id)

        if lead.x_living_doc_mode in ('google', 'both') and lead.x_google_doc_id:
            try:
                gsvc = self._get_google()
                gsvc.update_document(lead.x_google_doc_id, doc_md)
                rev = gsvc.get_revision_id(lead.x_google_doc_id)
                lead.sudo().write({'x_google_doc_revision_id': rev or lead.x_google_doc_revision_id})
                google_uploaded = True
                log.create_log(lead, 'google_sync', status='success', message='Uploaded to Google Doc', data={'revision_id': rev})
            except Exception as exc:  # pylint: disable=broad-except
                upload_errors.append("Google sync failed: %s" % str(exc))
                log.create_log(
                    lead,
                    'google_sync',
                    status='error',
                    message='Google doc upload failed: %s' % str(exc),
                )
                _logger.exception('Living doc Google sync failed for lead %s', lead.id)

        if upload_errors and not (odoo_uploaded or google_uploaded):
            raise UserError(_('; '.join(upload_errors)))

        # Persist state
        lead.sudo().write(
            {
                'x_last_processed_message_id': latest_new_id,
                'x_last_summary_json': json.dumps(new_summary, ensure_ascii=False, default=str),
                'x_living_doc_error': '; '.join(upload_errors) if upload_errors else False,
            }
        )
        log.create_log(
            lead,
            'complete',
            status='success',
            message='Living document updated',
            processing_time_ms=int((time.monotonic() - t0) * 1000),
        )
        return True

    def sync_google_doc(self, lead):
        """Bi-directional sync: detect external edits and merge into stored summary JSON."""
        lead = lead.exists()
        if not lead or not lead.x_google_doc_id:
            return False
        if lead.x_living_doc_mode not in ('google', 'both'):
            return False

        gsvc = self._get_google()
        current_rev = gsvc.get_revision_id(lead.x_google_doc_id)
        if not current_rev or current_rev == lead.x_google_doc_revision_id:
            return True

        # External edit detected -> fetch doc content and parse back
        raw_text = gsvc.get_document_content(lead.x_google_doc_id)
        parsed_summary = self._parse_markdown_summary(raw_text)
        if parsed_summary:
            lead.sudo().write({'x_last_summary_json': json.dumps(parsed_summary, ensure_ascii=False, default=str)})
        lead.sudo().write({'x_google_doc_revision_id': current_rev})
        self.env['living.doc.log'].sudo().create_log(
            lead,
            'google_sync',
            status='success',
            message='External Google Doc edit merged',
            data={'revision_id': current_rev},
        )
        return True

    # -------------------------
    # Formatting / storage
    # -------------------------
    def _format_document(self, lead, summary_data, timeline_entries, changes, attachment_summaries=None, timeline_digest=''):
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        partner = lead.partner_id.name if lead.partner_id else ''
        salesperson = lead.user_id.name if lead.user_id else ''
        stage = lead.stage_id.name if lead.stage_id else ''

        executive_summary = (summary_data or {}).get('executive_summary') or ''
        reqs = (summary_data or {}).get('requirements') or []
        decisions = (summary_data or {}).get('decisions') or []
        questions = (summary_data or {}).get('open_questions') or []
        actions = (summary_data or {}).get('action_items') or []

        def bullets(items, formatter):
            if not items:
                return '- (none)'
            lines = []
            for it in items:
                try:
                    lines.append('- ' + formatter(it))
                except Exception:
                    lines.append('- ' + str(it))
            return '\n'.join(lines)

        requirements_md = bullets(reqs, lambda r: f"[{r.get('id','')}] {r.get('text','').strip()} ({r.get('status','')}, {r.get('source_date','')})".strip())
        decisions_md = bullets(decisions, lambda d: f"[{d.get('id','')}] {d.get('text','').strip()} — {d.get('decided_by','')} ({d.get('date','')})".strip())
        questions_md = bullets(questions, lambda q: f"[{q.get('id','')}] {q.get('text','').strip()} — asked by {q.get('asked_by','')} ({q.get('date','')})".strip())
        actions_md = bullets(
            actions,
            lambda a: f"[{a.get('id','')}] {a.get('text','').strip()} — Owner: {a.get('owner','')} | Due: {a.get('due_date','')} | Status: {a.get('status','')}".strip(),
        )

        change_summary = ''
        if changes:
            change_summary = (changes.get('change_summary') or '').strip()
            if not change_summary and changes.get('has_significant_changes'):
                change_summary = json.dumps(changes, ensure_ascii=False)
        if not change_summary:
            change_summary = '(none)'

        parts = []
        parts.append(f"# Lead: {lead.name}\n")
        parts.append(f"**Partner:** {partner} | **Salesperson:** {salesperson} | **Stage:** {stage}\n")
        parts.append(f"**Last Updated:** {now}\n\n---\n")
        parts.append("## 1. Executive Summary\n")
        parts.append(executive_summary.strip() or '(none)')
        parts.append("\n\n## 2. Latest Requirements\n")
        parts.append(requirements_md)
        parts.append("\n\n## 3. Key Decisions\n")
        parts.append(decisions_md)
        parts.append("\n\n## 4. Open Questions\n")
        parts.append(questions_md)
        parts.append("\n\n## 5. Action Items\n")
        parts.append(actions_md)
        parts.append("\n\n## 6. Risk Alerts / Requirement Changes\n")
        parts.append(change_summary)
        parts.append("\n\n## 7. Communication Timeline\n\n")
        if timeline_digest:
            parts.append(timeline_digest.strip())
            parts.append("\n")
        else:
            # Fallback: compact latest communication markers only (no raw transcript dump).
            tail = (timeline_entries or [])[-12:]
            if not tail:
                parts.append('- (none)\n')
            else:
                for entry in tail:
                    date = entry.get('date') or ''
                    author = entry.get('author') or ''
                    typ = entry.get('type') or ''
                    content = re.sub(r'\s+', ' ', (entry.get('content') or '').strip())
                    if len(content) > 180:
                        content = content[:180].rstrip() + '...'
                    if not content:
                        content = '(no content)'
                    parts.append(f"- {date} — {author} ({typ}): {content}\n")

        # Keep attachment summaries but avoid repeating raw body text.
        if attachment_summaries:
            parts.append("\n\n---\n\n### Attachment Summaries\n")
            seen_attachment_ids = set()
            for entry in (timeline_entries or []):
                for a in (entry.get('attachments') or []):
                    aid = a.get('id')
                    aid_int = int(aid) if aid else 0
                    if aid_int and aid_int in attachment_summaries and aid_int not in seen_attachment_ids:
                        seen_attachment_ids.add(aid_int)
                        parts.append(f"\n- **{a.get('name') or ''}**\n")
                        parts.append(attachment_summaries[aid_int].strip() or '(none)')
                        parts.append("\n")

        # Full archive is required for auditability and downstream agents.
        parts.append("\n\n## 8. Full Communication Archive\n\n")
        if not timeline_entries:
            parts.append("- (none)\n")
        else:
            for entry in (timeline_entries or []):
                date = entry.get('date') or ''
                author = entry.get('author') or ''
                typ = entry.get('type') or ''
                subject = (entry.get('subject') or '').strip()
                content = (entry.get('content') or '').strip() or '(no content)'
                attachments = entry.get('attachments') or []
                att_names = ', '.join([a.get('name') or '' for a in attachments if a.get('name')]) or '(none)'
                parts.append(f"### {date} — {author} ({typ})\n")
                if subject:
                    parts.append(f"Subject: {subject}\n\n")
                parts.append(content)
                parts.append(f"\n\nAttachments: {att_names}\n\n---\n")

        return ''.join(parts).strip() + '\n'

    def _collect_attachment_entries(self, lead, timeline_entries):
        """Collect attachments for AI summarization, excluding living-document files."""
        Attachment = self.env['ir.attachment'].sudo()
        exclude_ids = set()
        if lead.x_living_doc_id and lead.x_living_doc_id.attachment_id:
            exclude_ids.add(lead.x_living_doc_id.attachment_id.id)

        entries = []
        seen = set()
        for t in (timeline_entries or []):
            for a in (t.get('attachments') or []):
                aid = a.get('id')
                if not aid:
                    continue
                aid = int(aid)
                if aid in seen or aid in exclude_ids:
                    continue
                seen.add(aid)
                att = Attachment.browse(aid).exists()
                if not att:
                    continue
                # Never summarize living-document files themselves.
                att_name = (att.name or '').lower()
                if (
                    att.res_model == 'document.file'
                    or att_name.startswith('living document')
                    or att_name.endswith('.md') and 'living document' in att_name
                ):
                    continue
                text = self._extract_attachment_text(att)
                # Redact financial patterns before AI
                redacted = ContentFilter.filter_sensitive([{'content': text}])[0].get('content') if text else ''
                entries.append(
                    {
                        'id': aid,
                        'name': att.name or '',
                        'mimetype': att.mimetype or '',
                        'text_excerpt': (redacted or '')[:6000],
                    }
                )
        return entries

    def _extract_attachment_text(self, attachment):
        """Best-effort text extraction (pdf/docx/plain)."""
        mimetype = attachment.mimetype or ''
        name = (attachment.name or '').lower()
        data_b64 = attachment.datas
        if not data_b64:
            return ''
        try:
            raw = base64.b64decode(data_b64)
        except Exception:
            return ''

        # Plain text / markdown
        if mimetype.startswith('text/') or name.endswith(('.txt', '.md', '.csv', '.log')):
            return raw.decode('utf-8', errors='ignore')

        # PDF
        if mimetype == 'application/pdf' or name.endswith('.pdf'):
            if not PyPDF2:
                return ''
            try:
                from io import BytesIO

                reader = PyPDF2.PdfReader(BytesIO(raw))
                parts = []
                for page in reader.pages[:10]:
                    parts.append(page.extract_text() or '')
                return '\n'.join(parts).strip()
            except Exception:
                return ''

        # DOCX
        if mimetype in ('application/vnd.openxmlformats-officedocument.wordprocessingml.document',) or name.endswith('.docx'):
            if not docx:
                return ''
            try:
                from io import BytesIO

                d = docx.Document(BytesIO(raw))
                return '\n'.join([p.text for p in d.paragraphs if p.text]).strip()
            except Exception:
                return ''

        return ''

    def _create_or_replace_odoo_document(self, lead, folder, markdown_content, creating=False):
        Attachment = self.env['ir.attachment'].sudo()
        Documents = self.env['document.file'].sudo()

        datas = base64.b64encode((markdown_content or '').encode('utf-8'))
        att = Attachment.create(
            {
                'name': f'Living Document - {lead.name}.md',
                'type': 'binary',
                'datas': datas,
                'mimetype': 'text/markdown',
                'res_model': 'crm.lead',
                'res_id': lead.id,
            }
        )
        if lead.x_living_doc_id and not creating:
            lead.x_living_doc_id.sudo().write({'attachment_id': att.id, 'workspace_id': folder.id, 'attachment': datas})
            return lead.x_living_doc_id

        doc_vals = {
            'name': f'Living Document - {lead.name}',
            'attachment_id': att.id,
            'workspace_id': folder.id,
            'attachment': datas,
            'date': fields.Datetime.now(),
        }
        # Optional fields in document.file; set only if present.
        if 'owner_id' in Documents._fields:
            doc_vals['owner_id'] = lead.user_id.id if lead.user_id else self.env.user.id
        if 'user_id' in Documents._fields:
            doc_vals['user_id'] = lead.user_id.id if lead.user_id else self.env.user.id
        if 'partner_id' in Documents._fields and lead.partner_id:
            doc_vals['partner_id'] = lead.partner_id.id
        doc = Documents.create(doc_vals)
        return doc

    def _create_google_doc(self, lead, markdown_content):
        gsvc = self._get_google()
        title = f'Living Document - {lead.name}'
        doc_id = gsvc.create_document(title, markdown_content)
        rev = gsvc.get_revision_id(doc_id)
        return doc_id, rev

    # -------------------------
    # Helpers
    # -------------------------
    def _get_claude(self):
        icp = self.env['ir.config_parameter'].sudo()
        api_key = icp.get_param('sales_ai.claude_api_key')
        return ClaudeService(api_key=api_key)

    def _get_google(self):
        creds = self.env['ir.config_parameter'].sudo().get_param('living_doc.google_credentials')
        return GoogleDocsService(credentials_json=creds)

    def _get_latest_message_id(self, lead):
        Mail = self.env['mail.message'].sudo()
        max_id = 0

        msg = Mail.search(
            [
                ('model', '=', 'crm.lead'),
                ('res_id', '=', lead.id),
                ('message_type', 'in', ['email', 'comment']),
            ],
            order='id desc',
            limit=1,
        )
        if msg:
            max_id = msg.id or 0

        ticket_model_candidates = ('sh.helpdesk.ticket', 'helpdesk.ticket')
        for ticket_model in ticket_model_candidates:
            if ticket_model not in self.env.registry.models:
                continue
            Ticket = self.env[ticket_model].sudo()
            ticket_fields = Ticket._fields
            if 'x_linked_lead_id' in ticket_fields:
                ticket_ids = Ticket.search([('x_linked_lead_id', '=', lead.id)]).ids
            elif 'x_related_lead_id' in ticket_fields:
                ticket_ids = Ticket.search([('x_related_lead_id', '=', lead.id)]).ids
            elif 'lead_id' in ticket_fields:
                ticket_ids = Ticket.search([('lead_id', '=', lead.id)]).ids
            else:
                ticket_ids = []

            if not ticket_ids:
                continue

            tmsg = Mail.search(
                [
                    ('model', '=', ticket_model),
                    ('res_id', 'in', ticket_ids),
                    ('message_type', 'in', ['email', 'comment']),
                ],
                order='id desc',
                limit=1,
            )
            if tmsg and (tmsg.id or 0) > max_id:
                max_id = tmsg.id

        return max_id

    def _ensure_lead_folder(self, lead, workspace_id=None):
        Folder = self.env['document.workspace'].sudo()
        icp = self.env['ir.config_parameter'].sudo()
        root_id = workspace_id.id if workspace_id else icp.get_param('living_doc.workspace_folder_id')
        root = Folder.browse(int(root_id)).exists() if root_id else False
        if not root:
            # Fallback: create a root folder if not configured.
            root = Folder.search([('name', '=', 'Living Documents')], limit=1)
            if not root:
                root = Folder.create({'name': 'Living Documents'})
                icp.set_param('living_doc.workspace_folder_id', root.id)

        folder_name = f'Lead {lead.id} - {lead.name}'
        folder = Folder.search([('name', '=', folder_name)], limit=1)
        return folder or Folder.create({'name': folder_name, 'description': 'Living document workspace for %s' % lead.name})

    def _chunk(self, items, size):
        items = items or []
        if not items:
            return []
        if size <= 0:
            size = len(items)
        for i in range(0, len(items), size):
            yield items[i : i + size]

    def _normalize_ids(self, structured):
        """Ensure stable sequential IDs for merged chunk outputs."""
        structured = structured or {}
        counters = {'requirements': 'R', 'questions': 'Q', 'decisions': 'D', 'action_items': 'A', 'issues': 'I'}
        for key, prefix in counters.items():
            out = []
            seq = 1
            for item in structured.get(key) or []:
                if not isinstance(item, dict):
                    item = {'text': str(item)}
                item = dict(item)
                item['id'] = item.get('id') or f'{prefix}{seq}'
                out.append(item)
                seq += 1
            structured[key] = out
        return structured

    def _timeline_for_ai(self, lead):
        """Provide a bounded timeline payload to AI while preserving context."""
        timeline = TimelineBuilder.get_all_messages(lead, self.env)
        if len(timeline) <= 200:
            return timeline
        # Keep some early context + the latest most relevant history.
        return timeline[:50] + timeline[-150:]

    # -------------------------
    # Markdown parsing for bi-directional sync
    # -------------------------
    _SECTION_RX = re.compile(r'^##\s+(\d+)\.\s+(.+)$', flags=re.MULTILINE)

    def _parse_markdown_summary(self, markdown_text):
        """Best-effort parsing of our strict template back into summary JSON.

        This is intentionally conservative: if parsing fails, we keep previous JSON.
        """
        if not markdown_text:
            return {}
        text = markdown_text.replace('\r\n', '\n')

        def section_text(title_prefix):
            # title_prefix like "1. Executive Summary"
            marker = f"## {title_prefix}\n"
            start = text.find(marker)
            if start < 0:
                return ''
            start += len(marker)
            # next section
            next_pos = text.find('\n## ', start)
            if next_pos < 0:
                return text[start:].strip()
            return text[start:next_pos].strip()

        executive = section_text('1. Executive Summary')
        reqs_txt = section_text('2. Latest Requirements')
        dec_txt = section_text('3. Key Decisions')
        q_txt = section_text('4. Open Questions')
        a_txt = section_text('5. Action Items')

        def parse_bullets(block, kind_prefix):
            items = []
            for line in (block or '').splitlines():
                line = line.strip()
                if not line.startswith('- '):
                    continue
                body = line[2:].strip()
                m = re.match(r'^\[([A-Z]\d+)\]\s*(.*)$', body)
                if m:
                    iid = m.group(1)
                    rest = m.group(2).strip()
                else:
                    iid = None
                    rest = body
                items.append({'id': iid or f'{kind_prefix}{len(items)+1}', 'text': rest})
            return items

        parsed = {
            'executive_summary': executive,
            'requirements': parse_bullets(reqs_txt, 'R'),
            'decisions': parse_bullets(dec_txt, 'D'),
            'open_questions': parse_bullets(q_txt, 'Q'),
            'action_items': parse_bullets(a_txt, 'A'),
        }
        return parsed

