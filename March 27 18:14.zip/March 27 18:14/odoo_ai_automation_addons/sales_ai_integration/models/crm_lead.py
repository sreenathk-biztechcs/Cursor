import base64
import html
import json
import logging
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List

import psycopg2.errors
import requests
from dateutil.relativedelta import relativedelta

from odoo import SUPERUSER_ID, api, fields, models, _, tools
from odoo.exceptions import UserError

from . import prompts

_logger = logging.getLogger("sales_ai")  # unified logger prefix


def _clean_internal_mom_text(text: str) -> str:
    """Normalize Claude internal MOM text so chatter stays readable.

    - Strip markdown headings (##, ###), bullets, blockquotes.
    - Drop markdown tables and horizontal rules.
    - Remove loud meta flags like RED FLAG / DATA QUALITY FLAG lines.
    """
    if not text:
        return ""

    cleaned_lines: List[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            cleaned_lines.append("")
            continue

        # Drop pure markdown table separators / horizontal rules
        if re.match(r"^\|[-\s|]+\|?$", line):
            continue
        if re.match(r"^-{3,}$", line):
            continue

        # Drop very meta commentary lines
        lower = line.lower()
        if "red flag" in lower or "data quality flag" in lower:
            continue

        # Strip common markdown prefixes
        line = re.sub(r"^#{1,6}\s*", "", line)  # headings
        line = re.sub(r"^>\s*", "", line)  # blockquote
        line = re.sub(r"^[-*+]\s+", "", line)  # bullet
        line = re.sub(r"^\d+\.\s+", "", line)  # numbered list marker

        cleaned_lines.append(line)

    # Collapse excessive blank lines
    result_lines: List[str] = []
    blank_streak = 0
    for l in cleaned_lines:
        if not l:
            blank_streak += 1
            if blank_streak > 1:
                continue
        else:
            blank_streak = 0
        result_lines.append(l)

    return "\n".join(result_lines).strip()


def _format_internal_mom_html(text: str) -> str:
    """Render internal MOM plain text into readable chatter HTML."""
    if not text:
        return ""

    lines = [(ln or "").strip() for ln in text.splitlines()]
    sections: List[tuple[str | None, List[str]]] = []
    current_title: str | None = None
    current_items: List[str] = []

    def _flush():
        nonlocal current_title, current_items
        if current_title is not None or current_items:
            sections.append((current_title, current_items))
        current_title = None
        current_items = []

    for line in lines:
        if not line:
            continue

        # Treat single-line labels as section headers.
        is_header = (
            line.endswith(":")
            and len(line) <= 80
            and not re.match(r"^\d+\.\s+", line)
        )
        if is_header:
            _flush()
            current_title = line[:-1].strip()
            continue

        # Normalize list markers but preserve content.
        item = re.sub(r"^[-*+]\s+", "", line)
        item = re.sub(r"^\d+\.\s+", "", item)
        current_items.append(item)

    _flush()

    if not sections:
        return tools.html_sanitize(tools.plaintext2html(text))

    parts: List[str] = ["<div class='o_sales_ai_mom'>"]
    for title, items in sections:
        if title:
            parts.append("<h4>%s</h4>" % tools.html_escape(title))
        if not items:
            continue
        parts.append("<ul>%s</ul>" % "".join("<li>%s</li>" % tools.html_escape(i) for i in items))
    parts.append("</div>")
    return tools.html_sanitize("\n".join(parts))


def _normalize_chatter_body(body: str) -> str:
    """
    Normalize chatter body so users don't see raw/escaped HTML tags.
    - If body contains escaped tags (&lt;p&gt;...), decode and sanitize.
    - If decoded body is HTML, keep only rendered text formatting.
    """
    if not body:
        return body

    source = body
    if "&lt;" in source and "&gt;" in source:
        source = html.unescape(source)

    if re.search(r"</?[a-zA-Z][^>]*>", source):
        plain = tools.html2plaintext(source or "").strip()
        if not plain:
            return ""
        return tools.html_sanitize(tools.plaintext2html(plain))

    return body


def _render_professional_chatter_html(body: str) -> str:
    """
    Convert raw/plain chatter text into a professional structure:
    - section headers (lines ending with ':')
    - bullet/numbered lists
    - compact paragraphs
    """
    if not body:
        return body

    plain = tools.html2plaintext(body).replace("\r", "").strip()
    if not plain:
        return ""

    # If AI returned one dense paragraph, split before known section labels.
    section_labels = (
        "Meeting Summary",
        "Attendees",
        "Client Pain Points",
        "Solution / Approach",
        "Client Questions & Our Responses",
        "Next Steps",
        "Action Items",
        "Key Signals",
        "Key Requirements Identified",
        "Prior Discussions Summary",
        "Open Questions",
        "Risk Flags",
        "Recommended Presale Approach",
        "Timeline",
        "Key Decisions",
        "Buying Signals",
    )
    for label in section_labels:
        plain = re.sub(rf"\s+({re.escape(label)}\s*:)", r"\n\1", plain, flags=re.IGNORECASE)
    plain = re.sub(r"\s+([A-Z][A-Z /&]{4,}\s*:)", r"\n\1", plain)
    plain = re.sub(r"\n{3,}", "\n\n", plain).strip()

    lines = [ln.strip() for ln in plain.splitlines()]
    parts: List[str] = [
        '<div style="font-family:Inter,Segoe UI,Arial,sans-serif;font-size:13px;line-height:1.5;">'
    ]
    in_list = False
    numbered = False

    def _close_list():
        nonlocal in_list, numbered
        if in_list:
            parts.append("</ol>" if numbered else "</ul>")
            in_list = False
            numbered = False

    for line in lines:
        if not line:
            _close_list()
            continue

        # Header style line
        if line.endswith(":") and len(line) <= 120 and not re.match(r"^\d+\.\s+", line):
            _close_list()
            parts.append("<h4 style='margin:12px 0 6px;'>%s</h4>" % tools.html_escape(line[:-1]))
            continue

        # Numbered list item
        if re.match(r"^\d+\.\s+", line):
            item = re.sub(r"^\d+\.\s+", "", line).strip()
            if not in_list or not numbered:
                _close_list()
                parts.append("<ol style='margin:0 0 8px 18px;padding:0;'>")
                in_list = True
                numbered = True
            parts.append("<li>%s</li>" % tools.html_escape(item))
            continue

        # Bullet list item
        if re.match(r"^[-*+]\s+", line):
            item = re.sub(r"^[-*+]\s+", "", line).strip()
            if not in_list or numbered:
                _close_list()
                parts.append("<ul style='margin:0 0 8px 16px;padding:0;'>")
                in_list = True
                numbered = False
            parts.append("<li>%s</li>" % tools.html_escape(item))
            continue

        # Paragraph
        _close_list()
        parts.append("<p style='margin:0 0 8px;'>%s</p>" % tools.html_escape(line))

    _close_list()
    parts.append("</div>")
    return tools.html_sanitize("\n".join(parts))


def _extract_latest_reply_text(body: str) -> str:
    """Extract only the latest human reply from an email body."""
    if not body:
        return ""

    plain = tools.html2plaintext(body).replace("\r", "")
    if not plain:
        return ""

    lines = [ln.rstrip() for ln in plain.splitlines()]
    kept: List[str] = []
    break_markers = (
        "on ",
        "from:",
        "subject:",
        "sent:",
        "to:",
        "internal communication:",
        "dear administrator",
        "odoobot has just assigned you the following activity",
    )

    for raw in lines:
        line = raw.strip()
        if not line:
            kept.append("")
            continue
        lower = line.lower()

        # Stop at quoted history or notification header.
        if lower.startswith(">") or lower.startswith("-----original message-----"):
            break
        if any(lower.startswith(m) for m in break_markers):
            break

        # Skip common signature/noise lines.
        if lower in ("--", "regards,", "best,", "thanks,", "system"):
            continue

        # Drop invisible character noise (zero-width etc.).
        compact = re.sub(r"[\s\u200b\u200c\u200d\ufeff]+", "", line)
        if not compact:
            continue
        kept.append(line)

    cleaned = "\n".join(kept).strip()
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned


def _bg_full_pipeline_worker(dbname, uid, lead_ids):
    """Background thread: classify + enrich + score + auto-ack for new leads.

    Runs entirely outside the HTTP request so incoming mail, web forms,
    and UI create all return instantly. Each lead gets its own cursor.
    """
    try:
        from odoo.orm.registry import Registry
        registry = Registry(dbname)
    except Exception:
        _logger.error("sales_ai: [BG-PIPELINE] Cannot obtain registry for db=%s", dbname, exc_info=True)
        return

    for lead_id in lead_ids:
        try:
            with registry.cursor() as cr:
                env = api.Environment(cr, uid, {})
                lead = env["crm.lead"].browse(lead_id)
                if not lead.exists():
                    continue

                settings = env["ir.config_parameter"].sudo()
                marketing_user_id = int(
                    settings.get_param("sales_ai.marketing_user_id", default="0") or 0
                )

                # STEP 1 — Junk filter (Haiku)
                _logger.info("sales_ai: [STEP 1/3] Junk filter — lead_id=%s", lead.id)
                t0 = time.time()
                classify_ok = False
                for attempt in range(1, 4):
                    try:
                        lead._classify_lead_quality(has_apollo_data=False)
                        classify_ok = True
                        break
                    except psycopg2.errors.SerializationFailure:
                        cr.rollback()
                        lead = env["crm.lead"].browse(lead_id)
                        _logger.warning(
                            "sales_ai: [STEP 1/3] SerializationFailure lead_id=%s (attempt %s/3). Retrying.",
                            lead_id, attempt,
                        )
                        time.sleep(0.2 * attempt)
                    except Exception:
                        break

                if not classify_ok:
                    cr.rollback()
                    lead = env["crm.lead"].browse(lead_id)
                    _logger.error(
                        "sales_ai: [STEP 1/3] FAIL — junk filter error lead_id=%s (%.2fs). "
                        "Defaulting to genuine so pipeline continues.",
                        lead.id, time.time() - t0, exc_info=True,
                    )
                    lead.write({
                        "x_classification": "genuine",
                        "x_lead_quality": "genuine",
                        "x_classification_reason": "Claude API failed — defaulted to genuine",
                    })

                classification = lead.x_classification or "genuine"
                _logger.info(
                    "sales_ai: [STEP 1/3] DONE — lead_id=%s classification=%s conf=%.0f%% (%.2fs)",
                    lead.id, classification,
                    lead.x_classification_conf or 0.0, time.time() - t0,
                )

                # Route junk/marketing/job_seeker to Marketing User (NEVER delete)
                if classification in ("junk", "marketing", "job_seeker"):
                    if marketing_user_id:
                        lead.user_id = env["res.users"].browse(marketing_user_id)
                        _logger.info(
                            "sales_ai: [STEP 2/3] %s — lead_id=%s routed to Marketing User (uid=%s)",
                            classification.upper(), lead.id, marketing_user_id,
                        )
                    else:
                        _logger.warning(
                            "sales_ai: [STEP 2/3] %s — lead_id=%s but no Marketing User configured! "
                            "Set it in Settings → Sales AI → Marketing User.",
                            classification.upper(), lead.id,
                        )
                    lead.message_post(
                        body="Classified as <b>%s</b> by AI (%.1f%% confidence). "
                             "Routed to Marketing user. Automation stopped."
                             % (classification, lead.x_classification_conf or 0.0),
                        subtype_xmlid="mail.mt_note",
                    )
                    continue

                # STEP 2 — Genuine: trigger Apollo enrichment via n8n
                _logger.info(
                    "sales_ai: [STEP 2/3] GENUINE — lead_id=%s triggering Apollo enrichment via n8n",
                    lead.id,
                )
                intake_ok = False
                for attempt in range(1, 4):
                    try:
                        lead.action_trigger_lead_intake()
                        intake_ok = True
                        break
                    except psycopg2.errors.SerializationFailure:
                        cr.rollback()
                        lead = env["crm.lead"].browse(lead_id)
                        _logger.warning(
                            "sales_ai: [STEP 2/3] SerializationFailure lead_id=%s (attempt %s/3). Retrying intake.",
                            lead_id, attempt,
                        )
                        time.sleep(0.2 * attempt)
                    except psycopg2.errors.InFailedSqlTransaction:
                        cr.rollback()
                        lead = env["crm.lead"].browse(lead_id)
                        _logger.warning(
                            "sales_ai: [STEP 2/3] InFailedSqlTransaction lead_id=%s (attempt %s/3). Retrying intake.",
                            lead_id, attempt,
                        )
                        time.sleep(0.2 * attempt)
                if not intake_ok:
                    raise UserError(_("Failed to trigger enrichment due to concurrent updates. Please retry."))
                _logger.info(
                    "sales_ai: [STEP 2/3] DONE — lead_id=%s n8n intake triggered; "
                    "awaiting /api/sales_ai/lead_intake_complete callback",
                    lead.id,
                )
        except Exception:
            _logger.error(
                "sales_ai: [BG-PIPELINE] FAIL for lead_id=%s",
                lead_id, exc_info=True,
            )


def _bg_client_mom_worker(dbname, uid, lead_id, kwargs):
    """Background thread: generate client MOM from transcript.

    Runs in its own DB cursor so the calling HTTP request can return
    immediately without waiting for Claude + chatter + activity creation.
    """
    try:
        from odoo.orm.registry import Registry
        registry = Registry(dbname)
    except Exception:
        _logger.error("sales_ai: [BG-MOM] Cannot obtain registry for db=%s", dbname, exc_info=True)
        return

    try:
        with registry.cursor() as cr:
            env = api.Environment(cr, uid, {})
            lead = env["crm.lead"].browse(lead_id)
            if not lead.exists():
                _logger.warning("sales_ai: [BG-MOM] lead %s not found", lead_id)
                return
            lead.action_generate_client_mom(**kwargs)
            # Only after transcript -> MOM is complete, clear pending AI follow-up
            # activities for this lead.
            lead._delete_next_planned_activities()
            _logger.info("sales_ai: [BG-MOM] completed for lead %s", lead_id)
    except Exception:
        _logger.error(
            "sales_ai: [BG-MOM] FAILED for lead %s",
            lead_id, exc_info=True,
        )


class CrmLead(models.Model):
    _name = "crm.lead"
    _inherit = ["crm.lead", "sales.ai.background.mixin"]

    # -------------------------------------------------------------------------
    # Custom fields – Lead qualification & enrichment
    # -------------------------------------------------------------------------

    # High-level classification (backwards compatible with earlier versions)
    x_lead_quality = fields.Selection(
        [
            ("genuine", "Genuine"),
            ("marketing", "Marketing"),
            ("junk", "Junk"),
        ],
        string="Lead Quality (Legacy)",
        tracking=True,
    )

    # Detailed classification as per Inbound_Sales_Mindmap_Workflow.md
    x_classification = fields.Selection(
        [
            ("genuine", "Genuine"),
            ("marketing", "Marketing"),
            ("junk", "Junk/Spam"),
            ("job_seeker", "Job Seeker"),
        ],
        string="Inbound Classification",
        tracking=True,
    )
    x_classification_conf = fields.Float(
        "Classification Confidence (0-100)",
        help="AI confidence score for lead classification.",
        tracking=True,
    )
    x_classification_reason = fields.Char(
        "Classification Reason", help="Short explanation from the AI classifier."
    )
    x_lead_score = fields.Integer("Lead Score (0-100)", tracking=True)
    x_lead_score_band = fields.Selection(
        [
            ("hot", "Hot"),
            ("warm", "Warm"),
            ("neutral", "Neutral"),
            ("cold", "Cold"),
        ],
        string="Lead Score Band",
        tracking=True,
    )
    x_lead_score_breakdown = fields.Text(
        "Lead Score Breakdown (JSON)",
        help="JSON breakdown of how the lead score was calculated.",
    )
    x_lead_score_rationale = fields.Text(
        "Lead Score Rationale",
        help="Short narrative explaining why the score was assigned.",
    )
    x_followup_stage = fields.Integer("Follow-up Stage", default=0, tracking=True)
    x_last_reply_date = fields.Datetime("Last Reply Date", tracking=True)
    x_reply_intent = fields.Selection(
        [
            ("interested", "Interested"),
            ("meeting_booked", "Meeting Booked"),
            ("not_interested", "Not Interested"),
            ("ooo", "Out of Office"),
            ("wrong_person", "Wrong Person"),
            ("referral", "Referral"),
            ("generic_positive", "Generic Positive"),
            ("unsubscribe", "Unsubscribe"),
            ("question", "Question"),
            ("negotiating", "Negotiating"),
        ],
        string="Reply Intent",
        tracking=True,
    )
    x_ooo_return_date = fields.Date("OOO Return Date")
    x_unsubscribed = fields.Boolean("Unsubscribed from Outreach", default=False)

    # Enrichment fields (populated from Apollo via n8n)
    x_is_it_company = fields.Boolean("Is IT Company")
    x_employee_count = fields.Integer("Employee Count")
    x_annual_revenue = fields.Monetary(
        "Annual Revenue", currency_field="company_currency"
    )
    x_tech_stack = fields.Text("Technology Stack (JSON Array)")
    x_is_decision_maker = fields.Boolean("Is Decision Maker")
    x_seniority = fields.Selection(
        [
            ("c_level", "C-level"),
            ("vp", "VP"),
            ("director", "Director"),
            ("manager", "Manager"),
            ("other", "Other"),
        ],
        string="Seniority",
    )
    x_contact_score = fields.Integer("Contact Score (0-100)")
    x_intent_score = fields.Integer("Intent Score (0-100)")
    x_linkedin_url = fields.Char("LinkedIn URL")
    x_apollo_data_raw = fields.Text("Apollo Raw Data", help="Raw JSON from Apollo.io")
    x_apollo_person_id = fields.Char("Apollo Person ID")
    x_attachment_extracts_json = fields.Text(
        "Attachment Extracts (JSON)",
        help="Cached text extracted from attachments (PDF, images, DOCX) as JSON.",
    )
    x_mom_history = fields.Text(
        "MOM History (JSON)",
        help="Optional JSON array of structured MOM entries.",
    )
    x_apollo_match = fields.Boolean("Apollo Match Found", help="True if Apollo People API returned a match")
    x_enrichment_done = fields.Boolean("Enrichment Completed")
    x_enrichment_status = fields.Selection(
        [
            ("none", "Not Started"),
            ("pending_n8n", "Awaiting n8n / Apollo"),
            ("enriching", "Enriching"),
            ("done", "Completed"),
            ("failed", "Failed"),
        ],
        string="Enrichment Status",
        default="none",
        tracking=True,
    )
    x_enrichment_requested_at = fields.Datetime(
        "Enrichment Requested At",
        help="When the n8n enrichment call was made — used for timeout detection.",
    )
    x_scoring_done = fields.Boolean("Scoring Completed")
    x_stale_monitor_start = fields.Date("Stale Monitor Start")

    # Extended structured enrichment fields (from EnrichmentStructurerAgent)
    x_industry = fields.Char("Industry")
    x_subindustry = fields.Char("Sub-industry")
    x_employee_count_range = fields.Char("Employee Count Range")
    x_revenue_range = fields.Char("Annual Revenue Range")
    x_hq_country_id = fields.Many2one("res.country", string="HQ Country")
    x_hq_city = fields.Char("HQ City")
    x_founded_year = fields.Integer("Founded Year")
    x_company_funding_stage = fields.Char("Funding Stage")
    x_company_linkedin_url = fields.Char("Company LinkedIn URL")
    x_website = fields.Char("Website")

    x_contact_job_title = fields.Char("Contact Job Title")
    x_contact_seniority_structured = fields.Selection(
        [
            ("c_level", "C-Level"),
            ("vp", "VP"),
            ("director", "Director"),
            ("manager", "Manager"),
            ("ic", "Individual Contributor"),
            ("unknown", "Unknown"),
        ],
        string="Contact Seniority (Structured)",
    )
    x_direct_email = fields.Char("Direct Email")
    x_direct_phone = fields.Char("Direct Phone")
    x_contact_linkedin_url = fields.Char("Contact LinkedIn URL")
    x_contact_decision_authority = fields.Selection(
        [("yes", "Yes"), ("no", "No"), ("unknown", "Unknown")],
        string="Decision-making Authority",
    )

    x_likely_pain_point = fields.Text("Likely Pain Point")
    x_similar_companies_won = fields.Text("Similar Companies We've Won")
    x_icp_match_signals = fields.Text("ICP Match Signals (JSON/List)")
    x_icp_disqualify_signals = fields.Text("ICP Disqualifying Signals (JSON/List)")
    x_apollo_conversation_summary = fields.Text("Apollo Conversation Summary")
    x_enrichment_conf = fields.Float("Enrichment Confidence (0-100)")
    x_enrichment_notes = fields.Text("Enrichment Notes")
    x_enrichment_source = fields.Char("Enrichment Source")
    x_enrichment_date = fields.Datetime("Enrichment Date")
    x_lead_language = fields.Char("Lead Language")
    x_inquiry_category = fields.Selection(
        [
            ("new_implementation", "New Implementation"),
            ("upgrade", "Upgrade"),
            ("support", "Support"),
            ("consulting", "Consulting"),
            ("other", "Other"),
        ],
        string="Inquiry Category",
    )
    x_inquiry_urgency = fields.Selection(
        [("high", "High"), ("medium", "Medium"), ("low", "Low")],
        string="Inquiry Urgency",
    )
    x_follow_up_angle = fields.Char("Follow-up Angle")

    # -------------------------------------------------------------------------
    # Presale fields – everything managed on the lead (no project.task needed)
    # -------------------------------------------------------------------------

    x_presale_status = fields.Selection(
        [
            ("none", "No Presale"),
            ("open", "Presale Open"),
            ("ready_for_wbs", "Ready for WBS"),
            ("wbs_done", "WBS Done"),
            ("ready_for_proposal", "Ready for Proposal"),
            ("proposal_generated", "Proposal Generated"),
            ("proposal_sent", "Proposal Sent"),
        ],
        default="none",
        string="Presale Status",
        tracking=True,
    )
    x_wbs_sheet_url = fields.Char("WBS Sheet URL")
    x_proposal_drive_url = fields.Char("Proposal Drive URL")
    x_last_agenda_date = fields.Date("Last Presale Agenda Date")
    x_retro_logged = fields.Boolean("Retro Logged")

    # Presale reference number (auto-assigned when presale opens, e.g. PST-42)
    x_presale_ref = fields.Char(
        "Presale Reference",
        help="Auto-generated presale reference (e.g. PST-42). Set when presale is opened.",
        readonly=True,
    )
    x_wbs_json = fields.Text(
        "WBS JSON",
        help="Structured WBS JSON generated by WBSGeneratorAgent (Sonnet).",
    )
    x_ticket_gist = fields.Text(
        "Presale Gist",
        help="AI-generated summary of all lead context for the presale team (TicketGistAgent).",
    )
    x_presale_mom_history = fields.Text(
        "Presale MOM History",
        help="JSON list of presale MOM texts from each presale meeting.",
    )
    transcript_ids = fields.One2many(
        "sales.ai.meeting.transcript",
        "lead_id",
        string="Meeting Transcripts",
    )

    # -------------------------------------------------------------------------
    # Attachment text cache – extract once, reuse for all AI calls
    # -------------------------------------------------------------------------

    x_attachment_summaries = fields.Text(
        "Attachment Text Cache",
        help="JSON dict mapping attachment_id -> extracted text / description. "
        "Auto-populated when attachments are added. Claude reads this cache "
        "instead of re-processing files each time.",
    )

    def _get_company_currency(self):
        return self.env.company.currency_id

    company_currency = fields.Many2one(
        "res.currency", string="Company Currency", default=_get_company_currency
    )

    # =========================================================================
    # UTILITIES
    # =========================================================================

    def _business_day_offset(self, base_date: datetime, days: int) -> datetime:
        """Move forward `days` business days from base_date.

        Skips weekends and public holidays defined in
        sales_ai.public_holidays_json (list of YYYY-MM-DD strings).
        """
        ICP = self.env["ir.config_parameter"].sudo()
        holidays_raw = ICP.get_param("sales_ai.public_holidays_json", default="[]")
        try:
            holiday_dates = {
                fields.Date.from_string(d)
                for d in json.loads(holidays_raw or "[]")
                if d
            }
        except Exception:
            holiday_dates = set()

        date = base_date
        added = 0
        while added < days:
            date += relativedelta(days=1)
            if date.weekday() < 5 and date.date() not in holiday_dates:
                added += 1
        return date

    def _claude(self):
        return self.env["claude.service"]

    def _n8n(self):
        return self.env["sales.ai.n8n"]

    def _sales_ai_send_email_notification(
        self,
        subject,
        body_html,
        recipients=None,
        include_team_lead=True,
        include_admin_fallback=True,
    ):
        """Send internal notification email from Odoo (replacement for Teams webhooks)."""
        self.ensure_one()
        recipients = recipients or []
        clean = []
        for e in recipients:
            if e and isinstance(e, str):
                em = e.strip()
                if em and em not in clean:
                    clean.append(em)
        if include_team_lead and self.team_id and self.team_id.user_id and self.team_id.user_id.email:
            em = self.team_id.user_id.email.strip()
            if em and em not in clean:
                clean.append(em)
        if include_admin_fallback and not clean:
            admins = self.env.ref("base.group_system").users.filtered("active")
            for u in admins:
                em = (u.email or "").strip()
                if em and em not in clean:
                    clean.append(em)
        if not clean:
            _logger.warning(
                "sales_ai: [EMAIL-NOTIFY] skipped lead %s - no recipients",
                self.id,
            )
            return False
        vals = {
            "subject": subject[:255],
            "email_to": ", ".join(clean),
            "body_html": tools.html_sanitize(body_html or "<p>No details.</p>"),
            "auto_delete": True,
        }
        # Queue email for mail cron instead of sending inline.
        # Inline send() can flush unrelated pending writes and trigger
        # serialization failures in long-running background pipelines.
        self.env["mail.mail"].sudo().create(vals)
        _logger.info(
            "sales_ai: [EMAIL-NOTIFY] queued lead=%s recipients=%s subject=%s",
            self.id,
            clean,
            subject,
        )
        return True

    def _n8n_safe_post(self, endpoint, payload, lead=None, context_label="n8n call"):
        """Post to n8n with full error handling: log + chatter warning + no crash.

        Returns the n8n response dict on success, or None on failure.
        On failure: logs the error, posts a warning note on the lead's chatter,
        and returns None so the caller can continue gracefully.
        """
        target = lead or self
        try:
            return self._n8n().post(endpoint, payload)
        except requests.exceptions.ConnectionError as exc:
            msg = _("n8n is unreachable (%s). Check if n8n is running and the webhook URL is correct.") % context_label
            _logger.error(
                "sales_ai: [N8N-FAIL] %s — endpoint=%s lead=%s error=%s",
                context_label, endpoint, target.id if hasattr(target, 'id') else '?',
                exc,
            )
            if hasattr(target, 'message_post'):
                target.message_post(
                    body="<b>⚠ %s</b><br/>%s<br/><small>%s</small>" % (
                        _("n8n Connection Error"), msg, str(exc)[:300],
                    ),
                    subtype_xmlid="mail.mt_note",
                )
            return None
        except requests.exceptions.Timeout as exc:
            msg = _("n8n did not respond in time (%s). The workflow may be overloaded or the endpoint is wrong.") % context_label
            _logger.error(
                "sales_ai: [N8N-FAIL] Timeout — %s endpoint=%s lead=%s",
                context_label, endpoint, target.id if hasattr(target, 'id') else '?',
            )
            if hasattr(target, 'message_post'):
                target.message_post(
                    body="<b>⚠ %s</b><br/>%s" % (_("n8n Timeout"), msg),
                    subtype_xmlid="mail.mt_note",
                )
            return None
        except requests.exceptions.HTTPError as exc:
            status = getattr(exc.response, 'status_code', '?') if hasattr(exc, 'response') else '?'
            body_preview = ""
            try:
                body_preview = exc.response.text[:500] if exc.response else ""
            except Exception:
                pass
            _logger.error(
                "sales_ai: [N8N-FAIL] HTTP %s — %s endpoint=%s lead=%s body=%s",
                status, context_label, endpoint,
                target.id if hasattr(target, 'id') else '?',
                body_preview,
            )
            if hasattr(target, 'message_post'):
                target.message_post(
                    body="<b>⚠ %s</b><br/>%s<br/><small>HTTP %s: %s</small>" % (
                        _("n8n Error"),
                        _("n8n returned an error for: %s") % context_label,
                        status,
                        body_preview[:200],
                    ),
                    subtype_xmlid="mail.mt_note",
                )
            return None
        except Exception as exc:
            _logger.error(
                "sales_ai: [N8N-FAIL] Unexpected — %s endpoint=%s lead=%s error=%s",
                context_label, endpoint,
                target.id if hasattr(target, 'id') else '?',
                exc, exc_info=True,
            )
            if hasattr(target, 'message_post'):
                target.message_post(
                    body="<b>⚠ %s</b><br/>%s<br/><small>%s</small>" % (
                        _("n8n Error"),
                        _("Unexpected error during: %s") % context_label,
                        str(exc)[:300],
                    ),
                    subtype_xmlid="mail.mt_note",
                )
            return None

    def _notify_pipeline_issue(self, title, detail, create_activity=True):
        """Surface pipeline failures in Odoo UI (chatter + optional activity)."""
        for lead in self:
            safe_lead = lead.with_user(SUPERUSER_ID).sudo()
            try:
                safe_lead.message_post(
                    body="<b>⚠ %s</b><br/>%s" % (title, detail),
                    subtype_xmlid="mail.mt_note",
                )
            except Exception:
                _logger.warning(
                    "sales_ai: Failed to post pipeline warning on lead %s",
                    lead.id,
                    exc_info=True,
                )
            if create_activity and safe_lead.user_id:
                todo_type = safe_lead.env.ref("mail.mail_activity_data_todo", raise_if_not_found=False)
                try:
                    safe_lead.env["mail.activity"].sudo().create({
                        "res_model_id": safe_lead.env.ref("crm.model_crm_lead").id,
                        "res_id": safe_lead.id,
                        "user_id": safe_lead.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": title[:120],
                        "note": detail[:2000],
                        "date_deadline": fields.Date.today(),
                    })
                except Exception:
                    _logger.warning(
                        "sales_ai: Failed to create pipeline issue activity on lead %s",
                        lead.id,
                        exc_info=True,
                    )

    # =========================================================================
    # PIPELINE DIAGNOSTICS
    # =========================================================================

    @api.model
    def action_test_pipeline(self):
        """
        Self-test for the AI pipeline. Call from Odoo shell:

            env['crm.lead'].action_test_pipeline()

        Checks Claude API key, Claude connectivity (Haiku ping), and n8n URL config.
        Logs results with [DIAG] prefix — grep 'sales_ai.*DIAG' in odoo.log.
        Returns dict with ok/failed counts.
        """
        _logger.info("sales_ai: [DIAG] ========== PIPELINE SELF-TEST START ==========")
        ok_count = 0
        fail_count = 0

        # 1. Check Claude API key
        api_key = self.env["ir.config_parameter"].sudo().get_param("sales_ai.claude_api_key", "")
        if api_key:
            _logger.info("sales_ai: [DIAG] OK Claude API key is SET (first 8 chars: %s...)", api_key[:8])
            ok_count += 1
        else:
            _logger.error(
                "sales_ai: [DIAG] FAIL Claude API key is MISSING. "
                "Set it: Settings -> Technical -> System Parameters -> sales_ai.claude_api_key"
            )
            fail_count += 1

        # 2. Test Claude Haiku connectivity
        if api_key:
            try:
                ping_result = self._claude().call(
                    tier="haiku",
                    system_prompt='Reply with exactly: {"ok": true}',
                    user_message="ping",
                    max_tokens=20,
                    expect_json=True,
                )
                if isinstance(ping_result, dict) and ping_result.get("ok"):
                    _logger.info("sales_ai: [DIAG] OK Claude Haiku ping OK — response: %s", ping_result)
                    ok_count += 1
                else:
                    _logger.error("sales_ai: [DIAG] FAIL Claude Haiku ping — unexpected response: %s", ping_result)
                    fail_count += 1
            except Exception as exc:
                _logger.error("sales_ai: [DIAG] FAIL Claude Haiku ping EXCEPTION: %s", exc, exc_info=True)
                fail_count += 1
        else:
            _logger.warning("sales_ai: [DIAG] SKIP Claude connectivity test (no API key)")

        # 3. Check n8n URL
        n8n_url = self.env["ir.config_parameter"].sudo().get_param("sales_ai.n8n_webhook_base_url", "")
        if n8n_url:
            _logger.info("sales_ai: [DIAG] OK n8n webhook URL is SET: %s", n8n_url)
            ok_count += 1
        else:
            _logger.error(
                "sales_ai: [DIAG] FAIL n8n webhook URL is MISSING. "
                "Set it: Settings -> Technical -> System Parameters -> sales_ai.n8n_webhook_base_url"
            )
            fail_count += 1

        # 4. Check marketing user
        mkt_uid = self.env["ir.config_parameter"].sudo().get_param("sales_ai.marketing_user_id", "")
        if mkt_uid and int(mkt_uid or 0):
            _logger.info("sales_ai: [DIAG] OK Marketing user ID is SET: %s", mkt_uid)
            ok_count += 1
        else:
            _logger.warning(
                "sales_ai: [DIAG] WARN Marketing user ID is MISSING — "
                "non-genuine leads won't be re-assigned. "
                "Set: Settings -> Technical -> System Parameters -> sales_ai.marketing_user_id"
            )
            fail_count += 1

        # 5. Check junk_filter_system prompt exists
        from . import prompts as _prompts
        if _prompts.get_system_prompt(self.env, "junk_filter_system"):
            _logger.info("sales_ai: [DIAG] OK junk_filter_system prompt is defined")
            ok_count += 1
        else:
            _logger.error("sales_ai: [DIAG] FAIL junk_filter_system prompt is MISSING in prompts.py")
            fail_count += 1

        _logger.info(
            "sales_ai: [DIAG] ========== SELF-TEST COMPLETE: %d OK, %d FAILED ==========",
            ok_count, fail_count,
        )
        return {"ok": ok_count, "failed": fail_count}

    # =========================================================================
    # ATTACHMENT HANDLING
    # =========================================================================

    def action_extract_attachment_texts(self):
        """
        Extract text from all unprocessed attachments on this lead.

        Strategy:
        - PDF/DOC/TXT: extract raw text, truncate to 4000 chars per file
        - Images (JPG/PNG): send to Claude Vision for a one-time description
        - Cache results in x_attachment_summaries so we never re-process

        This method is called:
        - Manually via a "Sync Attachments" button on the lead form
        - Automatically before any AI call that needs attachment context
        """
        for lead in self:
            existing_cache = {}
            if lead.x_attachment_summaries:
                try:
                    existing_cache = json.loads(lead.x_attachment_summaries)
                except Exception:
                    existing_cache = {}

            attachments = self.env["ir.attachment"].sudo().search([
                ("res_model", "=", "crm.lead"),
                ("res_id", "=", lead.id),
            ])

            updated = False
            for att in attachments:
                att_key = str(att.id)
                if att_key in existing_cache:
                    continue  # already cached

                mimetype = (att.mimetype or "").lower()
                text = ""

                if "pdf" in mimetype:
                    text = self._extract_pdf_text(att)
                elif any(t in mimetype for t in ("text", "csv", "xml", "json", "html")):
                    try:
                        raw = base64.b64decode(att.datas or b"")
                        text = raw.decode("utf-8", errors="replace")[:4000]
                    except Exception:
                        text = "[Could not decode text file]"
                elif any(t in mimetype for t in ("image/png", "image/jpeg", "image/jpg", "image/gif", "image/webp")):
                    text = self._describe_image_attachment(att)
                elif any(t in mimetype for t in ("msword", "wordprocessing", "opendocument")):
                    # For DOC/DOCX: extract what we can via basic parsing
                    text = self._extract_doc_text(att)
                else:
                    text = f"[Attachment: {att.name}, type: {att.mimetype}, size: {att.file_size} bytes]"

                existing_cache[att_key] = {
                    "name": att.name,
                    "mimetype": att.mimetype,
                    "summary": (text or "")[:4000],
                }
                updated = True
                _logger.info(
                    "sales_ai: Extracted text from attachment %s (%s) on lead %s",
                    att.name, att.mimetype, lead.id,
                )

            if updated:
                lead.x_attachment_summaries = json.dumps(existing_cache, ensure_ascii=False)

    def _extract_pdf_text(self, attachment):
        """Extract text from a PDF attachment using PyPDF2 or pdfplumber."""
        try:
            import io
            raw = base64.b64decode(attachment.datas or b"")
            try:
                import pdfplumber
                with pdfplumber.open(io.BytesIO(raw)) as pdf:
                    pages_text = []
                    for page in pdf.pages[:20]:  # max 20 pages
                        pages_text.append(page.extract_text() or "")
                    return "\n".join(pages_text)[:4000]
            except ImportError:
                pass
            try:
                from PyPDF2 import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                pages_text = []
                for page in reader.pages[:20]:
                    pages_text.append(page.extract_text() or "")
                return "\n".join(pages_text)[:4000]
            except ImportError:
                return "[PDF detected but no PDF parser available (install pdfplumber or PyPDF2)]"
        except Exception as exc:
            _logger.warning("sales_ai: PDF extraction failed for %s: %s", attachment.name, exc)
            return "[PDF extraction failed]"

    def _extract_doc_text(self, attachment):
        """Extract text from DOC/DOCX using python-docx."""
        try:
            import io
            raw = base64.b64decode(attachment.datas or b"")
            try:
                from docx import Document
                doc = Document(io.BytesIO(raw))
                text = "\n".join(p.text for p in doc.paragraphs)
                return text[:4000]
            except ImportError:
                return "[DOCX detected but python-docx not installed]"
        except Exception as exc:
            _logger.warning("sales_ai: DOC extraction failed for %s: %s", attachment.name, exc)
            return "[DOC extraction failed]"

    def _describe_image_attachment(self, attachment):
        """Send image to Claude Vision for a one-time description."""
        try:
            raw_b64 = attachment.datas
            if not raw_b64:
                return "[Empty image]"
            # Use Claude's vision capability
            media_type = attachment.mimetype or "image/jpeg"
            resp = self._claude().call_vision(
                image_b64=raw_b64.decode() if isinstance(raw_b64, bytes) else raw_b64,
                media_type=media_type,
                prompt="Describe this image in the context of a B2B sales lead. "
                       "Focus on: company logos, product screenshots, diagrams, "
                       "business cards, or any business-relevant information. "
                       "Keep description under 300 words.",
                max_tokens=400,
            )
            return resp or "[Image — no description generated]"
        except Exception as exc:
            _logger.warning("sales_ai: Image description failed for %s: %s", attachment.name, exc)
            return f"[Image: {attachment.name}]"

    def _get_attachment_context(self) -> str:
        """Return cached attachment summaries as a text block for AI prompts."""
        self.ensure_one()
        if not self.x_attachment_summaries:
            return ""
        try:
            cache = json.loads(self.x_attachment_summaries)
        except Exception:
            return ""
        parts = []
        for _att_id, info in cache.items():
            parts.append(f"--- {info.get('name', 'Unknown')} ({info.get('mimetype', '')}) ---\n{info.get('summary', '')}")
        return "\n\n".join(parts)

    # =========================================================================
    # PHASE 1: UNIFIED LEAD INTAKE (replaces old junk filter + enrichment)
    # =========================================================================
    #
    # Flow:
    #   1. Lead created → automation sends lead data to n8n
    #   2. n8n calls Apollo People Enrichment API (email, name, domain)
    #   3. n8n calls Apollo Organization Enrichment API (domain)
    #   4. n8n calls back: /api/sales_ai/lead_intake_complete
    #   5. Odoo: enrich → classify (genuine/marketing/junk) → score → assign
    #
    # If Apollo has NO match → classify from email content only.

    @api.model_create_multi
    def create(self, vals_list):
        # Standard Odoo default: user_id = env.user when the key is omitted. JSON-RPC /
        # call_kw creates (e.g. Postman on crm.lead/create) therefore assign every lead
        # to Administrator. Clear implicit salesperson so round-robin can run.
        if isinstance(vals_list, dict):
            vals_list = [vals_list]
        vals_list = [dict(v) for v in vals_list]
        for vals in vals_list:
            if "user_id" in vals:
                continue
            if self._sales_ai_rr_should_clear_implicit_salesperson():
                vals["user_id"] = False

        leads = super().create(vals_list)

        if self._sales_ai_round_robin_enabled():
            unassigned = leads.filtered(lambda l: not l.user_id)
            if unassigned:
                unassigned._sales_ai_assign_round_robin_if_needed()

        lead_ids = []
        for lead in leads:
            _logger.info(
                "sales_ai: [PIPELINE START] lead_id=%s name=%r email=%s user_id=%s source=%s",
                lead.id, lead.name, lead.email_from or "(none)",
                lead.user_id.id if lead.user_id else None,
                lead.source_id.name if lead.source_id else "direct",
            )
            lead_ids.append(lead.id)

        if lead_ids:
            self._defer_full_pipeline(lead_ids)

        return leads

    def _defer_full_pipeline(self, lead_ids):
        """Defer the entire AI pipeline (classify + enrich + score + auto-ack) to background.

        This ensures create() returns instantly regardless of source:
        UI button, incoming email, website form, API, or import.
        """
        dbname = self.env.cr.dbname
        uid = self.env.uid

        @self.env.cr.postcommit.add
        def _start_bg():
            thread = threading.Thread(
                target=_bg_full_pipeline_worker,
                args=(dbname, uid, lead_ids),
                daemon=True,
                name="sales_ai_pipeline_%s" % lead_ids,
            )
            thread.start()

    def action_trigger_lead_intake(self):
        """Send lead data to n8n for Apollo enrichment.

        When called from the UI, show a toast notification for both success and
        failure instead of raising blocking errors.

        If context key ``sales_ai_force_full_intake`` is True, the caller is
        explicitly asking to resume the full intake pipeline (enrich → classify
        → score → auto-ack → follow-ups) even if some steps ran earlier.
        """
        self.ensure_one()
        force_full = bool(self.env.context.get("sales_ai_force_full_intake"))
        notifications = []
        for lead in self:
            email = lead.email_from or ""
            domain = email.split("@")[-1] if "@" in email else ""
            payload = {
                "lead_id": lead.id,
                "email": email,
                "name": lead.contact_name or lead.name or "",
                "company": lead.partner_id.name if lead.partner_id else "",
                "domain": domain,
                "phone": lead.phone or "",
                "description": (lead.description or "")[:2000],
                "source": lead.source_id.display_name if lead.source_id else "",
                "force_full_intake": force_full,
            }
            _logger.info(
                "sales_ai: [INTAKE] lead_id=%s sending to n8n — email=%s domain=%s",
                lead.id, email, domain,
            )

            # Mark status BEFORE the n8n call so it's visible even if request hangs.
            lead.write({
                "x_enrichment_status": "pending_n8n",
                "x_enrichment_requested_at": fields.Datetime.now(),
            })

            # Flush + commit so the row lock is released before the (potentially
            # long-running) HTTP call to n8n.  Without this, the n8n callback
            # arrives in a separate HTTP request/cursor and blocks on the same
            # lead row — leading to SerializationFailure after ~90 s.
            # This is safe because action_trigger_lead_intake is always called
            # from a background thread (_bg_full_pipeline_worker) that owns its
            # own cursor, or from a UI button where an intermediate commit is
            # acceptable (the status is already "pending_n8n").
            self.env.cr.commit()
            lead.invalidate_recordset()

            try:
                result = self._n8n().post("lead_intake", payload)
                # If n8n returned Apollo data synchronously, apply it immediately.
                apollo_result = isinstance(result, dict) and result.get("apollo_result") or None
                if apollo_result:
                    # n8n can callback asynchronously and also return Apollo data
                    # in the POST response. If callback already started/completed,
                    # running intake again here causes duplicate processing and
                    # concurrent updates on the same lead.
                    # Use raw SQL to bypass ORM cache and get the absolute latest
                    # committed state — the ORM invalidate_recordset + field read
                    # can miss a concurrent commit due to snapshot timing.
                    self.env.cr.execute(
                        "SELECT x_enrichment_status, x_enrichment_done "
                        "FROM crm_lead WHERE id = %s",
                        [lead.id],
                    )
                    row = self.env.cr.fetchone()
                    cb_status, cb_done = row if row else (None, False)
                    if not force_full and (
                        cb_done
                        or cb_status in ("enriching", "done")
                    ):
                        _logger.info(
                            "sales_ai: [INTAKE] Skipping synchronous apply for lead %s; "
                            "callback already progressed status=%s done=%s",
                            lead.id, cb_status, cb_done,
                        )
                        apollo_result = None
                    lead.invalidate_recordset()

                if apollo_result:
                    if isinstance(apollo_result, dict) and (
                        "person" in apollo_result or "organization" in apollo_result
                    ):
                        person = apollo_result.get("person") or {}
                        org = apollo_result.get("organization") or {}
                    else:
                        person = apollo_result
                        org = (
                            apollo_result.get("organization")
                            if isinstance(apollo_result, dict)
                            else {}
                        ) or {}
                    match = bool(person or org)
                    _logger.info(
                        "sales_ai: [INTAKE] Applying synchronous Apollo enrichment + scoring for lead %s (match=%s)",
                        lead.id,
                        match,
                    )
                    try:
                        lead.x_enrichment_status = "enriching"
                        lead.action_lead_intake_complete(
                            person, org, match, force_full_intake=force_full
                        )
                    except psycopg2.errors.SerializationFailure:
                        # The async callback already committed changes to this
                        # lead row — our UPDATE conflicts.  This is harmless:
                        # the callback already handled enrichment + scoring.
                        _logger.info(
                            "sales_ai: [INTAKE] SerializationFailure for lead %s "
                            "— callback already handled enrichment, skipping",
                            lead.id,
                        )
                        self.env.cr.rollback()
                        lead.invalidate_recordset()
                else:
                    _logger.info(
                        "sales_ai: [INTAKE] n8n returned no immediate Apollo data for lead_id=%s — "
                        "waiting for async callback at /odoo/api/sales_ai/lead_intake_complete",
                        lead.id,
                    )
                    lead._ai_run_in_background("_bg_finalize_pending_intake")
                    lead.message_post(
                        body=_(
                            "Apollo enrichment requested via n8n. "
                            "Waiting for callback with Apollo data... "
                            "(If this persists beyond 10 min, check n8n workflow and Odoo Base URL in Settings.)"
                        ),
                        subtype_xmlid="mail.mt_note",
                    )

                notifications.append(
                    {
                        "title": _("Enrichment sync triggered"),
                        "type": "success",
                        "message": _(
                            "Lead %(id)s has been sent to n8n for Apollo enrichment."
                        )
                        % {"id": lead.id},
                        "sticky": False,
                    }
                )
            except requests.exceptions.ReadTimeout:
                # n8n received our request but its HTTP response didn't arrive
                # before our 90 s timeout.  The async callback
                # (/api/sales_ai/lead_intake_complete) is very likely already
                # running or has already committed enrichment data on this
                # same lead.  Any write/message_post here would race with
                # that callback and cause a PostgreSQL SerializationFailure,
                # killing both transactions.  So we ONLY log — no DB writes.
                _logger.warning(
                    "sales_ai: [INTAKE] n8n read-timeout for lead_id=%s — "
                    "NOT writing to lead (callback likely active). "
                    "Status was already set to pending_n8n before the call.",
                    lead.id,
                )
                lead._ai_run_in_background("_bg_finalize_pending_intake")
                notifications.append(
                    {
                        "title": _("Enrichment still pending"),
                        "type": "warning",
                        "message": _(
                            "The n8n request for lead %(id)s timed out waiting for a response, "
                            "but the enrichment callback may already be processing in the background."
                        )
                        % {"id": lead.id},
                        "sticky": False,
                    }
                )
            except Exception as exc:
                _logger.error(
                    "sales_ai: [INTAKE] FAIL — n8n unreachable for lead_id=%s. "
                    "Verify n8n URL/secret in Settings → Sales AI → n8n Configuration.",
                    lead.id, exc_info=True,
                )
                lead.write({
                    "x_enrichment_status": "failed",
                })
                lead.message_post(
                    body=_(
                        "n8n enrichment call FAILED: %(error)s. "
                        "Check Settings → Sales AI → n8n Configuration."
                    )
                    % {"error": str(exc)[:300]},
                    subtype_xmlid="mail.mt_note",
                )
                activity_type = self.env.ref(
                    "mail.mail_activity_data_todo", raise_if_not_found=False
                )
                self.env["mail.activity"].sudo().create(
                    {
                        "res_model_id": self.env.ref("crm.model_crm_lead").id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id or self.env.user.id,
                        "activity_type_id": activity_type.id if activity_type else False,
                        "summary": _("n8n enrichment failed — check connection"),
                        "note": _(
                            "n8n enrichment failed for this lead: %s. "
                            "Check the n8n connection and secrets in Sales AI settings."
                        ) % str(exc)[:200],
                        "date_deadline": fields.Date.today(),
                    }
                )
                _logger.info(
                    "sales_ai: [INTAKE] Created activity and chatter log for n8n failure on lead_id=%s",
                    lead.id,
                )
                notifications.append(
                    {
                        "title": _("Enrichment sync failed"),
                        "type": "warning",
                        "message": _(
                            "Could not reach the n8n enrichment service for lead %(id)s.\n"
                            "Details: %(details)s\n"
                            "Please verify the n8n Webhook URL, environment (Test/Live) "
                            "and secret in Settings → Sales AI → n8n Configuration."
                        )
                        % {"id": lead.id, "details": str(exc)},
                        "sticky": True,
                    }
                )

        # For multiple leads, show the last notification (most recent lead).
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": notifications[-1] if notifications else {
                "title": _("Enrichment"),
                "type": "info",
                "message": _("Nothing to sync."),
                "sticky": False,
            },
        }

    def _bg_finalize_pending_intake(self):
        """Fallback finalize for stuck pending_n8n leads."""
        self.ensure_one()
        time.sleep(120)
        self.invalidate_recordset()
        if self.x_enrichment_status != "pending_n8n" or self.x_scoring_done:
            return
        _logger.warning(
            "sales_ai: [INTAKE-FALLBACK] no callback yet for lead_id=%s; "
            "running local classify/score fallback",
            self.id,
        )
        try:
            self.action_lead_intake_complete({}, {}, False, force_full_intake=False)
        except Exception:
            _logger.error(
                "sales_ai: [INTAKE-FALLBACK] local finalize failed for lead_id=%s",
                self.id,
                exc_info=True,
            )

    def action_lead_intake_complete(
        self,
        apollo_person_data,
        apollo_org_data,
        apollo_match,
        force_full_intake: bool = False,
    ):
        """
        Unified callback from n8n after Apollo API lookup.

        :param apollo_person_data: dict from Apollo People Enrichment API (or {})
        :param apollo_org_data: dict from Apollo Organization Enrichment API (or {})
        :param apollo_match: bool — True if Apollo found a match
        """
        # Run callback logic as superuser to avoid issues with public/None users
        # hitting the endpoint (auth="none" + header-based auth).
        self = self.with_user(SUPERUSER_ID).sudo()
        self.ensure_one()

        if self.x_enrichment_done and not force_full_intake:
            _logger.info(
                "sales_ai: [INTAKE-CB] SKIP — lead_id=%s already enriched, ignoring duplicate callback",
                self.id,
            )
            return

        person_keys = len(apollo_person_data or {})
        org_keys = len(apollo_org_data or {})
        _logger.info(
            "sales_ai: [INTAKE-CB] lead_id=%s Apollo match=%s person_fields=%d org_fields=%d",
            self.id, apollo_match, person_keys, org_keys,
        )

        self.x_apollo_data_raw = json.dumps(
            {"person": apollo_person_data or {}, "organization": apollo_org_data or {}},
            ensure_ascii=False,
        )
        self.x_apollo_match = bool(apollo_match)
        self.x_enrichment_status = "enriching"

        had_failure = False

        # STEP 1/3 — Enrich from Apollo (re-run when forced to refresh enrichment)
        if apollo_match and (apollo_person_data or apollo_org_data):
            _logger.info("sales_ai: [INTAKE-CB] STEP 1/3 — Enriching from Apollo — lead_id=%s", self.id)
            t0 = time.time()
            try:
                self._enrich_from_apollo(apollo_person_data or {}, apollo_org_data or {})
                _logger.info(
                    "sales_ai: [INTAKE-CB] STEP 1/3 DONE — lead_id=%s enriched (%.2fs)",
                    self.id, time.time() - t0,
                )
            except Exception:
                had_failure = True
                _logger.error(
                    "sales_ai: [INTAKE-CB] STEP 1/3 FAIL — enrich error lead_id=%s",
                    self.id, exc_info=True,
                )
                self._notify_pipeline_issue(
                    _("Enrichment failed"),
                    _("Apollo enrichment parsing/writing failed. Check logs for details."),
                )
        else:
            _logger.info(
                "sales_ai: [INTAKE-CB] STEP 1/3 SKIP — no Apollo data for lead_id=%s",
                self.id,
            )

        # STEP 2/3 — Re-classify with Apollo context.
        # Wrap in a savepoint so a failure here doesn't poison the cursor
        # and block step 3 and the final status write.
        _logger.info(
            "sales_ai: [INTAKE-CB] STEP 2/3 — Re-classifying with Apollo context — lead_id=%s",
            self.id,
        )
        t0 = time.time()
        try:
            def _retry_classification():
                self.env.flush_all()
                with self.env.cr.savepoint():
                    self._classify_lead_quality(apollo_match)
                return True

            self._ai_retry_with_backoff(
                _retry_classification,
                max_retries=3,
                initial_delay=0.4,
                transient_only=True,
                on_retry=self._ai_reset_after_failure,
            )
            _logger.info(
                "sales_ai: [INTAKE-CB] STEP 2/3 DONE — lead_id=%s classification=%s conf=%.0f%% (%.2fs)",
                self.id, self.x_classification or "none",
                self.x_classification_conf or 0.0, time.time() - t0,
            )
        except Exception:
            had_failure = True
            _logger.error(
                "sales_ai: [INTAKE-CB] STEP 2/3 FAIL — classification error lead_id=%s (%.2fs)",
                self.id, time.time() - t0, exc_info=True,
            )
            self.env.cr.rollback()
            self.invalidate_recordset()

        # If step-2 hit a serialization rollback during retries, step-1 writes can be
        # rolled back in the same transaction. Re-apply enrichment deterministically
        # so step-3/auto-ack decisions use consistent state.
        if apollo_match and (apollo_person_data or apollo_org_data) and not self.x_enrichment_done:
            _logger.warning(
                "sales_ai: [INTAKE-CB] enrichment flag lost after retry rollback; re-applying for lead_id=%s",
                self.id,
            )
            try:
                self._enrich_from_apollo(apollo_person_data or {}, apollo_org_data or {})
            except Exception:
                had_failure = True
                _logger.error(
                    "sales_ai: [INTAKE-CB] enrichment re-apply failed lead_id=%s",
                    self.id,
                    exc_info=True,
                )

        # STEP 3/3 — Score if genuine
        classification = self.x_classification or "genuine"
        if classification == "genuine":
            _logger.info("sales_ai: [INTAKE-CB] STEP 3/3 — Scoring — lead_id=%s", self.id)
            t0 = time.time()
            try:
                def _retry_scoring():
                    self.env.flush_all()
                    with self.env.cr.savepoint():
                        # Intake callback orchestration must run scoring inline;
                        # async override here can race with auto-ack checks.
                        self.with_context(ai_force_sync=True).action_run_lead_scoring()
                        self.action_send_auto_ack()
                    return True

                self._ai_retry_with_backoff(
                    _retry_scoring,
                    max_retries=3,
                    initial_delay=0.4,
                    transient_only=True,
                    on_retry=self._ai_reset_after_failure,
                )

                _logger.info(
                    "sales_ai: [INTAKE-CB] STEP 3/3 DONE — lead_id=%s score=%s band=%s (%.2fs)",
                    self.id, self.x_lead_score, self.x_lead_score_band, time.time() - t0,
                )
            except Exception:
                had_failure = True
                _logger.error(
                    "sales_ai: [INTAKE-CB] STEP 3/3 FAIL — scoring error lead_id=%s",
                    self.id, exc_info=True,
                )
                self.env.cr.rollback()
                self.invalidate_recordset()
                try:
                    self._notify_pipeline_issue(
                        _("Scoring/acknowledgment failed"),
                        _(
                            "Lead scoring or auto-ack failed after enrichment. "
                            "Follow-up drafts may not be created."
                        ),
                    )
                except Exception:
                    _logger.warning(
                        "sales_ai: [INTAKE-CB] Could not notify pipeline issue for lead %s",
                        self.id, exc_info=True,
                    )
        else:
            _logger.info(
                "sales_ai: [INTAKE-CB] STEP 3/3 SKIP — lead_id=%s is %s, scoring skipped",
                self.id, classification,
            )

        self.x_enrichment_status = "failed" if had_failure else "done"
        _logger.info(
            "sales_ai: [INTAKE-CB] ALL STEPS COMPLETE — lead_id=%s enrichment_status=%s",
            self.id, self.x_enrichment_status,
        )

    def action_reenrich_from_raw(self):
        """
        Re-run enrichment from stored x_apollo_data_raw for leads that
        were previously processed by buggy code. Resets x_enrichment_done
        and re-runs the full enrichment pipeline.
        """
        for lead in self:
            raw = lead.x_apollo_data_raw
            if not raw:
                _logger.info(
                    "sales_ai: [RE-ENRICH] lead_id=%s — no raw Apollo data stored, skipping",
                    lead.id,
                )
                continue

            try:
                data = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                _logger.warning(
                    "sales_ai: [RE-ENRICH] lead_id=%s — invalid JSON in x_apollo_data_raw",
                    lead.id,
                )
                continue

            person = data.get("person") or {}
            org = data.get("organization") or data.get("account") or {}

            _logger.info(
                "sales_ai: [RE-ENRICH] lead_id=%s — re-enriching from stored raw data "
                "(person_keys=%d, org_keys=%d)",
                lead.id, len(person), len(org),
            )

            lead.x_enrichment_done = False
            lead._enrich_from_apollo(person, org)

    def _enrich_from_apollo(self, person: dict, org: dict):
        """Map Apollo API response fields to lead custom fields."""
        # n8n may sometimes pass Apollo blobs as JSON strings instead of dicts.
        if isinstance(person, str):
            try:
                person = json.loads(person) or {}
            except Exception:
                person = {}
        if isinstance(org, str):
            try:
                org = json.loads(org) or {}
            except Exception:
                org = {}

        # Apollo "person" payloads coming from n8n are often wrapped like:
        # {"person": {..., "contact": {...}, "organization": {...}}, "request_id": ...}
        ap_person = {}
        ap_contact = {}
        ap_person_org = {}
        if isinstance(person, dict) and person:
            if person.get("person"):
                ap_person = person.get("person") or {}
                ap_contact = ap_person.get("contact") or {}
                ap_person_org = ap_person.get("organization") or {}
            else:
                ap_person = person
                ap_contact = person.get("contact") or {}
                ap_person_org = person.get("organization") or {}

        # Unwrap org data if n8n sent it wrapped: {"organization": {...actual...}}
        if isinstance(org, dict) and org:
            if "organization" in org and isinstance(org["organization"], dict):
                org = org["organization"]
            elif "account" in org and isinstance(org["account"], dict):
                org = org["account"]

        _logger.info(
            "sales_ai: [ENRICH] lead_id=%s parsing Apollo — "
            "ap_person_keys=%s, org_keys=%s",
            self.id,
            list(ap_person.keys())[:10] if ap_person else "EMPTY",
            list(org.keys())[:10] if org else "EMPTY",
        )

        vals = {}

        # ------------------------------------------------------------------
        # Person + contact enrichment (from POST /api/v1/people/match)
        # ------------------------------------------------------------------
        if ap_person:
            # Core identity
            first_name = (ap_person.get("first_name") or "").strip()
            last_name = (ap_person.get("last_name") or "").strip()
            full_name = (ap_person.get("name") or "").strip()

            # Prefer an explicit full name, otherwise build from first/last.
            name = full_name or (" ".join(p for p in [first_name, last_name] if p).strip())
            # If a contact is already linked, do not mutate the lead contact_name
            # from enrichment data; keep user-selected contact identity stable.
            if name and not self.contact_name and not self.partner_id:
                vals["contact_name"] = name

            # Email: prefer verified contact email, then primary person email.
            email = None
            if ap_contact:
                email = ap_contact.get("email")
                if not email:
                    emails = ap_contact.get("contact_emails") or []
                    if emails and isinstance(emails[0], dict):
                        email = emails[0].get("email")
            if not email:
                email = ap_person.get("email")

            if email:
                # Direct email enrichment field
                if not self.x_direct_email:
                    vals["x_direct_email"] = email
                # Lead's primary email, if not already set
                if not self.email_from:
                    vals["email_from"] = email

            # Phone: take first number from Apollo contact phones.
            phone = None
            if ap_contact:
                phones = ap_contact.get("phone_numbers") or []
                if phones and isinstance(phones[0], dict):
                    phone = phones[0].get("raw_number") or phones[0].get("sanitized_number")
            if phone:
                if not self.x_direct_phone:
                    vals["x_direct_phone"] = phone
                if not self.phone:
                    vals["phone"] = phone

            # LinkedIn + seniority / decision maker signals
            linkedin = (
                ap_person.get("linkedin_url")
                or ap_contact.get("linkedin_url")
                or self.x_linkedin_url
            )
            if linkedin:
                vals["x_linkedin_url"] = linkedin

            seniority_raw = ap_person.get("seniority")
            vals["x_seniority"] = self._map_apollo_seniority(seniority_raw)
            vals["x_is_decision_maker"] = seniority_raw in (
                "c_suite", "vp", "director", "owner", "founder"
            )

            # Apollo person ID
            person_id = ap_person.get("id")
            if person_id:
                vals["x_apollo_person_id"] = str(person_id)

            # Job title — Apollo stores in "title" or "headline"
            title = (ap_person.get("title") or ap_person.get("headline") or "").strip()
            if title:
                vals["x_contact_job_title"] = title
                vals["function"] = title  # Odoo native job title field

            # Contact LinkedIn (person-level, separate from company)
            person_linkedin = ap_person.get("linkedin_url") or ""
            if person_linkedin:
                vals["x_contact_linkedin_url"] = person_linkedin

            # Apollo provides various score-like signals
            contact_accuracy = ap_contact.get("contact_accuracy") if ap_contact else None
            if contact_accuracy and isinstance(contact_accuracy, (int, float)):
                vals["x_contact_score"] = int(contact_accuracy)

            # Intent signals from person's organization engagement
            intent_strength = ap_person.get("intent_strength")
            if intent_strength and isinstance(intent_strength, (int, float)):
                vals["x_intent_score"] = int(intent_strength)

            p_org = ap_person_org or {}
            if isinstance(p_org, dict) and p_org.get("estimated_num_employees"):
                vals["x_employee_count"] = p_org["estimated_num_employees"]

        # Organization enrichment (from GET /api/v1/organizations/enrich or raw Apollo JSON)
        if isinstance(org, dict) and org:
            if org.get("estimated_num_employees"):
                vals["x_employee_count"] = org["estimated_num_employees"]
            if org.get("annual_revenue") or org.get("organization_revenue"):
                vals["x_annual_revenue"] = org.get("annual_revenue") or org.get(
                    "organization_revenue"
                )

            # Company profile
            if org.get("industry"):
                vals["x_industry"] = org["industry"]
            if org.get("subindustry") or org.get("sub_industry"):
                vals["x_subindustry"] = org.get("subindustry") or org.get("sub_industry")
            if org.get("founded_year"):
                vals["x_founded_year"] = org["founded_year"]
            if org.get("city"):
                vals["x_hq_city"] = org["city"]
            if org.get("website_url"):
                vals["x_website"] = org["website_url"]
            if org.get("linkedin_url"):
                vals["x_company_linkedin_url"] = org["linkedin_url"]

            # Company name — fill Odoo's native partner_name if empty
            org_name = (org.get("name") or org.get("organization_name") or "").strip()
            if org_name and not self.partner_name:
                vals["partner_name"] = org_name

            # HQ country from org
            country_code = org.get("country") or org.get("country_code") or ""
            if country_code and not self.x_hq_country_id:
                country = self.env["res.country"].sudo().search(
                    ["|", ("code", "=ilike", country_code), ("name", "=ilike", country_code)],
                    limit=1,
                )
                if country:
                    vals["x_hq_country_id"] = country.id

            # Funding stage from Apollo org
            funding = org.get("funding_stage") or org.get("latest_funding_stage") or ""
            if funding:
                vals["x_company_funding_stage"] = funding

            # Employee count / revenue ranges (simple bucketing for ICP display)
            emp = org.get("estimated_num_employees")
            if emp:
                if emp < 50:
                    vals["x_employee_count_range"] = "1-49"
                elif emp < 200:
                    vals["x_employee_count_range"] = "50-199"
                elif emp < 500:
                    vals["x_employee_count_range"] = "200-499"
                elif emp < 1000:
                    vals["x_employee_count_range"] = "500-999"
                else:
                    vals["x_employee_count_range"] = "1000+"

            rev = org.get("annual_revenue") or org.get("organization_revenue")
            if rev:
                try:
                    rev = float(rev)
                except Exception:
                    rev = None
                if rev is not None:
                    if rev < 5_000_000:
                        vals["x_revenue_range"] = "<5M"
                    elif rev < 10_000_000:
                        vals["x_revenue_range"] = "5M-10M"
                    elif rev < 50_000_000:
                        vals["x_revenue_range"] = "10M-50M"
                    elif rev < 100_000_000:
                        vals["x_revenue_range"] = "50M-100M"
                    else:
                        vals["x_revenue_range"] = "100M+"
            # Technology stack from Apollo — prefer structured current_technologies,
            # but fall back to technology_names list if needed.
            tech_names = []
            if org.get("current_technologies"):
                tech_names = [
                    t.get("name", "")
                    for t in (org["current_technologies"] or [])
                    if isinstance(t, dict) and t.get("name")
                ]
            elif org.get("technology_names"):
                tech_names = [name for name in (org.get("technology_names") or []) if name]
            if tech_names:
                vals["x_tech_stack"] = json.dumps(tech_names[:30])
            if org.get("industry"):
                # Check if it's an IT company
                industry = (org["industry"] or "").lower()
                it_keywords = ("software", "technology", "information", "saas", "cloud", "cyber", "data", "ai", "internet")
                vals["x_is_it_company"] = any(kw in industry for kw in it_keywords)

        if vals:
            self.write(vals)
            _logger.info(
                "sales_ai: [ENRICH] lead_id=%s Apollo direct — %d fields written: %s",
                self.id, len(vals), list(vals.keys()),
            )
        else:
            _logger.warning(
                "sales_ai: [ENRICH] lead_id=%s Apollo direct — 0 fields extracted from Apollo data!",
                self.id,
            )
        self.x_enrichment_done = True

        # ------------------------------------------------------------------
        # Create / update contact (res.partner) from Apollo person data
        # ------------------------------------------------------------------
        Partner = self.env["res.partner"].sudo()
        email = (person.get("email") or "").strip() if isinstance(person, dict) else ""

        # Preferred human-readable name:
        # 1) lead.contact_name
        # 2) Apollo name (first/last)
        # 3) email prefix, cleaned up
        name = (self.contact_name or "").strip()
        if not name and isinstance(person, dict):
            name = (
                person.get("name")
                or " ".join(
                    p for p in [person.get("first_name"), person.get("last_name")] if p
                )
                or ""
            )
        if not name and email:
            prefix = email.split("@")[0]
            for ch in [".", "_", "-"]:
                prefix = prefix.replace(ch, " ")
            name = prefix.title()

        phone = ""
        if isinstance(person, dict):
            # Apollo may have phone fields in different shapes; keep it simple
            phone = (person.get("phone") or "").strip()

        partner = False
        # 1) If user already selected a contact on lead, always keep and enrich it.
        if self.partner_id:
            partner = self.partner_id

        # 2) Otherwise, if we only have email, reuse any existing contact by email.
        if not partner and email:
            partner = Partner.search([("email", "=ilike", email)], limit=1)
            if partner and not self.partner_id:
                self.partner_id = partner
        if partner:
            # Update partner with latest Apollo / ICP details
            update_vals = {}
            if name and (not partner.name or partner.name == partner.email):
                update_vals["name"] = name
            if email and (not partner.email or partner.email.lower() == email.lower()):
                update_vals["email"] = email
            if phone and not partner.phone:
                update_vals["phone"] = phone

            # Contact enrichment
            if isinstance(person, dict):
                if person.get("linkedin_url"):
                    update_vals["x_contact_linkedin_url"] = person.get("linkedin_url")
                if self.x_contact_job_title:
                    update_vals["x_contact_job_title"] = self.x_contact_job_title
                if self.x_contact_seniority_structured:
                    update_vals[
                        "x_contact_seniority_structured"
                    ] = self.x_contact_seniority_structured
                if self.x_contact_decision_authority:
                    update_vals[
                        "x_contact_decision_authority"
                    ] = self.x_contact_decision_authority
                if self.x_inquiry_urgency:
                    update_vals["x_inquiry_urgency"] = self.x_inquiry_urgency

            # Company enrichment
            if isinstance(org, dict):
                if org.get("industry"):
                    update_vals["x_industry"] = org.get("industry")
                if org.get("subindustry"):
                    update_vals["x_sub_industry"] = org.get("subindustry")
                if org.get("estimated_num_employees"):
                    update_vals["x_employee_count"] = org.get("estimated_num_employees")
                if self.x_employee_count_range:
                    update_vals["x_employee_count_range"] = self.x_employee_count_range
                if self.x_revenue_range:
                    update_vals["x_annual_revenue_range"] = self.x_revenue_range
                if self.x_annual_revenue:
                    update_vals["x_annual_revenue"] = self.x_annual_revenue
                if self.x_is_it_company is not None:
                    update_vals["x_is_it_company"] = self.x_is_it_company
                if org.get("linkedin_url"):
                    update_vals["x_company_linkedin_url"] = org.get("linkedin_url")
                if org.get("city"):
                    update_vals["x_hq_city"] = org.get("city")
                if org.get("founded_year"):
                    update_vals["x_founded_year"] = org.get("founded_year")
                if org.get("website_url"):
                    update_vals["x_website"] = org.get("website_url")

                if org.get("country"):
                    country = (
                        self.env["res.country"]
                        .sudo()
                        .search(
                            [
                                "|",
                                ("name", "ilike", org.get("country")),
                                ("code", "ilike", org.get("country")),
                            ],
                            limit=1,
                        )
                    )
                    if country:
                        update_vals["x_hq_country_id"] = country.id

            # ICP / AI signals mirrored on contact
            if self.x_likely_pain_point:
                update_vals["x_likely_pain_point"] = self.x_likely_pain_point
            if self.x_similar_companies_won:
                update_vals["x_similar_companies_won"] = self.x_similar_companies_won
            if self.x_icp_match_signals:
                update_vals["x_icp_match_signals"] = self.x_icp_match_signals
            if self.x_icp_disqualify_signals:
                update_vals[
                    "x_icp_disqualify_signals"
                ] = self.x_icp_disqualify_signals
            if self.x_inquiry_category:
                update_vals["x_inquiry_category"] = self.x_inquiry_category
            if self.x_lead_language:
                update_vals["x_lead_language"] = self.x_lead_language
            if self.x_enrichment_conf:
                update_vals["x_enrichment_conf"] = self.x_enrichment_conf
            if self.x_enrichment_source:
                update_vals["x_enrichment_source"] = self.x_enrichment_source
            if self.x_enrichment_date:
                update_vals["x_enrichment_date"] = self.x_enrichment_date

            # Key Fit Signals -> partner
            if self.x_industry:
                update_vals["x_fit_industry"] = self.x_industry
            if self.x_employee_count_range:
                update_vals["x_fit_company_size"] = self.x_employee_count_range
            if self.x_revenue_range:
                update_vals["x_fit_revenue_range"] = self.x_revenue_range
            if self.x_hq_country_id:
                update_vals["x_fit_geography"] = self.x_hq_country_id.name
            if self.x_contact_seniority_structured:
                update_vals[
                    "x_fit_contact_seniority"
                ] = self.x_contact_seniority_structured
            if self.x_contact_decision_authority:
                update_vals[
                    "x_fit_decision_authority"
                ] = self.x_contact_decision_authority
            if self.x_inquiry_urgency:
                update_vals["x_fit_urgency"] = self.x_inquiry_urgency

            if update_vals:
                partner.write(update_vals)
        elif email:
            # No existing partner with this email, create a new one.
            # Create only when we have a concrete email (avoid noisy duplicates).
            create_vals = {
                "name": name or email or phone or "New Contact",
            }
            if email:
                create_vals["email"] = email
            if phone:
                create_vals["phone"] = phone
            if isinstance(org, dict):
                if org.get("city"):
                    create_vals["x_hq_city"] = org.get("city")
                if org.get("country"):
                    country = (
                        self.env["res.country"]
                        .sudo()
                        .search(
                            [
                                "|",
                                ("name", "ilike", org.get("country")),
                                ("code", "ilike", org.get("country")),
                            ],
                            limit=1,
                        )
                    )
                    if country:
                        create_vals["x_hq_country_id"] = country.id
                if org.get("industry"):
                    create_vals["x_industry"] = org.get("industry")
                if org.get("founded_year"):
                    create_vals["x_founded_year"] = org.get("founded_year")
                if org.get("website_url"):
                    create_vals["x_website"] = org.get("website_url")

            partner = Partner.create(create_vals)
            self.partner_id = partner

        # Final sync of all enrichment / ICP fields from lead to partner
        if partner:
            self._sync_partner_from_lead(partner)

    def _sync_partner_from_lead(self, partner):
        """Copy enrichment + key fit signals from lead onto contact."""
        update_vals = {}

        # Contact enrichment
        if self.x_contact_job_title:
            update_vals["x_contact_job_title"] = self.x_contact_job_title
        if self.x_contact_seniority_structured:
            update_vals[
                "x_contact_seniority_structured"
            ] = self.x_contact_seniority_structured
        if self.x_contact_decision_authority:
            update_vals[
                "x_contact_decision_authority"
            ] = self.x_contact_decision_authority
        if self.x_direct_email:
            update_vals["x_direct_email"] = self.x_direct_email
        if self.x_direct_phone:
            update_vals["x_direct_phone"] = self.x_direct_phone
        if self.x_contact_linkedin_url:
            update_vals["x_contact_linkedin_url"] = self.x_contact_linkedin_url

        # Company enrichment
        if self.x_industry:
            update_vals["x_industry"] = self.x_industry
        if hasattr(self, "x_sub_industry") and self.x_sub_industry:
            update_vals["x_sub_industry"] = self.x_sub_industry
        if self.x_employee_count_range:
            update_vals["x_employee_count_range"] = self.x_employee_count_range
        if self.x_employee_count:
            update_vals["x_employee_count"] = self.x_employee_count
        if self.x_revenue_range:
            update_vals["x_annual_revenue_range"] = self.x_revenue_range
        if self.x_annual_revenue:
            update_vals["x_annual_revenue"] = self.x_annual_revenue
        if hasattr(self, "x_is_it_company") and self.x_is_it_company is not None:
            update_vals["x_is_it_company"] = self.x_is_it_company
        if self.x_company_linkedin_url:
            update_vals["x_company_linkedin_url"] = self.x_company_linkedin_url
        if self.x_hq_city:
            update_vals["x_hq_city"] = self.x_hq_city
        if self.x_hq_country_id:
            update_vals["x_hq_country_id"] = self.x_hq_country_id.id
        if self.x_founded_year:
            update_vals["x_founded_year"] = self.x_founded_year
        if self.x_website:
            update_vals["x_website"] = self.x_website

        # AI / ICP signals
        if self.x_likely_pain_point:
            update_vals["x_likely_pain_point"] = self.x_likely_pain_point
        if self.x_similar_companies_won:
            update_vals["x_similar_companies_won"] = self.x_similar_companies_won
        if self.x_icp_match_signals:
            update_vals["x_icp_match_signals"] = self.x_icp_match_signals
        if self.x_icp_disqualify_signals:
            update_vals["x_icp_disqualify_signals"] = self.x_icp_disqualify_signals
        if self.x_inquiry_category:
            update_vals["x_inquiry_category"] = self.x_inquiry_category
        if self.x_inquiry_urgency:
            update_vals["x_inquiry_urgency"] = self.x_inquiry_urgency
        if self.x_lead_language:
            update_vals["x_lead_language"] = self.x_lead_language
        if self.x_enrichment_conf:
            update_vals["x_enrichment_conf"] = self.x_enrichment_conf
        if self.x_enrichment_source:
            update_vals["x_enrichment_source"] = self.x_enrichment_source
        if self.x_enrichment_date:
            update_vals["x_enrichment_date"] = self.x_enrichment_date

        # Key Fit Signals
        if self.x_industry:
            update_vals["x_fit_industry"] = self.x_industry
        if self.x_employee_count_range:
            update_vals["x_fit_company_size"] = self.x_employee_count_range
        if self.x_revenue_range:
            update_vals["x_fit_revenue_range"] = self.x_revenue_range
        if self.x_hq_country_id:
            update_vals["x_fit_geography"] = self.x_hq_country_id.name
        if self.x_contact_seniority_structured:
            update_vals[
                "x_fit_contact_seniority"
            ] = self.x_contact_seniority_structured
        if self.x_contact_decision_authority:
            update_vals[
                "x_fit_decision_authority"
            ] = self.x_contact_decision_authority
        if self.x_inquiry_urgency:
            update_vals["x_fit_urgency"] = self.x_inquiry_urgency

        if update_vals:
            partner.write(update_vals)

    def _ensure_partner_from_enrichment(self):
        """Ensure a contact exists for this lead, then sync enrichment onto it.

        This is called after the full Apollo + structured enrichment + ICP
        scoring pipeline so that the contact always reflects the final state.
        """
        self.ensure_one()
        Partner = self.env["res.partner"].sudo()

        # Best email/name/phone we have: prefer enriched direct fields, then lead.
        email = (self.x_direct_email or self.email_from or "").strip()

        # Contact name priority:
        # 1) Apollo person: first_name + last_name / full name → stored in contact_name
        # 2) Apollo organization: organization/company name → stored as partner_name / partner_id.name
        # 3) Fallback: local-part of email (before '@')
        name = (self.contact_name or "").strip()
        if not name:
            company_name = (self.partner_name or (self.partner_id.name if self.partner_id else "") or "").strip()
            name = company_name
        if not name and email:
            prefix = email.split("@")[0]
            for ch in [".", "_", "-"]:
                prefix = prefix.replace(ch, " ")
            name = prefix.title()
        phone = (self.x_direct_phone or self.phone or "").strip()

        # Keep selected partner if already chosen by user.
        partner = self.partner_id

        # If no selected partner, reuse any existing partner with same email.
        if not partner and email:
            partner = Partner.search([("email", "=ilike", email)], limit=1)
            if partner:
                self.partner_id = partner

        # Still nothing: create a new contact ONLY when we have a concrete email.
        # If there is no email, skip contact creation but still apply enrichment on the lead.
        if not partner and email:
            vals = {"name": name or email or phone or "New Contact"}
            if email:
                vals["email"] = email
            if phone:
                vals["phone"] = phone
            partner = Partner.create(vals)
            self.partner_id = partner

        # Finally sync all enrichment + key fit signals onto the contact.
        if partner:
            self._sync_partner_from_lead(partner)

        # Run AI-based structured enrichment on the raw Apollo JSON to populate
        # the remaining 30+ enrichment fields (ICP signals, pain points, etc.).
        # This is a best-effort call; if Claude or config is missing, we simply skip.
        try:
            raw_blob = {
                "person": person or {},
                "organization": org or {},
                "lead_context": {
                    "subject": (self.name or "")[:300],
                    "inquiry_body": (self.description or "")[:2000],
                    "email_from": self.email_from or "",
                },
            }
            struct = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "enrichment_structurer", "haiku"),
                system_prompt=prompts.get_system_prompt(self.env, "enrichment_system"),
                user_message=json.dumps(raw_blob, ensure_ascii=False),
                max_tokens=800,
                expect_json=True,
            )
        except Exception:
            _logger.warning(
                "sales_ai: EnrichmentStructurerAgent failed for lead %s; raw Apollo only.",
                self.id,
                exc_info=True,
            )
        else:
            if isinstance(struct, dict):
                _logger.info(
                    "sales_ai: Applying structured enrichment for lead %s (keys=%s)",
                    self.id,
                    list(struct.keys()),
                )
                self.action_apply_structured_enrichment(struct)
                if self.partner_id:
                    self._sync_partner_from_lead(self.partner_id)

    def _map_apollo_seniority(self, apollo_seniority):
        """Map Apollo seniority values to our selection field."""
        mapping = {
            "c_suite": "c_level",
            "owner": "c_level",
            "founder": "c_level",
            "vp": "vp",
            "director": "director",
            "manager": "manager",
            "senior": "other",
            "entry": "other",
            "training": "other",
        }
        return mapping.get(apollo_seniority or "", None)

    # -------------------------------------------------------------------------
    # Structured enrichment write-back (EnrichmentStructurerAgent)
    # -------------------------------------------------------------------------

    def action_apply_structured_enrichment(self, enrichment: dict):
        """
        Apply structured enrichment JSON (from EnrichmentStructurerAgent)
        onto this lead's fields.

        IMPORTANT: Only writes fields that Claude actually returned a non-null
        value for. Never overwrites existing lead data with False/empty.
        """
        self.ensure_one()
        vals = {}

        def _set_if_truthy(field_name, value):
            """Only include in vals if value is truthy — never clear existing data."""
            if value:
                vals[field_name] = value

        # -- Company ----------------------------------------------------------
        _set_if_truthy("x_industry", enrichment.get("company_industry"))
        _set_if_truthy("x_subindustry", enrichment.get("company_sub_industry"))

        # employee_count (integer) → x_employee_count; employee_range (string) → x_employee_count_range
        emp_count = enrichment.get("company_employee_count")
        if emp_count and isinstance(emp_count, (int, float)):
            vals["x_employee_count"] = int(emp_count)
        emp_range = enrichment.get("company_employee_range")
        _set_if_truthy("x_employee_count_range", emp_range)

        _set_if_truthy("x_revenue_range", enrichment.get("company_revenue_range"))
        _set_if_truthy("x_hq_city", enrichment.get("company_hq_city"))

        founded = enrichment.get("company_founded_year")
        if founded:
            try:
                vals["x_founded_year"] = int(founded)
            except (ValueError, TypeError):
                pass

        _set_if_truthy("x_company_funding_stage", enrichment.get("company_funding_stage"))
        _set_if_truthy("x_company_linkedin_url", enrichment.get("company_linkedin_url"))
        _set_if_truthy("x_website", enrichment.get("company_website"))

        country_name = enrichment.get("company_hq_country")
        if country_name:
            country = (
                self.env["res.country"]
                .sudo()
                .search([("name", "ilike", country_name)], limit=1)
            )
            if country:
                vals["x_hq_country_id"] = country.id

        tech_stack = enrichment.get("company_tech_stack")
        if tech_stack and isinstance(tech_stack, list):
            try:
                vals["x_tech_stack"] = json.dumps(tech_stack, ensure_ascii=False)
            except Exception:
                vals["x_tech_stack"] = str(tech_stack)

        # -- Contact ----------------------------------------------------------
        _set_if_truthy("x_contact_job_title", enrichment.get("contact_job_title"))

        seniority = (enrichment.get("contact_seniority") or "").lower()
        seniority_map = {
            "c-level": "c_level",
            "c_level": "c_level",
            "vp": "vp",
            "director": "director",
            "manager": "manager",
            "ic": "ic",
            "individual_contributor": "ic",
            "unknown": "unknown",
        }
        mapped_seniority = seniority_map.get(seniority)
        if mapped_seniority:
            vals["x_contact_seniority_structured"] = mapped_seniority

        # contact_email_verified: prompt now returns the actual email string (not a boolean)
        verified_email = enrichment.get("contact_email_verified")
        if verified_email and isinstance(verified_email, str) and "@" in verified_email:
            vals["x_direct_email"] = verified_email
            if not self.email_from:
                vals["email_from"] = verified_email

        _set_if_truthy("x_direct_phone", enrichment.get("contact_phone"))
        _set_if_truthy("x_contact_linkedin_url", enrichment.get("contact_linkedin_url"))

        is_dm = enrichment.get("contact_is_decision_maker")
        if is_dm is True:
            vals["x_contact_decision_authority"] = "yes"
            vals["x_is_decision_maker"] = True
        elif is_dm is False:
            vals["x_contact_decision_authority"] = "no"
            vals["x_is_decision_maker"] = False

        # -- Lead context / AI signals ----------------------------------------
        likely_pain = (
            enrichment.get("likely_pain_point")
            or enrichment.get("pain_point")
            or enrichment.get("client_pain_point")
        )
        _set_if_truthy("x_likely_pain_point", likely_pain)

        similar_wins = (
            enrichment.get("similar_clients_won")
            or enrichment.get("similar_companies_won")
            or enrichment.get("similar_win_examples")
        )
        _set_if_truthy("x_similar_companies_won", similar_wins)

        icp_signals = (
            enrichment.get("icp_match_signals")
            or enrichment.get("icp_signals")
            or enrichment.get("match_signals")
        )
        if icp_signals:
            try:
                vals["x_icp_match_signals"] = json.dumps(icp_signals, ensure_ascii=False)
            except Exception:
                vals["x_icp_match_signals"] = str(icp_signals)

        icp_disq = (
            enrichment.get("icp_disqualify_signals")
            or enrichment.get("icp_disqualifying_signals")
            or enrichment.get("disqualify_signals")
        )
        if icp_disq:
            try:
                vals["x_icp_disqualify_signals"] = json.dumps(icp_disq, ensure_ascii=False)
            except Exception:
                vals["x_icp_disqualify_signals"] = str(icp_disq)

        _set_if_truthy(
            "x_apollo_conversation_summary",
            enrichment.get("apollo_conversation_history"),
        )

        conf = (
            enrichment.get("enrichment_confidence")
            if enrichment.get("enrichment_confidence") is not None
            else enrichment.get("confidence")
        )
        if conf is not None:
            try:
                vals["x_enrichment_conf"] = float(conf)
            except (ValueError, TypeError):
                pass
        _set_if_truthy("x_enrichment_notes", enrichment.get("enrichment_notes"))
        source = enrichment.get("data_source") or enrichment.get("enrichment_source") or "apollo+ai"
        _set_if_truthy("x_enrichment_source", source)

        date_str = enrichment.get("enrichment_date")
        if date_str:
            try:
                if "T" in str(date_str):
                    vals["x_enrichment_date"] = fields.Datetime.to_datetime(date_str)
                else:
                    vals["x_enrichment_date"] = fields.Datetime.to_datetime(
                        str(date_str) + " 00:00:00"
                    )
            except Exception:
                vals["x_enrichment_date"] = fields.Datetime.now()

        lead_lang = enrichment.get("lead_language") or enrichment.get("language")
        _set_if_truthy("x_lead_language", lead_lang)

        cat = (
            enrichment.get("inquiry_category")
            or enrichment.get("category")
            or enrichment.get("inquiry_type")
            or ""
        ).lower()
        cat_map = {
            "new-implementation": "new_implementation",
            "new_implementation": "new_implementation",
            "upgrade": "upgrade",
            "support": "support",
            "consulting": "consulting",
            "other": "other",
        }
        mapped_cat = cat_map.get(cat)
        if mapped_cat:
            vals["x_inquiry_category"] = mapped_cat

        urg = (
            enrichment.get("inquiry_urgency")
            or enrichment.get("urgency")
            or ""
        ).lower()
        urg_map = {"high": "high", "medium": "medium", "low": "low"}
        mapped_urg = urg_map.get(urg)
        if mapped_urg:
            vals["x_inquiry_urgency"] = mapped_urg

        _set_if_truthy("x_follow_up_angle", enrichment.get("follow_up_angle"))

        # Ensure enrichment date is always stamped after AI response processing.
        if "x_enrichment_date" not in vals:
            vals["x_enrichment_date"] = fields.Datetime.now()

        vals["x_enrichment_done"] = True
        if vals:
            _logger.info(
                "sales_ai: Structured enrichment writing %d fields for lead %s: %s",
                len(vals), self.id, list(vals.keys()),
            )
            self.write(vals)

        # After final structured enrichment, always ensure there is a contact
        # and that it carries all enrichment + key fit signals.
        self._ensure_partner_from_enrichment()

        # Log to chatter
        self.message_post(
            body=_("Enriched from Apollo on %s", fields.Datetime.now()),
            subtype_xmlid="mail.mt_note",
        )

    def _classify_lead_quality(self, has_apollo_data: bool):
        """
        Classify lead as genuine / marketing / junk.

        If Apollo had data → use enriched fields + email content for classification.
        If no Apollo data → classify from email content only (more conservative).
        """
        _logger.info(
            "sales_ai: [JUNK-FILTER] lead_id=%s has_apollo=%s email=%s",
            self.id, has_apollo_data, self.email_from or "(none)",
        )
        settings = self.env["ir.config_parameter"].sudo()
        marketing_user_id = int(
            settings.get_param("sales_ai.marketing_user_id", default="0") or 0
        )
        if not marketing_user_id:
            _logger.warning(
                "sales_ai: [JUNK-FILTER] WARNING lead_id=%s — "
                "sales_ai.marketing_user_id not set. Non-genuine leads won't be routed. "
                "Fix: Settings → Sales AI → Marketing User.",
                self.id,
            )

        subject = (self.name or "")[:512]
        body = (self.description or "")[:4000]
        sender_email = self.email_from or ""
        sender_domain = (
            sender_email.split("@")[-1] if sender_email and "@" in sender_email else ""
        )

        payload = {
            "email_subject": subject,
            "email_body": body,
            "sender_email": sender_email,
            "sender_domain": sender_domain,
            "company_name": (self.partner_id.name or "") if self.partner_id else "",
            "lead_id": self.id,
        }

        # Include simple enrichment hints if available
        if has_apollo_data:
            payload.update(
                {
                    "employee_count": self.x_employee_count,
                    "is_it_company": self.x_is_it_company,
                    "seniority": self.x_seniority,
                    "is_decision_maker": self.x_is_decision_maker,
                    "linkedin_url": self.x_linkedin_url,
                    "tech_stack": self.x_tech_stack,
                }
            )

        t0 = time.time()
        try:
            result = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "junk_filter", "haiku"),
                system_prompt=prompts.get_system_prompt(self.env, "junk_filter_system"),
                user_message=json.dumps(payload, ensure_ascii=False),
                max_tokens=256,
                expect_json=True,
            )
        except Exception:
            _logger.error(
                "sales_ai: [JUNK-FILTER] FAIL — Claude API error lead_id=%s (%.2fs); "
                "defaulting to genuine. Check API key and network.",
                self.id, time.time() - t0, exc_info=True,
            )
            quality = "genuine"
            self.x_lead_quality = quality
            self.x_classification = quality
            return

        if not isinstance(result, dict):
            result = {}

        # Detect silent failure: Claude returned empty dict (API key missing / SDK error)
        if not result:
            _logger.error(
                "sales_ai: [JUNK-FILTER] NO RESULT — lead_id=%s (%.2fs). "
                "Claude returned empty response. Most likely cause: "
                "sales_ai.claude_api_key not set in Settings → Technical → System Parameters. "
                "Defaulting to genuine.",
                self.id, time.time() - t0,
            )
            quality = "genuine"
            self.x_lead_quality = quality
            self.x_classification = quality
            return

        _logger.info(
            "sales_ai: [JUNK-FILTER] Claude Haiku OK — lead_id=%s (%.2fs) raw=%s",
            self.id, time.time() - t0, str(result)[:150],
        )
        classification = (result.get("classification") or "genuine").lower()
        confidence = float(result.get("confidence") or 0.0)
        reason = result.get("reason") or ""
        suggested_tag = (result.get("suggested_tag") or "").strip()

        # Server-side safety net: for trusted internal domains with clearly
        # business-y subjects, force classification to genuine even if the
        # model is overly conservative (e.g. empty body during testing).
        internal_domains = {"biztechcs.com"}
        subject_lc = subject.lower()
        looks_like_requirement = any(
            kw in subject_lc
            for kw in [
                "requirement",
                "inquiry",
                "implementation",
                "web-to-print",
                "web to print",
                "business requirement",
                "software requirement",
                "discussion",
            ]
        )
        if (
            sender_domain in internal_domains
            and looks_like_requirement
            and classification in ("junk", "marketing")
        ):
            _logger.info(
                "sales_ai: [JUNK-FILTER] OVERRIDE to genuine for lead_id=%s "
                "(internal domain %s + requirement-style subject). "
                "Original: classification=%s conf=%.0f%% reason=%s",
                self.id,
                sender_domain,
                classification,
                confidence,
                reason,
            )
            classification = "genuine"
            confidence = max(confidence, 60.0)

        # Normalise to our selection values
        if classification not in ("genuine", "marketing", "junk", "job_seeker"):
            classification = "genuine"

        # Backwards-compatible lead quality (no job_seeker value there)
        quality_map = {
            "genuine": "genuine",
            "marketing": "marketing",
            "junk": "junk",
            "job_seeker": "marketing",  # job seekers are handled by Marketing
        }
        quality = quality_map[classification]

        self.write(
            {
                "x_lead_quality": quality,
                "x_classification": classification,
                "x_classification_conf": max(0.0, min(100.0, confidence)),
                "x_classification_reason": reason[:255] if reason else False,
            }
        )

        # Apply suggested Odoo tag if provided.
        # Flush pending writes first so the savepoint doesn't trigger a flush
        # that could fail with SerializationFailure on unrelated dirty fields.
        if suggested_tag:
            self.env.flush_all()
            Tag = self.env["crm.tag"].sudo()
            tag = Tag.search([("name", "=", suggested_tag)], limit=1)
            if not tag:
                tag = Tag.create({"name": suggested_tag})
            try:
                with self.env.cr.savepoint():
                    self.tag_ids = [(4, tag.id)]
            except Exception:
                _logger.warning(
                    "sales_ai: Failed to attach suggested tag %s on lead %s",
                    suggested_tag,
                    self.id,
                    exc_info=True,
                )

        _logger.info(
            "sales_ai: Lead %s classified as %s (conf=%.1f, Apollo match: %s)",
            self.id,
            classification,
            confidence,
            has_apollo_data,
        )

        # Route non-genuine leads to Marketing user and stop automation
        if classification in ("marketing", "junk", "job_seeker") and marketing_user_id:
            self.user_id = self.env["res.users"].browse(marketing_user_id)
            self.message_post(
                body=_(
                    "Classified as <b>%s</b> by AI (%.1f%% confidence, Apollo match: %s). "
                    "Routed to Marketing user and automation stopped.",
                    classification,
                    max(0.0, min(100.0, confidence)),
                    "Yes" if has_apollo_data else "No",
                ),
                subtype_xmlid="mail.mt_note",
            )

    # Legacy method — kept for backward compat with old automation XML
    def action_run_junk_filter(self):
        """Fallback: classify without Apollo data (for manually created leads)."""
        for lead in self.filtered(lambda l: not l.x_lead_quality):
            lead._classify_lead_quality(has_apollo_data=False)

    # =========================================================================
    # PHASE 2: LEAD SCORING
    # =========================================================================

    def action_run_lead_scoring(self):
        """Score the lead 0-100 and set band based on configured ICP JSON."""
        _logger.info("sales_ai: [SCORING] Starting for lead_id(s)=%s", self.ids)
        ICP = self.env["ir.config_parameter"].sudo()
        chatter_enabled = (ICP.get_param("sales_ai.enable_ai_chatter_notes", default="0") or "0") in ("1", "true", "True")
        icp_json = ICP.get_param("sales_ai.icp_criteria_json", default="{}")
        try:
            icp = json.loads(icp_json)
        except Exception:
            icp = {}
            _logger.warning(
                "sales_ai: [SCORING] WARNING — ICP JSON invalid. "
                "Default score 50/warm applied. Fix: Settings → Sales AI → ICP Criteria."
            )

        for lead in self.filtered(lambda l: not l.x_scoring_done):
            if not icp:
                lead.x_lead_score = 50
                lead.x_lead_score_band = "warm"
                lead.x_scoring_done = True
                lead.x_lead_score_breakdown = False
                lead.x_lead_score_rationale = _(
                    "Default score applied because no ICP criteria are configured."
                )
                _logger.info(
                    "sales_ai: Lead %s scored 50 (warm) — no ICP criteria configured",
                    lead.id,
                )
                continue

            payload = {
                "lead_id": lead.id,
                "enriched_fields": {
                    "company_industry": lead.x_industry or "",
                    "company_subindustry": lead.x_subindustry or "",
                    "company_employee_count": lead.x_employee_count or 0,
                    "company_employee_range": lead.x_employee_count_range or "",
                    "company_revenue_range": lead.x_revenue_range or "",
                    "company_hq_country": lead.x_hq_country_id.name if lead.x_hq_country_id else "",
                    "company_hq_city": lead.x_hq_city or "",
                    "tech_stack": lead.x_tech_stack or "",
                    "funding_stage": lead.x_company_funding_stage or "",
                    "contact_job_title": lead.x_contact_job_title or "",
                    "contact_seniority": lead.x_contact_seniority_structured or lead.x_seniority or "",
                    "contact_is_decision_maker": lead.x_contact_decision_authority == "yes",
                    "likely_pain_point": lead.x_likely_pain_point or "",
                    "icp_match_signals": lead.x_icp_match_signals or "",
                    "icp_disqualify_signals": lead.x_icp_disqualify_signals or "",
                    "apollo_match": lead.x_apollo_match,
                },
                "original_inquiry": (lead.description or "")[:2000],
                "icp_config": icp,
            }
            try:
                result = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "lead_scoring", "haiku"),
                    system_prompt=prompts.get_system_prompt(self.env, "lead_scoring_system"),
                    user_message=json.dumps(payload, ensure_ascii=False),
                    max_tokens=800,
                    expect_json=True,
                )
            except Exception:
                _logger.error(
                    "sales_ai: Lead scoring failed for lead %s",
                    lead.id,
                    exc_info=True,
                )
                continue

            if not isinstance(result, dict):
                result = {}

            score = int(result.get("score") or 0)
            band = (result.get("band") or "").lower()
            if band not in ("hot", "warm", "neutral", "cold"):
                # Map legacy three-band outputs into four-band scheme
                if score >= 90:
                    band = "hot"
                elif score >= 70:
                    band = "warm"
                elif score >= 50:
                    band = "neutral"
                else:
                    band = "cold"

            breakdown = result.get("breakdown") or {}
            rationale = result.get("rationale") or result.get("reasoning") or ""

            lead.write(
                {
                    "x_lead_score": max(0, min(100, score)),
                    "x_lead_score_band": band,
                    "x_scoring_done": True,
                    "x_lead_score_breakdown": json.dumps(breakdown, ensure_ascii=False)
                    if breakdown
                    else False,
                    "x_lead_score_rationale": rationale or False,
                }
            )

            _logger.info(
                "sales_ai: Lead %s scored %d (%s) — %s",
                lead.id,
                score,
                band,
                (rationale or "")[:100],
            )
            if rationale and chatter_enabled:
                lead.message_post(
                    body=_(
                        "AI lead scoring: <b>%d/100 (%s)</b><br/>%s",
                        score,
                        band,
                        rationale,
                    ),
                    subtype_xmlid="mail.mt_note",
                )

            # After scoring (ICP score done), push latest enrichment and key fit
            # signals down to the linked contact so the partner record always
            # reflects the final state of the lead.
            if lead.partner_id:
                lead._sync_partner_from_lead(lead.partner_id)

            # Follow-up activities will now be scheduled only AFTER the auto-ack
            # email has been sent (stage moved to "Contacted"), so we do not
            # create them immediately at scoring time.

    # =========================================================================
    # ROUND-ROBIN SALESPERSON (team members)
    # =========================================================================

    @api.model
    def _sales_ai_round_robin_enabled(self):
        ICP = self.env["ir.config_parameter"].sudo()
        raw = (ICP.get_param("sales_ai.round_robin_enabled", default="true") or "true").lower()
        return raw not in ("0", "false", "no", "off")

    @api.model
    def _sales_ai_rr_should_clear_implicit_salesperson(self):
        """When True, create() sets user_id=False so Odoo does not default to env.user.

        Triggers: superuser, context flag, or login listed in Settings
        (e.g. admin, dedicated API user used in Postman).
        """
        if not self._sales_ai_round_robin_enabled():
            return False
        if self.env.context.get("sales_ai_rr_clear_default_salesperson"):
            return True
        if self.env.user.id == SUPERUSER_ID:
            return True
        ICP = self.env["ir.config_parameter"].sudo()
        raw = (ICP.get_param("sales_ai.rr_clear_salesperson_logins", default="") or "").strip()
        if not raw:
            return False
        allowed = {x.strip().lower() for x in raw.split(",") if x.strip()}
        return (self.env.user.login or "").lower() in allowed

    @api.model
    def _sales_ai_next_round_robin_user(self, team):
        """Pick next active salesperson on the team using a persisted counter (per team)."""
        team = team.sudo() if team else self.env["crm.team"]
        if not team or not team.exists():
            return self.env["res.users"]

        members = team.crm_team_member_ids.filtered(
            lambda m: m.active and m.user_id and m.user_id.active
        )
        if "assignment_optout" in members._fields:
            members = members.filtered(lambda m: not m.assignment_optout)

        # Preserve team member order (create_date, id — same spirit as crm.team.member default order).
        epoch = fields.Datetime.from_string("1970-01-01 00:00:00")
        ordered = members.sorted(key=lambda m: (m.create_date or epoch, m.id))
        user_ids_ordered = []
        for m in ordered:
            if m.user_id and m.user_id.id not in user_ids_ordered:
                user_ids_ordered.append(m.user_id.id)
        # Include team leader in the rotation if not already listed (common when only
        # "Team Leader" is set but Team Members tab is incomplete).
        if team.user_id and team.user_id.active and team.user_id.id not in user_ids_ordered:
            user_ids_ordered.append(team.user_id.id)
        # Fallback: computed member_ids on crm.team (same users as member lines).
        if not user_ids_ordered and hasattr(team, "member_ids"):
            for u in team.member_ids.filtered(lambda x: x.active):
                if u.id not in user_ids_ordered:
                    user_ids_ordered.append(u.id)
        if not user_ids_ordered:
            _logger.warning(
                "sales_ai: [RR] team %s (%s) has no salespeople — add "
                "CRM → Sales Teams → Team Members (not only Team Leader).",
                team.id,
                team.name or "",
            )
            return self.env["res.users"]

        users = self.env["res.users"].sudo().browse(user_ids_ordered)
        ICP = self.env["ir.config_parameter"].sudo()
        key = "sales_ai.rr_counter_%s" % team.id
        idx = int(ICP.get_param(key, default="0") or 0)
        chosen = users[idx % len(users)]
        ICP.set_param(key, str(idx + 1))
        _logger.info(
            "sales_ai: [RR] team=%s next salesperson user_id=%s (%s) counter_was=%s",
            team.id,
            chosen.id,
            chosen.name,
            idx,
        )
        return chosen

    def _sales_ai_resolve_team_for_assignment(self):
        """Default team for round-robin when lead.team_id is empty."""
        self.ensure_one()
        ICP = self.env["ir.config_parameter"].sudo()
        if self.team_id:
            return self.team_id.sudo()
        tid = int(ICP.get_param("sales_ai.default_crm_team_id", default="0") or 0)
        team = self.env["crm.team"].sudo().browse(tid)
        if team.exists():
            return team
        team = self.env["crm.team"].sudo().search(
            [("use_leads", "=", True)], limit=1,
        )
        if team:
            return team
        return self.env["crm.team"].sudo().search([], limit=1)

    def _sales_ai_assign_round_robin_if_needed(self):
        """Assign user_id from team round-robin when empty (genuine / unclassified sales leads)."""
        if not self._sales_ai_round_robin_enabled():
            return False
        assigned_any = False
        for lead in self:
            if lead.user_id:
                continue
            cls = (lead.x_classification or "").strip().lower()
            if cls and cls != "genuine":
                continue

            team = lead._sales_ai_resolve_team_for_assignment()
            if not team or not team.exists():
                _logger.warning(
                    "sales_ai: [RR] lead %s — no crm.team available",
                    lead.id,
                )
                continue

            if not lead.team_id:
                lead.sudo().write({"team_id": team.id})

            user = lead._sales_ai_next_round_robin_user(team)
            if not user:
                continue
            lead.sudo().write({"user_id": user.id})
            try:
                lead.message_post(
                    body=_(
                        "Assigned to <b>%s</b> via sales team round-robin.",
                        user.name,
                    ),
                    subtype_xmlid="mail.mt_note",
                )
            except Exception:
                _logger.debug(
                    "sales_ai: [RR] chatter note failed for lead %s",
                    lead.id,
                    exc_info=True,
                )
            assigned_any = True
        return assigned_any

    # =========================================================================
    # PHASE 3: AUTO-ACK EMAIL + FOLLOW-UP SCHEDULING
    # =========================================================================

    def action_send_auto_ack(self):
        """
        Prepare an AI-generated acknowledgment email draft for the assigned rep.

        Mindmap alignment:
        - [4] LEAD ASSIGNMENT: rep gets an activity to review & send auto-ack.
        - [5] AUTO-ACK: AI drafts a personalized email; rep reviews & sends.

        This method now creates a review activity with the AI draft instead of
        immediately sending the email, so the rep stays in control.
        """
        for lead in self:
            if not lead.user_id:
                lead._sales_ai_assign_round_robin_if_needed()
            # Require assigned rep, enrichment and scoring to be completed, and
            # lead classified as genuine before drafting auto-ack.
            if not lead.user_id:
                _logger.warning(
                    "sales_ai: [AUTO-ACK] SKIP lead_id=%s — missing user_id (no assigned rep).",
                    lead.id,
                )
                continue
            if not lead.x_enrichment_done:
                _logger.info(
                    "sales_ai: [AUTO-ACK] SKIP lead_id=%s — enrichment not done yet.",
                    lead.id,
                )
                continue
            if lead.x_classification not in ("genuine",):
                _logger.info(
                    "sales_ai: [AUTO-ACK] SKIP lead_id=%s — classification=%s (only genuine leads get auto-ack).",
                    lead.id,
                    lead.x_classification,
                )
                continue
            if not lead.x_scoring_done:
                _logger.info(
                    "sales_ai: [AUTO-ACK] lead_id=%s scoring not ready, running inline scoring fallback.",
                    lead.id,
                )
                try:
                    lead.with_context(ai_force_sync=True).action_run_lead_scoring()
                except Exception:
                    _logger.error(
                        "sales_ai: [AUTO-ACK] inline scoring fallback failed for lead_id=%s",
                        lead.id,
                        exc_info=True,
                    )
                    continue
                lead.invalidate_recordset()
                if not lead.x_scoring_done:
                    _logger.info(
                        "sales_ai: [AUTO-ACK] SKIP lead_id=%s — scoring still not done after fallback.",
                        lead.id,
                    )
                    continue

            # Prefer partner email if present; fall back to lead.email_from. If still missing,
            # we cannot draft a meaningful auto-ack.
            client_email = (
                (lead.partner_id and lead.partner_id.email)
                or lead.email_from
                or ""
            )
            if not client_email:
                _logger.warning(
                    "sales_ai: [AUTO-ACK] SKIP lead_id=%s — no client email found on partner or lead.",
                    lead.id,
                )
                continue

            calendar_link = lead.user_id.x_calendar_link or "[CALENDAR_LINK]"
            if calendar_link == "[CALENDAR_LINK]":
                _logger.warning(
                    "sales_ai: [AUTO-ACK] WARNING lead_id=%s — rep %s has no x_calendar_link set. "
                    "Email will be sent without a booking link. "
                    "Fix: Users → rep profile → Calendar Booking Link field.",
                    lead.id, lead.user_id.name,
                )
            context_data = {
                "lead_id": lead.id,
                "client_name": lead.contact_name
                or (lead.partner_id and lead.partner_id.name)
                or (lead.name or "there"),
                "client_company": (lead.partner_id and lead.partner_id.name) or "",
                "client_role": getattr(lead, "function", "") or "",
                "original_inquiry": lead.description or "",
                "enriched_fields": {
                    "company_industry": (
                        lead.x_industry
                        or (
                            getattr(lead.partner_id, "industry_id", False)
                            and lead.partner_id.industry_id.name
                        )
                        or ""
                    ),
                    "likely_pain_point": getattr(lead, "x_pain_point", False) or "",
                },
                "client_email": client_email,
                "rep_name": lead.user_id.name or "",
                "rep_designation": lead.user_id.job_title or "Account Executive",
                "rep_calendar_link": calendar_link,
                "company_value_prop": "",
                "lead_score_band": lead.x_lead_score_band or "warm",
            }
            try:
                resp = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "auto_ack_drafter", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "auto_ack_system"),
                    user_message=json.dumps(context_data, ensure_ascii=False),
                    expect_json=True,
                )
            except Exception:
                _logger.error(
                    "sales_ai: Auto-ack generation failed for lead %s",
                    lead.id,
                    exc_info=True,
                )
                continue

            subject = resp.get("subject") or _("Thank you for your inquiry")
            body_raw = resp.get("body_html") or resp.get("body") or ""
            body_html = tools.plaintext2html(body_raw)

            # Send the auto-ack email directly to the client using Odoo's mail
            # thread (requires a partner recipient, not raw email_to).
            rep_email = (lead.user_id.email or "").strip()
            fetch_server = self.env["fetchmail.server"].sudo().search([
                ("state", "=", "done"),
                ("server_type", "=", "gmail"),
                ("user", "=ilike", rep_email or ""),
            ], limit=1)
            if not fetch_server:
                fetch_server = self.env["fetchmail.server"].sudo().search([
                    ("state", "=", "done"),
                    ("server_type", "=", "gmail"),
                ], limit=1)

            email_from = (
                lead.user_id.partner_id.email
                or self.env.user.partner_id.email
                or ""
            )
            # Always route replies to a mailbox that fetchmail monitors.
            reply_to = (fetch_server.user or "").strip() or email_from
            if not email_from:
                if fetch_server and fetch_server.user:
                    email_from = fetch_server.user

            if not email_from:
                _logger.warning(
                    "sales_ai: [AUTO-ACK] lead_id=%s has no valid sender mailbox. "
                    "Configure user email or Gmail fetchmail server login.",
                    lead.id,
                )

            # Ensure we have a partner to send to; create or reuse based on email
            partner_ids = []
            partner = lead.partner_id
            if not partner:
                Partner = self.env["res.partner"].sudo()
                partner = Partner.search([("email", "=", client_email)], limit=1)
                if not partner:
                    partner = Partner.create(
                        {
                            "name": context_data["client_name"],
                            "email": client_email,
                        }
                    )
                lead.partner_id = partner
            partner_ids = [partner.id]

            try:
                author_partner_id = (
                    lead.user_id.partner_id.id
                    or self.env.user.partner_id.id
                )
                # Auto-ack must go only to the client, not lead followers/internal users.
                lead.with_context(
                    mail_post_autofollow=False,
                    mail_notify_author=False,
                ).message_post(
                    body=body_html,
                    subject=subject,
                    # Use the same chatter "Send message" path as manual green
                    # messages, which is more reliable for Gmail thread continuity.
                    message_type="comment",
                    subtype_xmlid="mail.mt_comment",
                    author_id=author_partner_id,
                    email_from=email_from,
                    reply_to=reply_to,
                    partner_ids=partner_ids,
                    notify_skip_followers=True,
                )
                _logger.info(
                    "sales_ai: Auto-ack email SENT for lead %s to %s",
                    lead.id,
                    client_email,
                )
            except Exception:
                _logger.error(
                    "sales_ai: Failed to send auto-ack email for lead %s",
                    lead.id,
                    exc_info=True,
                )

    def action_create_followup_activities(self, base_date=None):
        """Create the 3 scheduled follow-ups based on x_lead_score_band."""
        # Prevent assignment email storms for AI-generated follow-ups.
        Activity = self.env["mail.activity"].sudo().with_context(mail_activity_quick_update=True)
        followup_type = self.env.ref(
            "sales_ai_integration.activity_type_followup_email", raise_if_not_found=False
        )

        for lead in self:
            if lead.x_unsubscribed:
                _logger.info(
                    "sales_ai: Skipping follow-up creation for lead %s — unsubscribed",
                    lead.id,
                )
                continue

            if not lead.user_id or not lead.x_lead_score_band:
                _logger.warning(
                    "sales_ai: Skipping follow-up creation for lead %s — user: %s, band: %s",
                    lead.id, lead.user_id.id if lead.user_id else None, lead.x_lead_score_band,
                )
                continue

            if base_date is None:
                # context_timestamp expects a naive datetime in UTC; avoid double-localizing
                naive_utc_now = datetime.utcnow()
                base_dt = fields.Datetime.context_timestamp(self, naive_utc_now)
            else:
                base_dt = base_date

            if lead.x_lead_score_band == "hot":
                gaps = [1, 3, 7]
            elif lead.x_lead_score_band == "cold":
                gaps = [3, 7, 14]
            else:
                gaps = [2, 5, 10]

            for idx, days in enumerate(gaps, start=1):
                deadline = self._business_day_offset(base_dt, days).date()
                Activity.create(
                    {
                        'res_model_id': self.env.ref('crm.model_crm_lead').id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id,
                        "activity_type_id": followup_type.id if followup_type else False,
                        "date_deadline": deadline,
                        # Draft content will be generated by the 9 AM cron only.
                        "note": "[AI-FOLLOWUP-PENDING] Draft generation scheduled by cron.",
                    }
                )
            lead.x_followup_stage = 1
            _logger.info(
                "sales_ai: Created 3 follow-up activities for lead %s (band=%s, gaps=%s)",
                lead.id, lead.x_lead_score_band, gaps,
            )

    def _cancel_pending_followups(self):
        """Cancel all pending follow-up activities for these leads."""
        Activity = self.env["mail.activity"].sudo()
        followup_type = self.env.ref(
            "sales_ai_integration.activity_type_followup_email",
            raise_if_not_found=False,
        )
        if not followup_type:
            return
        for lead in self:
            pending = Activity.search([
                ("res_model", "=", "crm.lead"),
                ("res_id", "=", lead.id),
                ("activity_type_id", "=", followup_type.id),
            ])
            if pending:
                _logger.info(
                    "sales_ai: Canceling %d pending follow-ups for lead %s",
                    len(pending), lead.id,
                )
                pending.unlink()

    def _delete_next_planned_activities(self):
        """Delete only AI-managed upcoming activities on the lead."""
        Activity = self.env["mail.activity"].sudo()
        today = fields.Date.today()
        ai_type_ids = []
        for xmlid in (
            "sales_ai_integration.activity_type_followup_email",
            "sales_ai_integration.activity_type_reply_received",
        ):
            act_type = self.env.ref(xmlid, raise_if_not_found=False)
            if act_type:
                ai_type_ids.append(act_type.id)
        if not ai_type_ids:
            return
        for lead in self:
            planned = Activity.search([
                ("res_model", "=", "crm.lead"),
                ("res_id", "=", lead.id),
                ("date_deadline", ">=", today),
                ("activity_type_id", "in", ai_type_ids),
            ])
            if planned:
                _logger.info(
                    "sales_ai: Deleting %d AI planned activities for lead %s after meeting schedule",
                    len(planned), lead.id,
                )
                planned.unlink()

    def _notify_salesperson_client_meeting_scheduled(self, meeting_name="", meeting_start=""):
        """Email salesperson when a client meeting gets scheduled."""
        Mail = self.env["mail.mail"].sudo()
        for lead in self:
            rep = lead.user_id
            if not rep or not rep.email:
                continue
            subject = _("Client meeting scheduled — %s") % (lead.name or "Lead")
            meeting_label = meeting_name or _("Client meeting")
            start_label = meeting_start or _("Not specified")
            body_html = (
                "<p>Hello %s,</p>"
                "<p>A client meeting has been scheduled for your lead <b>%s</b>.</p>"
                "<p><b>Meeting:</b> %s<br/>"
                "<b>Start:</b> %s</p>"
                "<p>All upcoming planned activities on this lead were cleared automatically.</p>"
                "<p>Regards,<br/>Sales AI Automation</p>"
            ) % (
                tools.html_escape(rep.name or ""),
                tools.html_escape(lead.name or ""),
                tools.html_escape(str(meeting_label)),
                tools.html_escape(str(start_label)),
            )
            Mail.create({
                "subject": subject,
                "email_to": rep.email,
                "body_html": body_html,
                "auto_delete": True,
            }).send()

            lead.message_post(
                body=_(
                    "Client meeting scheduled. Email notification sent to salesperson %s and upcoming planned activities were removed.",
                    rep.name or "",
                ),
                subtype_xmlid="mail.mt_note",
            )

    # =========================================================================
    # PHASE 4: FOLLOW-UP EMAIL DRAFTER
    # =========================================================================

    @api.model
    def cron_draft_followup_emails(self):
        """Backward-compatible alias for older server actions.

        Some databases may still have a scheduled action calling
        model.cron_draft_followup_emails(). Keep it as a thin wrapper
        around cron_generate_followup_drafts().
        """
        return self.cron_generate_followup_drafts()

    @api.model
    def cron_generate_followup_drafts(self):
        """Daily 09:00 cron — generate / refresh follow-up drafts due today or earlier.

        This implements the spec:
          - activities are scheduled at auto-ack time
          - drafts are created on (or just before) their due dates.
        """
        Activity = self.env["mail.activity"].sudo()
        followup_type = self.env.ref(
            "sales_ai_integration.activity_type_followup_email",
            raise_if_not_found=False,
        )
        if not followup_type:
            return

        today = fields.Date.today()
        pending_activities = Activity.search(
            [
                ("res_model", "=", "crm.lead"),
                ("activity_type_id", "=", followup_type.id),
                ("date_deadline", "<=", today),
                # Either no note or one of our pending markers
                ("note", "ilike", "[AI-FOLLOWUP-PENDING]%"),
            ]
        )
        if not pending_activities:
            return

        _logger.info(
            "sales_ai: [FOLLOWUP-CRON] Generating drafts for %d pending follow-up activities",
            len(pending_activities),
        )
        leads_by_id = {
            lead.id: lead
            for lead in self.browse(pending_activities.mapped("res_id")).sudo()
        }
        for act in pending_activities:
            lead = leads_by_id.get(act.res_id)
            if not lead:
                continue
            try:
                self._draft_single_followup_email(lead, act)
            except Exception:
                _logger.error(
                    "sales_ai: Failed to draft follow-up via cron for lead %s (activity %s)",
                    act.res_id,
                    act.id,
                    exc_info=True,
                )
                act.note = "[AI-FOLLOWUP-PENDING] Draft generation failed."

    def _draft_single_followup_email(self, lead, activity):
        """Generate one follow-up draft email into the activity note."""
        done_count = self.env["mail.activity"].search_count(
            [
                ("res_model", "=", "crm.lead"),
                ("res_id", "=", lead.id),
                ("activity_type_id", "=", activity.activity_type_id.id),
                ("date_deadline", "<", activity.date_deadline),
            ]
        )
        followup_no = done_count + 1

        messages = lead.message_ids.sorted("date", reverse=False)
        outbound: List[Dict[str, str]] = []
        inbound: List[Dict[str, str]] = []
        for msg in messages[-20:]:
            entry = {
                "subject": msg.subject or "",
                "snippet": (msg.body or "")[:400],
                "date": str(msg.date),
            }
            if msg.message_type == "email" and msg.author_id.user_ids:
                outbound.append(entry)
            elif msg.message_type == "email":
                inbound.append(entry)

        context_data = {
            "followup_number": followup_no,
            "lead_score": lead.x_lead_score,
            "lead_score_band": lead.x_lead_score_band,
            "company_name": lead.partner_id.name if lead.partner_id else "",
            "contact_name": lead.contact_name or "",
            "previous_outbound": outbound[-5:],
            "recent_replies": inbound[-3:],
            "calendar_link": lead.user_id.x_calendar_link or "",
        }

        # Include attachment context if available
        att_context = lead._get_attachment_context()
        if att_context:
            context_data["attachment_context"] = att_context[:2000]

        try:
            resp = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "followup_drafter", "sonnet"),
                system_prompt=prompts.get_system_prompt(self.env, "followup_email_system"),
                user_message=json.dumps(context_data, ensure_ascii=False),
                max_tokens=800,
                expect_json=True,
            )
        except Exception:
            _logger.error(
                "sales_ai: Follow-up draft generation failed for lead %s (JSON call)",
                lead.id,
                exc_info=True,
            )
            activity.note = (
                "<p><b>[AI DRAFT — Follow-up %s]</b></p>"
                "<p><i>Draft generation failed. Please compose manually or wait for daily retry.</i></p>"
            ) % followup_no
            return

        subject = ""
        body_text = ""
        angle = ""
        cta = ""

        if isinstance(resp, dict):
            subject = resp.get("subject") or ""
            body_text = resp.get("body") or resp.get("body_html") or ""
            angle = resp.get("angle") or ""
            cta = resp.get("cta") or ""

        # If JSON response had no usable body, fall back to a plain-text call
        if not body_text:
            _logger.warning(
                "sales_ai: Follow-up #%d JSON draft empty for lead %s — falling back to plain text",
                followup_no,
                lead.id,
            )
            try:
                raw = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "reply_classifier", "sonnet"),
                    system_prompt=(
                        "You are writing a single follow-up email in plain text only. "
                        "Do not output JSON, analysis, or commentary — only the email body. "
                        "Use the provided JSON as context to write the best possible email."
                    ),
                    user_message=json.dumps(context_data, ensure_ascii=False),
                    max_tokens=800,
                    expect_json=False,
                )
            except Exception:
                _logger.error(
                    "sales_ai: Follow-up draft generation failed for lead %s (plain-text fallback)",
                    lead.id,
                    exc_info=True,
                )
                activity.note = (
                    "<p><b>[AI DRAFT — Follow-up %s]</b></p>"
                    "<p><i>Draft generation failed. Please compose manually or wait for daily retry.</i></p>"
                ) % followup_no
                return

            if raw:
                body_text = raw
            else:
                _logger.warning(
                    "sales_ai: Follow-up #%d plain-text draft empty for lead %s — leaving pending",
                    followup_no,
                    lead.id,
                )
                activity.note = (
                    "<p><b>[AI DRAFT — Follow-up %s]</b></p>"
                    "<p><i>AI draft generation returned empty. Please compose manually or wait for daily retry.</i></p>"
                ) % followup_no
                return

        subject = subject or _("Quick follow-up on your inquiry")

        body_html = tools.plaintext2html(body_text)
        note_parts = [
            "<p><b>[AI DRAFT — Follow-up %s]</b></p>" % followup_no,
            "<p><b>Subject:</b> %s</p>" % subject,
            body_html,
        ]
        if angle:
            note_parts.append("<p><b>Angle:</b> %s</p>" % tools.plaintext2html(angle))
        if cta:
            note_parts.append("<p><b>CTA:</b> %s</p>" % tools.plaintext2html(cta))

        activity.note = "".join(note_parts)
        _logger.info("sales_ai: Follow-up #%d draft created for lead %s", followup_no, lead.id)

    # =========================================================================
    # PHASE 5: PRESALE ON LEAD
    # =========================================================================

    def action_start_presale(self):
        """
        TicketGistAgent (Sonnet) — generate a discussion gist from all prior lead history.
        Called by action_open_presale. Stores gist in x_ticket_gist and posts to chatter.
        """
        ICP = self.env["ir.config_parameter"].sudo()
        chatter_enabled = (ICP.get_param("sales_ai.enable_ai_chatter_notes", default="0") or "0") in ("1", "true", "True")
        for lead in self:
            # Assign reference if not set
            if not lead.x_presale_ref:
                lead.x_presale_ref = "PST-%d" % lead.id
            if lead.x_presale_status == "none":
                lead.x_presale_status = "open"

            # Keep presale gist grounded on the latest living document snapshot.
            try:
                if getattr(lead, "x_living_doc_status", "") == "active":
                    lead._schedule_living_doc_update(
                        force_immediate=True,
                        reason="presale_gist_sync",
                        ignore_auto_update=True,
                    )
                    lead._process_living_document_update()
            except Exception:
                _logger.warning(
                    "sales_ai: Living doc refresh before presale gist failed for lead %s",
                    lead.id,
                    exc_info=True,
                )

            # Gather last 50 messages (emails + comments)
            msgs = lead.message_ids.sorted("date", reverse=False)[-50:]
            lines = []
            for m in msgs:
                if m.message_type not in ("email", "comment"):
                    continue
                snippet = (m.body or "").replace("\n", " ")
                lines.append("[%s] %s: %s" % (m.date, m.author_id.display_name or "", snippet[:400]))

            # Include living doc summary+content so ticket gist is derived from the canonical document.
            try:
                if getattr(lead, "x_last_summary_json", False):
                    summary_json = json.loads(lead.x_last_summary_json)
                    lines.append("\n[Living Document Summary JSON]\n%s" % json.dumps(summary_json, ensure_ascii=False))

                living_doc = getattr(lead, "x_living_doc_id", False)
                if living_doc:
                    raw = living_doc.attachment or (living_doc.attachment_id.datas if living_doc.attachment_id else False)
                    if raw:
                        import base64 as _b64  # local import to avoid global overhead
                        doc_text = _b64.b64decode(raw).decode("utf-8", errors="ignore").strip()
                        if doc_text:
                            lines.append("\n[Living Document]\n" + doc_text[:6000])
                # If the lead is in google/both mode, include latest Google Doc text as source of truth.
                if (
                    getattr(lead, "x_google_doc_id", False)
                    and getattr(lead, "x_living_doc_mode", "") in ("google", "both")
                ):
                    try:
                        gsvc = self.env["living.document.engine"]._get_google()
                        gtext = gsvc.get_document_content(lead.x_google_doc_id)
                        if gtext:
                            lines.append("\n[Google Living Document]\n" + gtext[:8000])
                    except Exception:
                        _logger.warning(
                            "sales_ai: Failed to include Google living document content for lead %s",
                            lead.id,
                            exc_info=True,
                        )
            except Exception:
                _logger.warning("sales_ai: Failed to include living document content for lead %s", lead.id, exc_info=True)

            if not lines:
                if chatter_enabled:
                    lead.message_post(
                        body=_("<b>[%s] Presale opened.</b> No prior discussions found.") % lead.x_presale_ref,
                        subtype_xmlid="mail.mt_note",
                    )
                _logger.info("sales_ai: Presale opened for lead %s — ref %s (no history)", lead.id, lead.x_presale_ref)
                continue

            try:
                summary = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "ticket_gist", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "ticket_gist_system"),
                    user_message="\n\n".join(lines)[:120000],
                    max_tokens=800,
                    expect_json=False,
                )
            except Exception:
                _logger.error("sales_ai: Presale gist generation failed for lead %s", lead.id, exc_info=True)
                continue

            # Store gist on lead field
            lead.x_ticket_gist = summary or ""
            if chatter_enabled:
                lead.message_post(
                    body="<h3>[%s] Presale Discussion Gist</h3>%s" % (
                        lead.x_presale_ref, summary or "No gist generated."
                    ),
                    subtype_xmlid="mail.mt_note",
                )
            _logger.info("sales_ai: Presale gist generated for lead %s — ref %s", lead.id, lead.x_presale_ref)

    @api.model
    def cron_generate_presale_agenda(self):
        """10:30 AM cron — generate daily agenda for each lead in active presale."""
        _logger.info("sales_ai: [CRON] Presale agenda generator started")
        today = fields.Date.today()
        leads = self.search([
            ("x_presale_status", "in", ["open", "ready_for_wbs", "wbs_done"]),
        ])
        _logger.info("sales_ai: [CRON] Found %d leads with active presale", len(leads))

        generated = 0
        for lead in leads:
            try:
                lead._generate_single_presale_agenda(today)
                generated += 1
            except Exception:
                _logger.error("sales_ai: Agenda generation failed for lead %s", lead.id, exc_info=True)

        _logger.info("sales_ai: [CRON] Presale agenda completed — %d/%d generated", generated, len(leads))

    def _generate_single_presale_agenda(self, today):
        """Generate agenda for one lead's presale."""
        self.ensure_one()
        since = self.x_last_agenda_date or (today - relativedelta(days=2))
        msgs = self.message_ids.filtered(
            lambda m: m.date and m.date.date() >= since
        ).sorted("date", reverse=False)

        lines = ["[Recent Lead Activity]"]
        for m in msgs:
            lines.append(f"[{m.date}] {m.author_id.display_name}: {(m.body or '')[:400]}")

        try:
            agenda_html = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "daily_agenda", "haiku"),
                system_prompt=prompts.get_system_prompt(self.env, "presale_agenda_system"),
                user_message="\n".join(lines)[:160000],
                max_tokens=800,
                expect_json=False,
            )
        except Exception:
            _logger.error("sales_ai: Agenda Claude call failed for lead %s", self.id, exc_info=True)
            return

        if agenda_html:
            self.message_post(body=agenda_html, subtype_xmlid="mail.mt_note")
            self.x_last_agenda_date = today
            _logger.info("sales_ai: Presale agenda posted on lead %s", self.id)

    def action_generate_presale_client_email(self, mom_content=None):
        """Draft a client-facing email based on presale discussion."""
        self.ensure_one()

        # Last 20 client conversations
        history_msgs = self.message_ids.sorted("date", reverse=False)[-20:]
        history = []
        for m in history_msgs:
            if m.message_type == "email":
                history.append(
                    f"[{m.date}] {m.author_id.display_name}: {m.subject or ''} :: {(m.body or '')[:400]}"
                )

        if mom_content is None:
            # Use last few internal notes
            note_subtype = self.env.ref("mail.mt_note", raise_if_not_found=False)
            notes = self.message_ids.filtered(
                lambda m: m.subtype_id and note_subtype and m.subtype_id.id == note_subtype.id
            ).sorted("date", reverse=False)[-5:]
            mom_content = "\n\n".join((n.body or "")[:800] for n in notes)

        user_msg = json.dumps(
            {"presale_mom": mom_content, "client_history": history},
            ensure_ascii=False,
        )

        try:
            resp = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "presale_email_drafter", "sonnet"),
                system_prompt=prompts.get_system_prompt(self.env, "presale_email_system"),
                user_message=user_msg,
                max_tokens=800,
                expect_json=True,
            )
        except Exception:
            _logger.error("sales_ai: Presale email draft failed for lead %s", self.id, exc_info=True)
            return

        subject = resp.get("subject") or _("Follow-up from our technical discussion")
        body_html = resp.get("body_html") or _(
            "<p>Following up on our recent technical discussion.</p>"
        )

        activity_type = self.env.ref(
            "sales_ai_integration.activity_type_presale_email", raise_if_not_found=False
        )
        self.env["mail.activity"].sudo().create(
            {
                'res_model_id': self.env.ref('crm.model_crm_lead').id,
                "res_id": self.id,
                "user_id": self.user_id.id,
                "activity_type_id": activity_type.id if activity_type else False,
                "note": "[AI DRAFT — Presale]\n\n" + subject + "\n\n" + body_html,
                "date_deadline": fields.Date.today(),
            }
        )
        _logger.info("sales_ai: Presale email draft activity created on lead %s", self.id)

    def action_request_proposal_from_ai(self):
        """
        ProposalGeneratorAgent (Sonnet) — generate a full sales proposal directly on this lead.
        Stores the result on the lead, posts executive summary to chatter,
        and sends to n8n to write the full document to Google Drive.
        """
        raise UserError(
            _("Proposal generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        if self.x_presale_status not in ("wbs_done", "ready_for_proposal", "ready_for_wbs"):
            raise UserError(_("Complete WBS validation before requesting a proposal."))

        self.x_presale_status = "ready_for_proposal"

        # Gather all presale MOMs
        all_presale_moms = []
        if self.x_presale_mom_history:
            try:
                for entry in json.loads(self.x_presale_mom_history):
                    all_presale_moms.append(entry.get("mom") or "")
            except Exception:
                pass

        # WBS summary
        wbs_summary = []
        if self.x_wbs_json:
            try:
                wbs_data = json.loads(self.x_wbs_json)
                for phase in wbs_data.get("wbs_phases") or []:
                    wbs_summary.append({
                        "phase_name": phase.get("phase_name", ""),
                        "task_count": len(phase.get("tasks", [])),
                    })
            except Exception:
                pass

        # Enrichment fields summary
        enriched_fields = {
            "company_industry": self.x_industry or "",
            "company_employee_count": self.x_employee_count_range or str(self.x_employee_count or ""),
            "company_hq_country": self.x_hq_country_id.name if self.x_hq_country_id else "",
            "company_hq_city": self.x_hq_city or "",
            "contact_seniority": self.x_contact_seniority_structured or "",
            "likely_pain_point": self.x_likely_pain_point or "",
        }

        # Requirements from recent notes
        note_subtype = self.env.ref("mail.mt_note", raise_if_not_found=False)
        recent_notes = self.message_ids.filtered(
            lambda m: m.subtype_id and note_subtype and m.subtype_id.id == note_subtype.id
        ).sorted("date", reverse=False)[-10:]
        requirements = [(n.body or "")[:500] for n in recent_notes if (n.body or "").strip()]

        proposal_input = {
            "lead_id": self.id,
            "ticket_id": self.x_presale_ref or ("PST-%d" % self.id),
            "client_company": self.partner_id.name or self.partner_name or "",
            "client_primary_contact": self.contact_name or "",
            "client_designation": self.function or "",
            "template_sections": [
                "Executive Summary",
                "Understanding Your Requirements",
                "Our Proposed Solution",
                "Technical Architecture",
                "Implementation Approach",
                "Project Team",
                "Timeline & Milestones",
                "Investment",
                "Why Choose Us",
                "Next Steps",
            ],
            "requirements": requirements,
            "wbs_summary": wbs_summary,
            "wbs_sheet_url": self.x_wbs_sheet_url or "",
            "pricing_table": [],
            "tech_stack": [],
            "our_team_profiles": [],
            "timeline_weeks": "",
            "go_live_date": "",
            "enriched_fields": enriched_fields,
            "ticket_gist": self.x_ticket_gist or "",
            "all_presale_moms": all_presale_moms,
            "rep_name": self.user_id.name if self.user_id else "",
            "rep_designation": (self.user_id.job_title if self.user_id else "") or "Account Executive",
        }

        try:
            proposal_result = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "proposal_generator", "sonnet"),
                system_prompt=prompts.get_system_prompt(self.env, "proposal_system"),
                user_message=json.dumps(proposal_input, ensure_ascii=False),
                max_tokens=800,
                expect_json=True,
            )
        except Exception:
            _logger.error("sales_ai: Proposal generation failed for lead %s", self.id, exc_info=True)
            raise UserError(_("Proposal generation failed. Please try again."))

        if not isinstance(proposal_result, dict):
            raise UserError(_("Proposal Agent returned an unexpected response."))

        exec_summary = proposal_result.get("executive_summary") or ""
        sections = proposal_result.get("proposal_sections") or {}
        word_count = proposal_result.get("word_count") or 0
        cover = proposal_result.get("cover_page") or {}

        # Post executive summary + section list to chatter
        chatter_parts = [
            "<h3>[%s] Proposal Draft Generated (%d words)</h3>" % (
                self.x_presale_ref or ("PST-%d" % self.id), word_count
            )
        ]
        if cover:
            chatter_parts.append("<p><b>%s</b><br/>%s</p>" % (
                cover.get("title", ""), cover.get("subtitle", "")
            ))
        if exec_summary:
            chatter_parts.append("<h4>Executive Summary</h4><p>%s</p>" % exec_summary)
        if sections:
            chatter_parts.append(
                "<p><b>Sections:</b> %s</p>" % ", ".join(sections.keys())
            )

        self.message_post(body="\n".join(chatter_parts), subtype_xmlid="mail.mt_note")
        _logger.info(
            "sales_ai: Proposal (Sonnet) generated for lead %s — %d words, %d sections",
            self.id, word_count, len(sections),
        )

        # Send to n8n to write to Google Drive
        self._n8n_safe_post(
            "proposal_request",
            {
                "lead_id": self.id,
                "presale_ref": self.x_presale_ref or ("PST-%d" % self.id),
                "proposal_result": proposal_result,
                "wbs_sheet_url": self.x_wbs_sheet_url or "",
            },
            lead=self,
            context_label="Proposal → Google Drive",
        )

        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Proposal Generated"),
                "type": "success",
                "message": _(
                    "AI proposal generated (%d words). "
                    "n8n will write to Google Drive and send back the URL."
                ) % word_count,
            },
        }

    # =========================================================================
    # PHASE 6: CLIENT MOM GENERATION
    # =========================================================================

    def action_generate_client_mom(
        self,
        transcript: str,
        meeting_date: str = "",
        meeting_duration: int = 0,
        attendees: list = None,
        conversation_id: str = "",
        conversation_url: str = "",
        source: str = "",
        meeting_name: str = "",
        meeting_id: int | None = None,
        request_payload_json: str | None = None,
    ):
        """Generate full MOM + client-safe draft email from meeting transcript.

        :param transcript: raw transcript text
        :param meeting_date: ISO date string (from n8n / Apollo)
        :param meeting_duration: duration in minutes
        :param attendees: list of dicts [{name, role, company, is_client}]
        :param conversation_url: Apollo conversation URL
        """
        self.ensure_one()
        conversation_id = (conversation_id or "").strip()
        _logger.info(
            "sales_ai: Generating client MOM for lead %s (transcript: %d chars)",
            self.id, len(transcript),
        )

        calendar_link = self.user_id.x_calendar_link if self.user_id else ""
        enrichment_fields = {}
        if self.x_apollo_data_raw:
            try:
                enrichment_fields = json.loads(self.x_apollo_data_raw)
            except Exception:
                pass

        meeting_date = meeting_date or str(fields.Date.today())
        client_company = self.partner_name or (self.partner_id.name if self.partner_id else "")

        from .transcript_tools import prune_transcript_text, transcript_text_to_toon

        pruned = prune_transcript_text(transcript, max_chars=45000)
        toon_text, _segs = transcript_text_to_toon(pruned, max_segments=300)

        claude_payload = json.dumps(
            {
                "transcript": transcript[:120000],
                "meeting_date": meeting_date,
                "meeting_duration": meeting_duration or 0,
                "attendees": attendees or [],
                "rep_name": self.user_id.name if self.user_id else "",
                "rep_designation": self.user_id.job_title if self.user_id else "Account Executive",
                "rep_calendar_link": calendar_link,
                "client_company": client_company,
                "enriched_fields": enrichment_fields,
            },
            ensure_ascii=False,
        )

        # Persist raw transcript FIRST so no data is lost if Claude fails.
        transcript_rec = False
        try:
            transcript_rec = self.env["sales.ai.meeting.transcript"].sudo().create(
                {
                    "lead_id": self.id,
                    "meeting_id": meeting_id if meeting_id else False,
                    "meeting_name": meeting_name or self.name or "",
                    "meeting_date": meeting_date or str(fields.Date.today()),
                    "meeting_start": False,
                    "meeting_duration": meeting_duration or 0,
                    "conversation_id": conversation_id or "",
                    "conversation_url": conversation_url or "",
                    "source": source or "meeting_done",
                    "transcript": transcript[:150000],
                    "payload_json": claude_payload,
                    "request_payload_json": request_payload_json or "",
                }
            )
        except Exception:
            _logger.error(
                "sales_ai: Failed to log meeting transcript entry for lead %s",
                self.id, exc_info=True,
            )

        # Stage A (Haiku): extract compact facts from pruned TOON
        facts = {}
        try:
            facts = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "client_mom", "haiku"),
                system_prompt=prompts.get_system_prompt(self.env, "client_mom_facts_system"),
                user_message=json.dumps(
                    {
                        "toon": toon_text,
                        "meeting_date": meeting_date,
                        "meeting_duration": meeting_duration or 0,
                        "attendees": attendees or [],
                        "client_company": client_company,
                        "rep_name": self.user_id.name if self.user_id else "",
                    },
                    ensure_ascii=False,
                ),
                max_tokens=1800,
                expect_json=True,
            )
        except Exception:
            _logger.error(
                "sales_ai: Client MOM facts extraction failed for lead %s",
                self.id, exc_info=True,
            )
            facts = {}

        # Stage B (Sonnet): compose final MOM JSON from facts
        resp = {}
        try:
            if isinstance(facts, dict) and facts:
                resp = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "client_mom", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "client_mom_compose_system"),
                    user_message=json.dumps(
                        {
                            "facts": facts,
                            "meeting_date": meeting_date,
                            "meeting_duration": meeting_duration or 0,
                            "attendees": attendees or [],
                            "rep_name": self.user_id.name if self.user_id else "",
                            "rep_designation": self.user_id.job_title if self.user_id else "Account Executive",
                            "rep_calendar_link": calendar_link,
                            "client_company": client_company,
                        },
                        ensure_ascii=False,
                    ),
                    max_tokens=2600,
                    expect_json=True,
                )
            else:
                resp = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "client_mom", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "client_mom_system"),
                    user_message=claude_payload,
                    max_tokens=4000,
                    expect_json=True,
                )
        except Exception:
            _logger.error(
                "sales_ai: Client MOM generation failed for lead %s",
                self.id, exc_info=True,
            )
            return

        if not resp or resp == {}:
            _logger.error(
                "sales_ai: Client MOM Claude returned empty/unparseable JSON for lead %s. "
                "This usually means the response was truncated or not valid JSON.",
                self.id,
            )

        # Write full Claude response back to transcript record
        if transcript_rec:
            try:
                transcript_rec.sudo().write({
                    "ai_generated_data": json.dumps(
                        {"facts": facts, "final": resp}, ensure_ascii=False
                    ),
                })
            except Exception:
                _logger.error(
                    "sales_ai: Failed to write ai_generated_data for transcript %s",
                    transcript_rec.id, exc_info=True,
                )

        raw_mom_md = _clean_internal_mom_text(resp.get("internal_mom") or "")
        raw_mom_html = resp.get("full_mom_html") or ""
        if raw_mom_html:
            full_mom = raw_mom_html
        elif raw_mom_md:
            full_mom = _format_internal_mom_html(raw_mom_md)
        else:
            full_mom = "<p>%s</p>" % _("No MOM generated.")

        email_subject = resp.get("client_email_subject") or _("Summary of our recent call")
        email_body_text = (
            resp.get("client_email_body")
            or resp.get("client_email_body_html")
            or "Thank you for your time."
        )
        action_items_rep = resp.get("action_items_rep") or []
        action_items_client = resp.get("action_items_client") or []
        next_meeting = resp.get("next_meeting_suggested", False)

        # --- Post internal MOM + action items in a single, well-formatted chatter note ---
        body_parts = [full_mom]
        if action_items_rep:
            body_parts.append(
                "<h4>%s</h4><ul>%s</ul>"
                % (
                    _("Rep action items"),
                    "".join("<li>%s</li>" % tools.html_escape(i) for i in action_items_rep),
                )
            )
        if action_items_client:
            body_parts.append(
                "<h4>%s</h4><ul>%s</ul>"
                % (
                    _("Client action items"),
                    "".join("<li>%s</li>" % tools.html_escape(i) for i in action_items_client),
                )
            )
        if next_meeting:
            body_parts.append(
                "<p><i>%s</i></p>"
                % _("Claude suggests scheduling a follow-up meeting.")
            )
        self.message_post(body="\n".join(body_parts), subtype_xmlid="mail.mt_note")

        # --- Update x_mom_history JSON ---
        mom_entry = {
            "date": meeting_date or str(fields.Date.today()),
            "internal_mom": full_mom,
            "client_email_subject": email_subject,
            "client_email_body": email_body_text,
            "action_items_rep": action_items_rep,
            "action_items_client": action_items_client,
            "next_meeting_suggested": next_meeting,
        }
        try:
            history = json.loads(self.x_mom_history or "[]")
        except Exception:
            history = []
        history.append(mom_entry)
        self.x_mom_history = json.dumps(history, ensure_ascii=False)

        # --- Create review activity for rep ---
        activity_type = self.env.ref(
            "sales_ai_integration.activity_type_client_mom", raise_if_not_found=False
        )
        note_html = """
<p><b>[AI DRAFT — Client MOM]</b></p>
<p><b>%s</b> %s</p>
<hr/>
%s
""" % (
            _("Subject:"),
            tools.html_escape(email_subject),
            tools.plaintext2html(email_body_text),
        )

        self.env["mail.activity"].sudo().create(
            {
                "res_model_id": self.env.ref("crm.model_crm_lead").id,
                "res_id": self.id,
                "user_id": self.user_id.id,
                "activity_type_id": activity_type.id if activity_type else False,
                "summary": _(
                    "Review & send meeting MOM to %s",
                    self.partner_name or self.contact_name or "client",
                ),
                "note": tools.html_sanitize(note_html),
                "date_deadline": fields.Date.today(),
            }
        )

        # MOM is ready for rep review: clear pending AI follow-up/reply activities.
        # Keep this in the main method (not only background wrappers) so cleanup
        # always runs regardless of how MOM generation was triggered.
        self._delete_next_planned_activities()

        # # --- Notify n8n ---
        # try:
        #     self._n8n().post("mom_generated_notification", {
        #         "lead_id": self.id,
        #         "lead_name": self.name,
        #         "company": self.partner_name or "",
        #         "contact_name": self.contact_name or "",
        #         "rep_name": self.user_id.name if self.user_id else "",
        #         "rep_email": self.user_id.email if self.user_id else "",
        #         "meeting_date": meeting_date or str(fields.Date.today()),
        #         "email_subject": email_subject,
        #         "action_items_count": len(action_items_rep) + len(action_items_client),
        #         "next_meeting_suggested": next_meeting,
        #         "source": "transcript_processing",
        #     })
        # except Exception:
        #     _logger.error(
        #         "sales_ai: n8n mom_generated notification failed for lead %s",
        #         self.id, exc_info=True,
        #     )

        _logger.info(
            "sales_ai: Client MOM posted + review activity created for lead %s",
            self.id,
        )

    def _sales_ai_try_mark_conversation_processed(self, conversation_id: str, keep_last: int = 50) -> bool:
        """
        Idempotency guard: returns True if conversation_id was newly recorded;
        returns False if it was already processed.
        """
        self.ensure_one()
        cid = (conversation_id or "").strip()
        if not cid:
            return True
        ICP = self.env["ir.config_parameter"].sudo()
        key = f"sales_ai.processed_conversation_ids.lead_{self.id}"
        # Serialize access per lead key to avoid concurrent create() collisions
        # on ir_config_parameter(key) unique constraint.
        self.env.cr.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", [key])
        try:
            existing = json.loads(ICP.get_param(key, default="[]") or "[]")
            if not isinstance(existing, list):
                existing = []
        except Exception:
            existing = []

        if cid in existing:
            return False

        existing.append(cid)
        if keep_last and len(existing) > keep_last:
            existing = existing[-keep_last:]

        ICP.set_param(key, json.dumps(existing, ensure_ascii=False))
        return True

    # ------------------------------------------------------------------
    # Transcript request (manual button + cron)
    # ------------------------------------------------------------------

    def action_request_meeting_transcript(self):
        """Button handler: ask n8n to fetch the transcript for this lead's latest meeting."""
        self.ensure_one()
        event = self._find_latest_linked_meeting()
        if not event:
            return {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "title": _("No linked meeting"),
                    "message": _("No calendar event is linked to this lead."),
                    "type": "warning",
                    "sticky": False,
                },
            }
        # if event.x_transcript_requested:
        #     return {
        #         "type": "ir.actions.client",
        #         "tag": "display_notification",
        #         "params": {
        #             "title": _("Already requested"),
        #             "message": _(
        #                 "Transcript for '%s' was already requested. "
        #                 "Check back shortly or re-sync from n8n.",
        #                 event.name or "",
        #             ),
        #             "type": "info",
        #             "sticky": False,
        #         },
        #     }

        _logger.info(
            "sales_ai: [TRANSCRIPT-BTN] Manual transcript request started for lead %s / event %s",
            self.id,
            event.id,
        )
        try:
            self._post_transcript_request(event, source="manual_button")
        except Exception as exc:
            _logger.error(
                "sales_ai: [TRANSCRIPT-BTN] Error requesting transcript for lead %s / event %s: %s",
                self.id,
                event.id,
                exc,
                exc_info=True,
            )
            return {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "title": _("Transcript request failed"),
                    "message": _(
                        "Could not request transcript for '%s'. "
                        "Please check Sales AI → n8n settings and server logs.",
                        event.name or "",
                    ),
                    "type": "danger",
                    "sticky": False,
                },
            }

        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Transcript requested"),
                "message": _(
                    "n8n has been asked to fetch the transcript for '%s'. "
                    "MOM will be generated automatically once received.",
                    event.name or "",
                ),
                "type": "success",
                "sticky": False,
            },
        }

    @api.model
    def cron_request_meeting_transcripts(self):
        """Every 30 min: request transcripts for meetings that ended ~1 hour ago."""
        from datetime import timedelta

        now = fields.Datetime.now()
        window_start = now - timedelta(minutes=90)
        window_end = now - timedelta(minutes=30)

        Event = self.env["calendar.event"].sudo()
        events = Event.search([
            ("stop", ">=", window_start),
            ("stop", "<=", window_end),
            ("opportunity_id", "!=", False),
            ("x_transcript_requested", "=", False),
            ("x_is_presale_meeting", "=", False),
        ])

        if not events:
            return

        _logger.info(
            "sales_ai: [TRANSCRIPT-CRON] Found %d meetings that ended ~1h ago, requesting transcripts",
            len(events),
        )
        for event in events:
            lead = event.opportunity_id
            if not lead or not lead.active:
                continue
            try:
                lead._post_transcript_request(event, source="cron")
            except Exception:
                _logger.error(
                    "sales_ai: Transcript request failed for event %s (lead %s)",
                    event.id, lead.id, exc_info=True,
                )

    def _find_latest_linked_meeting(self):
        """Return the most recent calendar.event linked to this lead."""
        self.ensure_one()
        return self.env["calendar.event"].sudo().search(
            [("opportunity_id", "=", self.id)],
            order="start desc",
            limit=1,
        )

    def _post_transcript_request(self, event, source="cron"):
        """POST to n8n asking it to fetch the meeting transcript from Apollo."""
        attendees = [p for p in event.partner_ids if p.email or p.name]
        attendee_emails = [p.email for p in attendees if p.email]
        attendee_names = [p.name for p in attendees if p.name]
        ICP = self.env["ir.config_parameter"].sudo()
        odoo_base_url = (ICP.get_param("sales_ai.odoo_base_url", default="") or "").strip().rstrip("/")
        odoo_api_key = (ICP.get_param("sales_ai.odoo_api_key", default="") or "").strip()
        callback_endpoint = "/odoo/api/sales_ai/meeting_done"
        callback_url = (
            f"{odoo_base_url}{callback_endpoint}?db={self.env.cr.dbname}"
            if odoo_base_url
            else ""
        )
        payload = {
            "lead_id": self.id,
            "lead_name": self.name,
            "company": self.partner_name or "",
            "contact_name": self.contact_name or "",
            "contact_email": self.email_from or "",
            "rep_name": self.user_id.name if self.user_id else "",
            "rep_email": self.user_id.email if self.user_id else "",
            "lead_url": f"/web#id={self.id}&model=crm.lead&view_type=form",
            "meeting_id": event.id,
            "meeting_name": event.name or "",
            "meeting_start": str(event.start) if event.start else "",
            "meeting_stop": str(event.stop) if event.stop else "",
            "attendee_emails": attendee_emails,
            "participants": attendee_names,
            "calendar_owner": event.user_id.name if event.user_id else "",
            "calendar_owner_email": event.user_id.email if event.user_id else "",
            "source": source,
            "type": "client",
            "meeting_type": "client",
            "is_presale_meeting": False,
            # Explicit callback metadata prevents n8n from posting to a wrong DB.
            "odoo_callback_endpoint": callback_endpoint,
            "odoo_callback_url": callback_url,
            "odoo_callback_api_key": odoo_api_key,
            "odoo_db": self.env.cr.dbname,
        }
        _logger.info(
            "sales_ai: [TRANSCRIPT-REQ] lead_id=%s event_id=%s source=%s attendees=%s participants=%s",
            self.id,
            event.id,
            source,
            attendee_emails,
            attendee_names,
        )

        resp = self._n8n_safe_post(
            "request_meeting_transcript", payload,
            lead=self, context_label="Transcript request for '%s'" % (event.name or ""),
        )
        if resp is None:
            raise UserError(_(
                "Could not reach n8n to request the meeting transcript. "
                "Check the n8n connection in Sales AI settings."
            ))

        _logger.info(
            "sales_ai: [TRANSCRIPT-REQ] n8n response for lead %s / event %s: %s",
            self.id, event.id, repr(resp)[:500],
        )

        event.x_transcript_requested = True

        self.message_post(
            body=_(
                "Transcript requested for meeting '%s' (source: %s). "
                "MOM will be generated once n8n returns the transcript.",
                event.name or "", source,
            ),
            subtype_xmlid="mail.mt_note",
        )
        _logger.info(
            "sales_ai: Transcript requested for event %s (lead %s, source=%s)",
            event.id, self.id, source,
        )

    # =========================================================================
    # PHASE 7: LEAD CLOSURE RETROSPECTIVE
    # =========================================================================

    def _find_presale_ticket_for_retro(self):
        """Resolve linked presale ticket robustly across helpdesk variants."""
        self.ensure_one()
        tickets = self._find_presale_tickets_for_retro()
        return tickets[:1]

    def _find_presale_tickets_for_retro(self):
        """Resolve all linked presale tickets for retrospective posting."""
        self.ensure_one()
        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        tickets = Ticket.browse()

        # Primary link used by this module.
        tickets |= Ticket.search([("x_linked_lead_id", "=", self.id)])

        # Some helpdesk variants link via many2many sh_lead_ids.
        if "sh_lead_ids" in Ticket._fields:
            tickets |= Ticket.search([("sh_lead_ids", "in", [self.id])])

        # Fallback by presale reference when available.
        if self.x_presale_ref and "x_presale_ref" in Ticket._fields:
            tickets |= Ticket.search([("x_presale_ref", "=", self.x_presale_ref)])

        return tickets.sorted("id", reverse=True)

    def action_preview_closure_retro_payload(self):
        """Generate and attach the exact closure-retro payload JSON for inspection."""
        self.ensure_one()
        payload = self._build_closure_retro_payload()
        payload_json = json.dumps(payload, ensure_ascii=False, indent=2)
        filename = "retro_payload_lead_%s.json" % self.id

        attachment = self.env["ir.attachment"].sudo().create({
            "name": filename,
            "type": "binary",
            "datas": base64.b64encode(payload_json.encode("utf-8")),
            "mimetype": "application/json",
            "res_model": "crm.lead",
            "res_id": self.id,
        })

        self.message_post(
            body=_(
                "Closure retro payload preview generated and attached: <b>%s</b>",
                filename,
            ),
            attachment_ids=[attachment.id],
            subtype_xmlid="mail.mt_note",
        )
        _logger.info(
            "sales_ai: Retro payload preview generated for lead %s attachment=%s",
            self.id,
            attachment.id,
        )
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Retro Payload Ready"),
                "message": _("Attached %s on chatter.", filename),
                "type": "success",
                "sticky": False,
            },
        }

    def _build_closure_retro_payload(self):
        """Build full retrospective context from lead + presale history."""
        self.ensure_one()
        lead = self

        outcome = "Won" if (lead.stage_id and lead.stage_id.is_won) else "Lost"
        closed_dt = lead.date_closed or lead.write_date or fields.Datetime.now()
        days_to_close = 0
        if lead.create_date:
            days_to_close = max(0, (closed_dt.date() - lead.create_date.date()).days)

        # ------------------------------
        # Lead history (emails/chatter/stage tracking)
        # ------------------------------
        msgs = lead.message_ids.sorted("date", reverse=False)
        email_thread = []
        history_lines = []
        stage_events = []
        mail_partner_ids = set(self.env["res.users"].sudo().search([]).mapped("partner_id").ids)
        incoming_waiting = []
        response_hours = []

        for m in msgs[-600:]:
            if not m.date:
                continue
            who = m.author_id.display_name or (m.email_from or "")
            subj = m.subject or ""
            body_plain = tools.html2plaintext(m.body or "").replace("\n", " ").strip()
            body_short = body_plain[:1400]
            history_lines.append("[%s] %s: %s :: %s" % (m.date, who, subj, body_short[:800]))

            if m.message_type == "email":
                is_internal = bool(m.author_id and m.author_id.id in mail_partner_ids)
                direction = "outgoing" if is_internal else "incoming"
                email_thread.append({
                    "date": str(m.date),
                    "direction": direction,
                    "author": who,
                    "subject": subj,
                    "excerpt": body_short,
                })
                if direction == "incoming":
                    incoming_waiting.append(fields.Datetime.from_string(str(m.date)))
                else:
                    out_dt = fields.Datetime.from_string(str(m.date))
                    still_waiting = []
                    for in_dt in incoming_waiting:
                        if out_dt and in_dt and out_dt >= in_dt:
                            response_hours.append((out_dt - in_dt).total_seconds() / 3600.0)
                        else:
                            still_waiting.append(in_dt)
                    incoming_waiting = still_waiting

            for tv in m.tracking_value_ids:
                # Odoo's mail.tracking.value stores the tracked field as field_id.
                # In v19, there is no field_desc attribute.
                field_name = (tv.field_id.name or "") if tv.field_id else ""
                field_relation = (tv.field_id.relation or "") if tv.field_id else ""
                if field_name in ("stage_id", "stage") or field_relation == "crm.stage":
                    stage_events.append({
                        "date": str(m.date),
                        "from": tv.old_value_char or "",
                        "to": tv.new_value_char or "",
                    })

        avg_response_hours = round(sum(response_hours) / len(response_hours), 2) if response_hours else 0.0
        max_response_hours = round(max(response_hours), 2) if response_hours else 0.0

        # ------------------------------
        # Activities (including completed)
        # ------------------------------
        Activity = self.env["mail.activity"].sudo().with_context(active_test=False)
        activities = Activity.search(
            [("res_model", "=", "crm.lead"), ("res_id", "=", lead.id)],
            order="create_date asc, id asc",
        )
        activity_history = []
        for act in activities:
            activity_history.append({
                "type": act.activity_type_id.display_name if act.activity_type_id else "",
                "summary": act.summary or "",
                "owner": act.user_id.display_name if act.user_id else "",
                "deadline": str(act.date_deadline) if act.date_deadline else "",
                "completed_on": str(act.date_done) if act.date_done else "",
                "state": act.state or ("done" if not act.active else "planned"),
            })

        # ------------------------------
        # Stage timeline + bottleneck
        # ------------------------------
        pipeline_stage_history = []
        if lead.create_date:
            ordered = sorted(stage_events, key=lambda e: e.get("date") or "")
            cursor_dt = lead.create_date
            cursor_stage = ordered[0]["from"] if ordered and ordered[0].get("from") else (
                lead.stage_id.display_name if lead.stage_id else "Unknown"
            )
            for ev in ordered:
                ev_dt = fields.Datetime.from_string(ev["date"])
                if ev_dt and cursor_dt and ev_dt >= cursor_dt:
                    pipeline_stage_history.append({
                        "stage": cursor_stage or "Unknown",
                        "date": str(cursor_dt),
                        "duration_days": max(0, (ev_dt.date() - cursor_dt.date()).days),
                    })
                    cursor_stage = ev.get("to") or cursor_stage
                    cursor_dt = ev_dt
            pipeline_stage_history.append({
                "stage": cursor_stage or (lead.stage_id.display_name if lead.stage_id else "Unknown"),
                "date": str(cursor_dt),
                "duration_days": max(0, (closed_dt.date() - cursor_dt.date()).days) if cursor_dt else 0,
            })

        longest_stage = ""
        longest_stage_days = 0
        if pipeline_stage_history:
            top = max(pipeline_stage_history, key=lambda s: s.get("duration_days") or 0)
            longest_stage = top.get("stage") or ""
            longest_stage_days = int(top.get("duration_days") or 0)

        # ------------------------------
        # MOMs + presale ticket discussions
        # ------------------------------
        all_moms = []
        if lead.x_mom_history:
            try:
                for item in json.loads(lead.x_mom_history or "[]"):
                    rec = item or {}
                    txt = rec.get("internal_mom") or rec.get("full_mom_html") or rec.get("summary") or ""
                    if txt:
                        all_moms.append(str(txt))
            except Exception:
                pass
        if lead.x_presale_mom_history:
            try:
                for item in json.loads(lead.x_presale_mom_history or "[]"):
                    rec = item or {}
                    txt = rec.get("mom") or rec.get("summary") or ""
                    if txt:
                        all_moms.append(str(txt))
            except Exception:
                pass

        ticket = lead._find_presale_ticket_for_retro()
        ticket_discussions = []
        if ticket:
            for tm in ticket.message_ids.sorted("date", reverse=False)[-250:]:
                plain = tools.html2plaintext(tm.body or "").replace("\n", " ").strip()
                if not plain:
                    continue
                ticket_discussions.append({
                    "date": str(tm.date) if tm.date else "",
                    "author": tm.author_id.display_name if tm.author_id else "",
                    "subject": tm.subject or "",
                    "excerpt": plain[:1200],
                })

        # ------------------------------
        # Presale / proposal / WBS + meeting metrics
        # ------------------------------
        presale_notes = []
        if lead.x_ticket_gist:
            presale_notes.append(lead.x_ticket_gist)
        presale_notes.extend(all_moms[-12:])

        # calendar.event is linked to CRM via standard Odoo field opportunity_id
        # (see calendar_meeting_linker.py).
        meeting_count = self.env["calendar.event"].sudo().search_count([
            ("opportunity_id", "=", lead.id),
            ("x_is_presale_meeting", "=", False),
        ])
        presale_meeting_count = self.env["calendar.event"].sudo().search_count([
            ("opportunity_id", "=", lead.id),
            ("x_is_presale_meeting", "=", True),
        ])

        lost_reason = ""
        if hasattr(lead, "lost_reason_id") and lead.lost_reason_id:
            lost_reason = lead.lost_reason_id.display_name
        win_loss_reason = lost_reason or lead.x_classification_reason or ""

        proposal_sent = bool(
            lead.x_proposal_drive_url
            or lead.x_presale_status in ("proposal_sent", "proposal_generated")
        )
        wbs_data = {}
        if lead.x_wbs_json:
            try:
                wbs_data = json.loads(lead.x_wbs_json or "{}") or {}
            except Exception:
                wbs_data = {}

        payload = {
            "outcome": outcome.lower(),
            "lead_name": lead.name,
            "client_company": lead.partner_id.name if lead.partner_id else "",
            "rep_name": lead.user_id.name if lead.user_id else "",
            "deal_value": lead.expected_revenue or 0,
            "deal_value_band": "high" if (lead.expected_revenue or 0) >= 100000 else (
                "mid" if (lead.expected_revenue or 0) >= 20000 else "low"
            ),
            "lead_score": lead.x_lead_score or 0,
            "lead_score_band": lead.x_lead_score_band or "",
            "icp_match_signals": lead.x_icp_match_signals or "",
            "win_loss_reason": win_loss_reason,
            "days_to_close": days_to_close,
            "pipeline_stage_history": pipeline_stage_history,
            "stage_stalled_longest": {"stage": longest_stage, "days": longest_stage_days},
            "meeting_count": meeting_count,
            "presale_meeting_count": presale_meeting_count,
            "email_thread": email_thread[-180:],
            "history": history_lines[-350:],
            "activities": activity_history[-250:],
            "all_moms": all_moms[-40:],
            "response_time_audit": {
                "pairs_count": len(response_hours),
                "average_hours": avg_response_hours,
                "max_hours": max_response_hours,
                "samples_hours": [round(x, 2) for x in response_hours[-40:]],
            },
            "proposal_sent": proposal_sent,
            "proposal_details": {
                "drive_url": lead.x_proposal_drive_url or "",
                "status": lead.x_presale_status or "",
                "wbs_sheet_url": lead.x_wbs_sheet_url or "",
            },
            "wbs": wbs_data,
            "presale_ticket": {
                "exists": bool(ticket),
                "id": ticket.id if ticket else 0,
                "presale_ref": (ticket.x_presale_ref if ticket else "") or lead.x_presale_ref or "",
                "discussion": ticket_discussions[-200:],
            },
            "presale_ticket_notes": "\n\n".join(presale_notes[-12:])[:20000],
            "email_summary": "\n".join(history_lines[-40:])[:12000],
            "internal_notes_summary": "\n".join(presale_notes[-8:])[:6000],
        }
        return payload

    def action_generate_closure_retro(self):
        """Generate a Won/Lost retrospective.

        Posts to the linked helpdesk ticket (primary) or the lead (fallback).
        Also sends an internal Odoo email notification.
        """
        for lead in self:
            outcome = "Won" if lead.stage_id.is_won else "Lost"
            _logger.info("sales_ai: Generating %s retrospective for lead %s", outcome, lead.id)
            # Mark immediately to avoid duplicate generation on repeated write hooks.
            if not lead.x_retro_logged:
                lead.sudo().write({"x_retro_logged": True})
            data = lead._build_closure_retro_payload()

            try:
                html = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "retrospective", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "retro_system"),
                    user_message=json.dumps(data, ensure_ascii=False)[:160000],
                    max_tokens=1800,
                    expect_json=False,
                )
            except Exception:
                _logger.error("sales_ai: Closure retro failed for lead %s", lead.id, exc_info=True)
                lead.sudo().write({"x_retro_logged": False})
                continue

            if html:
                html = tools.html_sanitize(html)
            else:
                html = "<p>Retro not generated.</p>"

            # Always post retrospective on the lead.
            lead.message_post(
                body=html,
                subtype_xmlid="mail.mt_note",
            )
            tickets = lead._find_presale_tickets_for_retro()
            if tickets:
                for ticket in tickets:
                    ticket.message_post(
                        body=html,
                        subtype_xmlid="mail.mt_note",
                    )
                tickets.write({"x_retro_logged": True})
                try:
                    digest = "[%s] %s — %s | %s | Retro ready on ticket %s" % (
                        outcome,
                        lead.partner_id.name if lead.partner_id else (lead.name or ""),
                        (lead.expected_revenue or 0),
                        lead.user_id.name if lead.user_id else "Unassigned",
                        tickets[0].x_presale_ref or lead.x_presale_ref or ("PST-%s" % tickets[0].id),
                    )
                    body = (
                        "<p><b>Deal retrospective ready</b></p>"
                        "<p>%s</p>"
                        "<p><b>Lead:</b> %s (#%s)</p>"
                        "<p><b>Company:</b> %s</p>"
                        "<p><b>Rep:</b> %s</p>"
                        "<p><b>Expected Revenue:</b> %s</p>"
                    ) % (
                        tools.html_escape(digest),
                        tools.html_escape(lead.name or ""),
                        lead.id,
                        tools.html_escape(lead.partner_id.name if lead.partner_id else ""),
                        tools.html_escape(lead.user_id.name if lead.user_id else "Unassigned"),
                        lead.expected_revenue or 0,
                    )
                    recipients = []
                    if lead.user_id and lead.user_id.email:
                        recipients.append(lead.user_id.email)
                    lead._sales_ai_send_email_notification(
                        subject="[%s] Deal Retro Ready - %s" % (outcome, lead.name or "Lead"),
                        body_html=body,
                        recipients=recipients,
                    )
                except Exception:
                    self.env.cr.rollback()
                    _logger.error("sales_ai: Retro email notify failed for lead %s", lead.id, exc_info=True)
            else:
                try:
                    digest = "[%s] %s — %s | %s | Retro ready on lead #%s" % (
                        outcome,
                        lead.partner_id.name if lead.partner_id else (lead.name or ""),
                        (lead.expected_revenue or 0),
                        lead.user_id.name if lead.user_id else "Unassigned",
                        lead.id,
                    )
                    body = (
                        "<p><b>Deal retrospective ready</b></p>"
                        "<p>%s</p>"
                        "<p><b>Lead:</b> %s (#%s)</p>"
                        "<p><b>Company:</b> %s</p>"
                        "<p><b>Rep:</b> %s</p>"
                        "<p><b>Expected Revenue:</b> %s</p>"
                    ) % (
                        tools.html_escape(digest),
                        tools.html_escape(lead.name or ""),
                        lead.id,
                        tools.html_escape(lead.partner_id.name if lead.partner_id else ""),
                        tools.html_escape(lead.user_id.name if lead.user_id else "Unassigned"),
                        lead.expected_revenue or 0,
                    )
                    recipients = []
                    if lead.user_id and lead.user_id.email:
                        recipients.append(lead.user_id.email)
                    lead._sales_ai_send_email_notification(
                        subject="[%s] Deal Retro Ready - %s" % (outcome, lead.name or "Lead"),
                        body_html=body,
                        recipients=recipients,
                    )
                except Exception:
                    self.env.cr.rollback()
                    _logger.error("sales_ai: Retro email notify failed for lead %s", lead.id, exc_info=True)
            lead.x_retro_logged = True
            _logger.info("sales_ai: %s retrospective posted for lead %s", outcome, lead.id)

    def action_generate_closure_retro_async(self):
        for lead in self:
            lead.sudo().write({"x_retro_logged": True})
            lead.message_post(
                body=_("Deal retrospective generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background("_bg_generate_closure_retro")
        return True

    def _bg_generate_closure_retro(self):
        self.ensure_one()
        try:
            self.action_generate_closure_retro()
        except Exception:
            self.env.cr.rollback()
            self.sudo().write({"x_retro_logged": False})
            _logger.error("sales_ai: background closure retro failed for lead %s", self.id, exc_info=True)

    # =========================================================================
    # PHASE 8: ESCALATION CRON
    # =========================================================================

    @api.model
    def cron_check_human_pause_escalations(self):
        """Daily 08:00 cron: check overdue AI drafts, MOMs, stale WBS."""
        _logger.info("sales_ai: [CRON] Escalation check started")
        today = fields.Date.today()
        now = fields.Datetime.now()

        Activity = self.env["mail.activity"].sudo()
        # HP1 & HP3: overdue AI email drafts
        overdue_drafts = Activity.search(
            [
                (
                    "activity_type_id",
                    "in",
                    [
                        self.env.ref("sales_ai_integration.activity_type_followup_email").id,
                        self.env.ref("sales_ai_integration.activity_type_presale_email").id,
                    ],
                ),
                ("date_deadline", "<", today),
                ("note", "ilike", "AI DRAFT%"),
            ]
        )
        for act in overdue_drafts:
            days_overdue = (today - act.date_deadline).days
            lead = self.browse(act.res_id)
            if not lead.exists():
                continue
            payload = {
                "lead_id": lead.id,
                "lead_name": lead.name,
                "rep": act.user_id.name,
                "days_overdue": days_overdue,
            }
            if days_overdue == 1:
                payload["level"] = "warning"
                recipients = []
                if act.user_id and act.user_id.email:
                    recipients.append(act.user_id.email)
                lead._sales_ai_send_email_notification(
                    subject="[Warning] Follow-up draft overdue - %s" % (lead.name or "Lead"),
                    body_html=(
                        "<p>Follow-up draft is overdue.</p>"
                        "<p><b>Lead:</b> %s (#%s)</p>"
                        "<p><b>Rep:</b> %s</p>"
                        "<p><b>Days overdue:</b> %s</p>"
                    ) % (
                        tools.html_escape(lead.name or ""),
                        lead.id,
                        tools.html_escape(act.user_id.name if act.user_id else ""),
                        days_overdue,
                    ),
                    recipients=recipients,
                )
            elif days_overdue >= 2:
                payload["level"] = "urgent"
                recipients = []
                if act.user_id and act.user_id.email:
                    recipients.append(act.user_id.email)
                lead._sales_ai_send_email_notification(
                    subject="[Urgent] Follow-up draft overdue - %s" % (lead.name or "Lead"),
                    body_html=(
                        "<p><b>Urgent:</b> Follow-up draft is overdue.</p>"
                        "<p><b>Lead:</b> %s (#%s)</p>"
                        "<p><b>Rep:</b> %s</p>"
                        "<p><b>Days overdue:</b> %s</p>"
                    ) % (
                        tools.html_escape(lead.name or ""),
                        lead.id,
                        tools.html_escape(act.user_id.name if act.user_id else ""),
                        days_overdue,
                    ),
                    recipients=recipients,
                )

        # HP2: overdue MOM reviews
        mom_type = self.env.ref(
            "sales_ai_integration.activity_type_client_mom", raise_if_not_found=False
        )
        if mom_type:
            overdue_moms = Activity.search(
                [("activity_type_id", "=", mom_type.id), ("date_deadline", "<", today)]
            )
            for act in overdue_moms:
                lead = self.browse(act.res_id)
                if not lead.exists():
                    continue
                hours_since = (
                    now - fields.Datetime.from_string(str(act.date_deadline) + " 00:00:00")
                ).total_seconds() / 3600.0
                payload = {
                    "lead_id": lead.id,
                    "lead_name": lead.name,
                    "rep": act.user_id.name,
                    "hours_overdue": hours_since,
                }
                if 4 <= hours_since < 24:
                    payload["level"] = "warning"
                    recipients = []
                    if act.user_id and act.user_id.email:
                        recipients.append(act.user_id.email)
                    lead._sales_ai_send_email_notification(
                        subject="[Warning] MOM review overdue - %s" % (lead.name or "Lead"),
                        body_html=(
                            "<p>MOM review is overdue.</p>"
                            "<p><b>Lead:</b> %s (#%s)</p>"
                            "<p><b>Rep:</b> %s</p>"
                            "<p><b>Hours overdue:</b> %.2f</p>"
                        ) % (
                            tools.html_escape(lead.name or ""),
                            lead.id,
                            tools.html_escape(act.user_id.name if act.user_id else ""),
                            hours_since,
                        ),
                        recipients=recipients,
                    )
                elif hours_since >= 24:
                    payload["level"] = "urgent"
                    recipients = []
                    if act.user_id and act.user_id.email:
                        recipients.append(act.user_id.email)
                    lead._sales_ai_send_email_notification(
                        subject="[Urgent] MOM review overdue - %s" % (lead.name or "Lead"),
                        body_html=(
                            "<p><b>Urgent:</b> MOM review is overdue.</p>"
                            "<p><b>Lead:</b> %s (#%s)</p>"
                            "<p><b>Rep:</b> %s</p>"
                            "<p><b>Hours overdue:</b> %.2f</p>"
                        ) % (
                            tools.html_escape(lead.name or ""),
                            lead.id,
                            tools.html_escape(act.user_id.name if act.user_id else ""),
                            hours_since,
                        ),
                        recipients=recipients,
                    )

        # HP4: WBS validation stale leads (ready_for_wbs for too long)
        stale_wbs = self.search([
            ("x_presale_status", "=", "ready_for_wbs"),
            ("write_date", "<", now - relativedelta(days=2)),
        ])
        for lead in stale_wbs:
            days_waiting = (now.date() - lead.write_date.date()).days
            payload = {
                "lead_id": lead.id,
                "lead_name": lead.name,
                "days_waiting": days_waiting,
            }
            if days_waiting in (2, 4, 7):
                payload["level"] = "warning" if days_waiting == 2 else "urgent"
                recipients = []
                if lead.user_id and lead.user_id.email:
                    recipients.append(lead.user_id.email)
                lead._sales_ai_send_email_notification(
                    subject="[%s] WBS stale - %s" % (
                        "Warning" if days_waiting == 2 else "Urgent",
                        lead.name or "Lead",
                    ),
                    body_html=(
                        "<p>WBS validation is stale.</p>"
                        "<p><b>Lead:</b> %s (#%s)</p>"
                        "<p><b>Days waiting:</b> %s</p>"
                    ) % (
                        tools.html_escape(lead.name or ""),
                        lead.id,
                        days_waiting,
                    ),
                    recipients=recipients,
                )

        _logger.info("sales_ai: [CRON] Escalation check completed")

    # =========================================================================
    # PHASE 16: STALE DEAL MONITOR (daily 08:00)
    # =========================================================================

    @api.model
    def cron_stale_deal_monitor(self):
        """Compatibility wrapper. New stale detection lives in service model."""
        return self.env["sales.ai.stale.lead.checker"].sudo().run_daily_check()


# =============================================================================
# LIFECYCLE HOOKS
# =============================================================================

class CrmLeadLifecycle(models.Model):
    """
    Lost lead retro via write override.
    base.automation on_write skips archived records, so we intercept here.
    """

    _name = "crm.lead"
    _inherit = ["crm.lead", "sales.ai.background.mixin"]

    def write(self, vals):
        going_lost = self.env["crm.lead"]
        pre_state = {
            lead.id: {
                "active": lead.active,
                "is_won": bool(lead.stage_id and lead.stage_id.is_won),
                "stage_id": lead.stage_id.id if lead.stage_id else False,
            }
            for lead in self
        }
        if "active" in vals and not vals["active"]:
            going_lost = self.filtered(
                lambda l: l.active and not l.stage_id.is_won
            )

        # Detect leads gaining a new owner (lead assignment event)
        new_owner_ids = None
        if "user_id" in vals and vals["user_id"]:
            # Many2one write semantics: an int or (x, id, 0); only handle simple int
            new_owner_ids = self.filtered(lambda l: not l.user_id and vals["user_id"])

        res = super().write(vals)

        # Track stage entry date to drive stale monitor accurately.
        if "stage_id" in vals:
            self.filtered(lambda l: l.active).sudo().write({
                "x_stale_monitor_start": fields.Date.today()
            })

        # Trigger closure retrospective on won/lost transitions once.
        closure_candidates = self.env["crm.lead"]
        for lead in self.with_context(active_test=False):
            old = pre_state.get(lead.id, {})
            became_won = (not old.get("is_won")) and bool(lead.stage_id and lead.stage_id.is_won)
            old_stage_id = old.get("stage_id")
            new_stage_id = lead.stage_id.id if lead.stage_id else False
            became_lost_stage = (
                old_stage_id != new_stage_id
                and bool(lead.stage_id)
                and not lead.stage_id.is_won
                and ("lost" in (lead.stage_id.display_name or "").lower())
            )
            became_lost_archive = old.get("active", True) and not lead.active and not (lead.stage_id and lead.stage_id.is_won)
            became_lost = became_lost_stage or became_lost_archive
            if (became_won or became_lost) and not lead.x_retro_logged:
                closure_candidates |= lead
        if closure_candidates:
            try:
                _logger.info(
                    "sales_ai: Triggering closure retro for %d leads", len(closure_candidates)
                )
                closure_candidates.action_generate_closure_retro_async()
            except Exception:
                _logger.error("sales_ai: Closure retro auto-trigger failed", exc_info=True)

        # After write, create assignment activity + auto-ack draft for newly assigned leads
        if new_owner_ids:
            for lead in new_owner_ids.exists():
                try:
                    # Only generate assignment + auto-ack when enrichment + scoring
                    # are already done and the lead is genuine. Otherwise, wait until
                    # the pipeline completes.
                    if lead.x_enrichment_done and lead.x_scoring_done and lead.x_classification == "genuine":
                        # Activity = self.env["mail.activity"].sudo()
                        # activity_type = self.env.ref(
                        #     "mail.mail_activity_data_email", raise_if_not_found=False
                        # )
                        # Activity.create(
                        #     {
                        #         "res_model_id": self.env.ref('crm.model_crm_lead').id,
                        #         "res_id": lead.id,
                        #         "user_id": lead.user_id.id,
                        #         "activity_type_id": activity_type.id if activity_type else False,
                        #         "summary": _("New lead assigned — review & send auto-ack"),
                        #         "note": _(
                        #             "Lead %s assigned to you. Review the AI-generated auto-ack draft and send today.",
                        #             lead.name or "",
                        #         ),
                        #         "date_deadline": fields.Date.today(),
                        #     }
                        # )
                        # Generate AI auto-ack asynchronously to avoid blocking write automation.
                        lead.message_post(
                            body=_("Auto-ack draft generation started in background."),
                            subtype_xmlid="mail.mt_note",
                        )
                        lead._ai_run_in_background("_bg_action_send_auto_ack")
                    else:
                        _logger.info(
                            "sales_ai: [AUTO-ACK] Delay assignment/auto-ack for lead %s "
                            "(enriched=%s, scored=%s, classification=%s).",
                            lead.id,
                            lead.x_enrichment_done,
                            lead.x_scoring_done,
                            lead.x_classification,
                        )
                except Exception:
                    _logger.error(
                        "sales_ai: Failed to create assignment activity / auto-ack draft for lead %s",
                        lead.id,
                        exc_info=True,
                    )
        return res


# =============================================================================
# MESSAGE POST OVERRIDE (reply detection + discussion sync)
# =============================================================================

class CrmLeadMessage(models.Model):
    """
    Extend message_post to:
      - detect customer replies → classify intent → reset follow-ups
      - sync external discussions to presale (internal note on same lead)
    """

    _inherit = "crm.lead"

    def message_post(self, **kwargs):
        is_incoming_email = False
        body = kwargs.get("body") or ""
        if isinstance(body, str) and body:
            normalized = _normalize_chatter_body(body)
            message_type = kwargs.get("message_type", "comment")
            # Keep email bodies plain/neutral; enforce professional formatting
            # for chatter notes/comments posted by CRM lead flows.
            if message_type != "email":
                normalized = _render_professional_chatter_html(normalized)
            kwargs["body"] = normalized
            body = normalized
        author_id = kwargs.get("author_id")
        message_type = kwargs.get("message_type", "comment")
        post_target = self
        subtype_xmlid = (kwargs.get("subtype_xmlid") or "").strip()
        subtype_id = kwargs.get("subtype_id")
        mt_note = self.env.ref("mail.mt_note", raise_if_not_found=False)
        is_log_note = bool(
            subtype_xmlid == "mail.mt_note"
            or (subtype_id and mt_note and subtype_id == mt_note.id)
        )
        partner = self.env["res.partner"].browse(author_id) if author_id else False
        is_incoming_partner_email = bool(
            message_type == "email" and partner and not partner.user_ids
        )
        email_from = (kwargs.get("email_from") or "").strip()
        has_incoming_headers = bool(
            kwargs.get("incoming_email_to") or kwargs.get("incoming_email_cc")
        )
        has_outbound_recipients = bool(
            kwargs.get("outgoing_email_to")
            or kwargs.get("partner_ids")
        )
        # Manual chatter "Send message" can arrive as comment without explicit
        # recipients; default to the lead contact so it is actually delivered.
        if (
            message_type == "comment"
            and not is_log_note
            and not has_outbound_recipients
            and subtype_xmlid == "mail.mt_comment"
        ):
            lead = self[:1]
            partner = lead.partner_id if lead else False
            if partner and partner.email and not partner.user_ids:
                kwargs["partner_ids"] = [partner.id]
                has_outbound_recipients = True
        # Fetchmail-routed incoming replies may not always carry author_id.
        # Treat them as incoming if they have sender + incoming headers and no
        # explicit outbound recipients.
        is_incoming_email = bool(
            message_type == "email"
            and (
                is_incoming_partner_email
                or (
                    email_from
                    and has_incoming_headers
                    and not has_outbound_recipients
                )
            )
        )
        should_apply_threading = (
            not is_incoming_email
            and not is_log_note
            and (
                message_type == "email"
                or (message_type == "comment" and has_outbound_recipients)
            )
        )

        # Outbound CRM emails should route replies back to the sender mailbox
        # (Gmail account monitored by fetchmail), not to default odoobot@example.com.
        if should_apply_threading:
            if kwargs.get("subtype_xmlid") in (None, False, "mail.mt_note"):
                kwargs["subtype_xmlid"] = "mail.mt_comment"
            # Use light notification layout for client emails (no "View Lead"
            # action block in Gmail).
            kwargs.setdefault("email_layout_xmlid", "mail.mail_notification_light")
            if email_from and not kwargs.get("reply_to"):
                rep_email = ""
                lead = self[:1]
                if lead and lead.user_id and lead.user_id.email:
                    rep_email = (lead.user_id.email or "").strip()
                fetch_server = self.env["fetchmail.server"].sudo().search([
                    ("active", "=", True),
                    ("state", "=", "done"),
                    ("server_type", "=", "gmail"),
                    ("user", "=ilike", rep_email or ""),
                ], limit=1)
                if not fetch_server:
                    fetch_server = self.env["fetchmail.server"].sudo().search([
                        ("active", "=", True),
                        ("state", "=", "done"),
                        ("server_type", "=", "gmail"),
                    ], limit=1)
                kwargs["reply_to"] = (fetch_server.user or "").strip() or email_from
            # Keep Gmail replies in a single thread: include RFC threading headers
            # from the latest lead mail.message records.
            try:
                thread_msgs = self.message_ids.filtered(
                    lambda m: m.message_id
                    and m.message_type in ("email", "comment")
                    and (not m.subtype_id or m.subtype_id != mt_note)
                ).sorted("id", reverse=True)
                if thread_msgs:
                    # Anchor to the latest email-like message so outgoing messages
                    # continue from the most recent client/server exchange.
                    email_like_msgs = thread_msgs.filtered(
                        lambda m: bool(
                            m.incoming_email_to
                            or m.incoming_email_cc
                            or m.outgoing_email_to
                            or m.reply_to
                        )
                    )
                    # `thread_msgs` is newest->oldest, so first item is latest.
                    anchor_msg = email_like_msgs[:1] or thread_msgs[:1]
                    if anchor_msg:
                        kwargs.setdefault("parent_id", anchor_msg.id)

                    # Keep reply-style subject even when UI sends an empty subject.
                    subject_source = anchor_msg or thread_msgs[:1]
                    latest_subject = (subject_source.subject or "").strip() if subject_source else ""
                    subject = (kwargs.get("subject") or "").strip()
                    if latest_subject and (
                        not subject
                        or not re.match(r"^\s*(re|fwd?)\s*:", subject, re.I)
                    ):
                        kwargs["subject"] = "Re: %s" % latest_subject
            except Exception:
                _logger.warning("sales_ai: failed to set threading headers for lead %s", self.ids, exc_info=True)
        elif message_type != "email" and is_log_note:
            # Hard rule: log notes must stay internal only.
            # Keep "Send message" comments deliverable to followers/recipients.
            kwargs.pop("outgoing_email_to", None)
            kwargs.pop("incoming_email_to", None)
            kwargs.pop("incoming_email_cc", None)
            kwargs["partner_ids"] = []
            kwargs.setdefault("subtype_xmlid", "mail.mt_note")
            post_target = self.with_context(
                mail_post_autofollow=False,
                mail_auto_subscribe_no_notify=True,
                mail_notify_author=False,
            )

        # Guard against recursive calls from our own message_post calls
        if self.env.context.get("_sales_ai_message_post_lock"):
            return super().message_post(**kwargs)

        result = super(CrmLeadMessage, post_target).message_post(**kwargs)

        if is_incoming_email:
            # Skip Odoo/system notification emails fetched back from mailbox.
            subject_lc = (kwargs.get("subject") or "").lower()
            email_from_lc = (kwargs.get("email_from") or "").lower()
            compact_body = re.sub(r"[\s\u200b\u200c\u200d\ufeff]+", "", body or "")
            partner_root = self.env.ref("base.partner_root", raise_if_not_found=False)
            partner_id = author_id or 0
            looks_like_internal_notification = any([
                "assigned to you" in subject_lc,
                "internal communication" in subject_lc,
                "odoobot" in email_from_lc,
                "@example.com" in email_from_lc,
                bool(partner_root and partner_id == partner_root.id),
                not compact_body,
            ])
            if looks_like_internal_notification:
                _logger.info(
                    "sales_ai: Skipping internal/system email on lead(s) %s subject=%s from=%s",
                    self.ids, kwargs.get("subject"), kwargs.get("email_from"),
                )
                return result

            _logger.info("sales_ai: External reply detected on lead(s) %s", self.ids)
            reply_from = kwargs.get("email_from") or ""
            reply_subject = kwargs.get("subject") or ""
            self.with_context(
                _sales_ai_message_post_lock=True
            )._handle_external_reply(body, reply_from=reply_from, reply_subject=reply_subject)
        else:
            # Outgoing email: if this is the first outbound after scoring, treat it
            # as the auto-ack send event and schedule follow-ups from this date.
            if message_type == "email" or (
                message_type == "comment" and has_outbound_recipients
            ):
                for lead in self:
                    if lead.x_lead_score_band and lead.x_followup_stage == 0:
                        _logger.info(
                            "sales_ai: [AUTO-ACK] Detected outbound email for lead %s — "
                            "scheduling follow-up sequence based on ack date.",
                            lead.id,
                        )
                        # Use this email as base date for follow-up schedule
                        # (context_timestamp handles timezone correctly).
                        email_dt = fields.Datetime.context_timestamp(
                            lead, fields.Datetime.now()
                        )
                        lead.action_create_followup_activities(base_date=email_dt)

        return result



    def _handle_external_reply(self, body_text: str, reply_from: str = "", reply_subject: str = ""):
        """
        Full ReplyClassifierAgent — classifies inbound reply into 10 intents
        and takes appropriate CRM actions.
        """
        service = self.env["claude.service"]
        # Keep reply handling lightweight: create activities without email notify.
        Activity = self.env["mail.activity"].sudo().with_context(mail_activity_quick_update=True)
        reply_received_type = self.env.ref(
            "sales_ai_integration.activity_type_reply_received",
            raise_if_not_found=False,
        )
        confidence_threshold = 60.0

        for lead in self:
            lead.x_last_reply_date = fields.Datetime.now()

            latest_reply = _extract_latest_reply_text(body_text)
            if not latest_reply:
                continue

            # Pre-sale MOM Q&A cycle: mirror client reply into linked ticket log note.
            ticket = lead._find_presale_ticket_for_retro()
            if ticket:
                try:
                    ticket.message_post(
                        body=_(
                            "[AUTO-PRESALE-QA]\nClient reply captured from lead email.\n\n%s",
                            tools.html_escape(latest_reply[:3000]),
                        ),
                        subtype_xmlid="mail.mt_note",
                    )
                except Exception:
                    _logger.warning(
                        "sales_ai: failed to mirror client reply to ticket %s for lead %s",
                        ticket.id,
                        lead.id,
                        exc_info=True,
                    )

            classify_payload = {
                "reply_body": latest_reply[:3000],
                "reply_from": reply_from,
                "reply_subject": reply_subject,
                "lead_stage": lead.stage_id.name if lead.stage_id else "",
                "lead_score_band": lead.x_lead_score_band or "warm",
                "emails_sent": lead.x_followup_stage or 0,
            }
            try:
                result = service.call(
                    tier=prompts.get_agent_tier(self.env, "reply_classifier", "haiku"),
                    system_prompt=prompts.get_system_prompt(self.env, "reply_intent_system"),
                    user_message=json.dumps(classify_payload, ensure_ascii=False),
                    max_tokens=300,
                    expect_json=True,
                )
            except Exception:
                _logger.error(
                    "sales_ai: Reply intent classification failed for lead %s",
                    lead.id, exc_info=True,
                )
                continue

            if not isinstance(result, dict):
                result = {}

            parse_failed = not bool(result)
            intent = (result.get("intent") or "").lower().strip()
            confidence_raw = result.get("confidence")
            try:
                confidence = float(confidence_raw or 0)
            except (TypeError, ValueError):
                confidence = 0.0
            # Claude sometimes returns confidence in 0..1 scale.
            if 0.0 < confidence <= 1.0:
                confidence *= 100.0
            note_for_rep = result.get("note_for_rep") or ""
            ooo_return_date = result.get("ooo_return_date")
            new_contact_hint = result.get("new_contact_hint")
            priority = result.get("priority_flag", False)

            # Heuristic fallback when JSON parse fails or model returns no intent.
            if not intent:
                reply_lc = (latest_reply or "").lower()
                if "?" in (latest_reply or ""):
                    intent = "question"
                elif any(k in reply_lc for k in ("book", "calendar", "calendly", "meeting")):
                    intent = "meeting_booked"
                elif any(k in reply_lc for k in ("unsubscribe", "remove me", "stop emails", "stop emailing")):
                    intent = "unsubscribe"
                elif any(k in reply_lc for k in ("not interested", "no thanks", "don't contact")):
                    intent = "not_interested"
                else:
                    intent = "interested"
                if confidence <= 0:
                    confidence = 65.0
                if parse_failed and not note_for_rep:
                    note_for_rep = _(
                        "AI JSON parsing failed; applied heuristic intent from reply text. "
                        "Please review this customer reply."
                    )

            valid_intents = (
                "interested", "meeting_booked", "not_interested", "ooo",
                "wrong_person", "referral", "generic_positive", "unsubscribe",
                "question", "negotiating",
            )
            if intent not in valid_intents:
                intent = "interested"

            lead.x_reply_intent = intent
            if priority:
                lead.priority = "3"

            _logger.info(
                "sales_ai: Lead %s reply classified as %s (conf=%.0f%%)",
                lead.id, intent, confidence,
            )

            lead.message_post(
                body=_(
                    "<b>Reply received:</b> %s (confidence: %.0f%%)<br/>%s",
                    intent.replace("_", " ").title(), confidence, note_for_rep,
                ),
                subtype_xmlid="mail.mt_note",
            )

            if confidence < confidence_threshold:
                # Keep operational visibility: always create at least one follow-up
                # task for low-confidence classifications.
                if lead.user_id:
                    todo_type = self.env.ref(
                        "mail.mail_activity_data_todo", raise_if_not_found=False
                    )
                    Activity.create({
                        "res_model_id": self.env.ref("crm.model_crm_lead").id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": _("Answer customer question (priority)")
                        if intent == "question"
                        else _("Review customer reply (AI low confidence)"),
                        "note": note_for_rep or latest_reply[:800],
                        "date_deadline": fields.Date.today(),
                    })
                lead.message_post(
                    body=_(
                        "Low-confidence reply classification (%.0f%%). "
                        "Stage automation skipped; manual activity created for rep follow-up.",
                        confidence,
                    ),
                    subtype_xmlid="mail.mt_note",
                )
                continue

            if reply_received_type and lead.user_id:
                Activity.create({
                    'res_model_id': self.env.ref('crm.model_crm_lead').id,
                    "res_id": lead.id,
                    "user_id": lead.user_id.id,
                    "activity_type_id": reply_received_type.id,
                    "summary": _("Reply received — %s", intent.replace("_", " ").title()),
                    "note": note_for_rep,
                    "date_deadline": fields.Date.today(),
                })

            if intent != "meeting_booked":
                lead._cancel_pending_followups()

            # --- Intent-specific actions ---

            if intent in ("interested", "generic_positive"):
                lead.x_followup_stage = 0
                lead.action_create_followup_activities(base_date=fields.Datetime.now())

            elif intent == "question":
                todo_type = self.env.ref(
                    "mail.mail_activity_data_todo", raise_if_not_found=False
                )
                if lead.user_id:
                    Activity.create({
                        'res_model_id': self.env.ref('crm.model_crm_lead').id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": _("Answer customer question (priority)"),
                        "note": note_for_rep,
                        "date_deadline": fields.Date.today(),
                    })

            elif intent == "negotiating":
                stage_negotiation = self.env.ref(
                    "sales_ai_integration.stage_negotiation",
                    raise_if_not_found=False,
                )
                if stage_negotiation:
                    lead.stage_id = stage_negotiation
                todo_type = self.env.ref(
                    "mail.mail_activity_data_todo", raise_if_not_found=False
                )
                if lead.user_id:
                    Activity.create({
                        'res_model_id': self.env.ref('crm.model_crm_lead').id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": _("Negotiation follow-up — respond today"),
                        "note": note_for_rep,
                        "date_deadline": fields.Date.today(),
                    })

            elif intent == "meeting_booked":
                meeting_event = self.env["calendar.event"].sudo().search([
                    ("opportunity_id", "=", lead.id),
                    ("x_meeting_category", "=", "client"),
                ], order="start desc", limit=1)
                if lead.user_id:
                    todo_type = self.env.ref(
                        "mail.mail_activity_data_todo", raise_if_not_found=False
                    )
                    Activity.create({
                        'res_model_id': self.env.ref('crm.model_crm_lead').id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": _("Client interested in booking meeting"),
                        "note": _(
                            "%s\n\nClient indicated they may book a meeting. "
                            "Do not move stage or clear activities until a real calendar event exists.",
                            note_for_rep or "",
                        ),
                        "date_deadline": fields.Date.today(),
                    })
                if meeting_event and meeting_event.start:
                    lead.message_post(
                        body=_(
                            "Client confirmed meeting intent. Calendar event '%s' exists for %s. "
                            "Stage/activity automation will run after transcript + MOM processing.",
                            meeting_event.name or "Client meeting",
                            str(meeting_event.start),
                        ),
                        subtype_xmlid="mail.mt_note",
                    )
                else:
                    lead.message_post(
                        body=_(
                            "Client expressed meeting interest. Waiting for actual calendar event "
                            "before stage change or activity cleanup."
                        ),
                        subtype_xmlid="mail.mt_note",
                    )

            elif intent == "not_interested":
                lead.action_set_lost(
                    lost_reason_id=self.env.ref(
                        "crm.crm_lost_reason3", raise_if_not_found=False
                    ),
                )

            elif intent == "ooo":
                days_to_wait = 7
                if ooo_return_date:
                    try:
                        return_dt = fields.Date.from_string(ooo_return_date)
                        days_to_wait = max(
                            3, (return_dt - fields.Date.today()).days + 2
                        )
                        lead.x_ooo_return_date = return_dt
                    except Exception:
                        pass
                ooo_base_dt = lead._business_day_offset(
                    fields.Datetime.now(), days_to_wait
                )
                lead.x_followup_stage = 0
                lead.action_create_followup_activities(base_date=ooo_base_dt)

            elif intent == "wrong_person":
                if lead.user_id:
                    todo_type = self.env.ref(
                        "mail.mail_activity_data_todo", raise_if_not_found=False
                    )
                    Activity.create({
                        'res_model_id': self.env.ref('crm.model_crm_lead').id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": _("Find the right contact"),
                        "note": note_for_rep + (
                            "\n\nContact hint: %s" % new_contact_hint if new_contact_hint else ""
                        ),
                        "date_deadline": fields.Date.today(),
                    })

            elif intent == "referral":
                if new_contact_hint:
                    lead.message_post(
                        body=_("Referred to: %s", new_contact_hint),
                        subtype_xmlid="mail.mt_note",
                    )
                if lead.user_id:
                    todo_type = self.env.ref(
                        "mail.mail_activity_data_todo", raise_if_not_found=False
                    )
                    Activity.create({
                        'res_model_id': self.env.ref('crm.model_crm_lead').id,
                        "res_id": lead.id,
                        "user_id": lead.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": _("Follow up with referred contact"),
                        "note": note_for_rep + (
                            "\n\nReferred contact: %s" % new_contact_hint if new_contact_hint else ""
                        ),
                        "date_deadline": fields.Date.today(),
                    })

            elif intent == "unsubscribe":
                lead.x_unsubscribed = True
                tag = self.env["crm.tag"].sudo().search(
                    [("name", "=", "unsubscribed")], limit=1
                )
                if not tag:
                    tag = self.env["crm.tag"].sudo().create({"name": "unsubscribed"})
                lead.tag_ids = [(4, tag.id)]

            # Do not send additional direct emails here; chatter + activities are enough.

            # Discussion sync: finance-free summary posted to linked helpdesk ticket
            ticket = self.env["sh.helpdesk.ticket"].sudo().search(
                [("x_linked_lead_id", "=", lead.id)], order="id desc", limit=1,
            )
            sync_target = ticket or (
                lead if lead.x_presale_status not in ("none", False) else None
            )
            if sync_target:
                try:
                    sync_payload = service.call(
                        tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                        system_prompt=prompts.get_system_prompt(self.env, "discussion_sync_system"),
                        user_message=latest_reply[:4000],
                        max_tokens=600,
                        expect_json=True,
                    )
                    if isinstance(sync_payload, dict) and sync_payload.get("has_content"):
                        summary_html = sync_payload.get("summary_html") or ""
                        if summary_html:
                            sync_target.message_post(
                                body=_("<b>Presale note (auto-synced from lead %s)</b><br/>%s",
                                       lead.x_presale_ref or str(lead.id), summary_html),
                                subtype_xmlid="mail.mt_note",
                            )
                            # Keep helpdesk gist in sync with latest client replies.
                            if sync_target._name == "sh.helpdesk.ticket":
                                try:
                                    sync_target.action_generate_ticket_gist()
                                except Exception:
                                    _logger.error(
                                        "sales_ai: Ticket gist refresh failed after reply sync (ticket=%s, lead=%s)",
                                        sync_target.id, lead.id, exc_info=True,
                                    )
                except Exception:
                    _logger.error(
                        "sales_ai: Discussion sync failed for lead %s", lead.id, exc_info=True
                    )

    # =========================================================================
    # PHASE: OPEN PRESALE (no separate project.task — everything on the lead)
    # =========================================================================

    def action_open_presale(self):
        """
        Open the presale phase on this lead.
        Assigns a PST reference number and triggers the TicketGistAgent.
        All presale work (agenda, MOM, WBS, proposal) stays on the lead record.
        """
        self.ensure_one()
        if self.x_presale_status != "none":
            raise UserError(
                _("Presale is already open for this lead (%s)." % self.x_presale_ref)
            )
        # Assign reference number
        self.x_presale_ref = "PST-%d" % self.id
        self.x_presale_status = "open"
        self.action_start_presale()
        _logger.info("sales_ai: Presale opened for lead %s — ref %s", self.id, self.x_presale_ref)

    # =========================================================================
    # PHASE: NO-SHOW FOLLOW-UP
    # =========================================================================

    def action_no_show_followup(self, no_show_count=1):
        """Generate a no-show follow-up email draft when client misses a meeting."""
        self.ensure_one()
        calendar_link = self.user_id.x_calendar_link if self.user_id else "[CALENDAR_LINK]"

        payload = {
            "client_name": self.contact_name or (self.partner_id.name if self.partner_id else ""),
            "client_company": self.partner_id.name if self.partner_id else "",
            "meeting_date": str(fields.Date.today()),
            "meeting_topic": self.name or "",
            "rep_name": self.user_id.name if self.user_id else "",
            "rep_designation": self.user_id.job_title if self.user_id else "Account Executive",
            "rep_calendar_link": calendar_link,
            "lead_score_band": self.x_lead_score_band or "warm",
            "no_show_count": no_show_count,
            "prior_interaction": "Previous emails and meeting scheduled",
            "enriched_fields": {
                "company_industry": self.x_industry or "",
                "contact_seniority": self.x_contact_seniority_structured or "",
            },
        }

        try:
            resp = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "no_show_followup", "sonnet"),
                system_prompt=prompts.get_system_prompt(self.env, "no_show_followup_system"),
                user_message=json.dumps(payload, ensure_ascii=False),
                max_tokens=400,
                expect_json=True,
            )
        except Exception:
            _logger.error("sales_ai: No-show follow-up failed for lead %s", self.id, exc_info=True)
            return

        subject = resp.get("subject") or _("Following up — our calendars didn't align")
        body = resp.get("body") or ""

        activity_type = self.env.ref(
            "sales_ai_integration.activity_type_no_show_followup", raise_if_not_found=False
        ) or self.env.ref("mail.mail_activity_data_email", raise_if_not_found=False)

        self.env["mail.activity"].sudo().create({
            'res_model_id': self.env.ref('crm.model_crm_lead').id,
            "res_id": self.id,
            "user_id": self.user_id.id if self.user_id else self.env.uid,
            "activity_type_id": activity_type.id if activity_type else False,
            "summary": _("Review & send no-show follow-up"),
            "note": "[AI DRAFT — No-show follow-up]\n\nSubject: %s\n\n%s" % (subject, body),
            "date_deadline": fields.Date.today(),
        })
        _logger.info("sales_ai: No-show follow-up draft created for lead %s", self.id)

    # =========================================================================
    # PHASE: MEETING PREP BRIEF (cron before meetings)
    # =========================================================================

    @api.model
    def cron_meeting_prep_brief(self):
        """
        Daily 8:00 AM cron: generate meeting prep briefs for meetings
        scheduled in the next 24 hours.
        """
        _logger.info("sales_ai: [CRON] Meeting prep brief started")
        from datetime import timedelta
        now = fields.Datetime.now()
        cutoff = now + timedelta(hours=24)

        # Find meetings with linked leads
        events = self.env["calendar.event"].sudo().search([
            ("start", ">=", now),
            ("start", "<=", cutoff),
            ("opportunity_id", "!=", False),
        ])
        _logger.info("sales_ai: [CRON] Found %d upcoming meetings with linked leads", len(events))

        for event in events:
            lead = event.opportunity_id
            if not lead or not lead.user_id:
                continue
            try:
                lead._generate_meeting_prep_brief(event)
            except Exception:
                _logger.error(
                    "sales_ai: Meeting prep brief failed for lead %s event %s",
                    lead.id, event.id, exc_info=True,
                )

        _logger.info("sales_ai: [CRON] Meeting prep brief completed")

    def _generate_meeting_prep_brief(self, event=None):
        """Generate a 2-minute pre-meeting brief and post to lead."""
        self.ensure_one()

        # Gather last 5 emails
        emails = []
        for m in self.message_ids.sorted("date", reverse=True)[:10]:
            if m.message_type == "email":
                emails.append({
                    "subject": m.subject or "",
                    "snippet": (m.body or "")[:300],
                    "date": str(m.date),
                })
            if len(emails) >= 5:
                break

        # Prior MOMs
        prior_moms = []
        for m in self.message_ids.filtered(lambda x: "Meeting Minutes" in (x.body or "")):
            prior_moms.append((m.body or "")[:500])

        payload = {
            "client_name": self.contact_name or (self.partner_id.name if self.partner_id else ""),
            "client_company": self.partner_id.name if self.partner_id else "",
            "client_role": self.function or self.x_contact_job_title or "",
            "meeting_type": "follow-up",
            "meeting_duration": int((event.stop - event.start).total_seconds() / 60) if event and event.start and event.stop else 60,
            "meeting_agenda": event.description or event.name or "" if event else "",
            "enriched_fields": {
                "company_industry": self.x_industry or "",
                "company_size": self.x_employee_count_range or "",
                "contact_seniority": self.x_contact_seniority_structured or "",
                "likely_pain_point": self.x_likely_pain_point or "",
            },
            "email_thread": emails,
            "lead_score": self.x_lead_score or 0,
            "rep_name": self.user_id.name if self.user_id else "",
            "prior_moms": prior_moms[-3:],
            "open_questions": [],
        }

        try:
            resp = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "meeting_prep_brief", "sonnet"),
                system_prompt=prompts.get_system_prompt(self.env, "meeting_prep_brief_system"),
                user_message=json.dumps(payload, ensure_ascii=False),
                max_tokens=600,
                expect_json=False,
            )
        except Exception:
            _logger.error("sales_ai: Meeting prep brief failed for lead %s", self.id, exc_info=True)
            return

        if resp:
            self.message_post(
                body=_("<h4>Meeting Prep Brief</h4>%s", resp),
                subtype_xmlid="mail.mt_note",
            )
            _logger.info("sales_ai: Meeting prep brief posted for lead %s", self.id)

    # =========================================================================
    # PHASE: PRESALE MOM FROM TRANSCRIPT (webhook target)
    # =========================================================================

    def action_generate_presale_mom_from_transcript(self, transcript: str, meeting_date=None,
                                                      meeting_duration=None, attendees=None,
                                                      prior_open_items=None):
        """
        PresaleMOMAgent (Sonnet) — generate internal presale MOM from transcript.
        Everything posted to the lead chatter. No project.task involved.
        """
        self.ensure_one()
        _logger.info(
            "sales_ai: Generating presale MOM for lead %s — ref %s (transcript=%d chars)",
            self.id, self.x_presale_ref or "no-ref", len(transcript),
        )

        # Build context from lead
        ticket_context = self.x_ticket_gist or self.x_likely_pain_point or self.description or ""

        # Prior open items from last few internal notes
        prior_items = prior_open_items or []
        if not prior_items:
            note_subtype = self.env.ref("mail.mt_note", raise_if_not_found=False)
            recent_notes = self.message_ids.filtered(
                lambda m: m.subtype_id and note_subtype and m.subtype_id.id == note_subtype.id
            ).sorted("date", reverse=True)[:5]
            prior_items = [(m.body or "")[:300] for m in recent_notes]

        payload = {
            "lead_id": self.id,
            "ticket_id": self.x_presale_ref or ("PST-%d" % self.id),
            "meeting_date": meeting_date or str(fields.Date.today()),
            "meeting_duration": meeting_duration or 60,
            "attendees": attendees or [],
            "ticket_context": ticket_context[:2000],
            "prior_open_items": prior_items,
            "presale_stage": self.x_presale_status or "open",
        }

        try:
            from .transcript_tools import prune_transcript_text, transcript_text_to_toon

            pruned = prune_transcript_text(transcript, max_chars=45000)
            toon_text, _segs = transcript_text_to_toon(pruned, max_segments=300)

            facts = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "presale_mom", "haiku"),
                system_prompt=prompts.get_system_prompt(self.env, "presale_mom_facts_system"),
                user_message=json.dumps(
                    {
                        "toon": toon_text,
                        "meeting_date": payload["meeting_date"],
                        "meeting_duration": payload["meeting_duration"],
                        "attendees": payload["attendees"],
                        "ticket_context": payload["ticket_context"],
                        "prior_open_items": payload["prior_open_items"],
                        "presale_stage": payload["presale_stage"],
                    },
                    ensure_ascii=False,
                ),
                max_tokens=1600,
                expect_json=True,
            )

            if isinstance(facts, dict) and facts:
                resp = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "presale_mom_compose_system"),
                    user_message=json.dumps(
                        {
                            "facts": facts,
                            "lead_id": payload["lead_id"],
                            "ticket_id": payload["ticket_id"],
                            "meeting_date": payload["meeting_date"],
                            "meeting_duration": payload["meeting_duration"],
                            "attendees": payload["attendees"],
                            "ticket_context": payload["ticket_context"],
                            "prior_open_items": payload["prior_open_items"],
                            "presale_stage": payload["presale_stage"],
                        },
                        ensure_ascii=False,
                    ),
                    max_tokens=900,
                    expect_json=True,
                )
            else:
                fallback = dict(payload)
                fallback["transcript"] = transcript[:150000]
                resp = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "presale_mom_system"),
                    user_message=json.dumps(fallback, ensure_ascii=False),
                    max_tokens=800,
                    expect_json=True,
                )
        except Exception:
            _logger.error("sales_ai: Presale MOM generation failed for lead %s", self.id, exc_info=True)
            return

        mom_md = resp.get("internal_mom_markdown") or resp.get("internal_mom") or str(resp)
        technical_decisions = resp.get("technical_decisions") or []
        stage_rec = resp.get("stage_recommendation") or ""

        # Store MOM in history
        try:
            history = json.loads(self.x_presale_mom_history or "[]")
        except Exception:
            history = []
        history.append({
            "date": meeting_date or str(fields.Date.today()),
            "mom": mom_md[:3000],
            "decisions": technical_decisions,
        })
        self.x_presale_mom_history = json.dumps(history, ensure_ascii=False)

        # Post internal MOM to lead chatter
        self.message_post(
            body=tools.html_sanitize(tools.plaintext2html(mom_md or "")),
            subtype_xmlid="mail.mt_note",
        )

        # Post action items summary
        us_items = resp.get("new_action_items_us") or []
        client_items = resp.get("new_action_items_client") or []
        open_questions = resp.get("open_technical_questions") or []
        if us_items or client_items or stage_rec:
            parts = ["<b>Presale MOM Action Items [%s]</b><ul>" % (self.x_presale_ref or "")]
            for item in us_items:
                parts.append("<li><b>[Our Team]</b> %s</li>" % item)
            for item in client_items:
                parts.append("<li><b>[Client]</b> %s</li>" % item)
            parts.append("</ul>")
            if stage_rec:
                parts.append("<p><b>Stage recommendation:</b> %s</p>" % stage_rec)
            self.message_post(body="\n".join(parts), subtype_xmlid="mail.mt_note")

        if open_questions:
            todo_type = self.env.ref("mail.mail_activity_data_todo", raise_if_not_found=False)
            q_lines = ["Questions identified for client follow-up:"]
            q_lines.extend("%d. %s" % (idx + 1, q) for idx, q in enumerate(open_questions[:10]))
            q_note = "\n".join(q_lines)
            self.env["mail.activity"].sudo().create(
                {
                    "res_model_id": self.env.ref("crm.model_crm_lead").id,
                    "res_id": self.id,
                    "user_id": self.user_id.id if self.user_id else self.env.uid,
                    "activity_type_id": todo_type.id if todo_type else False,
                    "summary": _("Questions to ask client — %s", self.x_presale_ref or "Presale"),
                    "note": q_note,
                    "date_deadline": fields.Date.today(),
                }
            )
            self.message_post(
                body=tools.html_sanitize(tools.plaintext2html(q_note)),
                subtype_xmlid="mail.mt_note",
            )

        _logger.info(
            "sales_ai: Presale MOM posted on lead %s — %d technical decisions",
            self.id, len(technical_decisions),
        )

        # Auto-trigger client-facing presale email draft
        self.action_generate_presale_client_email(mom_content=mom_md)

    # =========================================================================
    # PHASE: WBS GENERATION (button on lead)
    # =========================================================================

    def action_generate_wbs(self):
        """
        Trigger n8n WBS generation for this presale lead.

        IMPORTANT:
        - Odoo does NOT call Claude for WBS.
        - n8n handles Claude + Google Sheets write-back.
        - n8n should call back to /api/sales_ai/wbs_ready with sheet_url.
        """
        raise UserError(
            _("WBS generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        if self.x_presale_status not in ("open", "ready_for_wbs", "ready_for_proposal"):
            raise UserError(_("Lead must be in presale mode to generate WBS."))

        ICP = self.env["ir.config_parameter"].sudo()
        url = (ICP.get_param("sales_ai.n8n_wbs_webhook_url", default="") or "").strip()
        if not url:
            raise UserError(
                _("n8n WBS webhook URL is not configured. Go to Settings → AI Sales Automation → n8n Integration.")
            )

        try:
            wbs_prompt = self.env["sales.ai.agent.prompt"].sudo().get_active_prompt("wbs_generator")
        except Exception:
            wbs_prompt = ""

        payload = {
            "lead_id": self.id,
            "presale_ref": self.x_presale_ref or ("PST-%d" % self.id),
            "client_company": self.partner_id.name or self.partner_name or "",
            "lead_name": self.name or "",
            "lead_context": {
                "industry": getattr(self, "x_industry", "") or "",
                "score": getattr(self, "x_lead_score", 0) or 0,
                "pain_point": getattr(self, "x_likely_pain_point", "") or "",
                "inquiry_category": getattr(self, "x_inquiry_category", "") or "",
            },
            "chatter_history": "\n".join(
                "[%s] %s | %s"
                % (
                    fields.Datetime.to_string(m.date) if m.date else "",
                    m.author_id.display_name or "Unknown",
                    tools.html2plaintext(m.body or "").replace("\n", " ").strip()[:300],
                )
                for m in self.message_ids.sorted("date", reverse=False)[-120:]
                if (m.body or "").strip()
            ),
            "wbs_prompt": wbs_prompt,
            "wbs_template_sheet_id": (ICP.get_param("sales_ai.wbs_template_sheet_id", default="") or ""),
        }

        import requests

        try:
            resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=30)
        except Exception as exc:
            raise UserError(_("WBS generation request failed: %s") % str(exc))

        if resp.status_code != 200:
            raise UserError(
                _("WBS generation failed. n8n returned HTTP %s: %s")
                % (resp.status_code, (resp.text or "")[:500])
            )

        self.message_post(
            body=_("WBS generation requested from n8n. Awaiting callback to set Google Sheet URL."),
            subtype_xmlid="mail.mt_note",
        )
        # TODO: If n8n returns sheet_url synchronously, store it on lead as x_wbs_sheet_url.
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("WBS Requested"),
                "type": "success",
                "message": _("WBS request sent to n8n."),
            },
        }

    # =========================================================================
    #  Fetch Mails Now (manual trigger)
    # =========================================================================

    def action_fetch_mails_now(self):
        """Manually trigger fetchmail for the current user's Gmail server."""
        self.ensure_one()
        user = self.env.user
        servers = self.env['fetchmail.server'].sudo().search([
            ('active', '=', True),
            ('state', '=', 'done'),
            ('server_type', '=', 'gmail'),
            ('user', '=ilike', user.email or ''),
        ])
        if not servers:
            servers = self.env['fetchmail.server'].sudo().search([
                ('active', '=', True),
                ('state', '=', 'done'),
                ('server_type', '=', 'gmail'),
            ], limit=1)
        if not servers:
            raise UserError(_(
                "No active incoming mail server found. "
                "Configure one in Settings > Technical > Incoming Mail Servers."
            ))
        # Manual button path: call per-server fetch method (cron-only bulk API asserts context in Odoo 19).
        failures = []
        for server in servers:
            exception = server._fetch_mail()
            if exception is not None:
                failures.append("%s: %s" % (server.name, str(exception)))
        if failures and len(failures) == len(servers):
            raise UserError(_("Failed to fetch mail: %s") % "; ".join(failures))
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _("Mail Fetched"),
                'message': (
                    _("Checked %d Gmail server(s); some failed: %s", len(servers), "; ".join(failures))
                    if failures else
                    _("Checked %d Gmail server(s) for new messages.", len(servers))
                ),
                'type': 'warning' if failures else 'success',
                'sticky': False,
            },
        }


class HelpdeskTicketMessageFormat(models.Model):
    _inherit = "sh.helpdesk.ticket"

    def message_post(self, **kwargs):
        body = kwargs.get("body") or ""
        if isinstance(body, str) and body:
            normalized = _normalize_chatter_body(body)
            message_type = kwargs.get("message_type", "comment")
            if message_type != "email":
                normalized = _render_professional_chatter_html(normalized)
            kwargs["body"] = normalized
        return super().message_post(**kwargs)

