import logging
import threading
import time

from odoo import api, models

_logger = logging.getLogger("sales_ai")


class BaseAIBackgroundMixin(models.AbstractModel):
    _name = "sales.ai.background.mixin"
    _description = "Reusable AI background execution helpers"

    def _ai_run_in_background(self, method_name, kwargs=None, user_id=None):
        """Run a model method asynchronously in a fresh DB cursor."""
        self.ensure_one()
        record_id = self.id
        model_name = self._name
        dbname = self.env.cr.dbname
        uid = user_id or self.env.uid
        payload = dict(kwargs or {})

        def _runner():
            from odoo.orm.registry import Registry

            registry = Registry(dbname)
            max_retries = 3
            for attempt in range(1, max_retries + 1):
                try:
                    with registry.cursor() as cr:
                        env = api.Environment(cr, uid, {})
                        rec = env[model_name].browse(record_id).exists()
                        if not rec:
                            return
                        fn = getattr(rec, method_name, None)
                        if not fn:
                            _logger.error("sales_ai: background method missing model=%s method=%s", model_name, method_name)
                            return
                        # Serialize same-record background updates across workers.
                        lock_key = f"sales_ai.bg.{model_name}.{record_id}"
                        env.cr.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", [lock_key])
                        fn(**payload)
                    return
                except Exception as exc:  # pylint: disable=broad-except
                    transient = (
                        "SerializationFailure" in exc.__class__.__name__
                        or "InFailedSqlTransaction" in exc.__class__.__name__
                        or "could not serialize access" in str(exc).lower()
                    )
                    if transient and attempt < max_retries:
                        _logger.warning(
                            "sales_ai: background transient error model=%s id=%s method=%s attempt=%s/%s",
                            model_name,
                            record_id,
                            method_name,
                            attempt,
                            max_retries,
                        )
                        time.sleep(0.4 * attempt)
                        continue
                    _logger.exception(
                        "sales_ai: background execution failed model=%s id=%s method=%s",
                        model_name,
                        record_id,
                        method_name,
                    )
                    return

        thread = threading.Thread(
            target=_runner,
            name=f"sales-ai-bg-{model_name}-{record_id}-{method_name}",
            daemon=True,
        )
        thread.start()
        return True

    def _ai_is_transient_db_error(self, exc):
        txt = str(exc).lower()
        return (
            "SerializationFailure" in exc.__class__.__name__
            or "InFailedSqlTransaction" in exc.__class__.__name__
            or "could not serialize access" in txt
            or "deadlock detected" in txt
            or "current transaction is aborted" in txt
        )

    def _ai_reset_after_failure(self):
        try:
            self.env.cr.rollback()
        except Exception:
            _logger.debug("sales_ai: rollback failed during retry reset", exc_info=True)
        try:
            self.invalidate_recordset()
        except Exception:
            _logger.debug("sales_ai: invalidate failed during retry reset", exc_info=True)

    def _ai_retry_with_backoff(
        self,
        callback,
        max_retries=3,
        initial_delay=1.0,
        transient_only=False,
        on_retry=None,
    ):
        """Retry helper for API and transient DB operations."""
        last_exc = None
        for attempt in range(max_retries):
            try:
                return callback()
            except Exception as exc:  # pylint: disable=broad-except
                last_exc = exc
                if transient_only and not self._ai_is_transient_db_error(exc):
                    break
                if attempt >= max_retries - 1:
                    break
                if on_retry:
                    try:
                        on_retry()
                    except Exception:
                        _logger.debug("sales_ai: retry reset hook failed", exc_info=True)
                time.sleep(initial_delay * (2 ** attempt))
        if last_exc:
            raise last_exc
        return None
