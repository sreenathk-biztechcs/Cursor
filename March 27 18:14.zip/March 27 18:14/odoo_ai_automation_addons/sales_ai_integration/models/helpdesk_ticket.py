"""
helpdesk_ticket.py — Presale AI workflow on sh.helpdesk.ticket.

When a helpdesk ticket is created from a CRM lead (via the "Create Ticket"
button), this extension auto-triggers the TicketGistAgent and makes the
ticket the primary workspace for all presale AI operations: agenda, MOM,
WBS, proposal, and retrospective.
"""
import base64
import html
import hashlib
import json
import logging
import re
import time
from datetime import date, datetime
from typing import Dict, List, Tuple

import psycopg2.errors

from odoo import api, fields, models, _, tools
from odoo.exceptions import UserError

from . import prompts

_logger = logging.getLogger("sales_ai")

_TICKET_SWITCH_RE = re.compile(
    r"(?:moving\s+to|switch(?:ing)?\s+to|next(?:\s+ticket)?\s+is)\s+ticket(?:\s+number)?\s*[:#-]?\s*([A-Za-z0-9\-_]+)\b",
    re.IGNORECASE,
)
_TICKET_NUMBER_RE = re.compile(
    r"\bticket(?:\s+number)?\s*[:#-]?\s*([A-Za-z0-9\-_]+)\b",
    re.IGNORECASE,
)
_TRANSCRIPT_TICKET_NUM_RE = re.compile(
    r"\bticket(?:\s+number)?\s*[:#-]?\s*(?:PST-?)?(\d{2,})\b",
    re.IGNORECASE,
)
_AGENDA_MARKER = "[AUTO-PRESALE-AGENDA]"
_LEAD_SYNC_MARKER = "[AUTO-PRESALE-LEAD-SYNC]"

# ---------------------------------------------------------------------------
# Financial data stripping (post-processing safety net)
# ---------------------------------------------------------------------------

_FINANCIAL_RE = re.compile(
    r"""
    (?:                         # currency symbol + number
        [\$\€\£\₹\¥]          # common currency symbols
        \s*[\d,]+\.?\d*        # digits with optional decimals
    )
    |
    (?:                         # number + currency word
        \b[\d,]+\.?\d*\s*
        (?:USD|EUR|GBP|INR|dollars?|euros?|pounds?|rupees?|lakhs?|crores?|million|billion)
        \b
    )
    |
    (?:                         # percentage patterns that look like pricing
        \b\d+(?:\.\d+)?%\s*(?:discount|margin|markup|off)\b
    )
    """,
    re.VERBOSE | re.IGNORECASE,
)

_BUDGET_LINE_RE = re.compile(
    r"\b(budget|pricing|price|cost|quote|commercial|investment|license\s*cost|payment\s*terms?)\b",
    re.IGNORECASE,
)


def _strip_financial_data(text: str) -> str:
    """Remove currency amounts and financial figures from text."""
    if not text:
        return ""
    return _FINANCIAL_RE.sub("[financial data removed]", text)


def _clean_gist_for_description(text: str) -> str:
    """Normalize LLM gist text for plain-text description storage."""
    if not text:
        return ""
    cleaned = tools.html2plaintext(text).replace("\r", "")
    # Remove markdown heading prefixes and common noisy symbols.
    cleaned = re.sub(r"(?m)^\s{0,3}#{1,6}\s*", "", cleaned)
    cleaned = cleaned.replace("**", "").replace("```", "")
    cleaned = cleaned.replace("->", "to").replace("—", "-")
    # Collapse repeated blank lines to keep description compact.
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    # Hard-remove budget/commercial lines from stored description gist.
    kept_lines: List[str] = []
    skip_budget_block = False
    for raw in cleaned.splitlines():
        line = (raw or "").strip()
        if not line:
            continue
        hdr = line[:-1].strip().lower() if line.endswith(":") else ""
        if hdr in ("budget & timeline signals", "budget and timeline signals"):
            skip_budget_block = True
            continue
        if line.endswith(":"):
            skip_budget_block = False
        if skip_budget_block:
            continue
        if _BUDGET_LINE_RE.search(line):
            continue
        kept_lines.append(line)
    return "\n".join(kept_lines).strip()


def _json_safe(value):
    """Convert mixed Python/Odoo values into JSON-serializable structures."""
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]
    # Odoo recordsets / custom objects fallback
    if hasattr(value, "ids") and hasattr(value, "_name"):
        return value.ids
    try:
        json.dumps(value)
        return value
    except Exception:
        return str(value)


def _normalize_gist_text(text: str) -> str:
    """Convert mixed/escaped HTML gist to clean plain text and redact finance."""
    if not text:
        return ""
    source = text
    if "&lt;" in source and "&gt;" in source:
        source = html.unescape(source)
    plain = tools.html2plaintext(source).replace("\r", "")
    plain = re.sub(r"(?m)^\s{0,3}#{1,6}\s*", "", plain)
    plain = plain.replace("**", "").replace("```", "")
    plain = re.sub(r"\n{3,}", "\n\n", plain).strip()
    plain = _strip_financial_data(plain)

    # Hard-remove budget/pricing/commercial lines from gist output.
    kept_lines: List[str] = []
    for ln in plain.splitlines():
        line = (ln or "").strip()
        if not line:
            continue
        if _BUDGET_LINE_RE.search(line):
            continue
        kept_lines.append(line)
    return "\n".join(kept_lines).strip()


def _format_gist_for_chatter(text: str) -> str:
    """Render normalized gist text into a professional structured HTML note."""
    gist = _normalize_gist_text(text)
    if not gist:
        return "<p>No gist available.</p>"

    ordered_sections = [
        "Client Overview",
        "What They're Looking For",
        "Key Requirements Identified",
        "Prior Discussions Summary",
        "Open Questions (must resolve in first presale meeting)",
        "Risk Flags",
        "Recommended Presale Approach",
    ]

    # Parse lines into {section -> items}; keep unknown lines in overview.
    sections: Dict[str, List[str]] = {k: [] for k in ordered_sections}
    current = "Client Overview"

    for raw in gist.splitlines():
        line = (raw or "").strip()
        if not line:
            continue
        header = line[:-1].strip() if line.endswith(":") else ""
        matched = next((s for s in ordered_sections if header.lower() == s.lower()), None)
        if matched:
            current = matched
            continue
        if line.lower().startswith("ticket gist -"):
            continue
        item = re.sub(r"^[-*+]\s+", "", line)
        item = re.sub(r"^\d+\.\s+", "", item)
        item = item.strip()
        if item:
            sections[current].append(item)

    esc = tools.html_escape
    parts: List[str] = [
        '<div style="font-family:Inter,Segoe UI,Arial,sans-serif;font-size:13px;line-height:1.5;">'
    ]

    for title in ordered_sections:
        items = sections.get(title) or []
        if not items:
            continue
        parts.append('<h4 style="margin:12px 0 6px;">%s</h4>' % esc(title))
        if title.startswith("Open Questions"):
            parts.append("<ol style='margin:0 0 8px 18px;padding:0;'>")
            for it in items[:8]:
                parts.append("<li>%s</li>" % esc(it))
            parts.append("</ol>")
        else:
            parts.append("<ul style='margin:0 0 8px 16px;padding:0;'>")
            for it in items[:8]:
                parts.append("<li>%s</li>" % esc(it))
            parts.append("</ul>")

    parts.append("</div>")
    return tools.html_sanitize("\n".join(parts))


class HelpdeskTicketPresale(models.Model):
    _inherit = "sh.helpdesk.ticket"

    # ------------------------------------------------------------------
    # Presale fields
    # ------------------------------------------------------------------

    x_linked_lead_id = fields.Many2one(
        "crm.lead",
        string="Linked CRM Lead",
        help="CRM lead this presale ticket was created from.",
        tracking=True,
    )
    x_ticket_status = fields.Selection(
        [
            ("open", "Presale Open"),
            ("won", "Won"),
            ("lost", "Lost"),
            ("cancelled", "Cancelled"),
        ],
        string="Presale Status",
        tracking=True,
    )
    x_presale_ref = fields.Char(
        "Presale Reference",
        help="Auto-generated reference (e.g. PST-1042).",
        readonly=True,
    )
    x_ticket_gist = fields.Text(
        "Discussion Gist",
        help="AI-generated summary of all lead discussions for the presale team.",
    )
    x_last_agenda_date = fields.Date("Last Presale Agenda Date")
    x_retro_logged = fields.Boolean("Retrospective Logged")
    x_presale_mom_history = fields.Text(
        "Presale MOM History",
        help="JSON list of presale MOM entries.",
    )
    x_last_presale_transcript = fields.Text(
        "Latest Presale Transcript",
        help="Raw transcript used for the latest presale MOM generation.",
    )
    x_last_presale_meeting_date = fields.Date(
        "Latest Presale Meeting Date",
        help="Meeting date associated with the latest stored presale transcript.",
    )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _claude(self):
        return self.env["claude.service"]

    def _n8n(self):
        return self.env["sales.ai.n8n"]

    def _store_and_log_presale_transcript(self, transcript, meeting_date=None):
        """Persist incoming transcript on ticket before any MOM generation."""
        self.ensure_one()
        transcript_text = (transcript or "").strip()
        if not transcript_text:
            return

        vals = {"x_last_presale_transcript": transcript_text[:200000]}
        if meeting_date:
            try:
                vals["x_last_presale_meeting_date"] = fields.Date.to_date(meeting_date)
            except Exception:
                pass
        self.sudo().write(vals)

        preview = transcript_text[:3000]
        if len(transcript_text) > 3000:
            preview += "\n\n... [truncated for preview]"
        body = "<b>Presale transcript captured for verification.</b><br/><pre>%s</pre>" % (
            tools.html_escape(preview),
        )
        self.message_post(body=body, subtype_xmlid="mail.mt_note")

    @api.model
    def _sales_ai_holiday_dates(self):
        ICP = self.env["ir.config_parameter"].sudo()
        raw = ICP.get_param("sales_ai.public_holidays_json", default="[]")
        try:
            return {fields.Date.from_string(d) for d in json.loads(raw or "[]") if d}
        except Exception:
            return set()

    @api.model
    def _sales_ai_is_working_day(self, day):
        if isinstance(day, str):
            day = fields.Date.from_string(day)
        holidays = self._sales_ai_holiday_dates()
        return day.weekday() < 5 and day not in holidays

    @api.model
    def _sales_ai_previous_working_day(self, day):
        from datetime import timedelta

        if isinstance(day, str):
            day = fields.Date.from_string(day)
        cur = day - timedelta(days=1)
        while not self._sales_ai_is_working_day(cur):
            cur -= timedelta(days=1)
        return cur

    def _notify_ticket_issue(self, title, detail, create_activity=True):
        """Surface runtime issues in ticket UI (chatter + optional activity)."""
        for ticket in self:
            try:
                ticket.with_context(sales_ai_silent_note=True).message_post(
                    body="<b>⚠ %s</b><br/>%s" % (title, detail),
                    subtype_xmlid="mail.mt_note",
                )
            except Exception:
                _logger.warning(
                    "sales_ai: failed to post ticket issue note ticket=%s",
                    ticket.id,
                    exc_info=True,
                )
            if create_activity and ticket.user_id:
                todo_type = self.env.ref("mail.mail_activity_data_todo", raise_if_not_found=False)
                try:
                    self.env["mail.activity"].sudo().create({
                        "res_model_id": self.env.ref(
                            "sh_all_in_one_helpdesk.model_sh_helpdesk_ticket"
                        ).id,
                        "res_id": ticket.id,
                        "user_id": ticket.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": title[:120],
                        "note": detail[:2000],
                        "date_deadline": fields.Date.today(),
                    })
                except Exception:
                    _logger.warning(
                        "sales_ai: failed to create ticket issue activity ticket=%s",
                        ticket.id,
                        exc_info=True,
                    )

    def _sync_yesterday_lead_messages_to_ticket(self, target_date):
        """Copy yesterday lead replies/log-notes into ticket chatter once."""
        self.ensure_one()
        lead = self._get_linked_lead()
        if not lead:
            return 0

        # Stop loop once WBS is generated.
        if self.x_ticket_status not in ("open",):
            return 0

        synced = 0
        for msg in lead.message_ids.sorted("date", reverse=False):
            if not msg.date or msg.date.date() != target_date:
                continue
            # Keep human-relevant content: emails, comments, and log notes.
            if msg.message_type not in ("email", "comment"):
                continue
            body = (msg.body or "").strip()
            if not body:
                continue
            if _AGENDA_MARKER in body or _LEAD_SYNC_MARKER in body:
                continue

            marker = "%s source_message_id=%s" % (_LEAD_SYNC_MARKER, msg.id)
            already = self.message_ids.filtered(lambda m: marker in (m.body or ""))
            if already:
                continue

            author = msg.author_id.display_name or "Unknown"
            subject = msg.subject or "No subject"
            when = fields.Datetime.to_string(msg.date) if msg.date else ""
            plain = tools.html2plaintext(body).strip()
            if len(plain) > 2000:
                plain = plain[:2000] + "\n\n... [truncated]"

            sync_body = (
                "<p><b>%s</b></p>"
                "<p><b>From lead chatter</b> | <b>Date:</b> %s | <b>Author:</b> %s</p>"
                "<p><b>Subject:</b> %s</p>"
                "<pre>%s</pre>"
            ) % (
                marker,
                tools.html_escape(when),
                tools.html_escape(author),
                tools.html_escape(subject),
                tools.html_escape(plain),
            )
            self.message_post(body=sync_body, subtype_xmlid="mail.mt_note")
            synced += 1

        if synced:
            _logger.info(
                "sales_ai: Synced %d lead message(s) to ticket %s for %s",
                synced, self.id, target_date,
            )
        return synced

    def _n8n_safe_post(self, endpoint, payload, context_label="n8n call"):
        """Post to n8n with full error handling."""
        try:
            return self._n8n().post(endpoint, payload)
        except Exception as exc:
            _logger.error(
                "sales_ai: [N8N-FAIL] %s — endpoint=%s ticket=%s error=%s",
                context_label, endpoint, self.id, exc, exc_info=True,
            )
            self._notify_ticket_issue(
                _("n8n Error"),
                _("%s failed: %s") % (context_label, str(exc)[:300]),
            )
            return None

    # ------------------------------------------------------------------
    # WBS context collection (ticket -> n8n)
    # ------------------------------------------------------------------

    def _get_all_moms(self):
        """Return presale MOM history entries as list of dicts."""
        self.ensure_one()
        moms = []
        try:
            raw = json.loads(self.x_presale_mom_history or "[]")
        except Exception:
            raw = []
        if isinstance(raw, list):
            for entry in raw[:50]:
                if not isinstance(entry, dict):
                    continue
                moms.append(
                    {
                        "date": entry.get("date") or "",
                        "content": entry.get("mom") or "",
                        "decisions": entry.get("decisions") or [],
                    }
                )
        return moms

    def _get_requirements(self):
        """Extract requirements hints from ticket notes + linked lead pain point."""
        self.ensure_one()
        req = []
        note_subtype = self.env.ref("mail.mt_note", raise_if_not_found=False)
        notes = self.message_ids.filtered(
            lambda m: m.subtype_id and note_subtype and m.subtype_id.id == note_subtype.id
        ).sorted("date", reverse=False)[-40:]
        for n in notes:
            body_plain = tools.html2plaintext(n.body or "").strip()
            body_plain = _strip_financial_data(body_plain)
            if len(body_plain) >= 80:
                req.append(body_plain[:500])
        lead = self._get_linked_lead()
        if lead and lead.x_likely_pain_point:
            req.insert(0, (lead.x_likely_pain_point or "")[:500])
        return req[:60]

    def _get_tech_stack(self):
        """Return tech stack hints (best-effort) from enrichment fields."""
        self.ensure_one()
        lead = self._get_linked_lead()
        if not lead:
            return ""
        chunks = []
        if getattr(lead, "x_industry", False):
            chunks.append("Industry: %s" % (lead.x_industry or ""))
        if getattr(lead, "x_apollo_data_raw", False):
            chunks.append("Apollo raw present: yes")
        return "\n".join([c for c in chunks if c]).strip()

    def _get_client_systems(self):
        """Return client's existing systems context (best-effort)."""
        self.ensure_one()
        lead = self._get_linked_lead()
        if not lead:
            return ""
        parts = []
        if getattr(lead, "x_company_tech_stack", False):
            parts.append("Company tech stack: %s" % (lead.x_company_tech_stack or ""))
        if getattr(lead, "x_apollo_data_raw", False):
            parts.append("Apollo data available")
        return "\n".join(parts).strip()

    def _get_chatter_summary(self):
        """Compact chronological chatter export (token controlled)."""
        self.ensure_one()
        lines = []
        msgs = self.message_ids.sorted("date", reverse=False)[-120:]
        for m in msgs:
            dt = fields.Datetime.to_string(m.date) if m.date else ""
            who = m.author_id.display_name or "Unknown"
            subject = (m.subject or "").strip()
            body_plain = tools.html2plaintext(m.body or "").replace("\n", " ").strip()
            body_plain = _strip_financial_data(body_plain)[:300]
            if not (subject or body_plain):
                continue
            lines.append("[%s] %s | %s | %s" % (dt, who, subject or "-", body_plain or "-"))
        return "\n".join(lines).strip()

    def _get_linked_lead_context(self):
        """Return key lead fields useful for n8n prompt context."""
        self.ensure_one()
        lead = self._get_linked_lead()
        if not lead:
            return {}
        return _json_safe(
            {
                "lead_id": lead.id,
                "lead_name": lead.name or "",
                "company": (lead.partner_id.name if lead.partner_id else lead.partner_name) or "",
                "score": getattr(lead, "x_lead_score", 0) or 0,
                "score_band": getattr(lead, "x_lead_score_band", "") or "",
                "industry": getattr(lead, "x_industry", "") or "",
                "pain_point": getattr(lead, "x_likely_pain_point", "") or "",
                "inquiry_category": getattr(lead, "x_inquiry_category", "") or "",
            }
        )

    # WBS/proposal flows removed.

    @api.model
    def _extract_ticket_marked_segments(self, transcript: str) -> List[Tuple[str, str]]:
        """Split transcript by markers like 'moving to ticket #PST-1042'."""
        transcript = (transcript or "").strip()
        if not transcript:
            return []
        lines = transcript.splitlines()
        segments: List[Tuple[str, str]] = []
        current_marker = ""
        current_lines: List[str] = []

        def _flush():
            marker = (current_marker or "").strip()
            content = "\n".join(current_lines).strip()
            if marker and content:
                segments.append((marker, content))

        for raw in lines:
            line = (raw or "").strip()
            if not line:
                if current_marker:
                    current_lines.append(raw)
                continue

            switch_m = _TICKET_SWITCH_RE.search(line)
            number_m = _TICKET_NUMBER_RE.search(line)
            if switch_m or number_m:
                _flush()
                marker_raw = ""
                if switch_m:
                    marker_raw = (switch_m.group(1) or "").strip()
                elif number_m:
                    marker_raw = (number_m.group(1) or "").strip()
                # Keep a compact token only (e.g. PST-1042, 1042)
                marker_raw = re.split(r"[\s;,.|]", marker_raw)[0].strip()
                marker_raw = re.sub(r"^(number|no|id|name)\s*[:\-]?\s*", "", marker_raw, flags=re.IGNORECASE)
                current_marker = marker_raw.upper()
                current_lines = []
                continue

            if current_marker:
                current_lines.append(raw)

        _flush()
        return segments

    @api.model
    def _resolve_ticket_from_marker(self, marker: str, lead_id: int | None = None):
        """Resolve marker token to a helpdesk ticket."""
        marker_raw = (marker or "").strip()
        if not marker_raw:
            return self.browse()
        key = marker_raw.upper().replace(" ", "")
        key = re.sub(r"^(?:TICKET|NUMBER|NO|ID)\s*[:#-]?\s*", "", key, flags=re.IGNORECASE)
        # Normalize PST123 to PST-123
        if key.startswith("PST") and not key.startswith("PST-"):
            key = "PST-" + key[3:].lstrip("-")
        num = re.sub(r"[^\d]", "", key)
        base_domain = []
        if lead_id:
            base_domain.append(("x_linked_lead_id", "=", int(lead_id)))
        if key.startswith("PST-"):
            d = list(base_domain) + [("x_presale_ref", "=", key)]
            ticket = self.search(d, order="id desc", limit=1)
            if ticket:
                return ticket
        if num:
            local = list(base_domain)
            local.extend(["|", ("id", "=", int(num)), ("x_presale_ref", "=", "PST-%s" % num)])
            ticket = self.search(local, order="id desc", limit=1)
            if ticket:
                return ticket
            # Ticket sequence names like TICKET/0014 or just "0014"
            by_name_num = self.search(
                list(base_domain) + [("name", "ilike", num)],
                order="id desc",
                limit=1,
            )
            if by_name_num:
                return by_name_num
            # Robust fallback: some DBs keep ticket number in custom fields.
            # Scan stored char/text fields for the numeric token.
            text_fields = []
            for fname, fdef in self._fields.items():
                if getattr(fdef, "type", None) in ("char", "text") and getattr(fdef, "store", True):
                    if fname not in {"display_name", "__last_update"}:
                        text_fields.append(fname)
            if text_fields:
                preferred = [f for f in ("name", "x_presale_ref", "description") if f in text_fields]
                text_fields = preferred + [f for f in text_fields if f not in preferred]
                chunk_size = 12
                candidates = self.browse()
                for i in range(0, len(text_fields), chunk_size):
                    chunk = text_fields[i:i + chunk_size]
                    dom = list(base_domain)
                    or_part = [(f, "ilike", num) for f in chunk]
                    if len(or_part) == 1:
                        dom += [or_part[0]]
                    else:
                        dom += ["|" for _ in range(len(or_part) - 1)] + or_part
                    candidates |= self.search(dom, order="id desc", limit=20)
                if candidates:
                    # Prefer exact numeric token occurrences.
                    best = self.browse()
                    best_score = -1
                    for cand in candidates[:40]:
                        txt = []
                        for f in text_fields[:40]:
                            v = getattr(cand, f, False)
                            if isinstance(v, str) and v:
                                txt.append(v[:200])
                        blob = " ".join(txt).upper()
                        score = 1
                        if ("PST-%s" % num) in blob:
                            score += 3
                        if re.search(r"\b%s\b" % re.escape(num), blob):
                            score += 2
                        if score > best_score:
                            best_score = score
                            best = cand
                    if best:
                        return best
        # Finally: resolve by ticket name phrase (no PST prefix required)
        by_name = self.search(
            list(base_domain) + [("name", "ilike", marker_raw)],
            order="id desc",
            limit=1,
        )
        if by_name:
            return by_name
        return self.browse()

    @api.model
    def _resolve_ticket_from_transcript_number_and_name(
        self,
        transcript: str,
        meeting_name: str = "",
        lead_id: int | None = None,
    ):
        """Fallback matcher using transcript ticket-number + meeting name hints."""
        transcript = (transcript or "").strip()
        if not transcript:
            return self.browse()

        nums = _TRANSCRIPT_TICKET_NUM_RE.findall(transcript or "")
        if not nums:
            # Secondary fallback: any strong numeric token in transcript.
            nums = re.findall(r"\b\d{3,}\b", transcript or "")
        # Keep order, de-duplicate.
        seen = set()
        ticket_nums: List[str] = []
        for n in nums:
            if n not in seen:
                seen.add(n)
                ticket_nums.append(n)
        if not ticket_nums:
            return self.browse()

        base_domain = []
        if lead_id:
            base_domain.append(("x_linked_lead_id", "=", int(lead_id)))

        # Candidate fields may differ per helpdesk installation.
        # Build robust field list dynamically from all text-like stored fields.
        num_fields = []
        for fname, fdef in self._fields.items():
            if getattr(fdef, "type", None) not in ("char", "text"):
                continue
            if not getattr(fdef, "store", True):
                continue
            if fname in {"display_name", "__last_update"}:
                continue
            num_fields.append(fname)
        # Keep common fields first for faster/better matches.
        preferred = [f for f in ("name", "x_presale_ref", "description") if f in num_fields]
        num_fields = preferred + [f for f in num_fields if f not in preferred]

        name_tokens = [t for t in re.findall(r"[A-Z0-9]{2,}", (meeting_name or "").upper()) if t not in {"MEETING", "STAND", "UP", "TICKET", "NUMBER"}]

        best_ticket = self.browse()
        best_score = -1
        for num in ticket_nums[:20]:
            # Try strict id/ref first.
            if "x_presale_ref" in self._fields:
                strict = self.search(list(base_domain) + [("x_presale_ref", "=", "PST-%s" % num)], limit=1)
                if strict:
                    return strict
            by_id = self.search(list(base_domain) + [("id", "=", int(num))], limit=1)
            if by_id:
                return by_id

            # Build OR domain over available fields using the number.
            if not num_fields:
                continue
            candidates = self.browse()
            # Split into chunks to avoid too-long domains on very customized models.
            chunk_size = 12
            for i in range(0, len(num_fields), chunk_size):
                chunk = num_fields[i:i + chunk_size]
                dom = list(base_domain)
                or_part = [(f, "ilike", num) for f in chunk]
                if len(or_part) == 1:
                    dom += [or_part[0]]
                else:
                    dom += ["|" for _ in range(len(or_part) - 1)] + or_part
                candidates |= self.search(dom, order="id desc", limit=20)
            candidates = candidates[:40]
            for t in candidates:
                text_chunks = []
                for f in num_fields[:40]:
                    val = getattr(t, f, False)
                    if isinstance(val, str) and val:
                        text_chunks.append(val[:200])
                text = " ".join(text_chunks).upper()
                score = 1  # number matched
                if name_tokens:
                    score += sum(1 for tok in name_tokens if tok in text)
                # Prioritize explicit presale refs and exact numeric occurrences.
                if ("PST-%s" % num) in text:
                    score += 3
                if re.search(r"\b%s\b" % re.escape(num), text):
                    score += 2
                if score > best_score:
                    best_score = score
                    best_ticket = t

        return best_ticket if best_ticket else self.browse()

    @api.model
    def action_route_multi_ticket_transcript(
        self,
        transcript: str,
        lead_id: int | None = None,
        meeting_date=None,
        meeting_duration=None,
        attendees=None,
        prior_open_items=None,
    ):
        """Route one transcript to multiple tickets based on spoken markers."""
        segments = self._extract_ticket_marked_segments(transcript)
        if not segments:
            return {"processed_count": 0, "segments": 0, "unmatched_markers": []}

        processed = 0
        unmatched: List[str] = []
        used_ticket_ids: List[int] = []

        for marker, chunk in segments:
            ticket = self._resolve_ticket_from_marker(marker, lead_id=lead_id)
            if not ticket:
                unmatched.append(marker)
                continue
            ticket.with_context(ai_force_sync=True).action_generate_presale_mom(
                transcript=chunk,
                meeting_date=meeting_date,
                meeting_duration=meeting_duration,
                attendees=attendees or [],
                prior_open_items=prior_open_items or [],
            )
            processed += 1
            used_ticket_ids.append(ticket.id)

        return {
            "processed_count": processed,
            "segments": len(segments),
            "ticket_ids": used_ticket_ids,
            "unmatched_markers": unmatched,
        }

    def _get_linked_lead(self):
        """Return the linked CRM lead, preferring x_linked_lead_id over sh_lead_ids."""
        self.ensure_one()
        if self.x_linked_lead_id:
            return self.x_linked_lead_id
        if hasattr(self, "sh_lead_ids") and self.sh_lead_ids:
            return self.sh_lead_ids[0]
        return self.env["crm.lead"]

    def _build_compact_timeline(self, lead):
        """Build a compact, deterministic timeline from lead mails/log notes.

        This is used both as Claude input and as a fallback gist when the API
        is unreachable. Keep it concise to reduce token usage.
        """
        msgs = lead.message_ids.sorted("date", reverse=False)
        timeline_lines = []
        for m in msgs:
            if m.message_type not in ("email", "comment"):
                continue
            msg_dt = fields.Datetime.to_string(m.date) if m.date else ""
            who = m.author_id.display_name or "Unknown"
            subtype = (m.subtype_id.name or "").strip() if m.subtype_id else ""
            title = (m.subject or "").strip()
            body_plain = tools.html2plaintext(m.body or "").replace("\n", " ").strip()
            body_plain = _strip_financial_data(body_plain)[:260]
            timeline_lines.append(
                "[%s] (%s%s) %s | %s | %s" % (
                    msg_dt,
                    m.message_type,
                    (":%s" % subtype) if subtype else "",
                    who,
                    title or "No subject",
                    body_plain or "No content",
                )
            )
        if not timeline_lines:
            return "No lead mails or log notes found."
        return "\n".join(timeline_lines[-120:])

    def _collect_timeline_entries(self, lead):
        """Collect ordered timeline entries with title/date/summary."""
        entries = []
        msgs = lead.message_ids.sorted("date", reverse=False)
        for m in msgs:
            if m.message_type not in ("email", "comment"):
                continue
            msg_dt = fields.Datetime.to_string(m.date) if m.date else ""
            title = (m.subject or "").strip() or "No subject"
            summary = tools.html2plaintext(m.body or "").replace("\n", " ").strip()
            summary = _strip_financial_data(summary)[:240] or "No content"
            entries.append({
                "date": msg_dt,
                "title": title,
                "summary": summary,
                "kind": m.message_type,
            })
        return entries[-120:]

    def _collect_attachment_summaries(self, lead):
        """Collect lightweight attachment summaries from lead chatter mails."""
        summaries = []
        attachments = lead.message_ids.mapped("attachment_ids").sorted(
            key=lambda a: (a.create_date or fields.Datetime.now())
        )
        for att in attachments[-50:]:
            dt = fields.Datetime.to_string(att.create_date) if att.create_date else ""
            name = att.name or "Unnamed attachment"
            mime = att.mimetype or "application/octet-stream"

            snippet = ""
            index_content = (getattr(att, "index_content", "") or "").strip()
            if index_content:
                snippet = index_content[:300]
            elif mime.startswith("text/") and att.datas:
                try:
                    decoded = base64.b64decode(att.datas or b"").decode("utf-8", errors="ignore")
                    snippet = decoded[:300]
                except Exception:
                    snippet = ""
            elif mime in ("application/json", "text/csv") and att.datas:
                try:
                    decoded = base64.b64decode(att.datas or b"").decode("utf-8", errors="ignore")
                    snippet = decoded[:300]
                except Exception:
                    snippet = ""

            snippet = _strip_financial_data((snippet or "").replace("\n", " ").strip())
            if not snippet:
                snippet = "Binary attachment captured; summary unavailable."

            summaries.append({
                "date": dt,
                "title": name,
                "summary": snippet[:240],
                "kind": "attachment",
                "mimetype": mime,
            })
        return summaries

    def _persist_gist(self, ticket, gist_html, timeline_entries=None, attachment_entries=None):
        """Persist gist in description (HTML field) and x_ticket_gist."""
        timeline_entries = timeline_entries or []
        attachment_entries = attachment_entries or []
        gist_plain = _normalize_gist_text(gist_html or "")
        gist_plain = _clean_gist_for_description(gist_plain)
        ref = ticket.x_presale_ref or ("PST-%d" % ticket.id)
        lock_key = "sales_ai.gist.persist.ticket_%s" % ticket.id
        last_exc = None

        for attempt in range(3):
            try:
                with self.env.cr.savepoint():
                    # Serialize concurrent gist writes/notes for the same ticket.
                    self.env.cr.execute(
                        "SELECT pg_advisory_xact_lock(hashtext(%s))",
                        [lock_key],
                    )

                    ticket.sudo().write({"x_ticket_gist": gist_plain})

                    if "description" in ticket._fields:
                        desc = self._build_description_html(
                            ref, gist_plain, timeline_entries, attachment_entries
                        )
                        ticket.sudo().write({"description": desc})

                    if gist_plain:
                        gist_body_content = _format_gist_for_chatter(gist_plain)
                        gist_body = "<b>[%s] Presale Gist</b><br/><br/>%s" % (
                            tools.html_escape(ref),
                            gist_body_content,
                        )
                    else:
                        gist_body = "<b>[%s] Gist synced to Description and Presale Gist fields.</b>" % (
                            tools.html_escape(ref),
                        )

                    ticket.with_context(sales_ai_silent_note=True).message_post(
                        body=gist_body,
                        subtype_xmlid="mail.mt_note",
                    )

                    company_name = ""
                    if ticket.x_linked_lead_id:
                        lead = ticket.x_linked_lead_id
                        company_name = lead.partner_name or (
                            lead.partner_id.name if lead.partner_id else ""
                        )
                    company_name = company_name or "Unknown"

                    ticket.message_notify(
                        body=_(
                            "New presale ticket %s created for %s "
                            "— Gist attached. Please review before daily agenda."
                        ) % (ref, company_name),
                        partner_ids=ticket.message_partner_ids.ids,
                        subtype_xmlid="mail.mt_note",
                    )
                return
            except psycopg2.errors.SerializationFailure as exc:
                last_exc = exc
                _logger.warning(
                    "sales_ai: gist persist serialization retry %d/3 ticket=%s",
                    attempt + 1, ticket.id,
                )
                continue

        if last_exc:
            raise last_exc

    @staticmethod
    def _build_description_html(ref, gist_plain, timeline_entries, attachment_entries):
        """Return clean HTML for the ticket description field."""
        esc = tools.html_escape

        parts = [
            '<div style="font-family: sans-serif; font-size: 13px; line-height: 1.5;">',
            '<h3 style="margin:0 0 4px;">[%s] Presale Gist</h3>' % esc(ref),
            '<p style="color:#666; margin:0 0 12px; font-size:11px;">'
            'Last synced: %s</p>' % esc(str(fields.Datetime.now())),
        ]

        # --- AI Summary section ---
        parts.append('<h4 style="margin:12px 0 4px;">AI Summary</h4>')
        if gist_plain:
            for line in gist_plain.split("\n"):
                line = line.strip()
                if not line:
                    continue
                if line.startswith("- "):
                    parts.append(
                        '<li style="margin-left:16px;">%s</li>' % esc(line[2:])
                    )
                elif line.endswith(":"):
                    parts.append(
                        '<p style="margin:8px 0 2px;"><b>%s</b></p>' % esc(line)
                    )
                else:
                    parts.append('<p style="margin:2px 0;">%s</p>' % esc(line))
        else:
            parts.append('<p style="color:#999;">No AI summary.</p>')

        # --- Timeline section (last 10) ---
        recent_timeline = timeline_entries[-10:]
        if recent_timeline:
            parts.append('<h4 style="margin:14px 0 4px;">Timeline</h4>')
            parts.append(
                '<table style="width:100%; border-collapse:collapse; font-size:12px;">'
                '<tr style="background:#f5f5f5;">'
                '<th style="text-align:left; padding:4px 6px;">Date</th>'
                '<th style="text-align:left; padding:4px 6px;">Subject</th>'
                '<th style="text-align:left; padding:4px 6px;">Summary</th></tr>'
            )
            for item in recent_timeline:
                parts.append(
                    '<tr>'
                    '<td style="padding:3px 6px; border-bottom:1px solid #eee; white-space:nowrap;">%s</td>'
                    '<td style="padding:3px 6px; border-bottom:1px solid #eee;">%s</td>'
                    '<td style="padding:3px 6px; border-bottom:1px solid #eee;">%s</td>'
                    '</tr>' % (
                        esc(str(item.get("date", ""))[:16]),
                        esc(str(item.get("title", ""))[:80]),
                        esc(str(item.get("summary", ""))[:120]),
                    )
                )
            parts.append('</table>')

        # --- Attachments section (last 5) ---
        recent_att = attachment_entries[-5:]
        if recent_att:
            parts.append('<h4 style="margin:14px 0 4px;">Attachments</h4><ul style="margin:0; padding-left:18px;">')
            for item in recent_att:
                parts.append(
                    '<li>%s - %s</li>' % (
                        esc(str(item.get("title", "Untitled"))),
                        esc(str(item.get("summary", ""))[:100]),
                    )
                )
            parts.append('</ul>')

        parts.append('</div>')
        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Create override: auto-trigger presale workflow
    # ------------------------------------------------------------------

    @api.model_create_multi
    def create(self, vals_list):
        tickets = super().create(vals_list)
        for ticket in tickets:
            lead = ticket._resolve_linked_lead_on_create()
            if not lead:
                # Plain helpdesk ticket, not a presale ticket linked to a lead
                continue
            if not ticket.x_linked_lead_id:
                ticket.x_linked_lead_id = lead.id

            # Ensure subject/name is set in a presale-friendly way if missing
            if not ticket.name:
                base_name = lead.partner_id.name or lead.partner_name or lead.name
                ticket.name = "%s - %s" % (_("Presale"), base_name or _("No subject"))

            ticket.x_presale_ref = "PST-%d" % ticket.id
            ticket.x_ticket_status = "open"

            if lead.user_id:
                try:
                    ticket.message_subscribe(partner_ids=[lead.user_id.partner_id.id])
                except Exception:
                    _logger.warning(
                        "sales_ai: Could not subscribe lead owner to ticket %s",
                        ticket.id,
                    )

            _logger.info(
                "sales_ai: [TICKET-CREATE] Presale ticket %s (PST-%d) created for lead %s",
                ticket.name, ticket.id, lead.id,
            )

            # Generate the initial Ticket Gist asynchronously after the transaction
            # commits so ticket creation stays responsive for the user.
            self._defer_gist_generation(ticket)

        return tickets

    def _resolve_linked_lead_on_create(self):
        """Determine the linked lead from various sources."""
        self.ensure_one()
        if self.x_linked_lead_id:
            return self.x_linked_lead_id
        if hasattr(self, "sh_lead_ids") and self.sh_lead_ids:
            return self.sh_lead_ids[0]
        return None

    @api.model
    def _defer_gist_generation(self, ticket):
        """Defer gist generation to a post-commit callback so create() stays fast.

        This avoids extra Python threads touching the database while still
        running the potentially long Claude call outside of the ticket
        creation transaction.

        IMPORTANT: We open a fresh cursor so that writes made by the gist
        agent (x_ticket_gist, description, chatter notes) get their own
        transaction and are actually committed.  Using the original env's
        cursor would leave those writes uncommitted because the main
        transaction already committed before this callback fires.
        """
        ticket_id = ticket.id
        uid = self.env.uid
        context = dict(self.env.context)

        @self.env.cr.postcommit.add
        def _generate_gist_after_commit():
            last_exc = None
            for attempt in range(3):
                try:
                    with self.pool.cursor() as new_cr:
                        new_env = api.Environment(new_cr, uid, context)
                        # Serialize per ticket to avoid concurrent post-commit gist writes.
                        new_env.cr.execute(
                            "SELECT pg_advisory_xact_lock(hashtext(%s))",
                            ["sales_ai.postcommit_gist.ticket_%s" % ticket_id],
                        )
                        t = new_env["sh.helpdesk.ticket"].browse(ticket_id)
                        if not t.exists():
                            _logger.warning("sales_ai: [POSTCOMMIT-GIST] ticket %s not found", ticket_id)
                            return
                        result = t.with_context(ai_force_sync=True).action_generate_ticket_gist()
                        if result and result.get("generated"):
                            _logger.info(
                                "sales_ai: [POSTCOMMIT-GIST] completed for ticket %s", ticket_id
                            )
                        else:
                            _logger.warning(
                                "sales_ai: [POSTCOMMIT-GIST] no gist generated for ticket %s",
                                ticket_id,
                            )
                    return
                except psycopg2.errors.SerializationFailure as exc:
                    last_exc = exc
                    _logger.warning(
                        "sales_ai: [POSTCOMMIT-GIST] serialization retry %d/3 ticket=%s",
                        attempt + 1,
                        ticket_id,
                    )
                    time.sleep(0.15 * (attempt + 1))
                    continue
                except Exception:
                    _logger.error(
                        "sales_ai: [POSTCOMMIT-GIST] FAILED for ticket %s",
                        ticket_id,
                        exc_info=True,
                    )
                    return
            if last_exc:
                _logger.error(
                    "sales_ai: [POSTCOMMIT-GIST] failed after retries ticket=%s error=%s",
                    ticket_id,
                    last_exc,
                )

    # ==================================================================
    # AGENT 8: TicketGistAgent (Sonnet)
    # ==================================================================

    def action_generate_ticket_gist(self):
        """Pull all lead history and generate a presale discussion gist.

        GIST STRUCTURE (per spec):
        - Client overview (company, size, industry)
        - What they're looking for
        - Key requirements identified so far
        - Open questions that need answering
        - Budget signals (qualitative only -- financial figures stripped)
        - Timeline signals
        - Risk flags
        - Recommended presale approach
        """
        generated = 0
        failed = 0
        for ticket in self:
            lead = ticket._get_linked_lead()
            if not lead:
                ticket.message_post(
                    body=_("No linked CRM lead found. Cannot generate gist."),
                    subtype_xmlid="mail.mt_note",
                )
                failed += 1
                continue

            lines: List[str] = []
            timeline = ticket._build_compact_timeline(lead)
            timeline_entries = ticket._collect_timeline_entries(lead)
            attachment_entries = ticket._collect_attachment_summaries(lead)
            lines.append("[Lead Timeline]\n%s" % timeline)
            if attachment_entries:
                lines.append("[Attachment Summaries]")
                for item in attachment_entries:
                    lines.append(
                        "[%s] %s (%s): %s" % (
                            item.get("date", ""),
                            item.get("title", ""),
                            item.get("mimetype", ""),
                            item.get("summary", ""),
                        )
                    )

            activity_notes = self.env["mail.activity"].sudo().search([
                ("res_model", "=", "crm.lead"),
                ("res_id", "=", lead.id),
            ])
            for act in activity_notes:
                if act.note:
                    act_plain = tools.html2plaintext(act.note or "").replace("\n", " ").strip()
                    act_plain = _strip_financial_data(act_plain)[:300]
                    lines.append("[Activity %s] %s" % (act.date_deadline, act_plain))

            enrichment_context = ""
            if lead.x_apollo_data_raw:
                try:
                    raw = json.loads(lead.x_apollo_data_raw)
                    enrichment_context = json.dumps({
                        "industry": lead.x_industry or "",
                        "employee_count": lead.x_employee_count_range or "",
                        "country": lead.x_hq_country_id.name if lead.x_hq_country_id else "",
                        "seniority": lead.x_contact_seniority_structured or "",
                        "pain_point": lead.x_likely_pain_point or "",
                        "icp_signals": lead.x_icp_match_signals or "",
                    }, ensure_ascii=False)
                except Exception:
                    pass

            if enrichment_context:
                lines.insert(0, "[Enrichment Data] %s" % enrichment_context)

            if lead.x_lead_score:
                lines.insert(0, "[Lead Score] %d/100 (%s)" % (
                    lead.x_lead_score, lead.x_lead_score_band or "unknown",
                ))

            if not lines:
                ticket.message_post(
                    body=_("<b>[%s] Presale opened.</b> No prior discussions found on lead.")
                    % ticket.x_presale_ref,
                    subtype_xmlid="mail.mt_note",
                )
                failed += 1
                continue

            try:
                summary = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "ticket_gist", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "ticket_gist_system"),
                    user_message="\n\n".join(lines)[:14000],
                    max_tokens=1400,
                    expect_json=False,
                )
                cleaned_summary = _strip_financial_data(summary or "")
                ticket._persist_gist(
                    ticket,
                    cleaned_summary,
                    timeline_entries=timeline_entries,
                    attachment_entries=attachment_entries,
                )
                generated += 1
            except Exception:
                _logger.error(
                    "sales_ai: Ticket gist generation failed for ticket %s",
                    ticket.id, exc_info=True,
                )
                ticket._notify_ticket_issue(
                    _("Ticket gist generation failed"),
                    _(
                        "Claude call failed; generated fallback timeline gist instead."
                    ),
                    create_activity=False,
                )
                # API/network failure fallback: deterministic HTML gist from
                # existing lead timeline so users still get usable output.
                fallback_html = (
                    "Client Timeline Snapshot:\n"
                    "Lead: %s\n"
                    "Generated: %s\n\n%s"
                ) % (
                    lead.display_name or "",
                    fields.Datetime.now(),
                    _strip_financial_data(timeline),
                )
                ticket._persist_gist(
                    ticket,
                    fallback_html,
                    timeline_entries=timeline_entries,
                    attachment_entries=attachment_entries,
                )
                generated += 1
                failed += 1

            lead.x_presale_status = "open"
            if not lead.x_presale_ref:
                lead.x_presale_ref = ticket.x_presale_ref

            _logger.info(
                "sales_ai: Ticket gist generated for ticket %s (lead %s)",
                ticket.id, lead.id,
            )
        return {"generated": generated, "failed": failed}

    # ==================================================================
    # AGENT 9: DailyAgendaAgent (Haiku) — 10:30 AM cron
    # ==================================================================

    @api.model
    def cron_generate_presale_agenda(self):
        """Daily 10:30 AM cron: generate agenda for each active presale ticket."""
        _logger.info("sales_ai: [CRON] Presale ticket agenda generator started")
        today = fields.Date.today()
        if not self._sales_ai_is_working_day(today):
            _logger.info("sales_ai: [CRON] Skip agenda on non-working day %s", today)
            return
        tickets = self.search([("x_ticket_status", "=", "open")])
        _logger.info("sales_ai: [CRON] Found %d active presale tickets", len(tickets))

        generated = 0
        for ticket in tickets:
            attempts = 3
            for attempt in range(1, attempts + 1):
                try:
                    with self.env.cr.savepoint():
                        # Re-browse inside savepoint to avoid stale cache/state.
                        t = self.browse(ticket.id)
                        created = t._generate_single_presale_agenda(today)
                    if created:
                        generated += 1
                    # Persist per-ticket to reduce cross-ticket flush conflicts.
                    self.env.cr.commit()
                    break
                except psycopg2.errors.SerializationFailure:
                    if attempt >= attempts:
                        _logger.error(
                            "sales_ai: Agenda serialization conflict for ticket %s after %d attempts",
                            ticket.id, attempts, exc_info=True,
                        )
                    else:
                        _logger.warning(
                            "sales_ai: Agenda serialization conflict for ticket %s (attempt %d/%d), retrying",
                            ticket.id, attempt, attempts,
                        )
                        time.sleep(0.2 * attempt)
                except Exception:
                    _logger.error(
                        "sales_ai: Agenda generation failed for ticket %s",
                        ticket.id, exc_info=True,
                    )
                    break

        _logger.info(
            "sales_ai: [CRON] Presale agenda completed — %d/%d generated",
            generated, len(tickets),
        )

    def _generate_single_presale_agenda(self, today):
        """Generate daily agenda for one presale ticket."""
        self.ensure_one()
        from dateutil.relativedelta import relativedelta

        note_subtype = self.env.ref("mail.mt_note", raise_if_not_found=False)
        target_date = self._sales_ai_previous_working_day(today)
        is_first_agenda = not bool(self.x_last_agenda_date)

        # First, sync yesterday lead-side communication into ticket chatter.
        self._sync_yesterday_lead_messages_to_ticket(target_date)

        # Day-2 onward: trigger only if there was yesterday communication
        # (emails/comments/log notes) excluding auto-generated notes.
        ticket_msgs = self.message_ids.filtered(
            lambda m: m.date
            and m.date.date() == target_date
            and m.message_type in ("email", "comment")
            and _AGENDA_MARKER not in (m.body or "")
            and _LEAD_SYNC_MARKER not in (m.body or "")
        ).sorted("date", reverse=False)
        # Include explicit log notes as well (even if message_type differs).
        ticket_msgs |= self.message_ids.filtered(
            lambda m: m.date
            and m.date.date() == target_date
            and m.subtype_id
            and note_subtype
            and m.subtype_id.id == note_subtype.id
            and _AGENDA_MARKER not in (m.body or "")
            and _LEAD_SYNC_MARKER not in (m.body or "")
        ).sorted("date", reverse=False)
        ticket_msgs = ticket_msgs.sorted("date", reverse=False)

        lead = self._get_linked_lead()
        lead_msgs = self.env["mail.message"]
        if lead:
            lead_msgs = lead.message_ids.filtered(
                lambda m: m.date
                and m.date.date() == target_date
                and m.message_type in ("email", "comment")
                and _AGENDA_MARKER not in (m.body or "")
            ).sorted("date", reverse=False)
            lead_msgs |= lead.message_ids.filtered(
                lambda m: m.date
                and m.date.date() == target_date
                and m.subtype_id
                and note_subtype
                and m.subtype_id.id == note_subtype.id
                and _AGENDA_MARKER not in (m.body or "")
            ).sorted("date", reverse=False)
            lead_msgs = lead_msgs.sorted("date", reverse=False)

        # First-time agenda: create once even without yesterday communication.
        if is_first_agenda:
            since = today - relativedelta(days=7)
            lines = ["[Initial Presale Context]"]
            if self.x_ticket_gist:
                lines.append("[Initial Ticket Gist]")
                lines.append((self.x_ticket_gist or "")[:1200])
            recent_ticket_msgs = self.message_ids.filtered(
                lambda m: m.date and m.date.date() >= since
            ).sorted("date", reverse=False)[-12:]
            if recent_ticket_msgs:
                lines.append("\n[Recent Ticket Activity]")
                for m in recent_ticket_msgs:
                    lines.append(
                        "[%s] %s: %s" % (m.date, m.author_id.display_name or "", (m.body or "")[:400])
                    )
            if lead:
                recent_lead_msgs = lead.message_ids.filtered(
                    lambda m: m.date and m.date.date() >= since
                ).sorted("date", reverse=False)[-12:]
                if recent_lead_msgs:
                    lines.append("\n[Recent Lead Activity]")
                    for m in recent_lead_msgs:
                        lines.append(
                            "[%s] %s: %s" % (m.date, m.author_id.display_name or "", (m.body or "")[:400])
                        )
        else:
            # If no communication yesterday on ticket/lead, skip agenda creation.
            if not ticket_msgs and not lead_msgs:
                _logger.info(
                    "sales_ai: Skip presale agenda for ticket %s — no communication on %s",
                    self.id, target_date,
                )
                return False
            lines = ["[Yesterday Ticket Communication]"]
            for m in ticket_msgs:
                lines.append(
                    "[%s] %s: %s" % (m.date, m.author_id.display_name or "", (m.body or "")[:400])
                )
            if lead_msgs:
                lines.append("\n[Yesterday Lead Communication]")
                for m in lead_msgs[-10:]:
                    lines.append(
                        "[%s] %s: %s" % (m.date, m.author_id.display_name or "", (m.body or "")[:400])
                    )

        if not is_first_agenda and not ticket_msgs and not lead_msgs:
            _logger.info(
                "sales_ai: Skip presale agenda for ticket %s — no communication on %s",
                self.id, target_date,
            )
            return False

        try:
            agenda_html = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "daily_agenda", "haiku"),
                system_prompt=prompts.get_system_prompt(self.env, "presale_agenda_system"),
                user_message="\n".join(lines)[:160000],
                max_tokens=800,
                expect_json=False,
            )
        except Exception:
            _logger.error(
                "sales_ai: Agenda Claude call failed for ticket %s",
                self.id, exc_info=True,
            )
            return False

        if agenda_html:
            self.message_post(
                body="<p><b>%s</b></p>%s" % (_AGENDA_MARKER, agenda_html),
                subtype_xmlid="mail.mt_note",
            )
            self.x_last_agenda_date = today
            _logger.info("sales_ai: Presale agenda posted on ticket %s", self.id)
            return True
        return False

    # ==================================================================
    # AGENT 10: PresaleMOMAgent (Sonnet)
    # ==================================================================

    def action_generate_presale_mom(self, transcript, meeting_date=None,
                                    meeting_duration=None, attendees=None,
                                    prior_open_items=None):
        """Generate internal presale MOM from meeting transcript.

        MOM is posted to the TICKET chatter. Financial figures are stripped.
        After MOM, auto-triggers PresaleEmailDrafterAgent on the LEAD.
        """
        self.ensure_one()
        # Serialize MOM generation per ticket to avoid concurrent-update retries
        # that can duplicate AI calls/history entries.
        self.env.cr.execute(
            "SELECT pg_advisory_xact_lock(hashtext(%s))",
            ["sales_ai.presale_mom.ticket_%s" % self.id],
        )
        lead = self._get_linked_lead()
        # json.dumps payloads sent to Claude must be plain JSON types.
        if meeting_date:
            # meeting_date may arrive as date OR string from webhook payloads.
            if isinstance(meeting_date, str):
                try:
                    meeting_date = fields.Date.to_string(fields.Date.from_string(meeting_date))
                except Exception:
                    meeting_date = str(meeting_date)[:10]
            else:
                meeting_date = fields.Date.to_string(meeting_date)
        else:
            meeting_date = fields.Date.to_string(fields.Date.today())
        _logger.info(
            "sales_ai: Generating presale MOM for ticket %s (transcript=%d chars)",
            self.id, len(transcript),
        )
        self._store_and_log_presale_transcript(transcript, meeting_date=meeting_date)

        ticket_context = self.x_ticket_gist or ""
        if lead:
            ticket_context = ticket_context or lead.x_likely_pain_point or lead.description or ""

        prior_items = prior_open_items or []
        if not prior_items:
            note_subtype = self.env.ref("mail.mt_note", raise_if_not_found=False)
            recent_notes = self.message_ids.filtered(
                lambda m: m.subtype_id and note_subtype and m.subtype_id.id == note_subtype.id
            ).sorted("date", reverse=True)[:5]
            prior_items = [(m.body or "")[:300] for m in recent_notes]

        payload = {
            "lead_id": lead.id if lead else 0,
            "ticket_id": self.x_presale_ref or ("PST-%d" % self.id),
            "meeting_date": meeting_date,
            "meeting_duration": meeting_duration or 60,
            "attendees": attendees or [],
            "ticket_context": ticket_context[:2000],
            "prior_open_items": prior_items,
            "presale_stage": self.x_ticket_status or "open",
        }
        payload = _json_safe(payload)

        from .transcript_tools import prune_transcript_text, transcript_text_to_toon

        pruned = prune_transcript_text(transcript, max_chars=45000)
        toon_text, _segs = transcript_text_to_toon(pruned, max_segments=300)

        try:
            facts = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "presale_mom", "haiku"),
                system_prompt=prompts.get_system_prompt(self.env, "presale_mom_facts_system"),
                user_message=json.dumps(
                    _json_safe({
                        "toon": toon_text,
                        "meeting_date": payload["meeting_date"],
                        "meeting_duration": payload["meeting_duration"],
                        "attendees": payload["attendees"],
                        "ticket_context": payload["ticket_context"],
                        "prior_open_items": payload["prior_open_items"],
                        "presale_stage": payload["presale_stage"],
                    }),
                    ensure_ascii=False,
                ),
                max_tokens=1600,
                expect_json=True,
            )

            if isinstance(facts, dict) and facts:
                compose_payload = _json_safe({
                    "facts": facts,
                    "lead_id": payload["lead_id"],
                    "ticket_id": payload["ticket_id"],
                    "meeting_date": payload["meeting_date"],
                    "meeting_duration": payload["meeting_duration"],
                    "attendees": payload["attendees"],
                    "ticket_context": payload["ticket_context"],
                    "prior_open_items": payload["prior_open_items"],
                    "presale_stage": payload["presale_stage"],
                })
                try:
                    resp = self._claude().call(
                        tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                        system_prompt=prompts.get_system_prompt(self.env, "presale_mom_compose_system"),
                        user_message=json.dumps(compose_payload, ensure_ascii=False),
                        max_tokens=900,
                        expect_json=True,
                    )
                except Exception:
                    # Do not fail whole MOM flow if structured JSON parsing fails.
                    # Fall back to plain-text draft and keep pipeline moving.
                    raw_mom = self._claude().call(
                        tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                        system_prompt=prompts.get_system_prompt(self.env, "presale_mom_system"),
                        user_message=json.dumps(_json_safe({**payload, "transcript": transcript[:150000]}), ensure_ascii=False),
                        max_tokens=900,
                        expect_json=False,
                    )
                    resp = {
                        "internal_mom_markdown": raw_mom or "",
                        "technical_decisions": [],
                        "stage_recommendation": "",
                        "new_action_items_us": [],
                        "new_action_items_client": [],
                        "open_technical_questions": [],
                    }
            else:
                fallback = dict(payload)
                fallback["transcript"] = transcript[:150000]
                try:
                    resp = self._claude().call(
                        tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                        system_prompt=prompts.get_system_prompt(self.env, "presale_mom_system"),
                        user_message=json.dumps(_json_safe(fallback), ensure_ascii=False),
                        max_tokens=800,
                        expect_json=True,
                    )
                except Exception:
                    raw_mom = self._claude().call(
                        tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                        system_prompt=prompts.get_system_prompt(self.env, "presale_mom_system"),
                        user_message=json.dumps(_json_safe(fallback), ensure_ascii=False),
                        max_tokens=900,
                        expect_json=False,
                    )
                    resp = {
                        "internal_mom_markdown": raw_mom or "",
                        "technical_decisions": [],
                        "stage_recommendation": "",
                        "new_action_items_us": [],
                        "new_action_items_client": [],
                        "open_technical_questions": [],
                    }
        except Exception:
            _logger.error(
                "sales_ai: Presale MOM generation failed for ticket %s",
                self.id, exc_info=True,
            )
            self._notify_ticket_issue(
                _("Presale MOM generation failed"),
                _("Could not generate MOM from transcript. Please retry."),
            )
            return

        if not isinstance(resp, dict):
            resp = {"internal_mom_markdown": str(resp or "")}

        # claude.service returns {} when expect_json=True parsing fails.
        # Never post "{}" as MOM; force a readable markdown fallback.
        if not resp:
            try:
                raw_mom = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "presale_mom", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "presale_mom_system"),
                    user_message=json.dumps(
                        _json_safe({
                            **payload,
                            "transcript": transcript[:150000],
                        }),
                        ensure_ascii=False,
                    ),
                    max_tokens=900,
                    expect_json=False,
                )
            except Exception:
                raw_mom = ""
            resp = {"internal_mom_markdown": raw_mom or ""}

        mom_md = (resp.get("internal_mom_markdown") or resp.get("internal_mom") or "").strip()
        # Guard against useless placeholder payloads.
        if mom_md in ("{}", "[]", "null", "None"):
            mom_md = ""
        if not mom_md:
            # Final deterministic fallback from transcript excerpts.
            lines = [ln.strip() for ln in (transcript or "").splitlines() if ln.strip()]
            preview = "\n".join(lines[:20])
            mom_md = (
                "## Presale MOM\n\n"
                "### Meeting Summary\n"
                "Transcript received and processed. AI returned an empty structured payload.\n\n"
                "### Discussion Highlights (raw excerpt)\n"
                f"{preview}\n\n"
                "### Action Needed\n"
                "- Review transcript and update MOM manually if needed.\n"
            )
        technical_decisions = resp.get("technical_decisions") or []
        stage_rec = resp.get("stage_recommendation") or ""

        cleaned_mom = _strip_financial_data(mom_md)
        if cleaned_mom.strip() in ("{}", "[]", "null", "None"):
            lines = [ln.strip() for ln in (transcript or "").splitlines() if ln.strip()]
            preview = "\n".join(lines[:20])
            cleaned_mom = (
                "## Presale MOM\n\n"
                "### Meeting Summary\n"
                "AI structured output was empty; using transcript excerpt.\n\n"
                "### Discussion Highlights\n"
                f"{preview}\n"
            )

        try:
            history = json.loads(self.x_presale_mom_history or "[]")
        except Exception:
            history = []
        # Remove broken placeholder entries from earlier runs.
        if isinstance(history, list):
            history = [
                h for h in history
                if isinstance(h, dict) and (h.get("mom") or "").strip() not in ("{}", "[]", "null", "None", "")
            ]
        else:
            history = []

        transcript_sha1 = hashlib.sha1((transcript or "").strip().encode("utf-8")).hexdigest()
        if history:
            last = history[-1] if isinstance(history[-1], dict) else {}
            if last.get("transcript_sha1") == transcript_sha1:
                _logger.info(
                    "sales_ai: Presale MOM duplicate transcript ignored for ticket %s",
                    self.id,
                )
                return
        history.append({
            "date": meeting_date or str(fields.Date.today()),
            "mom": cleaned_mom[:3000],
            "decisions": technical_decisions,
            "transcript_sha1": transcript_sha1,
        })
        self.x_presale_mom_history = json.dumps(history, ensure_ascii=False)

        self.message_post(
            body=tools.html_sanitize(tools.plaintext2html(cleaned_mom or "")),
            subtype_xmlid="mail.mt_note",
        )

        us_items = resp.get("new_action_items_us") or []
        client_items = resp.get("new_action_items_client") or []
        open_questions = resp.get("open_technical_questions") or []
        # Ensure "questions to client" are always AI-derived, even when
        # structured compose fallback path produced limited fields.
        if lead and not open_questions:
            try:
                q_payload = {
                    "mom_markdown": (cleaned_mom or "")[:12000],
                    "transcript_excerpt": (transcript or "")[:12000],
                    "presale_stage": self.x_ticket_status or "open",
                }
                q_resp = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "presale_mom", "haiku"),
                    system_prompt=prompts.get_system_prompt(self.env, "presale_client_questions_system"),
                    user_message=json.dumps(_json_safe(q_payload), ensure_ascii=False),
                    max_tokens=500,
                    expect_json=True,
                )
                if isinstance(q_resp, dict):
                    open_questions = q_resp.get("open_technical_questions") or []
            except Exception:
                _logger.warning(
                    "sales_ai: failed to extract client questions from presale MOM ticket=%s",
                    self.id,
                    exc_info=True,
                )
        if us_items or client_items or stage_rec:
            parts = [
                "<b>Presale MOM Action Items [%s]</b><ul>" % (
                    self.x_presale_ref or ""
                )
            ]
            for item in us_items:
                parts.append("<li><b>[Our Team]</b> %s</li>" % item)
            for item in client_items:
                parts.append("<li><b>[Client]</b> %s</li>" % item)
            parts.append("</ul>")
            if stage_rec:
                parts.append("<p><b>Stage recommendation:</b> %s</p>" % stage_rec)
            self.message_post(body="\n".join(parts), subtype_xmlid="mail.mt_note")

        _logger.info(
            "sales_ai: Presale MOM posted on ticket %s — %d technical decisions",
            self.id, len(technical_decisions),
        )

        if lead:
            if open_questions:
                self._create_client_query_activity(lead, open_questions)
            self._trigger_presale_email_draft(lead, cleaned_mom)

    def _create_client_query_activity(self, lead, open_questions):
        """Create lead activity + note for questions to ask client."""
        questions = [q.strip() for q in (open_questions or []) if (q or "").strip()]
        if not questions:
            return
        todo_type = self.env.ref("mail.mail_activity_data_todo", raise_if_not_found=False)
        body_lines = ["Questions identified in presale MOM for %s:" % (self.x_presale_ref or self.id)]
        body_lines.extend("%d. %s" % (idx + 1, q) for idx, q in enumerate(questions[:10]))
        note = "\n".join(body_lines)

        assign_user = lead.user_id or self.user_id
        if not assign_user:
            assign_user = self.env.ref("base.user_admin", raise_if_not_found=False)
        self.env["mail.activity"].sudo().create(
            {
                "res_model_id": self.env.ref("crm.model_crm_lead").id,
                "res_id": lead.id,
                "user_id": assign_user.id if assign_user else False,
                "activity_type_id": todo_type.id if todo_type else False,
                "summary": _("Questions to ask client — %s", self.x_presale_ref or "Presale"),
                "note": note,
                "date_deadline": fields.Date.today(),
            }
        )
        lead.message_post(
            body=tools.html_sanitize(tools.plaintext2html(note)),
            subtype_xmlid="mail.mt_note",
        )

    # ==================================================================
    # AGENT 11: PresaleEmailDrafterAgent (Sonnet)
    # ==================================================================

    def _trigger_presale_email_draft(self, lead, mom_content):
        """Draft a client-facing email on the LEAD after presale MOM."""
        history_msgs = lead.message_ids.sorted("date", reverse=False)[-20:]
        history = []
        for m in history_msgs:
            if m.message_type == "email":
                history.append(
                    "[%s] %s: %s :: %s" % (
                        m.date, m.author_id.display_name or "",
                        m.subject or "", (m.body or "")[:400],
                    )
                )

        user_msg = json.dumps(
            {"presale_mom": mom_content, "client_history": history},
            ensure_ascii=False,
        )

        try:
            resp = self._claude().call(
                tier=prompts.get_agent_tier(self.env, "presale_email_drafter", "sonnet"),
                system_prompt=prompts.get_system_prompt(self.env, "presale_email_system"),
                user_message=user_msg,
                max_tokens=800,
                expect_json=True,
            )
        except Exception:
            _logger.error(
                "sales_ai: Presale email draft failed for ticket %s / lead %s",
                self.id, lead.id, exc_info=True,
            )
            self._notify_ticket_issue(
                _("Presale email draft failed"),
                _("Client email draft could not be generated from MOM."),
            )
            return

        subject = resp.get("subject") or _("Follow-up from our technical discussion")
        body_html = resp.get("body_html") or resp.get("body") or _(
            "<p>Following up on our recent technical discussion.</p>"
        )

        activity_type = self.env.ref(
            "sales_ai_integration.activity_type_presale_email",
            raise_if_not_found=False,
        )
        assign_user = lead.user_id or self.user_id
        if not assign_user:
            assign_user = self.env.ref("base.user_admin", raise_if_not_found=False)
        self.env["mail.activity"].sudo().create({
            "res_model_id": self.env.ref("crm.model_crm_lead").id,
            "res_id": lead.id,
            "user_id": assign_user.id if assign_user else False,
            "activity_type_id": activity_type.id if activity_type else False,
            "note": "[AI DRAFT — Presale]\n\n%s\n\n%s" % (subject, body_html),
            "date_deadline": fields.Date.today(),
        })
        _logger.info(
            "sales_ai: Presale email draft activity created on lead %s (from ticket %s)",
            lead.id, self.id,
        )

    # ==================================================================
    # AGENT 12: WBSGeneratorAgent (Sonnet) — button on ticket
    # ==================================================================

    def action_generate_wbs(self):
        """Trigger n8n WBS generation (Claude + Google Sheets happens in n8n)."""
        raise UserError(
            _("WBS generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        if self.x_ticket_status not in ("open", "ready_for_wbs", "ready_for_proposal"):
            raise UserError(_("Ticket must be in an active presale state to generate WBS."))

        ICP = self.env["ir.config_parameter"].sudo()
        url = (ICP.get_param("sales_ai.n8n_wbs_webhook_url", default="") or "").strip()
        if not url:
            raise UserError(
                _("n8n WBS webhook URL is not configured. Go to Settings → AI Sales Automation → n8n Integration.")
            )

        payload = self._build_wbs_payload()
        self.write({"x_wbs_status": "generating"})

        import requests
        try:
            resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=30)
        except Exception as exc:
            self.write({"x_wbs_status": "not_generated"})
            raise UserError(_("WBS generation request failed: %s") % str(exc))

        if resp.status_code == 200:
            try:
                data = resp.json() if (resp.text or "").strip() else {}
            except Exception:
                data = {}
            sheet_url = (data.get("sheet_url") or "").strip() if isinstance(data, dict) else ""
            vals = {"x_wbs_generated_date": fields.Datetime.now()}
            if sheet_url:
                vals.update({"x_wbs_sheet_url": sheet_url, "x_wbs_status": "generated"})
                self.message_post(
                    body=_('WBS generated successfully. <a href="%s" target="_blank">Open in Google Sheets</a>') % sheet_url,
                    subtype_xmlid="mail.mt_note",
                )
            else:
                # Async-friendly: if n8n responds quickly without URL, expect callback to /api/sales_ai/wbs_ready
                vals.update({"x_wbs_status": "generating"})
                self.message_post(
                    body=_("WBS generation requested from n8n. Awaiting callback to set Google Sheet URL."),
                    subtype_xmlid="mail.mt_note",
                )
                # TODO: convert to explicit async callback-only pattern if n8n always responds slowly.
            self.write(vals)

            todo_type = self.env.ref("mail.mail_activity_data_todo", raise_if_not_found=False)
            if self.user_id:
                self.env["mail.activity"].sudo().create(
                    {
                        "res_model_id": self.env.ref("sh_all_in_one_helpdesk.model_sh_helpdesk_ticket").id,
                        "res_id": self.id,
                        "user_id": self.user_id.id,
                        "activity_type_id": todo_type.id if todo_type else False,
                        "summary": _("Review generated WBS"),
                        "note": _("AI-generated WBS is ready for review in Google Sheets. Validate scope before tech estimation."),
                        "date_deadline": fields.Date.today(),
                    }
                )
            return {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "title": _("WBS Requested"),
                    "type": "success",
                    "message": _("WBS request sent to n8n."),
                    "sticky": False,
                },
            }

        self.write({"x_wbs_status": "not_generated"})
        raise UserError(_("WBS generation failed. n8n returned HTTP %s: %s") % (resp.status_code, (resp.text or "")[:500]))

    def action_regenerate_wbs(self):
        raise UserError(
            _("WBS generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        self.write({"x_wbs_status": "not_generated"})
        return self.action_generate_wbs()

    def action_open_wbs_sheet(self):
        raise UserError(
            _("WBS generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        if not self.x_wbs_sheet_url:
            raise UserError(_("No WBS sheet URL is available yet."))
        return {
            "type": "ir.actions.act_url",
            "url": self.x_wbs_sheet_url,
            "target": "new",
        }

    # ==================================================================
    # AGENT 13: ProposalGeneratorAgent (Sonnet) — stage-gated button
    # ==================================================================

    def action_request_proposal_from_ai(self):
        """Request proposal generation via n8n webhook (Claude + Drive in n8n)."""
        raise UserError(
            _("Proposal generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        if self.x_ticket_status not in ("ready_for_proposal",):
            raise UserError(
                _("Proposal can only be generated when ticket is at 'Ready for Proposal'.")
            )
        if self.x_wbs_status not in ("estimated", "complete"):
            raise UserError(_("WBS must be completed with tech estimates before generating a proposal."))

        lead = self._get_linked_lead()
        ICP = self.env["ir.config_parameter"].sudo()
        webhook_url = (ICP.get_param("sales_ai.n8n_proposal_webhook_url", default="") or "").strip()
        if not webhook_url:
            raise UserError(
                _("n8n Proposal webhook URL is not configured. Go to Settings → AI Sales Automation → n8n Integration.")
            )
        proposal_prompt = self.env["sales.ai.agent.prompt"].sudo().get_active_prompt("proposal_generator")
        # TODO: Switch to Opus 4.6 when restriction is lifted.
        payload = {
            "ticket_id": self.id,
            "ticket_reference": self.x_presale_ref or (self.name or ""),
            "client": {
                "name": (lead.contact_name if lead else "") or "",
                "company": (lead.partner_id.name if lead and lead.partner_id else lead.partner_name if lead else "") or "",
                "industry": (lead.x_industry if lead else "") or "",
                "website": (lead.partner_id.website if lead and lead.partner_id else "") or "",
                "country": (lead.partner_id.country_id.name if lead and lead.partner_id and lead.partner_id.country_id else "") or "",
                "company_size": str(self._get_partner_field_safe("employee_count", "")),
                "description": (lead.partner_id.comment if lead and lead.partner_id else "") or "",
            },
            "requirements": self._get_requirements(),
            "meeting_minutes": self._get_all_moms(),
            "wbs_sheet_url": self.x_wbs_sheet_url or "",
            "wbs_summary": self._get_wbs_summary(),
            "tech_estimates": self._get_tech_estimates(),
            "pricing": self._get_pricing_data(),
            "relationship_notes": self._get_relationship_notes(),
            "proposal_prompt": proposal_prompt,
            "proposal_template_doc_id": (ICP.get_param("sales_ai.proposal_template_doc_id", default="") or ""),
            "lead_context": self._get_linked_lead_context(),
            "ticket_gist": self.x_ticket_gist or "",
        }

        import requests
        self.write({"proposal_status": "generating"})
        try:
            response = requests.post(
                webhook_url,
                json=_json_safe(payload),
                headers={"Content-Type": "application/json"},
                timeout=120,
            )
        except Exception as exc:
            self.write({"proposal_status": "not_generated"})
            raise UserError(_("Proposal generation request failed: %s") % str(exc))

        if response.status_code == 200:
            try:
                result = response.json() if (response.text or "").strip() else {}
            except Exception:
                result = {}
            doc_url = (result.get("doc_url") or result.get("proposal_doc_url") or "").strip() if isinstance(result, dict) else ""
            vals = {"proposal_generated_date": fields.Datetime.now()}
            if doc_url:
                vals.update(
                    {
                        "proposal_doc_url": doc_url,
                        "x_proposal_drive_url": doc_url,
                        "proposal_status": "draft_ready",
                        "x_ticket_status": "proposal_generated",
                    }
                )
                self.message_post(
                    body=_("Proposal draft generated. <a href='%s' target='_blank'>Open in Google Docs</a>") % doc_url,
                    subtype_xmlid="mail.mt_note",
                )
            else:
                vals.update({"proposal_status": "generating"})
                self.message_post(
                    body=_("Proposal generation requested from n8n. Awaiting callback to set Google Doc URL."),
                    subtype_xmlid="mail.mt_note",
                )
                # TODO: convert to callback-only async pattern in n8n for large proposals.
            self.write(vals)
            if lead:
                lead.x_presale_status = "proposal_generated"
            if self.user_id:
                todo = self.env.ref("mail.mail_activity_data_todo", raise_if_not_found=False)
                self.env["mail.activity"].sudo().create(
                    {
                        "res_model_id": self.env["ir.model"]._get_id("sh.helpdesk.ticket"),
                        "res_id": self.id,
                        "user_id": self.user_id.id,
                        "activity_type_id": todo.id if todo else False,
                        "summary": _("Review proposal draft"),
                        "note": _("AI-generated proposal is ready. Review, edit, then share as PDF."),
                        "date_deadline": fields.Date.today(),
                    }
                )
            return {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "title": _("Proposal Requested"),
                    "type": "success",
                    "message": _("Proposal request sent to n8n."),
                    "sticky": False,
                },
            }

        self.write({"proposal_status": "not_generated"})
        raise UserError(
            _("Proposal generation failed. n8n returned status %s: %s")
            % (response.status_code, (response.text or "")[:500])
        )

    def action_request_proposal(self):
        raise UserError(
            _("Proposal generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        return self.action_request_proposal_from_ai()

    def action_mark_proposal_sent(self):
        raise UserError(
            _("Proposal generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        self.write({"proposal_status": "sent", "proposal_sent_date": fields.Datetime.now()})
        lead = self._get_linked_lead()
        if lead and lead.exists():
            stage = self.env["crm.stage"].sudo().search([("name", "=", "Proposal Sent")], limit=1)
            if stage:
                lead.write({"stage_id": stage.id})
        self.message_post(body=_("Proposal sent to client."), subtype_xmlid="mail.mt_note")
        return True

    def action_open_proposal_doc(self):
        raise UserError(
            _("Proposal generation flow has been removed. Living document is now auto-updated from lead/ticket chatter.")
        )
        self.ensure_one()
        doc_url = (self.proposal_doc_url or self.x_proposal_drive_url or "").strip()
        if not doc_url:
            raise UserError(_("No proposal Google Doc URL is available yet."))
        return {"type": "ir.actions.act_url", "url": doc_url, "target": "new"}

        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Proposal Generated"),
                "type": "success",
                "message": _(
                    "AI proposal generated (%d words). n8n will write to Google Drive."
                ) % word_count,
            },
        }

    # ==================================================================
    # AGENT 14: RetrospectiveAgent (Sonnet) — triggered by lead won/lost
    # ==================================================================

    def action_generate_retro(self):
        """Generate a deal retrospective and post to this ticket."""
        for ticket in self:
            lead = ticket._get_linked_lead()
            if not lead:
                continue

            outcome = "Won" if lead.stage_id and lead.stage_id.is_won else "Lost"
            _logger.info(
                "sales_ai: Generating %s retrospective on ticket %s (lead %s)",
                outcome, ticket.id, lead.id,
            )

            data = lead._build_closure_retro_payload()

            try:
                html = self._claude().call(
                    tier=prompts.get_agent_tier(self.env, "retrospective", "sonnet"),
                    system_prompt=prompts.get_system_prompt(self.env, "retro_system"),
                    user_message=json.dumps(data, ensure_ascii=False)[:160000],
                    max_tokens=800,
                    expect_json=False,
                )
            except Exception:
                _logger.error(
                    "sales_ai: Retro failed for ticket %s (lead %s)",
                    ticket.id, lead.id, exc_info=True,
                )
                ticket._notify_ticket_issue(
                    _("Retrospective generation failed"),
                    _("Could not generate deal retrospective from lead history."),
                    create_activity=False,
                )
                continue

            ticket.message_post(
                body=html or "<p>Retrospective not generated.</p>",
                subtype_xmlid="mail.mt_note",
            )
            ticket.x_retro_logged = True

            if outcome == "Won":
                ticket.x_ticket_status = "won"
            else:
                ticket.x_ticket_status = "lost"

            try:
                recipients = []
                if lead.user_id and lead.user_id.email:
                    recipients.append(lead.user_id.email)
                if hasattr(lead, "_sales_ai_send_email_notification"):
                    lead._sales_ai_send_email_notification(
                        subject="[%s] Deal Retro Ready - %s" % (outcome, lead.name or "Lead"),
                        body_html=(
                            "<p><b>Deal retrospective ready</b></p>"
                            "<p><b>Ticket:</b> %s (#%s)</p>"
                            "<p><b>Lead:</b> %s (#%s)</p>"
                            "<p><b>Company:</b> %s</p>"
                            "<p><b>Rep:</b> %s</p>"
                            "<p><b>Expected Revenue:</b> %s</p>"
                        ) % (
                            tools.html_escape(ticket.x_presale_ref or ticket.name or ""),
                            ticket.id,
                            tools.html_escape(lead.name or ""),
                            lead.id,
                            tools.html_escape(lead.partner_id.name if lead.partner_id else ""),
                            tools.html_escape(lead.user_id.name if lead.user_id else "Unassigned"),
                            lead.expected_revenue or 0,
                        ),
                        recipients=recipients,
                    )
            except Exception:
                _logger.error(
                    "sales_ai: deal retrospective email notification failed for ticket %s lead %s",
                    ticket.id,
                    lead.id,
                    exc_info=True,
                )

            _logger.info(
                "sales_ai: %s retrospective posted on ticket %s (lead %s)",
                outcome, ticket.id, lead.id,
            )

    # ==================================================================
    # Callback handlers (called by webhook controller)
    # ==================================================================

    def action_store_wbs_url(self, sheet_url):
        """Called by n8n callback when WBS is written to Google Sheets."""
        self.ensure_one()
        # WBS generation flow removed; ignore callback.
        _logger.info("sales_ai: Ignoring WBS callback for ticket %s (flow removed)", self.id)
        return True
        self.x_wbs_sheet_url = sheet_url
        self.x_wbs_status = "generated"
        self.x_wbs_generated_date = fields.Datetime.now()
        self.x_ticket_status = "wbs_done"
        lead = self._get_linked_lead()
        if lead:
            lead.x_wbs_sheet_url = sheet_url
            lead.x_presale_status = "wbs_done"
        self.message_post(
            body=_('WBS written to Google Sheets: <a href="%s" target="_blank">Open Sheet</a>') % sheet_url,
            subtype_xmlid="mail.mt_note",
        )
        _logger.info("sales_ai: WBS URL stored on ticket %s: %s", self.id, sheet_url)

    def action_store_proposal_url(self, drive_url):
        """Called by n8n callback when proposal is written to Google Drive."""
        self.ensure_one()
        # Proposal generation flow removed; ignore callback.
        _logger.info("sales_ai: Ignoring proposal callback for ticket %s (flow removed)", self.id)
        return True
        self.x_proposal_drive_url = drive_url
        self.proposal_doc_url = drive_url
        self.proposal_status = "draft_ready"
        self.proposal_generated_date = fields.Datetime.now()
        self.x_ticket_status = "proposal_generated"
        lead = self._get_linked_lead()
        if lead:
            lead.x_proposal_drive_url = drive_url
            lead.x_presale_status = "proposal_generated"

        activity_type = self.env.ref(
            "mail.mail_activity_data_todo", raise_if_not_found=False
        )
        if lead and lead.user_id:
            self.env["mail.activity"].sudo().create({
                "res_model_id": self.env.ref("crm.model_crm_lead").id,
                "res_id": lead.id,
                "user_id": lead.user_id.id,
                "activity_type_id": activity_type.id if activity_type else False,
                "summary": _("Review proposal draft"),
                "note": _('Proposal ready for review: <a href="%s">Open in Google Drive</a>') % drive_url,
                "date_deadline": fields.Date.today(),
            })

        self.message_post(
            body=_('Proposal written to Google Drive: <a href="%s" target="_blank">Open Document</a>') % drive_url,
            subtype_xmlid="mail.mt_note",
        )
        _logger.info("sales_ai: Proposal URL stored on ticket %s: %s", self.id, drive_url)
