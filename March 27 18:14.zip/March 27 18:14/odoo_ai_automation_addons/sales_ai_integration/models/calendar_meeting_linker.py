import hashlib
import json
import logging
import re
import threading
from datetime import timedelta

from odoo import api, fields, models, _

_logger = logging.getLogger("sales_ai")

# Default delays (overridden by Settings → system parameters)
_DEFAULT_CLIENT_TRANSCRIPT_DELAY = 60
_DEFAULT_PRESALE_TRANSCRIPT_DELAY = 120
_DEFAULT_PRESALE_MOM_DELAY = 0


def _bg_request_transcript(dbname, uid, event_id):
    """Background thread: request transcript from n8n ~1 min after meeting end."""
    try:
        from odoo.orm.registry import Registry
        registry = Registry(dbname)
    except Exception:
        _logger.error(
            "Sales AI: [BG-TRANSCRIPT] Cannot obtain registry for db=%s",
            dbname, exc_info=True,
        )
        return
    try:
        with registry.cursor() as cr:
            env = api.Environment(cr, uid, {})
            event = env["calendar.event"].browse(event_id)
            if not event.exists():
                return
            if event.x_transcript_requested or event.x_transcript_request_sent:
                return
            lead = event.opportunity_id
            if not lead.exists():
                return
            _logger.info(
                "Sales AI: [BG-TRANSCRIPT] Auto-requesting client transcript for event %s (lead %s)",
                event_id, lead.id,
            )
            lead._post_transcript_request(event, source="auto_1min_after_end")
    except Exception:
        _logger.error(
            "Sales AI: [BG-TRANSCRIPT] Failed for event %s",
            event_id, exc_info=True,
        )


class CalendarEvent(models.Model):
    _inherit = "calendar.event"

    x_meeting_category = fields.Selection(
        [
            ("client", "Client Meeting"),
            ("presale_internal", "Presale Internal"),
            ("other", "Other"),
        ],
        string="Meeting Category",
        default="other",
        help=(
            "Client Meeting: booked with client (e.g. Calendly/opportunity-linked). "
            "Presale Internal: recurring or internal presale planning. "
            "Other: everything else."
        ),
    )
    x_is_presale_meeting = fields.Boolean("Is Presale Meeting", default=False)
    x_presale_refs = fields.Char(
        "Presale References",
        help="Comma-separated presale references (e.g. PST-42, PST-43) discussed in this meeting.",
    )
    x_transcript_requested = fields.Boolean(
        "Transcript Requested",
        default=False,
        help="Set to True once Odoo has asked n8n to fetch the meeting transcript.",
    )
    x_transcript_request_sent = fields.Boolean(
        "Transcript Request Sent",
        default=False,
        help="Set to True once Odoo sends transcript fetch request to n8n; reset after callback handling.",
    )
    x_last_transcript_raw = fields.Text(
        "Last Raw Transcript",
        help="Last transcript text received from callback for this meeting.",
    )
    x_last_transcript_received_at = fields.Datetime(
        "Last Transcript Received At",
        help="Timestamp of the latest transcript callback stored on this meeting.",
    )
    x_n8n_last_request_at = fields.Datetime(
        "n8n Last Request At",
        help="Last time Odoo sent transcript request for this meeting.",
    )
    x_n8n_last_request_payload = fields.Text(
        "n8n Last Request Payload",
        help="Last request payload sent to n8n for transcript fetch.",
    )
    x_n8n_last_response_at = fields.Datetime(
        "n8n Last Response At",
        help="Last time response/error was received from n8n request call.",
    )
    x_n8n_last_response_body = fields.Text(
        "n8n Last Response Body",
        help="Last response body received from n8n for transcript request.",
    )
    x_n8n_last_status = fields.Selection(
        [("success", "Success"), ("failed", "Failed"), ("pending", "Pending")],
        string="n8n Last Status",
        default="pending",
    )
    x_n8n_last_error = fields.Text(
        "n8n Last Error",
        help="Last n8n error message for this meeting request.",
    )
    transcript_ids = fields.One2many(
        "sales.ai.meeting.transcript",
        "meeting_id",
        string="Meeting Transcripts",
    )
    x_presale_mom_transcript_sha = fields.Char(
        "Presale MOM Transcript SHA1",
        copy=False,
        help=(
            "SHA1 of transcript text last successfully processed into presale MOM. "
            "Used by the catch-up cron to post MOM when the first callback did not match tickets."
        ),
    )

    @api.model
    def _sales_ai_client_transcript_delay_seconds(self):
        """Seconds to wait after meeting end before requesting client transcript (n8n may wait longer)."""
        ICP = self.env["ir.config_parameter"].sudo()
        raw = ICP.get_param(
            "sales_ai.transcript_delay_seconds",
            default=str(_DEFAULT_CLIENT_TRANSCRIPT_DELAY),
        )
        try:
            v = int(float(raw))
            return max(10, min(v, 86400))
        except Exception:
            return _DEFAULT_CLIENT_TRANSCRIPT_DELAY

    @api.model
    def _sales_ai_presale_transcript_delay_seconds(self):
        """Hint for n8n: delay before fetching/processing presale meeting recording."""
        ICP = self.env["ir.config_parameter"].sudo()
        raw = ICP.get_param(
            "sales_ai.presale_transcript_delay_seconds",
            default=str(_DEFAULT_PRESALE_TRANSCRIPT_DELAY),
        )
        try:
            v = int(float(raw))
            return max(0, min(v, 86400))
        except Exception:
            return _DEFAULT_PRESALE_TRANSCRIPT_DELAY

    @api.model
    def _sales_ai_presale_mom_delay_seconds(self):
        """Hint for n8n: extra delay before triggering presale MOM / split workflow."""
        ICP = self.env["ir.config_parameter"].sudo()
        raw = ICP.get_param(
            "sales_ai.presale_mom_delay_seconds",
            default=str(_DEFAULT_PRESALE_MOM_DELAY),
        )
        try:
            v = int(float(raw))
            return max(0, min(v, 86400))
        except Exception:
            return _DEFAULT_PRESALE_MOM_DELAY

    def _presale_transcript_sha1(self, transcript_text: str) -> str:
        return hashlib.sha1((transcript_text or "").strip().encode("utf-8")).hexdigest()

    def _latest_presale_transcript_text(self):
        """Return (text, transcript_record) for presale MOM routing."""
        self.ensure_one()
        latest = self.transcript_ids.filtered(lambda t: (t.transcript or "").strip())
        latest = latest.sorted("create_date", reverse=True)[:1]
        if latest:
            return (latest.transcript or "").strip(), latest
        raw = (self.x_last_transcript_raw or "").strip()
        return raw, False

    def _try_post_presale_mom_from_stored_transcript(self, source="internal", force=False):
        """Route stored transcript to ticket(s) and generate presale MOM (same logic as manual Sync)."""
        self.ensure_one()
        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        transcript_text, latest_transcript = self._latest_presale_transcript_text()
        if not transcript_text:
            _logger.info(
                "Sales AI: [PRESALE-MOM] skip event %s (%s) — no transcript text",
                self.id,
                source,
            )
            return {"processed": 0, "reason": "no_transcript"}

        current_sha = self._presale_transcript_sha1(transcript_text)
        if (
            not force
            and self.x_presale_mom_transcript_sha
            and self.x_presale_mom_transcript_sha == current_sha
        ):
            _logger.debug(
                "Sales AI: [PRESALE-MOM] event %s transcript SHA already synced (%s)",
                self.id,
                source,
            )
            return {"processed": 0, "reason": "already_synced_sha"}

        meeting_date = False
        if latest_transcript and latest_transcript.meeting_date:
            meeting_date = latest_transcript.meeting_date
        elif self.start:
            meeting_date = self.start.date()
        duration = int((latest_transcript.meeting_duration if latest_transcript else 0) or 0)

        _logger.info(
            "Sales AI: [PRESALE-MOM] event %s routing transcript (%d chars) source=%s",
            self.id,
            len(transcript_text),
            source,
        )

        routed = Ticket.action_route_multi_ticket_transcript(
            transcript=transcript_text,
            lead_id=None,
            meeting_date=meeting_date,
            meeting_duration=duration,
            attendees=[],
            prior_open_items=[],
        )
        processed = int((routed or {}).get("processed_count") or 0)
        if processed <= 0:
            by_name_ticket = Ticket._resolve_ticket_from_marker(self.name or "", lead_id=None)
            if by_name_ticket:
                by_name_ticket.action_generate_presale_mom(
                    transcript=transcript_text,
                    meeting_date=meeting_date,
                    meeting_duration=duration,
                    attendees=[],
                    prior_open_items=[],
                )
                processed = 1
            else:
                by_transcript_num = Ticket._resolve_ticket_from_transcript_number_and_name(
                    transcript=transcript_text,
                    meeting_name=self.name or "",
                    lead_id=None,
                )
                if by_transcript_num:
                    by_transcript_num.action_generate_presale_mom(
                        transcript=transcript_text,
                        meeting_date=meeting_date,
                        meeting_duration=duration,
                        attendees=[],
                        prior_open_items=[],
                    )
                    processed = 1

        if processed > 0:
            self.sudo().write({
                "x_transcript_requested": True,
                "x_transcript_request_sent": False,
                "x_n8n_last_status": "success",
                "x_n8n_last_error": False,
                "x_presale_mom_transcript_sha": current_sha,
            })
            self.message_post(
                body=_("Presale MOM posted from stored transcript (source: %s).", source),
                subtype_xmlid="mail.mt_note",
            )
            _logger.info(
                "Sales AI: [PRESALE-MOM] event %s posted MOM for %d ticket segment(s) source=%s",
                self.id,
                processed,
                source,
            )
            return {"processed": processed, "reason": "ok"}

        _logger.warning(
            "Sales AI: [PRESALE-MOM] event %s could not match ticket (source=%s)",
            self.id,
            source,
        )
        self.sudo().write({
            "x_n8n_last_status": "failed",
            "x_n8n_last_error": "Could not match presale ticket from transcript/meeting name.",
        })
        return {"processed": 0, "reason": "ticket_not_matched"}

    def action_sync_transcript_and_post_mom(self):
        """Manual meeting button:
        - request transcript from n8n when missing
        - if transcript already exists but MOM was missed, post MOM now.
        """
        self.ensure_one()

        def _notify(title, message, level="info", sticky=False):
            return {
                "type": "ir.actions.client",
                "tag": "display_notification",
                "params": {
                    "title": title,
                    "message": message,
                    "type": level,
                    "sticky": sticky,
                },
            }

        latest_transcript = self.transcript_ids.filtered(lambda t: (t.transcript or "").strip())
        latest_transcript = latest_transcript.sorted("create_date", reverse=True)[:1]
        transcript_text = (latest_transcript.transcript or "").strip() if latest_transcript else (self.x_last_transcript_raw or "").strip()

        # Presale: never depend on lead_id; route transcript to ticket(s).
        if self.x_meeting_category == "presale_internal":
            if not transcript_text:
                sent = self._request_presale_transcript_from_n8n(source="manual_sync_button")
                if sent:
                    return _notify(
                        _("Transcript sync requested"),
                        _("Requested transcript from n8n for this presale meeting. MOM will auto-post after callback."),
                        level="success",
                    )
                return _notify(
                    _("Sync failed"),
                    _("Could not request presale transcript from n8n. Please check n8n settings/logs."),
                    level="danger",
                    sticky=True,
                )

            res = self._try_post_presale_mom_from_stored_transcript(
                source="manual_sync_button",
                force=True,
            )
            processed = int(res.get("processed") or 0)
            if processed > 0:
                return _notify(
                    _("MOM posted"),
                    _("Presale MOM posted from existing transcript for this meeting."),
                    level="success",
                )

            self.message_post(
                body=_("Manual sync could not match a presale ticket from transcript or meeting name."),
                subtype_xmlid="mail.mt_note",
            )
            return _notify(
                _("Ticket not matched"),
                _("Transcript exists, but no matching presale ticket was found to post MOM."),
                level="warning",
                sticky=True,
            )

        # Client meeting flow.
        lead = self.opportunity_id
        if not lead:
            return _notify(
                _("No linked lead"),
                _("This meeting is not linked to a lead. Please link the meeting first."),
                level="warning",
            )

        if not transcript_text:
            try:
                lead._post_transcript_request(self, source="manual_sync_button")
            except Exception as exc:
                _logger.error("Sales AI: manual client transcript sync failed for event %s", self.id, exc_info=True)
                return _notify(
                    _("Sync failed"),
                    _("Could not request client transcript from n8n: %s", str(exc)[:200]),
                    level="danger",
                    sticky=True,
                )
            return _notify(
                _("Transcript sync requested"),
                _("Requested transcript from n8n for this client meeting."),
                level="success",
            )

        try:
            lead.action_generate_client_mom(
                transcript=transcript_text,
                meeting_date=str((latest_transcript.meeting_date if latest_transcript else False) or (self.start.date() if self.start else fields.Date.today())),
                meeting_duration=int((latest_transcript.meeting_duration if latest_transcript else 0) or 0),
                attendees=[],
                conversation_id=(latest_transcript.conversation_id if latest_transcript else "") or "",
                conversation_url=(latest_transcript.conversation_url if latest_transcript else "") or "",
                source="manual_sync_button",
                meeting_name=self.name or "",
                meeting_id=self.id,
                request_payload_json=(latest_transcript.request_payload_json if latest_transcript else "") or "",
            )
            self.write({
                "x_transcript_requested": True,
                "x_transcript_request_sent": False,
                "x_n8n_last_status": "success",
                "x_n8n_last_error": False,
            })
            self.message_post(
                body=_("Manual sync button posted client MOM from existing transcript."),
                subtype_xmlid="mail.mt_note",
            )
            return _notify(
                _("MOM posted"),
                _("Client MOM posted from existing transcript for this meeting."),
                level="success",
            )
        except Exception as exc:
            _logger.error("Sales AI: manual client MOM post failed for event %s", self.id, exc_info=True)
            self.write({
                "x_n8n_last_status": "failed",
                "x_n8n_last_error": str(exc)[:1000],
            })
            return _notify(
                _("MOM post failed"),
                _("Transcript exists but MOM posting failed: %s", str(exc)[:200]),
                level="danger",
                sticky=True,
            )

    # ------------------------------------------------------------------
    # Meeting category helpers
    # ------------------------------------------------------------------

    @api.model
    def _is_recurring_meeting(self, event):
        return bool(
            getattr(event, "recurrency", False)
            or getattr(event, "recurrence_id", False)
            or getattr(event, "follow_recurrence", False)
        )

    @api.model
    def _auto_detect_meeting_category(self, event):
        """Auto-classify meeting conservatively.

        Presale must be an explicit/manual action in Odoo (or via explicit refs),
        not inferred from attendees/recurrence. External synced bookings that get
        linked to an opportunity are treated as client meetings.
        """
        refs = (event.x_presale_refs or "").strip()
        if refs:
            return "presale_internal"

        # Any opportunity-linked meeting (including Calendly/Google synced)
        # should be treated as a client meeting.
        if event.opportunity_id:
            return "client"

        # Do not infer "presale_internal" automatically from recurrence/attendees.
        # Presale is set explicitly by users from Odoo.
        return "other"

    def _sync_presale_boolean_from_category(self):
        for event in self:
            event.x_is_presale_meeting = event.x_meeting_category == "presale_internal"

    # ------------------------------------------------------------------
    # Lead linking
    # ------------------------------------------------------------------

    def action_link_to_leads(self):
        """
        Match meeting attendees to existing active leads and set opportunity_id.
        Searches email_from, x_direct_email, and partner_id.email for robust matching.
        """
        Lead = self.env["crm.lead"].sudo()
        Activity = self.env["mail.activity"].sudo()
        stage_meeting = self.env.ref(
            "sales_ai_integration.stage_meeting", raise_if_not_found=False
        )
        activity_type_meeting = self.env.ref(
            "mail.mail_activity_data_meeting", raise_if_not_found=False
        )

        for event in self:
            if event.opportunity_id:
                continue

            emails = {
                (p.email or "").lower().strip()
                for p in event.partner_ids
                if p.email
            }
            if not emails:
                continue

            email_list = list(emails)
            domain = [
                ("active", "=", True),
                "|", "|",
                ("email_from", "in", email_list),
                ("x_direct_email", "in", email_list),
                ("partner_id.email", "in", email_list),
            ]
            lead = Lead.search(domain, order="id desc", limit=1)
            if not lead:
                continue

            event.opportunity_id = lead.id
            # Preserve explicit presale classification only when refs are set.
            # This prevents auto-inferred presale tags from external sync events.
            if not (event.x_meeting_category == "presale_internal" and (event.x_presale_refs or "").strip()):
                event.x_meeting_category = "client"
            event._sync_presale_boolean_from_category()
            lead.message_post(
                body=_("Meeting '%s' auto-linked to this lead (calendar sync).", event.name or ""),
                subtype_xmlid="mail.mt_note",
            )
            _logger.info(
                "Sales AI: calendar event %s auto-linked to lead %s",
                event.id, lead.id,
            )

            if stage_meeting and lead.stage_id and lead.stage_id.sequence < stage_meeting.sequence:
                lead.stage_id = stage_meeting
                _logger.info(
                    "Sales AI: lead %s moved to Meeting stage via calendar link", lead.id,
                )

            # Create a 'Meeting' activity on the lead so it appears in the rep's
            # activity list, aligned with the auto-linked calendar event.
            if activity_type_meeting and lead.user_id:
                existing = Activity.search(
                    [
                        ("res_model", "=", "crm.lead"),
                        ("res_id", "=", lead.id),
                        ("activity_type_id", "=", activity_type_meeting.id),
                        ("date_deadline", "=", (event.start or fields.Datetime.now()).date()),
                    ],
                    limit=1,
                )
                if not existing:
                    Activity.create(
                        {
                            "res_model_id": self.env.ref("crm.model_crm_lead").id,
                            "res_id": lead.id,
                            "user_id": lead.user_id.id,
                            "activity_type_id": activity_type_meeting.id,
                            "summary": _("Client meeting: %s", event.name or lead.name or ""),
                            "date_deadline": (event.start or fields.Datetime.now()).date(),
                        }
                    )

            lead._delete_next_planned_activities()
            lead._notify_salesperson_client_meeting_scheduled(
                meeting_name=event.name or "",
                meeting_start=str(event.start) if event.start else "",
            )

    # ------------------------------------------------------------------
    # Auto transcript request (replaces cron)
    # ------------------------------------------------------------------

    def _schedule_transcript_after_meeting(self):
        """Schedule transcript request ~1 min after meeting end.

        If the meeting already ended, fires immediately (with 10s grace).
        If it ends in the future, calculates the delay.
        """
        now = fields.Datetime.now()
        for event in self:
            if event.x_transcript_requested or event.x_transcript_request_sent:
                continue
            # Presale remains cron-driven by design.
            if event.x_meeting_category == "presale_internal":
                continue
            if not event.opportunity_id:
                continue
            stop = event.stop
            if not stop:
                continue

            delay = (stop - now).total_seconds() + self.env[
                "calendar.event"
            ]._sales_ai_client_transcript_delay_seconds()
            if delay < 10:
                delay = 10

            dbname = self.env.cr.dbname
            uid = self.env.uid
            event_id = event.id

            timer = threading.Timer(
                delay,
                _bg_request_transcript,
                args=(dbname, uid, event_id),
            )
            timer.daemon = True
            timer.start()

            _logger.info(
                "Sales AI: Transcript auto-request scheduled in %.0fs for event %s (category=%s)",
                delay, event_id, event.x_meeting_category or "other",
            )

    @api.model
    def _sales_ai_holiday_dates(self):
        """Return configured public holidays as date set."""
        ICP = self.env["ir.config_parameter"].sudo()
        raw = ICP.get_param("sales_ai.public_holidays_json", default="[]")
        try:
            return {fields.Date.from_string(d) for d in json.loads(raw or "[]") if d}
        except Exception:
            return set()

    @api.model
    def _sales_ai_is_working_day(self, day):
        """Working day = Mon-Fri and not in configured public holidays."""
        if isinstance(day, str):
            day = fields.Date.from_string(day)
        holidays = self._sales_ai_holiday_dates()
        return day.weekday() < 5 and day not in holidays

    @api.model
    def _sales_ai_previous_working_day(self, day):
        """Return previous working day before `day`."""
        if isinstance(day, str):
            day = fields.Date.from_string(day)
        cur = day - timedelta(days=1)
        while not self._sales_ai_is_working_day(cur):
            cur -= timedelta(days=1)
        return cur

    @api.model
    def cron_request_presale_transcripts(self):
        """Request transcripts for today's completed presale meetings."""
        today = fields.Date.today()
        if not self._sales_ai_is_working_day(today):
            _logger.info(
                "Sales AI: [PRESALE-TRANSCRIPT-CRON] skip non-working day %s",
                today,
            )
            return

        # Presale transcript cron now works on TODAY basis (not yesterday).
        # Request only for meetings that have already ended today.
        day_start = fields.Datetime.to_datetime(f"{today} 00:00:00")
        day_end = fields.Datetime.to_datetime(f"{today} 23:59:59")
        now = fields.Datetime.now()
        effective_end = min(day_end, now)

        meetings = self.sudo().search(
            [
                ("x_meeting_category", "=", "presale_internal"),
                ("stop", ">=", day_start),
                ("stop", "<=", effective_end),
            ],
            order="stop asc, id asc",
        )
        if not meetings:
            _logger.info(
                "Sales AI: [PRESALE-TRANSCRIPT-CRON] no pending presale meetings for today (%s)",
                today,
            )
            return

        _logger.info(
            "Sales AI: [PRESALE-TRANSCRIPT-CRON] requesting %d transcript(s) for today (%s)",
            len(meetings),
            today,
        )
        for meeting in meetings:
            try:
                meeting._request_presale_transcript_from_n8n(source="presale_noon_cron")
            except Exception:
                _logger.error(
                    "Sales AI: [PRESALE-TRANSCRIPT-CRON] meeting %s request failed",
                    meeting.id,
                    exc_info=True,
                )

    @api.model
    def cron_post_pending_presale_mom(self):
        """Catch-up: post presale MOM when transcript exists but routing/MOM did not complete.

        Manual Sync uses the same routing as this cron. Typical failure mode: n8n callback
        reached Odoo and stored the transcript, but ticket markers were missing from the
        payload so automatic routing returned early — this job retries with stored text.
        """
        now = fields.Datetime.now()
        horizon_days = 7
        horizon_start = now - timedelta(days=horizon_days)

        Transcript = self.env["sales.ai.meeting.transcript"].sudo()
        meeting_ids_with_rows = Transcript.search(
            [("meeting_id", "!=", False), ("transcript", "!=", False)],
        ).mapped("meeting_id.id")

        candidates = self.sudo().search(
            [
                ("x_meeting_category", "=", "presale_internal"),
                ("stop", "<=", now),
                ("stop", ">=", horizon_start),
                "|",
                ("x_last_transcript_raw", "!=", False),
                ("id", "in", meeting_ids_with_rows),
            ],
            order="stop desc, id desc",
            limit=80,
        )
        _logger.info(
            "Sales AI: [PRESALE-MOM-CRON] scanning %d presale meeting(s) in last %d day(s)",
            len(candidates),
            horizon_days,
        )
        handled = 0
        for meeting in candidates:
            text, _rec = meeting._latest_presale_transcript_text()
            if not text:
                continue
            sha = meeting._presale_transcript_sha1(text)
            if meeting.x_presale_mom_transcript_sha == sha:
                continue
            try:
                res = meeting._try_post_presale_mom_from_stored_transcript(
                    source="cron_post_pending_presale_mom",
                )
                if int(res.get("processed") or 0) > 0:
                    handled += 1
            except Exception:
                _logger.error(
                    "Sales AI: [PRESALE-MOM-CRON] failed for meeting %s",
                    meeting.id,
                    exc_info=True,
                )
        _logger.info(
            "Sales AI: [PRESALE-MOM-CRON] finished — posted MOM for %d meeting(s)",
            handled,
        )

    def _request_presale_transcript_from_n8n(self, source="presale_noon_cron"):
        """Send a presale transcript fetch request to n8n for this meeting."""
        self.ensure_one()
        if self.x_transcript_requested or self.x_transcript_request_sent:
            return False

        refs_raw = self.x_presale_refs or ""
        refs = [r.strip().upper() for r in refs_raw.split(",") if r and r.strip()]

        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        tickets = Ticket.browse()
        if refs:
            # Accept PST refs and numeric ticket ids in the same refs field.
            ref_domain = [("x_presale_ref", "in", refs)]
            numeric_tokens = [int(r) for r in refs if r.isdigit()]
            if numeric_tokens:
                ref_domain = ["|", ("id", "in", numeric_tokens)] + ref_domain
            tickets = Ticket.search(ref_domain)

        # Fallback for manual cron testing: resolve by meeting-name keys
        # (e.g. "PX Stand-up Meeting", "CS Stand-up Meeting", "CJ ... Meeting").
        if not tickets:
            meeting_name = (self.name or "").strip()
            if meeting_name:
                raw_tokens = re.findall(r"[A-Z0-9]{2,}", meeting_name.upper())
                stop_tokens = {"MEETING", "STAND", "UP", "AND"}
                key_tokens = [t for t in raw_tokens if t not in stop_tokens]
                if key_tokens:
                    tickets = Ticket.browse()
                    for tok in key_tokens:
                        tickets |= Ticket.search([("name", "ilike", tok)], limit=10)
                    tickets = tickets[:10]
                    if tickets:
                        _logger.info(
                            "Sales AI: [PRESALE-TRANSCRIPT] fallback ticket match by meeting name '%s' -> ids=%s",
                            meeting_name,
                            tickets.ids,
                        )
        ticket_ids = tickets.ids
        lead_ids = tickets.mapped("x_linked_lead_id").ids

        attendees = [p for p in self.partner_ids if p.email or p.name]
        attendee_emails = [p.email for p in attendees if p.email]
        attendee_names = [p.name for p in attendees if p.name]
        ICP = self.env["ir.config_parameter"].sudo()
        odoo_base_url = (ICP.get_param("sales_ai.odoo_base_url", default="") or "").strip().rstrip("/")
        odoo_api_key = (ICP.get_param("sales_ai.odoo_api_key", default="") or "").strip()
        # Reuse the same callback path as client meetings.
        # Odoo will route internally based on meeting_type/is_presale_meeting.
        callback_endpoint = "/odoo/api/sales_ai/meeting_done"
        callback_url = (
            f"{odoo_base_url}{callback_endpoint}?db={self.env.cr.dbname}"
            if odoo_base_url
            else ""
        )

        payload = {
            "meeting_id": self.id,
            "meeting_name": self.name or "",
            "meeting_start": str(self.start) if self.start else "",
            "meeting_stop": str(self.stop) if self.stop else "",
            "attendee_emails": attendee_emails,
            "participants": attendee_names,
            "calendar_owner": self.user_id.name if self.user_id else "",
            "calendar_owner_email": self.user_id.email if self.user_id else "",
            "source": source,
            "type": "presale",
            "meeting_type": "presale",
            "is_presale_meeting": True,
            "presale_refs": refs,
            "presale_ticket_ids": ticket_ids,
            "lead_ids": lead_ids,
            # n8n should call this callback after transcript extraction/split.
            "odoo_callback_endpoint": callback_endpoint,
            "odoo_callback_url": callback_url,
            "odoo_callback_api_key": odoo_api_key,
            "odoo_db": self.env.cr.dbname,
            "workflow_timing": {
                "client_transcript_delay_seconds": self._sales_ai_client_transcript_delay_seconds(),
                "presale_transcript_delay_seconds": self._sales_ai_presale_transcript_delay_seconds(),
                "presale_mom_delay_seconds": self._sales_ai_presale_mom_delay_seconds(),
            },
        }
        self.write({
            "x_n8n_last_request_at": fields.Datetime.now(),
            "x_n8n_last_request_payload": json.dumps(payload, ensure_ascii=False),
            "x_n8n_last_status": "pending",
            "x_n8n_last_error": False,
            "x_presale_mom_transcript_sha": False,
        })
        try:
            resp = self.env["sales.ai.n8n"].post("request_meeting_transcript", payload)
            self.x_transcript_request_sent = True
            self.write({
                "x_n8n_last_response_at": fields.Datetime.now(),
                "x_n8n_last_response_body": json.dumps(resp, ensure_ascii=False) if resp is not None else "null",
                "x_n8n_last_status": "success",
                "x_n8n_last_error": False,
            })
            self.message_post(
                body=_(
                    "Presale transcript requested (source: %s). "
                    "Awaiting n8n callback to /odoo/api/sales_ai/meeting_done.",
                    source,
                ),
                subtype_xmlid="mail.mt_note",
            )
            self.message_post(
                body=_(
                    "<p><b>n8n request success</b> for transcript fetch.</p>"
                    "<p><b>Response:</b> %s</p>",
                    json.dumps(resp, ensure_ascii=False) if resp is not None else "null",
                ),
                subtype_xmlid="mail.mt_note",
            )
            _logger.info(
                "Sales AI: [PRESALE-TRANSCRIPT] requested for meeting %s refs=%s ticket_ids=%s callback=%s",
                self.id,
                refs,
                ticket_ids,
                callback_url or callback_endpoint,
            )
            return True
        except Exception as exc:
            self.write({
                "x_n8n_last_response_at": fields.Datetime.now(),
                "x_n8n_last_status": "failed",
                "x_n8n_last_error": str(exc)[:1000],
            })
            self.message_post(
                body=_(
                    "<p><b>n8n request failed</b> for transcript fetch.</p>"
                    "<p><b>Error:</b> %s</p>",
                    str(exc)[:500],
                ),
                subtype_xmlid="mail.mt_note",
            )
            _logger.error(
                "Sales AI: [PRESALE-TRANSCRIPT] request failed for meeting %s",
                self.id,
                exc_info=True,
            )
            return False

    # ------------------------------------------------------------------
    # CRUD overrides
    # ------------------------------------------------------------------

    def _trigger_client_meeting_workflow(self):
        """On client meetings: notify rep by email.

        Activity cleanup is intentionally delayed until transcript callback +
        MOM generation completes.
        """
        for event in self:
            if not event.opportunity_id:
                continue
            if event.x_meeting_category != "client":
                continue
            lead = event.opportunity_id
            lead._notify_salesperson_client_meeting_scheduled(
                meeting_name=event.name or "",
                meeting_start=str(event.start) if event.start else "",
            )

    @api.model_create_multi
    def create(self, vals_list):
        if isinstance(vals_list, dict):
            vals_list = [vals_list]

        events = super().create(vals_list)
        for event, vals in zip(events, vals_list):
            if not vals.get("x_meeting_category"):
                event.x_meeting_category = event._auto_detect_meeting_category(event)
            elif vals.get("x_meeting_category") == "presale_internal" and not (vals.get("x_presale_refs") or "").strip():
                # Manual Odoo presale can be selected without refs; keep the explicit category.
                event.x_meeting_category = "presale_internal"
            event._sync_presale_boolean_from_category()
            try:
                event.action_link_to_leads()
            except Exception:
                _logger.error(
                    "Sales AI: Meeting-lead auto-link failed for event %s",
                    event.id, exc_info=True,
                )
            # Covers meetings created directly from Odoo with client type.
            try:
                event._trigger_client_meeting_workflow()
            except Exception:
                _logger.error(
                    "Sales AI: client meeting workflow failed on create for event %s",
                    event.id,
                    exc_info=True,
                )
            if event.stop and event.opportunity_id and event.x_meeting_category != "presale_internal":
                event._schedule_transcript_after_meeting()
        return events

    def write(self, vals):
        pre_write_starts = {}
        pre_state = {
            event.id: {
                "category": event.x_meeting_category,
                "lead_id": event.opportunity_id.id if event.opportunity_id else False,
            }
            for event in self
        }
        auto_category_fields = {"partner_ids", "opportunity_id", "x_presale_refs", "name", "recurrency"}
        if "start" in vals or "stop" in vals:
            for event in self:
                if event.opportunity_id:
                    pre_write_starts[event.id] = event.start

        res = super().write(vals)

        if "x_meeting_category" in vals:
            self._sync_presale_boolean_from_category()
        elif auto_category_fields.intersection(vals.keys()):
            for event in self:
                event.x_meeting_category = event._auto_detect_meeting_category(event)
            self._sync_presale_boolean_from_category()

        if "partner_ids" in vals:
            for event in self:
                if not event.opportunity_id:
                    try:
                        event.action_link_to_leads()
                    except Exception:
                        _logger.error(
                            "Sales AI: Meeting-lead re-link failed for event %s on attendee change",
                            event.id, exc_info=True,
                        )

        # Covers meetings updated directly from Odoo to become client meetings.
        if {"x_meeting_category", "opportunity_id"}.intersection(vals.keys()):
            for event in self:
                before = pre_state.get(event.id, {})
                became_client = (
                    event.x_meeting_category == "client"
                    and bool(event.opportunity_id)
                    and (
                        before.get("category") != "client"
                        or before.get("lead_id") != (event.opportunity_id.id if event.opportunity_id else False)
                    )
                )
                if became_client:
                    try:
                        event._trigger_client_meeting_workflow()
                    except Exception:
                        _logger.error(
                            "Sales AI: client meeting workflow failed on write for event %s",
                            event.id,
                            exc_info=True,
                        )

        if pre_write_starts:
            for event in self:
                if event.id in pre_write_starts and event.opportunity_id:
                    old_start = pre_write_starts[event.id]
                    if old_start != event.start:
                        self._handle_meeting_rescheduled(event, old_start)

        if "opportunity_id" in vals or "stop" in vals:
            for event in self:
                if not event.stop:
                    continue
                if event.x_transcript_requested or event.x_transcript_request_sent:
                    continue
                if event.opportunity_id and event.x_meeting_category != "presale_internal":
                    event._schedule_transcript_after_meeting()

        return res

    def unlink(self):
        for event in self:
            if event.opportunity_id:
                self._handle_meeting_cancelled(event)
        return super().unlink()

    # ------------------------------------------------------------------
    # Reschedule / cancel handling
    # ------------------------------------------------------------------

    def _handle_meeting_rescheduled(self, event, old_start):
        """Notify lead and salesperson when a linked meeting's time changes."""
        lead = event.opportunity_id
        lead.message_post(
            body=_(
                "Meeting '%s' rescheduled from %s to %s.",
                event.name or "", str(old_start), str(event.start),
            ),
            subtype_xmlid="mail.mt_note",
        )
        _logger.info(
            "Sales AI: Meeting %s (lead %s) rescheduled %s → %s",
            event.id, lead.id, old_start, event.start,
        )
        rep = lead.user_id or self.env.user
        if not rep or not rep.email:
            _logger.warning(
                "Sales AI: Meeting %s rescheduled but no salesperson email for lead %s",
                event.id, lead.id,
            )
            return
        try:
            Mail = self.env["mail.mail"].sudo()
            subject = _("Meeting Rescheduled: %s", event.name or lead.name or "Client Meeting")
            body_html = _(
                "<p>Hi %s,</p>"
                "<p>Your linked client meeting has been rescheduled.</p>"
                "<p><b>Lead:</b> %s</p>"
                "<p><b>Meeting:</b> %s</p>"
                "<p><b>Old time:</b> %s</p>"
                "<p><b>New time:</b> %s</p>",
                rep.name or "Salesperson",
                lead.name or "",
                event.name or "",
                str(old_start),
                str(event.start),
            )
            mail = Mail.create({
                "subject": subject,
                "body_html": body_html,
                "email_to": rep.email,
                "auto_delete": True,
            })
            mail.send()
            _logger.info(
                "Sales AI: Reschedule email sent to %s for lead %s meeting %s",
                rep.email, lead.id, event.id,
            )
        except Exception:
            _logger.error(
                "Sales AI: Failed sending reschedule email for lead %s",
                lead.id,
                exc_info=True,
            )

    def _handle_meeting_cancelled(self, event):
        """
        Handle linked meeting deletion: log note on lead, restart follow-ups
        if the lead hasn't progressed past the Meeting stage, notify n8n.
        """
        lead = event.opportunity_id
        stage_meeting = self.env.ref(
            "sales_ai_integration.stage_meeting", raise_if_not_found=False
        )
        lead.message_post(
            body=_(
                "Meeting '%s' (was scheduled for %s) has been cancelled.",
                event.name or "",
                str(event.start) if event.start else "unknown",
            ),
            subtype_xmlid="mail.mt_note",
        )
        _logger.info(
            "Sales AI: Meeting %s (lead %s) cancelled", event.id, lead.id,
        )

        if stage_meeting and lead.stage_id == stage_meeting:
            stage_qualified = self.env.ref(
                "sales_ai_integration.stage_qualified", raise_if_not_found=False
            )
            if stage_qualified:
                lead.stage_id = stage_qualified
            lead.x_followup_stage = 0
            lead.action_create_followup_activities()
            _logger.info(
                "Sales AI: Restarted follow-ups for lead %s after meeting cancellation",
                lead.id,
            )

        rep = lead.user_id or self.env.user
        if rep and rep.email:
            try:
                self.env["mail.mail"].sudo().create({
                    "subject": _("Meeting Cancelled: %s", event.name or lead.name or "Client Meeting"),
                    "email_to": rep.email,
                    "body_html": _(
                        "<p>Hi %s,</p>"
                        "<p>A linked client meeting was cancelled.</p>"
                        "<p><b>Lead:</b> %s</p>"
                        "<p><b>Meeting:</b> %s</p>"
                        "<p><b>Previously scheduled for:</b> %s</p>",
                        rep.name or "Salesperson",
                        lead.name or "",
                        event.name or "",
                        str(event.start) if event.start else "-",
                    ),
                    "auto_delete": True,
                }).send()
            except Exception:
                _logger.error(
                    "Sales AI: Failed sending cancellation email for lead %s",
                    lead.id, exc_info=True,
                )
