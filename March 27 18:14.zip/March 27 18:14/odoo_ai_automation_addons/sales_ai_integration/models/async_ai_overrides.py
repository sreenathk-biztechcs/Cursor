import logging

from odoo import _, models

_logger = logging.getLogger("sales_ai")


class CrmLeadAsyncOverrides(models.Model):
    _name = "crm.lead"
    _inherit = ["crm.lead", "sales.ai.background.mixin"]

    def _ai_background_notification(self, title, message):
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": title,
                "message": message,
                "type": "success",
                "sticky": False,
            },
        }

    def action_start_presale(self):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_start_presale()
        for lead in self:
            lead.message_post(
                body=_("Presale AI processing started in background. This will update automatically."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background("_bg_action_start_presale")
        return self._ai_background_notification(
            _("Presale"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_send_auto_ack(self):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_send_auto_ack()

    def action_run_junk_filter(self):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_run_junk_filter()
        for lead in self:
            lead.message_post(
                body=_("Junk filter started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background("_bg_action_run_junk_filter")
        return self._ai_background_notification(
            _("Junk Filter"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_run_junk_filter(self):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_run_junk_filter()

    def action_run_lead_scoring(self):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_run_lead_scoring()
        for lead in self:
            lead.message_post(
                body=_("Lead scoring started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background("_bg_action_run_lead_scoring")
        return self._ai_background_notification(
            _("Lead Scoring"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_run_lead_scoring(self):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_run_lead_scoring()

    def action_generate_client_mom(self, **kwargs):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_generate_client_mom(**kwargs)
        for lead in self:
            lead.message_post(
                body=_("Client MOM generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background("_bg_action_generate_client_mom", kwargs=kwargs or {})
        return self._ai_background_notification(
            _("Client MOM"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_generate_client_mom(self, **kwargs):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_generate_client_mom(**kwargs)

    def action_generate_presale_mom_from_transcript(
        self, transcript, meeting_date=None, meeting_duration=None, attendees=None, prior_open_items=None
    ):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_generate_presale_mom_from_transcript(
                transcript=transcript,
                meeting_date=meeting_date,
                meeting_duration=meeting_duration,
                attendees=attendees,
                prior_open_items=prior_open_items,
            )
        for lead in self:
            lead.message_post(
                body=_("Presale MOM generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background(
                "_bg_action_generate_presale_mom_from_transcript",
                kwargs={
                    "transcript": transcript or "",
                    "meeting_date": meeting_date or False,
                    "meeting_duration": meeting_duration or False,
                    "attendees": attendees or [],
                    "prior_open_items": prior_open_items or [],
                },
            )
        return self._ai_background_notification(
            _("Presale MOM"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_generate_presale_mom_from_transcript(
        self, transcript="", meeting_date=False, meeting_duration=False, attendees=None, prior_open_items=None
    ):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_generate_presale_mom_from_transcript(
            transcript=transcript or "",
            meeting_date=meeting_date or None,
            meeting_duration=meeting_duration or None,
            attendees=attendees or [],
            prior_open_items=prior_open_items or [],
        )

    def action_no_show_followup(self, no_show_count=1):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_no_show_followup(no_show_count=no_show_count)
        for lead in self:
            lead.message_post(
                body=_("No-show follow-up generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background(
                "_bg_action_no_show_followup",
                kwargs={"no_show_count": int(no_show_count or 1)},
            )
        return self._ai_background_notification(
            _("No-show Follow-up"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_no_show_followup(self, no_show_count=1):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_no_show_followup(no_show_count=no_show_count)

    def action_lead_intake_complete(
        self, apollo_person_data, apollo_org_data, apollo_match, force_full_intake=False
    ):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_lead_intake_complete(
                apollo_person_data=apollo_person_data,
                apollo_org_data=apollo_org_data,
                apollo_match=apollo_match,
                force_full_intake=force_full_intake,
            )
        for lead in self:
            lead.message_post(
                body=_("Lead intake processing started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background(
                "_bg_action_lead_intake_complete",
                kwargs={
                    "apollo_person_data": apollo_person_data or {},
                    "apollo_org_data": apollo_org_data or {},
                    "apollo_match": bool(apollo_match),
                    "force_full_intake": bool(force_full_intake),
                },
            )
        return True

    def _bg_action_lead_intake_complete(
        self, apollo_person_data=None, apollo_org_data=None, apollo_match=False, force_full_intake=False
    ):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_lead_intake_complete(
            apollo_person_data=apollo_person_data or {},
            apollo_org_data=apollo_org_data or {},
            apollo_match=bool(apollo_match),
            force_full_intake=bool(force_full_intake),
        )

    def _bg_action_start_presale(self):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_start_presale()

    def action_generate_presale_client_email(self, mom_content=None):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_generate_presale_client_email(mom_content=mom_content)
        for lead in self:
            lead.message_post(
                body=_("Presale client email draft generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background(
                "_bg_action_generate_presale_client_email",
                kwargs={"mom_content": mom_content or ""},
            )
        return self._ai_background_notification(
            _("Presale Email Draft"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_generate_presale_client_email(self, mom_content=""):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_generate_presale_client_email(
            mom_content=mom_content or None
        )

    def action_request_proposal_from_ai(self):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_request_proposal_from_ai()
        for lead in self:
            lead.message_post(
                body=_("AI proposal generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background("_bg_action_request_proposal_from_ai")
        return self._ai_background_notification(
            _("Proposal"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_request_proposal_from_ai(self):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_request_proposal_from_ai()

    def action_generate_wbs(self):
        if self.env.context.get("ai_force_sync"):
            return super(CrmLeadAsyncOverrides, self).action_generate_wbs()
        for lead in self:
            lead.message_post(
                body=_("WBS generation request started in background."),
                subtype_xmlid="mail.mt_note",
            )
            lead._ai_run_in_background("_bg_action_generate_wbs")
        return self._ai_background_notification(
            _("WBS"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_generate_wbs(self):
        self.ensure_one()
        super(CrmLeadAsyncOverrides, self).action_generate_wbs()

    def cron_generate_presale_agenda(self):
        try:
            return self._ai_retry_with_backoff(
                lambda: super(CrmLeadAsyncOverrides, self).cron_generate_presale_agenda(),
                max_retries=3,
                initial_delay=1.0,
            )
        except Exception:
            _logger.error("sales_ai: cron_generate_presale_agenda failed", exc_info=True)
            return True

    def cron_generate_followup_drafts(self):
        try:
            return self._ai_retry_with_backoff(
                lambda: super(CrmLeadAsyncOverrides, self).cron_generate_followup_drafts(),
                max_retries=3,
                initial_delay=1.0,
            )
        except Exception:
            _logger.error("sales_ai: cron_generate_followup_drafts failed", exc_info=True)
            return True

    def cron_request_meeting_transcripts(self):
        try:
            return self._ai_retry_with_backoff(
                lambda: super(CrmLeadAsyncOverrides, self).cron_request_meeting_transcripts(),
                max_retries=3,
                initial_delay=1.0,
            )
        except Exception:
            _logger.error("sales_ai: cron_request_meeting_transcripts failed", exc_info=True)
            return True

    def cron_check_human_pause_escalations(self):
        try:
            return self._ai_retry_with_backoff(
                lambda: super(CrmLeadAsyncOverrides, self).cron_check_human_pause_escalations(),
                max_retries=3,
                initial_delay=1.0,
            )
        except Exception:
            _logger.error("sales_ai: cron_check_human_pause_escalations failed", exc_info=True)
            return True


class HelpdeskTicketAsyncOverrides(models.Model):
    _name = "sh.helpdesk.ticket"
    _inherit = ["sh.helpdesk.ticket", "sales.ai.background.mixin"]

    def _ai_background_notification(self, title, message):
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": title,
                "message": message,
                "type": "success",
                "sticky": False,
            },
        }

    def action_generate_ticket_gist(self):
        if self.env.context.get("ai_force_sync"):
            return super(HelpdeskTicketAsyncOverrides, self).action_generate_ticket_gist()
        for ticket in self:
            ticket.message_post(
                body=_("Ticket gist generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            ticket._ai_run_in_background("_bg_action_generate_ticket_gist")
        return self._ai_background_notification(
            _("Ticket Gist"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_generate_ticket_gist(self):
        self.ensure_one()
        super(HelpdeskTicketAsyncOverrides, self).action_generate_ticket_gist()

    def action_generate_presale_mom(
        self,
        transcript,
        meeting_date=None,
        meeting_duration=None,
        attendees=None,
        prior_open_items=None,
    ):
        if self.env.context.get("ai_force_sync"):
            return super(HelpdeskTicketAsyncOverrides, self).action_generate_presale_mom(
                transcript=transcript,
                meeting_date=meeting_date,
                meeting_duration=meeting_duration,
                attendees=attendees,
                prior_open_items=prior_open_items,
            )
        for ticket in self:
            ticket.message_post(
                body=_("Presale MOM generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            ticket._ai_run_in_background(
                "_bg_action_generate_presale_mom",
                kwargs={
                    "transcript": transcript or "",
                    "meeting_date": meeting_date or False,
                    "meeting_duration": meeting_duration or False,
                    "attendees": attendees or [],
                    "prior_open_items": prior_open_items or [],
                },
            )
        return self._ai_background_notification(
            _("Presale MOM"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_generate_presale_mom(
        self, transcript="", meeting_date=False, meeting_duration=False, attendees=None, prior_open_items=None
    ):
        self.ensure_one()
        super(HelpdeskTicketAsyncOverrides, self).action_generate_presale_mom(
            transcript=transcript or "",
            meeting_date=meeting_date or None,
            meeting_duration=meeting_duration or None,
            attendees=attendees or [],
            prior_open_items=prior_open_items or [],
        )

    def action_generate_retro(self):
        if self.env.context.get("ai_force_sync"):
            return super(HelpdeskTicketAsyncOverrides, self).action_generate_retro()
        for ticket in self:
            ticket.message_post(
                body=_("Retrospective generation started in background."),
                subtype_xmlid="mail.mt_note",
            )
            ticket._ai_run_in_background("_bg_action_generate_retro")
        return self._ai_background_notification(
            _("Retrospective"),
            _("Processing in background, this will update automatically."),
        )

    def _bg_action_generate_retro(self):
        self.ensure_one()
        super(HelpdeskTicketAsyncOverrides, self).action_generate_retro()

    def cron_generate_presale_agenda(self):
        try:
            return self._ai_retry_with_backoff(
                lambda: super(HelpdeskTicketAsyncOverrides, self).cron_generate_presale_agenda(),
                max_retries=3,
                initial_delay=1.0,
            )
        except Exception:
            _logger.error("sales_ai: helpdesk cron_generate_presale_agenda failed", exc_info=True)
            return True
