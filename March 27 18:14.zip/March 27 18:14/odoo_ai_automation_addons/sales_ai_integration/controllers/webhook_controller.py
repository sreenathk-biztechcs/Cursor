import hashlib
import logging
import json
import base64
import hmac
import hashlib

from dateutil.relativedelta import relativedelta

from odoo import http, fields, SUPERUSER_ID
from odoo.http import request

_logger = logging.getLogger("sales_ai")


def _check_n8n_auth(headers) -> bool:
    """
    Lightweight shared auth check for endpoints that are called from n8n or
    other trusted automations which cannot easily use Odoo API key auth.

    Expected header:
        X-N8N-Secret: <shared_secret>

    The secret value is stored in ir.config_parameter under:
        sales_ai.n8n_secret_token

    For stronger integrity checks on JSON payloads, see the HMAC-based
    signing used by the outbound helper model `sales.ai.n8n`.
    """
    if not headers:
        return False

    ICP = request.env["ir.config_parameter"].sudo()
    expected = ICP.get_param("sales_ai.n8n_secret_token", default="") or ""
    received = headers.get("X-N8N-Secret") or ""

    if not expected or not received:
        return False

    token = received.strip()

    # Optional JWT mode:
    # - expected is used as the HMAC secret (HS256)
    # - n8n sends a JWT string in X-N8N-Secret
    # If decode succeeds, we accept the request.
    if "." in token:
        try:
            import jwt  # PyJWT

            # We don't enforce particular claims here; n8n can add `exp`
            # or other claims if desired. Signature verification is enough
            # to prove possession of the shared secret.
            jwt.decode(token, expected, algorithms=["HS256"])
            return True
        except Exception:
            # Fall through to shared-secret compare if JWT verification fails
            pass

    # Default: shared-secret comparison (static token)
    try:
        return hmac.compare_digest(expected, received)
    except Exception:
        # Fallback to simple equality if compare_digest is unavailable
        return expected == received

# ---------------------------------------------------------------------------
# Authentication strategy (n8n → Odoo):
#
# All routes use auth="api_key".  In n8n, configure an HTTP Header Auth
# credential with:
#   Header name:  Authorization
#   Value:        Bearer <odoo_api_key>
#
# To generate the Odoo API key:
#   Settings → Technical → API Keys → New → copy the key into n8n.
# The key is bound to a dedicated "n8n Service" Odoo user with only the
# rights needed by these endpoints (read/write crm.lead).
# ---------------------------------------------------------------------------


class SalesAiWebhookController(http.Controller):
    """
    HTTP endpoints for n8n callbacks.

    n8n sends data here after:
      - Apollo API enrichment completes (lead intake)
      - Meeting transcript is ready
      - WBS sheet generated
      - Proposal generated
      - Presale MOM posted
      - Stale deal query
    """
    @staticmethod
    def _notify_n8n_callback_issue(message: str, level: str = "warning"):
        """Show sticky notification in Odoo UI for callback-side issues."""
        try:
            env = request.env
            payload = {
                "type": level,
                "title": "Sales AI callback notice",
                "message": message[:500],
                "sticky": True,
            }
            admins = env.ref("base.group_system").users.filtered("active")
            for user in admins:
                try:
                    user._bus_send("simple_notification", payload)
                except Exception:
                    # Fallback to bus.bus direct send for environments where
                    # user helper cannot push the UI notification.
                    env["bus.bus"]._sendone(user.partner_id, "simple_notification", payload)
        except Exception:
            _logger.debug("sales_ai: failed to send callback notification", exc_info=True)

    @staticmethod
    def _post_fallback_admin_note(body: str):
        """Post a fallback note to admin partner chatter when no target record exists."""
        if not body:
            return
        try:
            env = request.env
            admins = env.ref("base.group_system").users.filtered("active")
            for user in admins:
                if user.partner_id:
                    user.partner_id.message_post(body=body, subtype_xmlid="mail.mt_note")
        except Exception:
            _logger.debug("sales_ai: failed to post fallback admin note", exc_info=True)

    @staticmethod
    def _post_callback_note(lead=None, meeting=None, ticket=None, body=""):
        if not body:
            return
        try:
            if lead and lead.exists():
                lead.sudo().message_post(body=body, subtype_xmlid="mail.mt_note")
            if meeting and meeting.exists():
                meeting.sudo().message_post(body=body, subtype_xmlid="mail.mt_note")
            if ticket and ticket.exists():
                ticket.sudo().message_post(body=body, subtype_xmlid="mail.mt_note")
        except Exception:
            _logger.debug("sales_ai: failed to post callback note", exc_info=True)

    @staticmethod
    def _meeting_from_id(meeting_id):
        if not meeting_id:
            return request.env["calendar.event"]
        try:
            meeting = request.env["calendar.event"].sudo().browse(int(meeting_id))
            return meeting if meeting.exists() else request.env["calendar.event"]
        except Exception:
            return request.env["calendar.event"]

    @staticmethod
    def _update_meeting_callback_audit(meeting, payload, status, error=None, transcript=None, mark_processed=False):
        """Store callback payload/status/transcript on the meeting record."""
        if not meeting or not meeting.exists():
            return
        vals = {
            "x_n8n_last_response_at": fields.Datetime.now(),
            "x_n8n_last_status": status if status in ("success", "failed", "pending") else "failed",
            "x_n8n_last_response_body": json.dumps(payload or {}, ensure_ascii=False)[:200000],
            "x_n8n_last_error": (error or False) and str(error)[:1000],
        }
        if transcript is not None:
            vals["x_last_transcript_raw"] = (transcript or "")[:200000]
            vals["x_last_transcript_received_at"] = fields.Datetime.now()
        if mark_processed:
            vals["x_transcript_requested"] = True
            vals["x_transcript_request_sent"] = False
        meeting.sudo().write(vals)

    @staticmethod
    def _meeting_done_merge_callback_sources(payload, odoo_inner):
        """Merge n8n callback shapes so presale hints are visible (top-level, odoo_payload, nested payload)."""
        merged = {}
        if isinstance(odoo_inner, dict):
            merged.update(odoo_inner)
        if isinstance(payload, dict):
            nested = payload.get("payload")
            if isinstance(nested, dict):
                for k, v in nested.items():
                    if v not in (None, "", [], {}):
                        merged.setdefault(k, v)
            for k, v in payload.items():
                if k == "payload" or k == "odoo_payload":
                    continue
                if v not in (None, "", [], {}):
                    merged.setdefault(k, v)
        return merged

    @staticmethod
    def _meeting_done_resolve_meeting_type(payload, odoo_inner, meeting):
        """Classify client vs presale after unwrapping (fixes cron/n8n paths that only send type at top level)."""
        pl = payload if isinstance(payload, dict) else {}
        merged = SalesAiWebhookController._meeting_done_merge_callback_sources(
            payload, odoo_inner,
        )
        mt = (
            (pl.get("meeting_type") or merged.get("meeting_type") or "")
            .strip()
            .lower()
        )
        type_hint = (pl.get("type") or merged.get("type") or "").strip().lower()
        if not mt and type_hint == "presale":
            mt = "presale"
        if not mt and (pl.get("is_presale_meeting") or merged.get("is_presale_meeting")):
            mt = "presale"
        if not mt and meeting and meeting.exists() and meeting.x_meeting_category == "presale_internal":
            mt = "presale"
        if mt not in ("client", "presale"):
            mt = "client"
        _logger.info(
            "sales_ai: [MEETING-DONE] resolved meeting_type=%s meeting_id=%s keys_merged=%s",
            mt,
            meeting.id if meeting and meeting.exists() else None,
            list(merged.keys())[:25],
        )
        return mt

    @staticmethod
    def _mark_meeting_presale_mom_synced(meeting, transcript: str):
        if not meeting or not meeting.exists() or not (transcript or "").strip():
            return
        sha = hashlib.sha1((transcript or "").strip().encode("utf-8")).hexdigest()
        meeting.sudo().write({"x_presale_mom_transcript_sha": sha})

    # -----------------------------------------------------------------
    # PING — reverse-direction health check (n8n → Odoo)
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/ping",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def ping(self, **payload):
        """
        Lightweight endpoint for n8n to verify the reverse connection
        (n8n → Odoo) during the bidirectional handshake.

        n8n calls this with:
            POST /api/sales_ai/ping
            Authorization: Bearer <odoo_api_key>
            {"ping": true}

        Response:
            {"status": "pong", "odoo_version": "19.0", "timestamp": "..."}
        """
        ICP = request.env["ir.config_parameter"].sudo()
        ICP.set_param("sales_ai.n8n_reverse_status", "ok")
        _logger.info("sales_ai: [PING] Reverse ping from n8n — OK")
        return {
            "status": "pong",
            "odoo_version": "19.0",
            "timestamp": fields.Datetime.now(),
        }

    @http.route(
        "/odoo/api/sales_ai/crm_lead_quick_create",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def crm_lead_quick_create(self, **payload):
        """
        Create a CRM lead or opportunity with minimal fields.

        Expected params (JSON-RPC ``call`` kwargs or flat body, depending on client):
        - name (str, required): opportunity/lead title
        - email (str, required): contact email — partner is matched or created
        - contact_name (str, optional)
        - team_id (int, optional): ``crm.team`` id; falls back to Settings or first team
        - type (str, optional): ``lead`` or ``opportunity`` (default: ``opportunity``)
        - user_id (int, optional): explicit salesperson; if omitted, round-robin applies
        - skip_round_robin (bool, optional): if true, do not auto-assign a salesperson

        Auth: same as other Sales AI endpoints — ``Authorization: Bearer <API key>``.
        """
        name = (payload.get("name") or "").strip()
        email = (payload.get("email") or "").strip().lower()
        contact_name = (payload.get("contact_name") or "").strip()
        if not name or not email:
            return {
                "status": "error",
                "message": "Fields `name` and `email` are required.",
            }
        if "@" not in email:
            return {"status": "error", "message": "Invalid email address."}

        Partner = request.env["res.partner"].sudo()
        partner = Partner.search([("email", "=", email)], limit=1)
        if not partner:
            partner = Partner.create({
                "name": contact_name or email.split("@", 1)[0],
                "email": email,
            })
        elif contact_name and (partner.name == partner.email or not (partner.name or "").strip()):
            partner.write({"name": contact_name})

        ICP = request.env["ir.config_parameter"].sudo()
        Team = request.env["crm.team"].sudo()
        raw_team = payload.get("team_id")
        team = Team.browse(int(raw_team)) if raw_team and str(raw_team).isdigit() else Team.browse()
        if not team.exists():
            tid = int(ICP.get_param("sales_ai.default_crm_team_id", default="0") or 0)
            team = Team.browse(tid) if tid else Team.browse()
        if not team.exists():
            team = Team.search([("use_leads", "=", True)], limit=1)
        if not team.exists():
            team = Team.search([], limit=1)

        ltype = (payload.get("type") or "opportunity").strip().lower()
        if ltype not in ("lead", "opportunity"):
            ltype = "opportunity"

        Lead = request.env["crm.lead"].sudo()
        lead_vals = {
            "name": name,
            "contact_name": contact_name or partner.name,
            "email_from": email,
            "partner_id": partner.id,
            "type": ltype,
        }
        if team:
            lead_vals["team_id"] = team.id

        raw_uid = payload.get("user_id")
        if raw_uid and str(raw_uid).isdigit():
            lead_vals["user_id"] = int(raw_uid)

        lead = Lead.create(lead_vals)

        if not lead_vals.get("user_id") and not payload.get("skip_round_robin"):
            lead._sales_ai_assign_round_robin_if_needed()
            lead.invalidate_recordset(["user_id", "team_id"])

        _logger.info(
            "sales_ai: [API] crm_lead_quick_create lead_id=%s partner_id=%s team_id=%s user_id=%s",
            lead.id,
            partner.id,
            lead.team_id.id if lead.team_id else None,
            lead.user_id.id if lead.user_id else None,
        )
        return {
            "status": "ok",
            "lead_id": lead.id,
            "partner_id": partner.id,
            "team_id": lead.team_id.id if lead.team_id else False,
            "user_id": lead.user_id.id if lead.user_id else False,
            "type": ltype,
        }

    # -----------------------------------------------------------------
    # UNIFIED LEAD INTAKE (Apollo enrichment + classification)
    # -----------------------------------------------------------------
    # n8n flow:
    #   1. Odoo sends: lead_intake webhook → n8n
    #   2. n8n calls Apollo People Enrichment API (POST /api/v1/people/match)
    #   3. n8n calls Apollo Organization Enrichment API (GET /api/v1/organizations/enrich)
    #   4. n8n calls THIS endpoint with combined results

    @http.route(
        ["/odoo/api/sales_ai/lead_intake_complete", "/api/sales_ai/lead_intake_complete"],
        type="http",
        auth="none",
        methods=["POST"],
        csrf=False,
    )
    def lead_intake_complete(self, **kw):
        """
        Unified callback after n8n queries Apollo APIs.

        n8n sends plain JSON (not JSON-RPC), so this uses type="http".

        Expected payload:
        {
            "lead_id": int,
            "apollo_match": bool,
            "apollo_person": {...},
            "apollo_organization": {...},
        }
        """
        def _json_resp(data, status=200):
            return request.make_response(
                json.dumps(data),
                headers=[("Content-Type", "application/json")],
                status=status,
            )

        if not _check_n8n_auth(request.httprequest.headers):
            _logger.warning("sales_ai: Unauthorized lead_intake_complete call")
            self._notify_n8n_callback_issue("lead_intake_complete unauthorized callback blocked", level="danger")
            return _json_resp({"status": "ok", "skipped": True, "reason": "unauthorized"}, 200)

        try:
            data = json.loads(request.httprequest.get_data(as_text=True) or "{}")
        except (json.JSONDecodeError, Exception):
            data = {}

        if isinstance(data, dict) and isinstance(data.get("params"), dict):
            payload = data["params"]
        else:
            payload = data if isinstance(data, dict) else {}

        lead_id = payload.get("lead_id")
        if not lead_id:
            self._notify_n8n_callback_issue("lead_intake_complete skipped: missing lead_id", level="warning")
            return _json_resp({"status": "ok", "skipped": True, "reason": "missing_lead_id"}, 200)

        lead = request.env["crm.lead"].sudo().browse(int(lead_id))
        if not lead.exists():
            _logger.warning("sales_ai: lead_intake_complete — lead %s not found", lead_id)
            self._notify_n8n_callback_issue("lead_intake_complete skipped: lead %s not found" % lead_id, level="warning")
            return _json_resp({"status": "ok", "skipped": True, "reason": "lead_not_found"}, 200)

        if lead.x_enrichment_done:
            _logger.info(
                "sales_ai: lead_intake_complete for lead %s — already enriched via synchronous path, skipping",
                lead_id,
            )
            return _json_resp({"status": "ok", "note": "already_enriched"})

        # n8n may send either:
        # - apollo_person / apollo_organization
        # - OR only apollo_result with nested person/org (older flow)
        apollo_person = payload.get("apollo_person") or {}
        apollo_org = payload.get("apollo_organization") or {}
        if not (apollo_person or apollo_org):
            apollo_result = payload.get("apollo_result") or {}
            if isinstance(apollo_result, dict):
                apollo_person = apollo_result.get("person") or apollo_result or {}
                apollo_org = apollo_result.get("organization") or {}

        apollo_match = payload.get("apollo_match")
        # If match flag is missing or empty, infer it from the presence of Apollo data
        if apollo_match in (None, "", "unknown"):
            apollo_match = bool(apollo_person or apollo_org)

        _logger.info(
            "sales_ai: lead_intake_complete received for lead %s (match=%s, force_full_intake=%s)",
            lead_id, apollo_match, payload.get("force_full_intake"),
        )
        try:
            lead.action_lead_intake_complete(
                apollo_person,
                apollo_org,
                bool(apollo_match),
                force_full_intake=bool(payload.get("force_full_intake")),
            )
            return _json_resp({"status": "ok", "async": True})
        except Exception as exc:
            _logger.error(
                "sales_ai: lead_intake_complete processing failed for lead %s: %s",
                lead.id, exc, exc_info=True,
            )
            try:
                lead._notify_pipeline_issue(
                    "Lead intake callback failed",
                    "n8n callback reached Odoo but processing failed: %s" % str(exc)[:500],
                )
            except Exception:
                pass
            self._notify_n8n_callback_issue(
                "lead_intake_complete failed in Odoo for lead %s: %s" % (lead.id, str(exc)[:200]),
                level="danger",
            )
            return _json_resp({"status": "ok", "skipped": True, "reason": "lead_intake_processing_failed"}, 200)

    # -----------------------------------------------------------------
    # LEGACY: receive_apollo_data (backward compat)
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/receive_apollo_data",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def receive_apollo_data(self, **payload):
        """Legacy endpoint — use lead_intake_complete instead."""
        lead_id = payload.get("lead_id")
        apollo_data = payload.get("apollo_data")
        if not lead_id or apollo_data is None:
            self._notify_n8n_callback_issue("receive_apollo_data skipped: missing lead_id/apollo_data")
            return {"status": "ok", "skipped": True, "reason": "missing_lead_id_or_apollo_data"}
        lead = request.env["crm.lead"].sudo().browse(int(lead_id))
        if not lead.exists():
            self._notify_n8n_callback_issue("receive_apollo_data skipped: lead not found %s" % lead_id)
            return {"status": "ok", "skipped": True, "reason": "lead_not_found"}
        # Treat as person data with match
        lead.action_lead_intake_complete(
            apollo_person_data=apollo_data if isinstance(apollo_data, dict) else {},
            apollo_org_data={},
            apollo_match=bool(apollo_data),
        )
        return {"status": "ok", "async": True}

    # -----------------------------------------------------------------
    # MEETING TRANSCRIPT
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/receive_transcript",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def receive_transcript(self, **payload):
        lead_id = payload.get("lead_id")
        transcript = payload.get("transcript")
        meeting_type = payload.get("meeting_type", "client")
        if not lead_id or not transcript:
            self._notify_n8n_callback_issue("receive_transcript skipped: missing lead/transcript")
            return {"status": "ok", "skipped": True, "reason": "missing_lead_or_transcript"}
        lead = request.env["crm.lead"].sudo().browse(int(lead_id))
        if not lead.exists():
            self._notify_n8n_callback_issue("receive_transcript skipped: lead %s not found" % lead_id)
            return {"status": "ok", "skipped": True, "reason": "lead_not_found"}

        _logger.info(
            "sales_ai: Transcript received for lead %s (type=%s, %d chars)",
            lead_id, meeting_type, len(transcript),
        )

        if meeting_type == "client":
            lead.action_generate_client_mom(
                transcript=transcript,
                meeting_date=payload.get("meeting_date") or "",
                meeting_duration=int(payload.get("meeting_duration") or 0),
                attendees=payload.get("attendees") or [],
            )
        elif meeting_type == "presale":
            lead.action_generate_presale_mom_from_transcript(
                transcript=transcript,
                meeting_date=payload.get("meeting_date"),
                meeting_duration=payload.get("meeting_duration"),
                attendees=payload.get("attendees") or [],
                prior_open_items=payload.get("prior_open_items") or [],
            )
        return {"status": "ok", "async": meeting_type == "client"}

    # -----------------------------------------------------------------
    # STRUCTURED ENRICHMENT WRITE-BACK (EnrichmentStructurerAgent)
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/enrichment_structured",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def enrichment_structured(self, **payload):
        """
        Endpoint for n8n / EnrichmentStructurerAgent to POST structured
        enrichment JSON back to Odoo.

        Expected payload:
        {
          "lead_id": int,
          "enrichment": { ... }  # JSON keys as defined by EnrichmentStructurerAgent
        }
        """
        lead_id = payload.get("lead_id")
        enrichment = payload.get("enrichment") or {}
        if not lead_id or not isinstance(enrichment, dict):
            self._notify_n8n_callback_issue("enrichment_structured skipped: invalid payload")
            return {"status": "ok", "skipped": True, "reason": "missing_lead_or_enrichment"}

        lead = request.env["crm.lead"].sudo().browse(int(lead_id))
        if not lead.exists():
            _logger.warning("sales_ai: enrichment_structured — lead %s not found", lead_id)
            self._notify_n8n_callback_issue("enrichment_structured skipped: lead %s not found" % lead_id)
            return {"status": "ok", "skipped": True, "reason": "lead_not_found"}

        _logger.info(
            "sales_ai: enrichment_structured received for lead %s (keys=%s)",
            lead_id,
            list(enrichment.keys()),
        )
        lead.action_apply_structured_enrichment(enrichment)
        return {"status": "ok"}

    # -----------------------------------------------------------------
    # PROPOSAL READY
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/proposal_ready",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def proposal_ready(self, **payload):
        # Proposal generation flow has been removed; keep endpoint to return success.
        _logger.info("sales_ai: proposal_ready ignored (flow removed)")
        return {"status": "ok", "skipped": True, "reason": "proposal_flow_removed"}
        lead_id = payload.get("lead_id")
        ticket_id = payload.get("ticket_id")
        url = payload.get("proposal_drive_url")
        if not url:
            self._notify_n8n_callback_issue("proposal_ready skipped: missing proposal URL")
            return {"status": "ok", "skipped": True, "reason": "missing_proposal_url"}

        Ticket = request.env["sh.helpdesk.ticket"].sudo()
        ticket = None
        if ticket_id:
            ticket = Ticket.browse(int(ticket_id))
            if not ticket.exists():
                ticket = None
        if not ticket and lead_id:
            ticket = Ticket.search(
                [("x_linked_lead_id", "=", int(lead_id))], order="id desc", limit=1,
            )

        if ticket:
            ticket.action_store_proposal_url(url)
            _logger.info("sales_ai: Proposal ready for ticket %s — URL: %s", ticket.id, url)
            return {"status": "ok", "ticket_id": ticket.id}

        if lead_id:
            lead = request.env["crm.lead"].sudo().browse(int(lead_id))
            if lead.exists():
                lead.write({
                    "x_proposal_drive_url": url,
                    "x_presale_status": "proposal_generated",
                })
                lead.message_post(
                    body="AI-generated proposal ready: <a href='%s'>Open proposal</a>" % url,
                    subtype_xmlid="mail.mt_note",
                )
                _logger.info("sales_ai: Proposal ready for lead %s — URL: %s", lead_id, url)
                return {"status": "ok", "lead_id": lead_id}

        self._notify_n8n_callback_issue("proposal_ready skipped: no matching ticket/lead found")
        return {"status": "ok", "skipped": True, "reason": "no_ticket_or_lead_found"}

    # -----------------------------------------------------------------
    # WBS READY
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/wbs_ready",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def wbs_ready(self, **payload):
        # WBS generation flow has been removed; keep endpoint to return success.
        _logger.info("sales_ai: wbs_ready ignored (flow removed)")
        return {"status": "ok", "skipped": True, "reason": "wbs_flow_removed"}
        lead_id = payload.get("lead_id")
        ticket_id = payload.get("ticket_id")
        sheet_url = payload.get("sheet_url")
        if not sheet_url:
            self._notify_n8n_callback_issue("wbs_ready skipped: missing sheet URL")
            return {"status": "ok", "skipped": True, "reason": "missing_sheet_url"}

        Ticket = request.env["sh.helpdesk.ticket"].sudo()
        ticket = None
        if ticket_id:
            ticket = Ticket.browse(int(ticket_id))
            if not ticket.exists():
                ticket = None
        if not ticket and lead_id:
            ticket = Ticket.search(
                [("x_linked_lead_id", "=", int(lead_id))], order="id desc", limit=1,
            )

        if ticket:
            ticket.action_store_wbs_url(sheet_url)
            _logger.info("sales_ai: WBS ready for ticket %s — URL: %s", ticket.id, sheet_url)
            return {"status": "ok", "ticket_id": ticket.id}

        if lead_id:
            lead = request.env["crm.lead"].sudo().browse(int(lead_id))
            if lead.exists():
                lead.write({
                    "x_wbs_sheet_url": sheet_url,
                    "x_presale_status": "ready_for_wbs",
                })
                lead.message_post(
                    body="WBS generated. <a href='%s'>Open Google Sheet</a>" % sheet_url,
                    subtype_xmlid="mail.mt_note",
                )
                _logger.info("sales_ai: WBS ready for lead %s — URL: %s", lead_id, sheet_url)
                return {"status": "ok", "lead_id": lead_id}

        self._notify_n8n_callback_issue("wbs_ready skipped: no matching ticket/lead found")
        return {"status": "ok", "skipped": True, "reason": "no_ticket_or_lead_found"}

    # -----------------------------------------------------------------
    # PRESALE MOM POSTED
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/presale_mom_posted",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def presale_mom_posted(self, **payload):
        """n8n callback: presale MOM text available. Routes to ticket (primary) or lead (fallback)."""
        lead_id = payload.get("lead_id")
        ticket_id = payload.get("ticket_id")
        mom_content = payload.get("mom_content") or ""

        Ticket = request.env["sh.helpdesk.ticket"].sudo()
        ticket = None
        if ticket_id:
            ticket = Ticket.browse(int(ticket_id))
            if not ticket.exists():
                ticket = None
        if not ticket and lead_id:
            ticket = Ticket.search(
                [("x_linked_lead_id", "=", int(lead_id))], order="id desc", limit=1,
            )

        if ticket and mom_content:
            ticket.action_generate_presale_mom(
                transcript=mom_content,
                meeting_date=payload.get("meeting_date"),
                meeting_duration=payload.get("meeting_duration"),
                attendees=payload.get("attendees") or [],
            )
            _logger.info("sales_ai: Presale MOM routed to ticket %s", ticket.id)
            return {"status": "ok", "ticket_id": ticket.id}

        if lead_id:
            lead = request.env["crm.lead"].sudo().browse(int(lead_id))
            if not lead.exists():
                self._notify_n8n_callback_issue("presale_mom_posted skipped: lead %s not found" % lead_id)
                return {"status": "ok", "skipped": True, "reason": "lead_not_found"}
            if mom_content:
                mom_html = tools.html_sanitize(
                    tools.plaintext2html((mom_content or "")[:5000])
                )
                lead.message_post(
                    body="<p><b>Presale MOM (from n8n)</b></p>%s" % mom_html,
                    subtype_xmlid="mail.mt_note",
                )
            _logger.info("sales_ai: Presale MOM posted for lead %s (no ticket)", lead_id)
            lead.action_generate_presale_client_email(mom_content=mom_content)
            return {"status": "ok", "lead_id": lead_id}

        self._notify_n8n_callback_issue("presale_mom_posted skipped: missing lead/ticket")
        return {"status": "ok", "skipped": True, "reason": "missing_lead_or_ticket"}

    # -----------------------------------------------------------------
    # STALE DEALS EXPORT
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/stale_deals",
        type="jsonrpc",
        auth="api_key",
        methods=["GET", "POST"],
        csrf=False,
    )
    def stale_deals(self, **kwargs):
        ICP = request.env["ir.config_parameter"].sudo()
        thresholds_raw = ICP.get_param("sales_ai.stale_thresholds_json", default="{}")
        try:
            thresholds = json.loads(thresholds_raw)
        except Exception:
            thresholds = {}

        Lead = request.env["crm.lead"].sudo()
        today = fields.Date.today()
        result = []
        for stage_name, days in thresholds.items():
            stage = request.env["crm.stage"].sudo().search(
                [("name", "=", stage_name)], limit=1
            )
            if not stage:
                continue
            cutoff = today - relativedelta(days=int(days))
            leads = Lead.search([
                ("stage_id", "=", stage.id),
                ("write_date", "<", cutoff),
            ])
            for lead in leads:
                result.append({
                    "lead_id": lead.id,
                    "lead_name": lead.name,
                    "stage": stage_name,
                    "salesperson": lead.user_id.name if lead.user_id else "",
                    "days_stuck": (today - lead.write_date.date()).days,
                    "email": lead.user_id.email if lead.user_id else "",
                })
        _logger.info("sales_ai: Stale deals query returned %d results", len(result))
        return result

    # ------------------------------------------------------------------
    # Apollo enrichment endpoint (direct Apollo REST from Odoo)
    # ------------------------------------------------------------------

    @http.route(
        "/odoo/api/enrich_lead",
        type="jsonrpc",
        auth="none",
        methods=["POST"],
        csrf=False,
    )
    def api_enrich_lead(self, **payload):
        """
        Entry point that can be called directly (or from n8n) to:
        - take {email / name / phone}
        - call Apollo /v1/mixed_people/search and /v1/accounts/search
        - match/update existing lead OR, if no match, call Claude to
          generate a new lead payload and create it.
        """
        if not _check_n8n_auth(request.httprequest.headers):
            _logger.warning("Unauthorized /api/enrich_lead call")
            return {"error": "unauthorized"}

        from requests import Session

        ICP = request.env["ir.config_parameter"].sudo()
        api_key = ICP.get_param("sales_ai.apollo_api_key", default="")
        base_url = (
            ICP.get_param("sales_ai.apollo_api_base_url", default="https://api.apollo.io")
            or "https://api.apollo.io"
        ).rstrip("/")

        if not api_key:
            _logger.error("Apollo API key not configured (sales_ai.apollo_api_key)")
            return {"error": "apollo_api_key_missing"}

        email = (payload.get("email") or "").strip()
        name = (payload.get("name") or "").strip()
        phone = (payload.get("phone") or "").strip()

        if not (email or name or phone):
            return {"error": "missing_identifiers"}

        session = Session()
        headers = {"Content-Type": "application/json", "X-Api-Key": api_key}

        # 1) Person search
        search_body = {"q_keywords": name} if name else {}
        if email:
            search_body["person_email"] = email
        if phone:
            search_body["person_phone"] = phone

        person = None
        try:
            resp = session.post(
                f"{base_url}/v1/mixed_people/search",
                json=search_body,
                headers=headers,
                timeout=90,
            )
            resp.raise_for_status()
            data = resp.json()
            people = data.get("people", []) or data.get("contacts", []) or []
            if people:
                person = people[0]
        except Exception as exc:
            _logger.error("Apollo person search failed: %s", exc, exc_info=True)

        # Junk filter via Apollo email_status
        if person and person.get("email_status") and person["email_status"] != "deliverable":
            _logger.error(
                "Apollo marked email %s as %s; treating as junk.",
                person.get("email"),
                person.get("email_status"),
            )
            return {"status": "junk"}

        # 2) Organisation search (if we have company/domain)
        account = None
        company_name = person and (person.get("organization_name") or person.get("company_name"))
        domain = person and person.get("organization_website_url")
        org_body = {}
        if company_name:
            org_body["q_organization_name"] = company_name
        if domain:
            org_body["domain"] = domain
        if org_body:
            try:
                resp = session.post(
                    f"{base_url}/v1/accounts/search",
                    json=org_body,
                    headers=headers,
                    timeout=90,
                )
                resp.raise_for_status()
                org_data = resp.json()
                accounts = org_data.get("accounts", [])
                if accounts:
                    account = accounts[0]
            except Exception as exc:
                _logger.error("Apollo org search failed: %s", exc, exc_info=True)

        env = request.env
        Lead = env["crm.lead"].sudo()

        # 3) Try to match existing lead by email
        matched_lead = None
        if email:
            leads = Lead.search(
                [("email_from", "=ilike", email), ("active", "=", True)], limit=1
            )
            if leads:
                matched_lead = leads[0]

        # 4) Enrich existing lead
        if matched_lead and person:
            _logger.info("Apollo enrichment start for lead %s", matched_lead.id)
            vals = {
                "x_apollo_person_id": person.get("id"),
                "x_apollo_data_raw": json.dumps(
                    {"person": person, "account": account}, ensure_ascii=False
                ),
            }
            if account and account.get("employee_count"):
                vals["x_employee_count"] = account["employee_count"]
            if account and account.get("estimated_annual_revenue"):
                vals["x_annual_revenue"] = account["estimated_annual_revenue"]
            if person.get("linkedin_url"):
                vals["x_linkedin_url"] = person["linkedin_url"]
            matched_lead.write(vals)
            _logger.info("Apollo enrichment completed for lead %s", matched_lead.id)
            return {"status": "enriched", "lead_id": matched_lead.id}

        # 5) No match -> use Claude to create a new lead payload
        claude_service = env["claude.service"]
        system_prompt = ICP.get_param("sales_ai.claude_system_prompt", default="") or (
            "You are an assistant that converts Apollo person/account JSON into "
            "a CRM lead creation payload."
        )
        try:
            resp = claude_service.call(
                tier="sonnet",
                system_prompt=system_prompt,
                user_message=json.dumps(
                    {"input": payload, "person": person, "account": account},
                    ensure_ascii=False,
                ),
                max_tokens=800,
                expect_json=True,
            )
        except Exception as exc:
            _logger.error("Claude failed to generate lead payload: %s", exc, exc_info=True)
            return {"error": "claude_failed"}

        if not isinstance(resp, dict):
            return {"error": "invalid_claude_payload"}

        lead_vals = {
            "name": resp.get("name") or (company_name or email or name or "New Lead"),
            "email_from": resp.get("email_from") or email,
            "phone": resp.get("phone") or phone,
            "description": resp.get("description") or "",
            "type": "lead",
        }
        # Assign by simple rule: if estimated revenue > 1M, assign to Sales Team 1 lead
        revenue = resp.get("expected_revenue") or 0
        team = env["crm.team"].sudo().search([], limit=1)
        if team:
            lead_vals["team_id"] = team.id

        new_lead = Lead.create(lead_vals)
        _logger.info("New lead %s created from Apollo/Claude enrichment", new_lead.id)
        return {"status": "created", "lead_id": new_lead.id}

    # -----------------------------------------------------------------
    # CALENDLY / CALENDAR EVENT CREATED
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/calendar_event_create",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def calendar_event_create(self, **payload):
        """
        Called by n8n when a Calendly booking is created.

        Expected payload:
        {
            "lead_id": int,
            "event_name": str,
            "start_datetime": str,   ISO datetime
            "duration_minutes": int,
            "invitee_name": str,
            "invitee_email": str,
            "calendly_event_id": str,
            "calendly_event_url": str,
        }
        """
        lead_id = payload.get("lead_id")
        if not lead_id:
            # Try to find lead by invitee email
            email = (payload.get("invitee_email") or "").strip()
            if email:
                lead = request.env["crm.lead"].sudo().search(
                    [("email_from", "=ilike", email), ("active", "=", True)], limit=1
                )
                if lead:
                    lead_id = lead.id

        if not lead_id:
            _logger.warning("sales_ai: calendar_event_create — no lead_id and no email match")
            return {"error": "no_lead_found"}

        lead = request.env["crm.lead"].sudo().browse(int(lead_id))
        if not lead.exists():
            return {"error": "lead_not_found"}

        start_dt = payload.get("start_datetime", "")
        event_name = payload.get("event_name") or "Meeting"
        invitee = payload.get("invitee_name") or lead.contact_name or ""
        calendly_url = payload.get("calendly_event_url") or ""

        # Post note on lead
        note_html = (
            "<p><b>Meeting scheduled via Calendly:</b> %s</p>"
            "<p><b>Invitee:</b> %s &lt;%s&gt;</p>"
            "<p><b>Start:</b> %s</p>"
            "%s"
        ) % (
            event_name, invitee, payload.get("invitee_email") or "",
            start_dt,
            ("<p><a href='%s'>Calendly event</a></p>" % calendly_url) if calendly_url else "",
        )
        lead.message_post(body=note_html, subtype_xmlid="mail.mt_note")

        # Update lead stage to "Meeting Scheduled" if it exists
        meeting_stage = request.env["crm.stage"].sudo().search(
            [("name", "ilike", "meeting")], limit=1
        )
        if meeting_stage:
            lead.stage_id = meeting_stage

        _logger.info(
            "sales_ai: Calendar event created for lead %s — %s at %s",
            lead_id, event_name, start_dt,
        )
        return {"status": "ok", "lead_id": lead_id}

    # -----------------------------------------------------------------
    # MEETING DONE (transcript ready)
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/meeting_done",
        type="http",
        auth="none",
        methods=["POST"],
        csrf=False,
    )
    def meeting_done(self):
        """
        Called by n8n after a client meeting transcript is ready.
        Accepts plain JSON POST (Content-Type: application/json).

        Accepts TWO formats:

        **Format A – Apollo Transcript Service webhook** (preferred):
        {
            "lead_id": int,
            "job_id": "53",
            "status": "completed",
            "data": {
                "meeting_title": str,
                "conversation_id": str,
                "conversation_url": str,
                "segments": [{"speaker": str, "text": str, "timestamp": str}, ...],
                "extracted_at": str,
                "extraction_method": str
            }
        }

        **Format B – flat / legacy**:
        {
            "lead_id": int,
            "transcript": str,
            "meeting_date": str,
            "meeting_duration": int,
            "attendees": [...],
            "conversation_id": str,
            "meeting_name": str,
            "source": str
        }
        """
        try:
            raw_body = request.httprequest.get_data(as_text=True)
            payload = json.loads(raw_body) if raw_body else {}
        except (json.JSONDecodeError, Exception) as exc:
            _logger.error("sales_ai: [MEETING-DONE] invalid JSON: %s", exc)
            self._notify_n8n_callback_issue("meeting_done received invalid JSON payload", level="danger")
            return request.make_json_response({"status": "ok", "skipped": True, "reason": "invalid_json"}, status=200)

        # Unwrap n8n envelope (list / body / params wrappers)
        if isinstance(payload, list):
            payload = payload[0] if payload else {}
        if "body" in payload and isinstance(payload.get("body"), dict):
            payload = payload["body"]
        elif "params" in payload and isinstance(payload.get("params"), dict) and payload["params"]:
            payload = payload["params"]

        if not _check_n8n_auth(request.httprequest.headers):
            _logger.warning("sales_ai: [MEETING-DONE] unauthorized")
            self._notify_n8n_callback_issue("meeting_done unauthorized callback blocked", level="danger")
            return request.make_json_response({"status": "ok", "skipped": True, "reason": "unauthorized"}, status=200)

        # Extract lead_id: top-level OR from odoo_payload.payload.lead_id
        odoo_payload = payload.get("odoo_payload") or {}
        odoo_inner = odoo_payload.get("payload") or {} if isinstance(odoo_payload, dict) else {}
        lead_id = payload.get("lead_id") or odoo_inner.get("lead_id")

        # Detect Apollo format (has "data.segments") vs legacy flat
        apollo_data = payload.get("data") or {}
        segments = apollo_data.get("segments") if isinstance(apollo_data, dict) else None

        meeting_id = (
            payload.get("meeting_id")
            or odoo_inner.get("meeting_id")
            or (
                (payload.get("payload") or {}).get("meeting_id")
                if isinstance(payload.get("payload"), dict)
                else None
            )
        )
        meeting = self._meeting_from_id(meeting_id)

        if segments and isinstance(segments, list):
            transcript = self._segments_to_transcript(segments)
            conversation_id = apollo_data.get("conversation_id") or ""
            conversation_url = apollo_data.get("conversation_url") or ""
            speakers = list({seg.get("speaker") for seg in segments if seg.get("speaker")})

            meeting_name = (
                odoo_inner.get("meeting_name")
                or apollo_data.get("meeting_title")
                or ""
            )
            source = odoo_inner.get("source") or "apollo"
            meeting_date = odoo_inner.get("meeting_start", "")[:10] if odoo_inner.get("meeting_start") else ""
            meeting_start = odoo_inner.get("meeting_start") or ""
            meeting_stop = odoo_inner.get("meeting_stop") or ""
            meeting_duration = int(payload.get("meeting_duration") or 0)
            if not meeting_duration and meeting_start and meeting_stop:
                try:
                    from datetime import datetime
                    fmt = "%Y-%m-%d %H:%M:%S"
                    dt_start = datetime.strptime(meeting_start, fmt)
                    dt_stop = datetime.strptime(meeting_stop, fmt)
                    meeting_duration = int((dt_stop - dt_start).total_seconds() / 60)
                except Exception:
                    pass

            odoo_participants = odoo_inner.get("participants") or []
            attendees = [{"name": n, "is_client": True} for n in odoo_participants]
            if not attendees:
                attendees = [{"name": s, "is_client": True} for s in speakers]

            _logger.info(
                "sales_ai: [MEETING-DONE] apollo format — lead=%s, segments=%d, transcript=%d chars",
                lead_id, len(segments), len(transcript),
            )
        else:
            transcript = payload.get("transcript") or ""
            meeting_name = payload.get("meeting_name") or ""
            conversation_id = payload.get("conversation_id") or ""
            conversation_url = payload.get("conversation_url") or ""
            source = payload.get("source") or "meeting_done"
            attendees = payload.get("attendees") or []
            meeting_date = payload.get("meeting_date") or ""
            meeting_duration = int(payload.get("meeting_duration") or 0)
            _logger.info(
                "sales_ai: [MEETING-DONE] legacy format — lead=%s, transcript=%d chars",
                lead_id, len(transcript),
            )

        meeting_type = self._meeting_done_resolve_meeting_type(payload, odoo_inner, meeting)

        if not transcript:
            _logger.error("sales_ai: [MEETING-DONE] empty transcript for lead "
                      "%s", lead_id)
            self._update_meeting_callback_audit(
                meeting,
                payload,
                status="failed",
                error="empty transcript in callback payload",
                transcript="",
                mark_processed=False,
            )
            # Do not fail n8n call; keep error visibility inside Odoo.
            try:
                note_body = (
                    "<p><b>Transcript callback received empty transcript.</b></p>"
                    "<p>Please retry transcript extraction from n8n/Apollo.</p>"
                )
                if lead_id:
                    lead = request.env["crm.lead"].with_user(SUPERUSER_ID).browse(int(lead_id))
                    if lead.exists():
                        self._post_callback_note(lead=lead, body=note_body)
                elif meeting and meeting.exists():
                    self._post_callback_note(meeting=meeting, body=note_body)
                else:
                    self._post_fallback_admin_note(note_body)
            except Exception:
                _logger.warning(
                    "sales_ai: [MEETING-DONE] unable to post empty-transcript note",
                    exc_info=True,
                )
            self._notify_n8n_callback_issue(
                "meeting_done received empty transcript; skipped processing",
                level="warning",
            )
            return request.make_json_response(
                {"status": "ok", "skipped": True, "reason": "empty_transcript"},
                status=200,
            )

        # Unified callback path: if this transcript is presale, route through
        # existing presale transcript handler (ticket split/routing) even when
        # n8n only calls /meeting_done.
        if meeting_type == "presale":
            # Persist transcript + callback payload on meeting immediately.
            self._update_meeting_callback_audit(
                meeting, payload, status="pending", error=False, transcript=transcript, mark_processed=False
            )

            # Route presale transcript ONLY by ticket markers/ids/name.
            # lead_id is intentionally ignored for presale routing.
            merged_src = self._meeting_done_merge_callback_sources(payload, odoo_inner)
            candidate_ticket_ids = []
            for raw in (
                payload.get("presale_ticket_ids"),
                odoo_inner.get("presale_ticket_ids"),
                merged_src.get("presale_ticket_ids"),
            ):
                if isinstance(raw, list):
                    candidate_ticket_ids.extend([int(x) for x in raw if str(x).isdigit()])
            ticket_id = int(
                payload.get("ticket_id")
                or odoo_inner.get("ticket_id")
                or merged_src.get("ticket_id")
                or 0,
            ) or (candidate_ticket_ids[0] if candidate_ticket_ids else 0)
            presale_payload = {
                "lead_id": None,
                "ticket_id": ticket_id or None,
                "ticket_ids": candidate_ticket_ids,
                "meeting_id": int(meeting_id) if meeting_id else None,
                "meeting_name": meeting_name or "",
                "transcript": transcript,
                "meeting_date": meeting_date,
                "meeting_duration": meeting_duration,
                "attendees": attendees or [],
                "prior_open_items": payload.get("prior_open_items") or [],
            }
            try:
                presale_res = self.presale_transcript(**presale_payload)
            except Exception as exc:
                _logger.error("sales_ai: [MEETING-DONE] presale route failed: %s", exc, exc_info=True)
                # Recovery path: even if controller-level presale routing fails,
                # try direct ticket resolution + MOM generation so cron/callback
                # still lands MOM automatically.
                fallback_res = {"status": "ok", "skipped": True, "reason": "presale_processing_failed"}
                try:
                    Ticket = request.env["sh.helpdesk.ticket"].sudo()
                    ticket = Ticket.browse(int(ticket_id)) if ticket_id else Ticket.browse()
                    if not ticket.exists():
                        ticket = Ticket._resolve_ticket_from_transcript_number_and_name(
                            transcript=transcript,
                            meeting_name=meeting_name,
                            lead_id=None,
                        )
                    if ticket and ticket.exists():
                        ticket.action_generate_presale_mom(
                            transcript=transcript,
                            meeting_date=meeting_date,
                            meeting_duration=meeting_duration,
                            attendees=attendees or [],
                            prior_open_items=payload.get("prior_open_items") or [],
                        )
                        if meeting and meeting.exists():
                            meeting.sudo().write({
                                "x_transcript_requested": True,
                                "x_transcript_request_sent": False,
                            })
                        fallback_res = {
                            "status": "ok",
                            "mode": "meeting_done_fallback",
                            "ticket_id": ticket.id,
                            "presale_ref": ticket.x_presale_ref,
                        }
                        self._update_meeting_callback_audit(
                            meeting,
                            payload,
                            status="success",
                            error=False,
                            transcript=transcript,
                            mark_processed=True,
                        )
                        self._mark_meeting_presale_mom_synced(meeting, transcript)
                        return request.make_json_response(
                            {"status": "ok", "meeting_type": "presale", "result": fallback_res}
                        )
                except Exception:
                    _logger.error(
                        "sales_ai: [MEETING-DONE] presale fallback processing failed",
                        exc_info=True,
                    )

                self._update_meeting_callback_audit(
                    meeting,
                    payload,
                    status="failed",
                    error="presale route failed: %s" % str(exc),
                    transcript=transcript,
                    mark_processed=False,
                )
                self._post_callback_note(
                    meeting=meeting if meeting and meeting.exists() else None,
                    body=(
                        "<p><b>Presale transcript callback failed in Odoo.</b></p>"
                        "<p>Error: %s</p>" % str(exc)[:500]
                    ),
                )
                self._notify_n8n_callback_issue(
                    "meeting_done presale processing failed in Odoo: %s" % str(exc)[:200],
                    level="danger",
                )
                return request.make_json_response(fallback_res, status=200)
            if isinstance(presale_res, dict) and not presale_res.get("skipped"):
                self._update_meeting_callback_audit(
                    meeting, payload, status="success", error=False, transcript=transcript, mark_processed=True
                )
                self._mark_meeting_presale_mom_synced(meeting, transcript)
            else:
                self._update_meeting_callback_audit(
                    meeting,
                    payload,
                    status="failed",
                    error=(presale_res or {}).get("reason") if isinstance(presale_res, dict) else "presale skipped",
                    transcript=transcript,
                    mark_processed=False,
                )
            _logger.info(
                "sales_ai: [MEETING-DONE] routed to presale_transcript lead=%s meeting=%s ticket=%s",
                lead_id or "n/a", meeting_id or "n/a", ticket_id or "auto",
            )
            return request.make_json_response(
                {"status": "ok", "meeting_type": "presale", "result": presale_res}
            )

        if not lead_id:
            _logger.warning("sales_ai: [MEETING-DONE] missing lead_id for client meeting")
            self._post_callback_note(
                meeting=meeting if meeting and meeting.exists() else None,
                body=(
                    "<p><b>Client meeting transcript callback skipped.</b></p>"
                    "<p>Reason: missing lead_id in callback payload.</p>"
                ),
            )
            self._notify_n8n_callback_issue(
                "meeting_done skipped: missing lead_id for client processing",
                level="warning",
            )
            self._update_meeting_callback_audit(
                meeting,
                payload,
                status="failed",
                error="missing lead_id for client processing",
                transcript=transcript,
                mark_processed=False,
            )
            return request.make_json_response({"status": "ok", "skipped": True, "reason": "missing_lead_id"}, status=200)

        lead = request.env["crm.lead"].with_user(SUPERUSER_ID).browse(int(lead_id))
        if not lead.exists():
            _logger.warning("sales_ai: [MEETING-DONE] lead %s not found", lead_id)
            self._post_callback_note(
                meeting=meeting if meeting and meeting.exists() else None,
                body=(
                    "<p><b>Client meeting transcript callback skipped.</b></p>"
                    "<p>Reason: lead not found for lead_id=%s.</p>" % lead_id
                ),
            )
            self._notify_n8n_callback_issue(
                "meeting_done skipped: lead %s not found" % lead_id,
                level="warning",
            )
            self._update_meeting_callback_audit(
                meeting,
                payload,
                status="failed",
                error="lead not found for lead_id=%s" % lead_id,
                transcript=transcript,
                mark_processed=False,
            )
            return request.make_json_response({"status": "ok", "skipped": True, "reason": "lead_not_found"}, status=200)

        # Idempotency guard: do not process the same meeting transcript twice.
        # Prefer Apollo conversation_id; fallback to deterministic hash for legacy payloads.
        dedupe_token = (conversation_id or "").strip()
        if not dedupe_token:
            raw = "%s|%s|%s|%s" % (
                int(lead_id),
                meeting_name or "",
                meeting_date or "",
                (transcript or "").strip(),
            )
            dedupe_token = "legacy:%s" % hashlib.sha1(raw.encode("utf-8")).hexdigest()
        if not lead._sales_ai_try_mark_conversation_processed(dedupe_token, keep_last=200):
            _logger.info(
                "sales_ai: [MEETING-DONE] duplicate transcript skipped for lead %s token=%s",
                lead_id, dedupe_token[:80],
            )
            self._update_meeting_callback_audit(
                meeting,
                payload,
                status="success",
                error=False,
                transcript=transcript,
                mark_processed=True,
            )
            return request.make_json_response(
                {"status": "ok", "skipped": True, "reason": "duplicate_transcript"}
            )

        # Non-blocking: model handles background processing with fresh cursor.
        lead.action_generate_client_mom(
            transcript=transcript,
            meeting_date=meeting_date,
            meeting_duration=meeting_duration,
            attendees=attendees,
            conversation_id=conversation_id,
            conversation_url=conversation_url,
            source=source,
            meeting_name=meeting_name,
            meeting_id=int(meeting_id) if meeting_id else None,
            request_payload_json=json.dumps(payload, ensure_ascii=False),
        )

        _logger.info(
            "sales_ai: [MEETING-DONE] background MOM thread spawned for lead %s", lead_id,
        )
        self._update_meeting_callback_audit(
            meeting,
            payload,
            status="success",
            error=False,
            transcript=transcript,
            mark_processed=True,
        )
        return request.make_json_response({"status": "ok", "async": True})

    @staticmethod
    def _segments_to_transcript(segments):
        """Convert Apollo segments list to a readable transcript string.

        Input:  [{"speaker": "Alice", "text": "Hello", "timestamp": "00:01"}, ...]
        Output: "[00:01] Alice: Hello\n[00:02] Bob: Hi\n..."
        """
        lines = []
        for seg in segments:
            ts = seg.get("timestamp") or ""
            speaker = seg.get("speaker") or "Unknown"
            text = seg.get("text") or ""
            if ts:
                lines.append(f"[{ts}] {speaker}: {text}")
            else:
                lines.append(f"{speaker}: {text}")
        return "\n".join(lines)

    # -----------------------------------------------------------------
    # MEETING NO-SHOW
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/meeting_no_show",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def meeting_no_show(self, **payload):
        """
        Called by n8n when a scheduled meeting has no-show (Calendly detects cancellation
        or rep marks it manually).

        Expected payload:
        {
            "lead_id": int,
            "no_show_count": int,   1 = first no-show, 2 = second, etc.
        }
        """
        lead_id = payload.get("lead_id")
        if not lead_id:
            self._notify_n8n_callback_issue("meeting_no_show skipped: missing lead_id")
            return {"status": "ok", "skipped": True, "reason": "missing_lead_id"}

        lead = request.env["crm.lead"].sudo().browse(int(lead_id))
        if not lead.exists():
            self._notify_n8n_callback_issue("meeting_no_show skipped: lead %s not found" % lead_id)
            return {"status": "ok", "skipped": True, "reason": "lead_not_found"}

        no_show_count = int(payload.get("no_show_count") or 1)
        _logger.info(
            "sales_ai: Meeting no-show for lead %s (count=%d)", lead_id, no_show_count
        )
        lead.action_no_show_followup(no_show_count=no_show_count)
        return {"status": "ok"}

    # -----------------------------------------------------------------
    # PRESALE TRANSCRIPT (routes to ticket or lead)
    # -----------------------------------------------------------------

    @http.route(
        "/odoo/api/sales_ai/presale_transcript",
        type="jsonrpc",
        auth="api_key",
        methods=["POST"],
        csrf=False,
    )
    def presale_transcript(self, **payload):
        """
        Called by n8n "Presale MOM Splitter" workflow after a presale meeting.
        Routes to the helpdesk ticket (primary) or lead (fallback).

        Expected payload:
        {
            "lead_id": int,
            "ticket_id": int (optional),
            "transcript": str,
            "meeting_date": str,
            "meeting_duration": int,
            "attendees": [...],
            "prior_open_items": [...],
        }
        """
        lead_id = payload.get("lead_id")
        ticket_id = payload.get("ticket_id")
        ticket_ids = payload.get("ticket_ids") or []
        meeting_id = payload.get("meeting_id")
        meeting_name = payload.get("meeting_name") or ""
        transcript = payload.get("transcript") or ""
        meeting = self._meeting_from_id(meeting_id)
        transcript_record = False

        if not transcript:
            self._notify_n8n_callback_issue(
                "presale_transcript skipped: missing transcript",
                level="warning",
            )
            if meeting_id:
                meeting = request.env["calendar.event"].sudo().browse(int(meeting_id))
                if meeting.exists():
                    self._post_callback_note(
                        meeting=meeting,
                        body=(
                            "<p><b>Presale transcript callback skipped.</b></p>"
                            "<p>Reason: missing transcript in payload.</p>"
                        ),
                    )
            return {"status": "ok", "skipped": True, "reason": "missing_transcript"}

        # Persist transcript callback as a transcript record (meeting-centric view).
        try:
            transcript_record = request.env["sales.ai.meeting.transcript"].sudo().create({
                "lead_id": int(lead_id) if lead_id else False,
                "meeting_id": int(meeting_id) if meeting_id else False,
                "meeting_name": meeting_name or (meeting.name if meeting and meeting.exists() else ""),
                "meeting_date": payload.get("meeting_date") or False,
                "meeting_start": (meeting.start if meeting and meeting.exists() else False),
                "meeting_duration": int(payload.get("meeting_duration") or 0),
                "conversation_id": "",
                "conversation_url": "",
                "source": "presale_meeting_done",
                "transcript": (transcript or "")[:150000],
                "payload_json": "",
                "request_payload_json": json.dumps(payload, ensure_ascii=False),
            })
        except Exception:
            _logger.warning("sales_ai: failed to create presale transcript record", exc_info=True)

        Ticket = request.env["sh.helpdesk.ticket"].sudo()

        # Multi-ticket meeting flow:
        # transcript may contain markers like "moving to ticket #PST-1042".
        # In that case, split and route each chunk to the matched ticket.
        if not ticket_id and not ticket_ids:
            routed = Ticket.action_route_multi_ticket_transcript(
                transcript=transcript,
                lead_id=None,
                meeting_date=payload.get("meeting_date"),
                meeting_duration=payload.get("meeting_duration"),
                attendees=payload.get("attendees") or [],
                prior_open_items=payload.get("prior_open_items") or [],
            )
            if (routed or {}).get("processed_count"):
                if meeting and meeting.exists():
                    meeting.sudo().write({
                        "x_transcript_requested": True,
                        "x_transcript_request_sent": False,
                    })
                    self._mark_meeting_presale_mom_synced(meeting, transcript)
                return {
                    "status": "ok",
                    "mode": "multi_ticket",
                    "transcript_record_id": transcript_record.id if transcript_record else False,
                    "processed_count": routed.get("processed_count"),
                    "segments": routed.get("segments"),
                    "ticket_ids": routed.get("ticket_ids") or [],
                    "unmatched_markers": routed.get("unmatched_markers") or [],
                }

            # No spoken ticket marker found; fallback to meeting name-based ticket match.
            if meeting_name:
                by_name_ticket = Ticket._resolve_ticket_from_marker(
                    meeting_name, lead_id=None
                )
                if by_name_ticket:
                    by_name_ticket.action_generate_presale_mom(
                        transcript=transcript,
                        meeting_date=payload.get("meeting_date"),
                        meeting_duration=payload.get("meeting_duration"),
                        attendees=payload.get("attendees") or [],
                        prior_open_items=payload.get("prior_open_items") or [],
                    )
                    if meeting and meeting.exists():
                        meeting.sudo().write({
                            "x_transcript_requested": True,
                            "x_transcript_request_sent": False,
                        })
                        self._mark_meeting_presale_mom_synced(meeting, transcript)
                    return {
                        "status": "ok",
                        "mode": "meeting_name_fallback",
                        "transcript_record_id": transcript_record.id if transcript_record else False,
                        "ticket_id": by_name_ticket.id,
                        "presale_ref": by_name_ticket.x_presale_ref,
                    }
            # Final fallback: extract ticket number from transcript and
            # combine with meeting-name hints to locate ticket.
            by_transcript_num = Ticket._resolve_ticket_from_transcript_number_and_name(
                transcript=transcript,
                meeting_name=meeting_name,
                lead_id=None,
            )
            if by_transcript_num:
                by_transcript_num.action_generate_presale_mom(
                    transcript=transcript,
                    meeting_date=payload.get("meeting_date"),
                    meeting_duration=payload.get("meeting_duration"),
                    attendees=payload.get("attendees") or [],
                    prior_open_items=payload.get("prior_open_items") or [],
                )
                if meeting and meeting.exists():
                    meeting.sudo().write({
                        "x_transcript_requested": True,
                        "x_transcript_request_sent": False,
                    })
                    self._mark_meeting_presale_mom_synced(meeting, transcript)
                return {
                    "status": "ok",
                    "mode": "transcript_number_fallback",
                    "transcript_record_id": transcript_record.id if transcript_record else False,
                    "ticket_id": by_transcript_num.id,
                    "presale_ref": by_transcript_num.x_presale_ref,
                }

        ticket = None
        if ticket_id:
            ticket = Ticket.browse(int(ticket_id))
            if not ticket.exists():
                ticket = None
        if not ticket and ticket_ids:
            for tid in ticket_ids:
                if str(tid).isdigit():
                    candidate = Ticket.browse(int(tid))
                    if candidate.exists():
                        ticket = candidate
                        break

        if ticket:
            _logger.info(
                "sales_ai: Presale transcript routed to ticket %s (%d chars)",
                ticket.id, len(transcript),
            )
            ticket.action_generate_presale_mom(
                transcript=transcript,
                meeting_date=payload.get("meeting_date"),
                meeting_duration=payload.get("meeting_duration"),
                attendees=payload.get("attendees") or [],
                prior_open_items=payload.get("prior_open_items") or [],
            )
            if meeting and meeting.exists():
                meeting.sudo().write({
                    "x_transcript_requested": True,
                    "x_transcript_request_sent": False,
                })
                self._mark_meeting_presale_mom_synced(meeting, transcript)
            return {
                "status": "ok",
                "transcript_record_id": transcript_record.id if transcript_record else False,
                "ticket_id": ticket.id,
                "presale_ref": ticket.x_presale_ref,
            }

        self._notify_n8n_callback_issue(
            "presale_transcript skipped: could not match a ticket from transcript",
            level="warning",
        )
        if meeting and meeting.exists():
            self._post_callback_note(
                meeting=meeting,
                body=(
                    "<p><b>Presale transcript callback skipped.</b></p>"
                    "<p>Reason: unable to match ticket by spoken marker, ticket id, or meeting name.</p>"
                ),
            )
        return {
            "status": "ok",
            "skipped": True,
            "reason": "ticket_not_matched",
            "transcript_record_id": transcript_record.id if transcript_record else False,
        }

    # ------------------------------------------------------------------
    # MOM activity creation – transcript + attachment extracts
    # ------------------------------------------------------------------

    @http.route(
        "/odoo/api/create_mom_activity",
        type="jsonrpc",
        auth="none",
        methods=["POST"],
        csrf=False,
    )
    def api_create_mom_activity(self, **payload):
        if not _check_n8n_auth(request.httprequest.headers):
            _logger.warning("Unauthorized /api/create_mom_activity call")
            self._notify_n8n_callback_issue("create_mom_activity unauthorized callback blocked", level="danger")
            return {"status": "ok", "skipped": True, "reason": "unauthorized"}

        lead_id = payload.get("lead_id")
        transcript = payload.get("transcript") or ""
        attachment_ids = payload.get("attachment_ids") or []
        if not lead_id or not transcript:
            self._notify_n8n_callback_issue("create_mom_activity skipped: missing lead/transcript")
            return {"status": "ok", "skipped": True, "reason": "missing_lead_or_transcript"}

        env = request.env
        Lead = env["crm.lead"].sudo()
        lead = Lead.browse(int(lead_id))
        if not lead.exists():
            self._notify_n8n_callback_issue("create_mom_activity skipped: lead %s not found" % lead_id)
            return {"status": "ok", "skipped": True, "reason": "lead_not_found"}

        # Non-blocking behavior: schedule MOM generation on lead in background.
        lead.action_generate_client_mom(
            transcript=transcript,
            meeting_date=payload.get("meeting_date") or "",
            meeting_duration=int(payload.get("meeting_duration") or 0),
            attendees=payload.get("attendees") or [],
            request_payload_json=json.dumps(payload, ensure_ascii=False),
        )
        return {"status": "ok", "lead_id": lead.id, "async": True}

        # Extract attachments into text
        extracts = {}
        Attachment = env["ir.attachment"].sudo()
        try:
            from PyPDF2 import PdfReader
            import pytesseract
            from docx import Document
            from io import BytesIO
            from PIL import Image
        except Exception as exc:
            _logger.error("Attachment libraries missing: %s", exc, exc_info=True)
            # Proceed with transcript only
            extracts = {}
        else:
            for att_id in attachment_ids:
                att = Attachment.browse(int(att_id))
                if not att.exists() or not att.datas:
                    continue
                raw = att.datas
                try:
                    data = base64.b64decode(raw)
                except Exception:
                    continue
                text = ""
                mime = att.mimetype or ""
                name = (att.name or "").lower()
                try:
                    if mime == "application/pdf" or name.endswith(".pdf"):
                        reader = PdfReader(BytesIO(data))
                        for page in reader.pages:
                            text += page.extract_text() or ""
                    elif mime.startswith("image/"):
                        img = Image.open(BytesIO(data))
                        text = pytesseract.image_to_string(img)
                    elif name.endswith(".docx"):
                        doc = Document(BytesIO(data))
                        text = "\n".join(p.text for p in doc.paragraphs)
                except Exception as exc:
                    _logger.error("Failed to extract text from attachment %s: %s", att.id, exc)
                if text:
                    extracts[str(att.id)] = text[:20000]

        # Cache extracts on lead
        if extracts:
            lead.x_attachment_extracts_json = json.dumps(extracts, ensure_ascii=False)

        # Call Claude for structured MOM JSON
        claude_service = env["claude.service"]
        system_prompt = (
            "You are a sales assistant creating structured meeting minutes (MOM). "
            "Return JSON: {date: string, time: string, points: [..], "
            "actions: [{owner, description, due_date}], next_steps: string}."
        )
        try:
            resp = claude_service.call(
                tier="sonnet",
                system_prompt=system_prompt,
                user_message=json.dumps(
                    {
                        "transcript": transcript[:150000],
                        "attachments": extracts,
                    },
                    ensure_ascii=False,
                ),
                max_tokens=800,
                expect_json=True,
            )
        except Exception as exc:
            _logger.error("Claude MOM structuring failed: %s", exc, exc_info=True)
            self._notify_n8n_callback_issue("create_mom_activity skipped: Claude failed", level="danger")
            return {"status": "ok", "skipped": True, "reason": "claude_failed"}

        if not isinstance(resp, dict):
            self._notify_n8n_callback_issue("create_mom_activity skipped: invalid MOM JSON", level="warning")
            return {"status": "ok", "skipped": True, "reason": "invalid_mom_json"}

        # Append to x_mom_history
        try:
            history = json.loads(lead.x_mom_history or "[]")
        except Exception:
            history = []
        history.append(resp)
        lead.x_mom_history = json.dumps(history, ensure_ascii=False)

        # Create mail.activity + chatter note
        mom_html = "<p><b>Date:</b> %s<br/><b>Time:</b> %s</p>" % (
            resp.get("date") or "",
            resp.get("time") or "",
        )
        mom_html += "<h4>Discussion Points</h4><ul>"
        for pt in resp.get("points") or []:
            mom_html += "<li>%s</li>" % pt
        mom_html += "</ul><h4>Actions</h4><ul>"
        for act in resp.get("actions") or []:
            mom_html += "<li><b>%s</b>: %s (due %s)</li>" % (
                act.get("owner") or "",
                act.get("description") or "",
                act.get("due_date") or "",
            )
        mom_html += "</ul><h4>Next Steps</h4><p>%s</p>" % (resp.get("next_steps") or "")

        lead.message_post(body=mom_html, subtype_xmlid="mail.mt_note")

        mom_type = env.ref(
            "sales_ai_integration.activity_type_client_mom", raise_if_not_found=False
        )
        env["mail.activity"].sudo().create(
            {
                "res_model_id": env.ref("crm.model_crm_lead").id,
                "res_id": lead.id,
                "user_id": lead.user_id.id,
                "activity_type_id": mom_type.id if mom_type else False,
                "note": "[AI MOM] " + (resp.get("next_steps") or ""),
                "date_deadline": fields.Date.today(),
            }
        )

        return {"status": "ok", "lead_id": lead.id}
