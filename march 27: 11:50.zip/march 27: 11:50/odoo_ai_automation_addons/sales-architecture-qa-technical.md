# Inbound Sales Automation — Architecture Q&A + Technical Workflows
**Odoo 19 CE + Claude AI + n8n | March 2026**

> This document answers every critical architecture question, maps all human pause points with restart logic, defines the minimal effective n8n integration strategy, and includes the full technical workflow for every integration point.

---

## Table of Contents

1. [Section 1 — Recording-to-Lead Matching](#section-1--recording-to-lead-matching)
2. [Section 2 — Human Pause Points](#section-2--human-pause-points)
3. [Section 3 — Reducing Integration Complexity](#section-3--reducing-integration-complexity)
4. [Section 4 — Multi-Flow Integration & Technical Workflows](#section-4--multi-flow-integration--technical-workflows)
5. [Section 5 — AI Model Selection](#section-5--ai-model-selection)
6. [Section 6 — Implementation Priority](#section-6--implementation-priority)

---

## Section 1 — Recording-to-Lead Matching

### Q1 — How does Playwright know which Apollo recording belongs to which Odoo lead?

**The Problem**

Apollo has: recording title, datetime, attendee emails, duration.
Odoo has: lead record, calendar event, partner emails.
These exist in separate systems with no shared key — unless we create one during enrichment.

**The 4-Signal Matching Strategy**

| Signal | What Playwright Extracts | How Odoo Matches | Confidence |
|--------|--------------------------|------------------|------------|
| S1 — Contact Email | `attendees[]` from recording page | `res.partner.email` → `crm.lead.email_from` or `partner_id.email` | HIGH |
| S2 — Calendar Timestamp | `start_datetime` from recording metadata | `calendar.event.start_datetime ±15 min` → `event.opportunity_id` | VERY HIGH |
| S3 — Apollo Contact ID | `apollo_contact_id` from recording page URL or metadata | `crm.lead.x_apollo_contact_id` (stored during enrichment) | CERTAIN |
| S4 — Company Name Fuzzy | `company_name` from recording page | Fuzzy match on `crm.lead.partner_name` | MEDIUM |

> **Recommended build order:** Start with S2 (calendar timestamp + email) in V1. Add S3 (Apollo Contact ID stored during enrichment) in Week 2 — this becomes your permanent primary key and makes everything else a fallback.

---

### Q2 — What is the exact step-by-step matching flow n8n runs?

**Decision Tree — Run In This Exact Order**

```
Apollo Recording Scraped by Playwright
            │
            ▼
  ┌─────────────────────────────────────────────────────┐
  │  STEP 1: Apollo Contact ID Match                    │
  │  Playwright extracts apollo_contact_id from         │
  │  recording page URL or metadata                     │
  │                                                     │
  │  n8n → GET /api/sales_ai/find_lead                 │
  │  ?apollo_contact_id={extracted_id}                  │
  └─────────────────────────────────────────────────────┘
            │
      Match found?
       /         \
     YES          NO
      │            │
      ▼            ▼
   MATCH       STEP 2: Email + Timestamp Match
  (certain)    n8n queries calendar.event in Odoo:
               attendee_email IN recording_emails
               AND start_datetime BETWEEN
               (recording_time - 15min, recording_time + 15min)
               AND event.opportunity_id IS NOT NULL
                    │
              Match found?
               /         \
             YES          NO
              │            │
              ▼            ▼
           MATCH       STEP 3: Email Only Match
         (strong)      n8n queries crm.lead:
                       email_from IN recording_emails
                       AND active = True
                            │
                  Exactly 1 lead found?
                 /      |       \
               YES   MULTIPLE   NO
                │       │        │
                ▼       ▼        ▼
             MATCH    PARK     PARK
            (medium)  in       in
                    queue    queue
                    (flag    (notify
                    multiple) rep)
                │
                ▼
        STEP 4: No Match → Create unmatched recording
        in Odoo → POST Teams alert → Rep links manually
        → MOM generation triggers after manual confirm
```

**n8n Implementation (W1 workflow — Apollo Recording Fetch)**

```javascript
// n8n Function node: Match Recording to Lead
async function matchRecordingToLead(recording) {
  const { apollo_contact_id, attendee_emails, start_datetime, company_name } = recording;

  // Step 1 — Apollo Contact ID
  if (apollo_contact_id) {
    const lead = await odooQuery('crm.lead', [
      ['x_apollo_contact_id', '=', apollo_contact_id],
      ['active', '=', true]
    ]);
    if (lead.length === 1) return { lead_id: lead[0].id, confidence: 'certain', method: 'apollo_id' };
  }

  // Step 2 — Email + Timestamp
  const timeFrom = new Date(start_datetime);
  timeFrom.setMinutes(timeFrom.getMinutes() - 15);
  const timeTo   = new Date(start_datetime);
  timeTo.setMinutes(timeTo.getMinutes() + 15);

  for (const email of attendee_emails) {
    const events = await odooQuery('calendar.event', [
      ['attendee_ids.email', '=', email],
      ['start', '>=', timeFrom.toISOString()],
      ['start', '<=', timeTo.toISOString()],
      ['opportunity_id', '!=', false]
    ]);
    if (events.length > 0) {
      return { lead_id: events[0].opportunity_id[0], confidence: 'strong', method: 'email_timestamp' };
    }
  }

  // Step 3 — Email only
  for (const email of attendee_emails) {
    const leads = await odooQuery('crm.lead', [
      ['email_from', 'ilike', email],
      ['active', '=', true]
    ]);
    if (leads.length === 1) return { lead_id: leads[0].id, confidence: 'medium', method: 'email_only' };
    if (leads.length > 1)  return { lead_id: null, confidence: 'low', method: 'multiple_leads', leads };
  }

  // Step 4 — No match
  return { lead_id: null, confidence: 'none', method: 'unmatched' };
}
```

**Odoo Side — Unmatched Recording Model**

```python
# models/unmatched_recording.py
class SalesAiUnmatchedRecording(models.Model):
    _name = 'sales.ai.unmatched.recording'
    _description = 'Unmatched Apollo Recording'

    apollo_recording_url = fields.Char('Recording URL')
    recording_datetime   = fields.Datetime('Recording DateTime')
    participant_emails   = fields.Text('Participant Emails (JSON)')
    company_name         = fields.Char('Company Name')
    match_confidence     = fields.Selection([
        ('none','No Match'),('low','Multiple Leads Found')
    ], default='none')
    matched_lead_id  = fields.Many2one('crm.lead', 'Link to Lead')
    state = fields.Selection([
        ('pending','Pending Review'),
        ('matched','Matched'),
        ('ignored','Ignored')
    ], default='pending')

    def action_confirm_match(self):
        self.ensure_one()
        if not self.matched_lead_id:
            raise UserError("Please select a lead before confirming.")
        self.state = 'matched'
        # Trigger MOM generation with the matched lead
        self.matched_lead_id.action_generate_client_mom(
            self.apollo_recording_url
        )
```

---

### Q3 — How do we match PRESALE recordings (internal meetings covering multiple tickets)?

**Why Presale is Different**

Presale meetings are internal-only (your team, no client). One recording covers multiple tickets. There is no client email to match against. The challenge: find which Odoo calendar event this recording belongs to, then get the ticket list.

**Primary Approach — Pre-filled Ticket List on Calendar Event**

```
1. Rep creates presale meeting in Google Calendar
           │
           ▼
2. google_calendar module syncs to Odoo calendar.event
           │
           ▼
3. Rep fills x_presale_ticket_ids (Many2many → project.task)
   on the Odoo calendar event BEFORE the meeting
   Example: [Ticket 101, Ticket 102, Ticket 103]
           │
           ▼
4. Meeting happens. Apollo records it.
           │
           ▼
5. Playwright scrapes recording:
   {
     start_datetime: "2026-03-14T14:00:00Z",
     attendees: ["dev1@co.com", "dev2@co.com"],
     transcript_text: "...Moving to ticket 101...Moving to ticket 102..."
   }
           │
           ▼
6. n8n W1 matches calendar.event by start_datetime ±15 min
   + any internal attendee email
           │
           ▼
7. Gets event.x_presale_ticket_ids → [101, 102, 103]
   Gets event.x_is_presale_meeting → True
           │
           ▼
8. Routes to n8n W2 (Presale MOM Splitter)
   with transcript + ticket_id_list
           │
           ▼
9. n8n W2 calls Claude:
   "Split this transcript by ticket number.
    Known ticket IDs: [101, 102, 103].
    Split on 'Moving to ticket XXXXX' cues.
    Return JSON: { ticket_id: mom_content }"
           │
           ▼
10. n8n POSTs each MOM section to its Odoo ticket
```

**How Playwright Tells Client vs Presale Meeting Apart**

```python
# Odoo automation rule on calendar.event:
# When all attendees are internal users (res.users),
# set x_is_presale_meeting = True automatically

class CalendarEvent(models.Model):
    _inherit = 'calendar.event'

    x_is_presale_meeting = fields.Boolean('Is Presale Meeting', default=False)
    x_presale_ticket_ids = fields.Many2many(
        'project.task', string='Presale Tickets Discussed'
    )

    @api.model
    def create(self, vals):
        record = super().create(vals)
        record._auto_flag_presale_meeting()
        return record

    def write(self, vals):
        result = super().write(vals)
        if 'attendee_ids' in vals:
            self._auto_flag_presale_meeting()
        return result

    def _auto_flag_presale_meeting(self):
        for event in self:
            attendee_emails = event.attendee_ids.mapped('email')
            internal_users  = self.env['res.users'].search([
                ['email', 'in', attendee_emails], ['share', '=', False]
            ])
            all_internal = len(internal_users) == len(attendee_emails)
            event.x_is_presale_meeting = all_internal
```

**n8n Routing Logic**

```javascript
// n8n Function node: Route Recording
function routeRecording(calendarEvent, transcript) {
  if (calendarEvent.x_is_presale_meeting) {
    // Send to W2 — Presale MOM Splitter
    return {
      route: 'presale',
      ticket_ids: calendarEvent.x_presale_ticket_ids,
      transcript
    };
  } else {
    // Send to Odoo client MOM endpoint
    return {
      route: 'client',
      lead_id: calendarEvent.opportunity_id,
      transcript
    };
  }
}
```

**Fallback — Naming Convention**

If rep forgets to pre-fill ticket IDs on the calendar event, Playwright reads the recording title.

Standard naming convention (enforce in operating procedures):
```
"Presale | 2026-03-14 | Tickets: 101, 102, 103"
```

```javascript
// n8n Function: Extract ticket IDs from recording title
function extractTicketsFromTitle(recordingTitle) {
  // Match "Tickets: 101, 102, 103" pattern
  const match = recordingTitle.match(/Tickets?:\s*([\d,\s]+)/i);
  if (!match) return [];
  return match[1].split(',').map(id => parseInt(id.trim())).filter(Boolean);
}
```

---

## Section 2 — Human Pause Points

### Q4 — What are all the human pause points and what happens at each one?

| Pause | Name | Owner | Escalation L1 → L2 | Auto-Action (L3) | Restart Trigger |
|-------|------|-------|---------------------|-----------------|-----------------|
| HP1 | Follow-up Email Draft | Sales Rep | Day+1: Teams ping to rep / Day+2: Teams to manager | Day+3: Log "Follow-up Missed". Activity stays. **Never auto-send.** | Activity marked done + outbound email on lead |
| HP2 | Client MOM Review | Sales Rep (meeting attendee) | Hour+4: Teams reminder / Hour+24: Teams to manager | Hour+48: Auto-send simplified MOM only if `x_allow_mom_auto_send = True` | Activity done + email sent from Odoo |
| HP3 | Presale Email Draft | Sales Rep | Day+1: Teams reminder / Day+2: Teams to presale lead | Day+3: Flag ticket "Needs Attention". **NEVER auto-send presale emails.** | Activity done + email sent |
| HP4 | WBS Validation | Presale Team | Day+2: Teams to presale team / Day+4: Teams to manager | Day+7: Reset ticket to "Open". Re-Generate WBS button appears. | `x_ticket_status = 'wbs_done'` set in Odoo |
| HP5 | Proposal Button Click | Presale Team | N/A — deliberate action / Stale deal monitor handles delay | No auto-action. Stale deal monitor flags lead stuck in Tech Review. | Button click fires n8n W8 webhook |
| HP6 | Proposal Review & Send | Sales Rep | Day+2: Teams reminder / Day+4: Teams to manager | Day+7: Stale deal flag "Proposal Not Sent". **Never auto-send proposals.** | Lead stage = Proposal Sent (manual) |

> **Key rule:** Never auto-send emails to clients as an L3 auto-action for HP1, HP3, or HP6. The only permitted auto-send is HP2 (Client MOM) and only if the rep has explicitly opted in via `x_allow_mom_auto_send = True` on their Odoo profile.

---

### Q5 — What exactly restarts the automation after each human pause?

**Complete Pause → Restart Flow**

```
══════════════════════════════════════════════════════════════════
HP1 — FOLLOW-UP EMAIL PAUSE
══════════════════════════════════════════════════════════════════

BEFORE PAUSE:
  9 AM cron → finds follow-up activity due today/tomorrow
  → calls Claude Sonnet → draft saved in activity.note
  → activity appears in rep's "My Activities" view

PAUSE: Rep must review draft and send email

RESTART DETECTION:
  Override mail.activity.action_feedback()
  When activity_type = "Follow-up Email" AND state = done:
    if x_followup_sequence == 3:
      lead.x_followup_stage = 'complete'
      lead.stage_id = 'No Response'  ← pipeline update
    else:
      increment x_followup_stage
      next activity becomes active (already created)

ESCALATION:
  08:00 AM cron checks: activity.date_deadline < today
  day_overdue = (today - activity.date_deadline).days
  if day_overdue == 1: Teams ping to rep
  if day_overdue == 2: Teams ping to manager
  if day_overdue >= 3: log x_followup_missed = True on lead

══════════════════════════════════════════════════════════════════
HP2 — CLIENT MOM PAUSE
══════════════════════════════════════════════════════════════════

BEFORE PAUSE:
  n8n W1 fetches transcript from Apollo via Playwright
  → POSTs to /api/sales_ai/receive_transcript
  → Odoo calls Claude Sonnet → generates full MOM + client email draft
  → full MOM logged to lead chatter (internal note)
  → draft email created as mail.activity type "Client MOM Review"
  → activity assigned to lead owner (rep who attended)

PAUSE: Rep reviews draft → edits if needed → sends from Odoo

RESTART DETECTION:
  message_post override on crm.lead detects:
    message_type = 'email' AND
    author_id = lead.user_id (internal user sending out)
    AND linked activity type = 'Client MOM Review'
  → marks activity done
  → logs: "Client MOM sent to [client] on [date]"
  → enables presale ticket creation flow (next manual step by rep)

══════════════════════════════════════════════════════════════════
HP3 — PRESALE EMAIL PAUSE
══════════════════════════════════════════════════════════════════

BEFORE PAUSE:
  n8n W2 POSTs presale MOM to /api/sales_ai/presale_mom_posted
  → Odoo posts MOM to presale TICKET (internal)
  → Odoo calls Claude Sonnet to draft client-facing email
  → Creates mail.activity type "Presale Email Draft" ON THE LEAD
  → Appears in rep's "My Activities" alongside follow-up drafts

PAUSE: Rep reviews draft → edits → sends from Odoo

RESTART DETECTION:
  Same mail.activity override as HP1
  Activity type = "Presale Email Draft" AND state = done
  → audit log on presale ticket: "Client update sent on [date]"

══════════════════════════════════════════════════════════════════
HP4 — WBS VALIDATION PAUSE
══════════════════════════════════════════════════════════════════

BEFORE PAUSE:
  Presale team sets ticket status = 'ready_for_wbs' in Odoo
  → automation rule fires webhook to n8n W3
  → n8n pulls ticket data via Odoo JSON-RPC
  → calls Claude Sonnet (WBS Skill) to generate WBS
  → writes WBS rows to Google Sheet (Sheets API)
  → names revision "AI Generated" via Sheets API
  → POSTs Sheet URL back to Odoo ticket (x_wbs_sheet_url)
  → Teams notification to presale team: "WBS ready for review"

PAUSE: Presale team opens Sheet → reviews → modifies
       → changes x_ticket_status = 'wbs_done' in Odoo

RESTART DETECTION:
  base_automation rule on project.task:
    trigger: on_write
    filter_pre: x_ticket_status != 'wbs_done'
    filter: x_ticket_status == 'wbs_done'
  → immediately fires Teams notification to tech team:
    "WBS validated for [ticket] — please add effort estimates"
  → tech team opens Sheet, adds hours per line item
  → when done: presale marks ticket 'estimation_complete'
    (another status change → another Teams ping to presale lead)

══════════════════════════════════════════════════════════════════
HP5 — PROPOSAL REQUEST PAUSE
══════════════════════════════════════════════════════════════════

BEFORE PAUSE:
  Tech team completes estimates in Sheet
  Presale reviews estimates → satisfied
  Ticket status set to 'wbs_done' (HP4 complete)

PAUSE: Presale clicks "Request Proposal from AI" button on ticket
       (button only visible when x_ticket_status = 'wbs_done')

RESTART DETECTION:
  Button click → server action fires → validates:
    x_ticket_status = 'wbs_done' ✓
    x_wbs_sheet_url is set ✓
    x_linked_lead_id is set ✓
  → sets x_ticket_status = 'ready_for_proposal'
  → POSTs webhook to n8n W8 with:
    { ticket_id, lead_id, wbs_sheet_url }
  → n8n W8 runs asynchronously (Opus call ~30 seconds)
  → n8n POSTs Drive URL back to Odoo:
    /api/sales_ai/proposal_ready
    { ticket_id, proposal_drive_url }
  → Odoo sets x_proposal_drive_url on ticket
  → Teams notification to rep: "Proposal ready — [Drive link]"

══════════════════════════════════════════════════════════════════
HP6 — PROPOSAL REVIEW PAUSE
══════════════════════════════════════════════════════════════════

BEFORE PAUSE:
  Proposal generated and written to Google Drive
  Drive link on Odoo ticket
  Teams notification sent to rep

PAUSE: Rep opens Drive link → reviews proposal →
       customizes if needed → sends to client from Odoo →
       manually changes lead stage to "Proposal Sent"

RESTART DETECTION:
  base_automation rule on crm.lead:
    trigger: on_stage_set
    filter: stage_id.name = 'Proposal Sent'
  → sets x_stale_monitor_start = today
  → stale deal monitoring begins for this lead
  → if lead is still in 'Proposal Sent' after configured days:
    stale deal monitor fires daily Teams alert
```

---

### Q6 — What happens when nothing occurs at a human pause?

**Silent Failure Design — Full Escalation System**

```python
# models/crm_lead.py — Daily Escalation Cron (08:00 AM)

def cron_check_human_pause_escalations(self):
    today = fields.Date.today()
    now   = fields.Datetime.now()

    # ── HP1 & HP3: Overdue email draft activities ─────────────
    overdue_drafts = self.env['mail.activity'].search([
        ('activity_type_id.name', 'in', ['Follow-up Email', 'Presale Email Draft']),
        ('date_deadline', '<', today),
        ('note', 'ilike', 'AI DRAFT'),
    ])
    for act in overdue_drafts:
        days_overdue = (today - act.date_deadline).days
        lead = self.env['crm.lead'].browse(act.res_id)
        rep  = act.user_id
        manager = rep.parent_id or rep

        if days_overdue == 1:
            self._send_n8n_teams_alert({
                'level': 'warning',
                'message': f"Follow-up draft for *{lead.partner_name}* is 1 day overdue.",
                'rep': rep.name,
                'link': f"/odoo/crm/{lead.id}",
                'channel': 'sales-alerts'
            })
        elif days_overdue == 2:
            self._send_n8n_teams_alert({
                'level': 'urgent',
                'message': f"Follow-up for *{lead.partner_name}* is 2 days overdue — unsent.",
                'manager': manager.name,
                'rep': rep.name,
                'channel': 'sales-manager-alerts'
            })
        elif days_overdue >= 3:
            lead.x_followup_missed = True
            lead.message_post(
                body=f"<b>Follow-up #{act.x_followup_sequence} was not sent.</b> "
                     f"Overdue by {days_overdue} days. Marked as missed.",
                subtype_xmlid='mail.mt_note'
            )
            # DO NOT unlink activity — rep can still send manually

    # ── HP2: Overdue MOM review ───────────────────────────────
    overdue_moms = self.env['mail.activity'].search([
        ('activity_type_id.name', '=', 'Client MOM Review'),
        ('date_deadline', '<', today),
    ])
    for act in overdue_moms:
        hours_since = (now - act.date_deadline).total_seconds() / 3600
        lead = self.env['crm.lead'].browse(act.res_id)

        if 4 <= hours_since < 24:
            self._send_n8n_teams_alert({
                'message': f"MOM not sent to client for lead: {lead.partner_name}",
                'channel': 'sales-alerts'
            })
        elif hours_since >= 24:
            if lead.user_id.x_allow_mom_auto_send:
                self._auto_send_mom(lead, act)  # Opt-in only
            else:
                self._send_n8n_teams_alert({
                    'level': 'urgent',
                    'message': f"MOM for {lead.partner_name} still not sent — 24hrs passed.",
                    'channel': 'sales-manager-alerts'
                })

    # ── HP4: WBS not validated ────────────────────────────────
    stale_wbs = self.env['project.task'].search([
        ('x_ticket_status', '=', 'ready_for_wbs'),
        ('write_date', '<', now - timedelta(days=2))
    ])
    for ticket in stale_wbs:
        days_waiting = (now - ticket.write_date).days
        if days_waiting == 2:
            self._send_n8n_teams_alert({'message': f"WBS pending review: {ticket.name}"})
        elif days_waiting == 4:
            self._send_n8n_teams_alert({
                'level': 'urgent',
                'message': f"WBS not validated in 4 days: {ticket.name}",
                'channel': 'presale-manager'
            })
        elif days_waiting >= 7:
            # Reset — something is wrong, needs investigation
            ticket.x_ticket_status = 'open'
            ticket.message_post(
                body="<b>WBS validation timed out (7 days).</b> "
                     "Ticket reset to Open. Click Re-Generate WBS to restart.",
                subtype_xmlid='mail.mt_note'
            )

    # ── HP6: Proposal not sent ────────────────────────────────
    # Handled by n8n W5 Stale Deal Monitor querying
    # GET /api/sales_ai/stale_deals which returns leads
    # stuck in 'Proposal Sent' stage beyond threshold days
```

**Blocked Items Dashboard — Manager View**

```python
# views/crm_lead_views.xml — Blocked Items list view

# View 1: Overdue Email Drafts
# Model: crm.lead (via mail.activity join)
# Domain: [
#   ('activity_ids.activity_type_id.name', 'in',
#    ['Follow-up Email', 'Client MOM Review', 'Presale Email Draft']),
#   ('activity_ids.date_deadline', '<', today)
# ]
# Group by: user_id (salesperson)
# Order by: days overdue DESC

# View 2: Stuck Tickets
# Model: project.task
# Domain: [
#   ('x_ticket_status', 'in', ['ready_for_wbs', 'ready_for_proposal']),
#   ('write_date', '<', (today - 3 days))
# ]
# Group by: user_id (presale member)
```

**What Does NOT Restart — Hard Boundaries**

- ❌ Automation does NOT re-draft follow-up emails if rep ignores them. Draft stays as-is.
- ❌ Automation does NOT re-generate WBS on its own after timeout. Rep must click Re-Generate.
- ❌ Automation does NOT re-send any client-facing email automatically (except HP2 MOM with opt-in).
- ❌ Lead dormant with no activity for 30 days: marked "Dormant" — not deleted. Quarterly cleanup by manager.

---

## Section 3 — Reducing Integration Complexity

### Q7 — Where can we reduce complexity and cut unnecessary n8n workflows?

| Reduction | Affects | How To Do It | Impact |
|-----------|---------|--------------|--------|
| Remove W6 from V1 | Prospect import (outbound) | Outbound is Phase 2. Remove entirely. One less Playwright session = less Apollo detection risk. | Medium |
| Collapse W1 + W7 into ONE Playwright run | Apollo Recording Fetch + Enrichment | After a meeting, one Playwright session extracts BOTH recording/transcript AND enrichment data in one login. Never run separately. | High |
| Replace W4 with Odoo native for most alerts | Teams Notifications (W4) | Presale agenda posts directly on ticket — Odoo notifies subscribers automatically. Use W4 only for cross-team/manager escalations. Removes ~60% of W4 volume. | High |
| WBS as ticket note first, Sheets only if needed | WBS Generator (W3) | Claude generates WBS as structured note on ticket. Only move to Sheets if multi-person collaborative editing is required. | Medium |
| Reduce Gmail Add-on to 2 features for V1 | Gmail Workspace Add-on | Reps send from Odoo UI. Add-on V1: Log email + Sidebar only. Skip Create Lead from Gmail. | Medium |

**The V1 Minimum Viable n8n Set — Start With Only These 4**

✅ **W7** — Apollo Data Scraper (Playwright enrichment) — critical path, blocks entire data pipeline
✅ **W1 merged into W7** — Apollo Recording Fetch done in the SAME Playwright session as enrichment after meetings
✅ **W8** — Proposal Generator (Google Drive template in/out) — needed at end of funnel
✅ **W4** — Teams Notifications — but ONLY for manager-level escalations, not daily agenda

❌ Defer W2 (Presale MOM Splitter) to Week 3 — presale team manually posts MOMs initially
❌ Defer W3 (WBS to Sheets) to Week 3 — Claude posts WBS as ticket note first
❌ Skip W5 (Stale Deal Monitor) until pilot — implement stale check directly in Odoo instead
❌ Skip W6 (Prospect Import) until Phase 2

---

### Q8 — How do we use n8n most effectively?

**The Golden Rule**

> n8n = Data Transport Only. Odoo = Business Logic Owner. Claude = Intelligence Layer.

**n8n SHOULD DO — External I/O Only**

- ✅ Playwright sessions into Apollo (login, extract, logout)
- ✅ Read/write to Google Sheets (WBS collaboration)
- ✅ Read/write to Google Drive (proposal templates, generated proposals)
- ✅ POST to Teams webhooks (push notifications)
- ✅ Receive webhooks from Odoo and call external APIs
- ✅ Pass raw data back to Odoo via JSON-RPC — nothing more

**n8n Should NOT DO — Keep in Odoo**

- ❌ Claude API calls — all AI calls go through Odoo `claude.service` model
- ❌ Business logic decisions — which lead gets scored, who gets the email, which ticket
- ❌ Activity creation — Odoo creates and manages all `mail.activity` records
- ❌ Pipeline stage transitions — always driven by Odoo automation rules or manual rep actions
- ❌ Email sending — always from Odoo via Gmail OAuth. Never send client emails from n8n.

**Why This Boundary Matters**

If business logic lives in n8n and n8n goes down, your entire sales pipeline breaks. If business logic stays in Odoo, n8n going down only affects external data fetches. The Odoo pipeline keeps running — reps can still send follow-ups, manage leads, and track deals without n8n. n8n failure = degraded experience, not total outage.

---

### Q9 — When exactly should each n8n workflow trigger?

| # | Workflow | What Triggers It | Trigger Method | Timing | What n8n Does | What Restarts in Odoo |
|---|---------|-----------------|----------------|--------|---------------|----------------------|
| W1 | Apollo Recording Fetch | `calendar.event` completed + `opportunity_id` linked | Odoo automation rule → n8n webhook | 10 min after meeting end | Playwright logs in, finds recording by email + timestamp, extracts transcript, POSTs to `/api/sales_ai/receive_transcript` | Client MOM generation triggered |
| W2 | Presale MOM Splitter | `calendar.event` with `x_is_presale_meeting=True` completed | Odoo automation rule → n8n webhook | 20 min after meeting end | Fetch presale recording, send transcript + ticket IDs to Claude, split by ticket cues, POST each MOM to correct ticket | Presale email draft created on lead |
| W3 | WBS Generator | `x_ticket_status` changes to `ready_for_wbs` | Odoo automation rule → n8n webhook | Immediate | Pull ticket data, invoke WBS Skill (Claude Sonnet), write to Google Sheet, return Sheet URL to Odoo | Tech team notified to add estimates |
| W4 | Teams Notifications | Various Odoo events (escalations, retro done) | Odoo server action calls n8n webhook | Real-time | Receive payload, format Teams card, POST to Teams webhook | Human receives notification |
| W5 | Stale Deal Monitor | Daily schedule | 08:00 AM cron in n8n | Daily 08:00 | GET `/api/sales_ai/stale_deals`, format Teams alert per stale lead | Manager/rep notified to act |
| W7 | Apollo Data Scraper | Genuine lead created in Odoo | Odoo webhook → n8n (queued, batch every 10 min) | Batch every 10 min | Playwright logs in, search by contact email, extract enrichment data, POST to `/api/sales_ai/receive_apollo_data` | Enrichment + scoring runs automatically |
| W8 | Proposal Generator | "Request Proposal" button click on ticket | Odoo server action → n8n webhook | Immediate | Fetch template from Drive, fetch WBS from Sheets, call Claude Opus, write proposal back to Drive, POST Drive URL to Odoo | Proposal link on ticket, Teams notification to rep |

> **Critical Playwright batching rule:** Never trigger Playwright more than once per Apollo session per hour. Use a 10-minute collect queue in n8n — if 5 leads come in within 10 minutes, run ONE Playwright session for all 5, not 5 separate sessions.

---

## Section 4 — Multi-Flow Integration & Technical Workflows

### Q10 — Full Technical Workflow: Lead Created to First Email

```
TRIGGER: Email arrives at sales@company.com (Gmail alias)
═══════════════════════════════════════════════════════════

1. ODOO MAIL GATEWAY
   Gmail IMAP (OAuth 2.0 via google_gmail module)
   → fetches email every 5 minutes
   → mail.thread.message_process() called
   → mail_smart_link module intercepts:

   2. MAIL SMART LINK CHECK
      Extract sender email from message headers
      Search res.partner by email
      │
      Partner exists AND has active lead?
      ├── YES → message_post to EXISTING lead (no duplicate)
      └── NO  → default: create new crm.lead

   3. NEW LEAD CREATED
      crm.lead record created with:
        name = email subject
        email_from = sender email
        description = email body
        source_id = (from UTM if web form)

4. JUNK FILTER (automated action on lead create)
   ─────────────────────────────────────────────
   claude.service.call(
     tier='haiku',
     system=PROMPTS['junk_filter_system'],
     user_message=f"""
       Email From: {lead.email_from}
       Subject: {lead.name}
       Body: {lead.description[:500]}
       Source: {lead.source_id.name}
     """
   )
   Response: "GENUINE" / "MARKETING" / "JUNK"

   GENUINE → x_lead_quality = 'genuine' → continue
   JUNK/MARKETING → reassign to marketing_user_id → STOP

5. APOLLO ENRICHMENT REQUEST
   ──────────────────────────
   Odoo fires webhook to n8n W7:
   POST {n8n_base_url}/webhook/enrich_lead
   Headers: { X-N8N-Secret: token }
   Body: {
     lead_id: 142,
     email: "john@acme.com",
     company: "Acme Corp",
     domain: "acme.com"
   }

   n8n W7 (Apollo Data Scraper):
   ┌────────────────────────────────────────────────┐
   │ Playwright script:                              │
   │ 1. Load stored Apollo session cookies           │
   │ 2. If session expired: login with credentials  │
   │ 3. Navigate to Apollo people search            │
   │ 4. Search by email: john@acme.com              │
   │ 5. Extract contact page data:                  │
   │    - apollo_contact_id (from URL)              │
   │    - job_title, seniority, linkedin_url        │
   │    - is_decision_maker                         │
   │ 6. Navigate to company page                    │
   │ 7. Extract company data:                       │
   │    - employee_count, annual_revenue            │
   │    - tech_stack[], funding_stage               │
   │    - is_it_company                             │
   │ 8. Save/update session cookies                 │
   │ 9. Return raw JSON                             │
   └────────────────────────────────────────────────┘

   n8n POSTs to Odoo:
   POST /api/sales_ai/receive_apollo_data
   Body: { lead_id: 142, apollo_data: { ...raw } }

6. ENRICHMENT STRUCTURING (Odoo webhook handler)
   ───────────────────────────────────────────────
   claude.service.call(
     tier='haiku',
     system=PROMPTS['enrichment_system'],
     user_message=f"Structure this Apollo data: {apollo_raw_json}",
     expect_json=True
   )
   → Writes 16 custom fields to crm.lead
   → Sets x_enrichment_done = True
   → Calls action_run_lead_scoring()

7. LEAD SCORING
   ─────────────
   ICP criteria fetched from ir.config_parameter
   (filled by sales team in module settings)

   claude.service.call(
     tier='haiku',
     system=PROMPTS['lead_scoring_system'],
     user_message=f"""
       ICP Criteria: {icp_json}
       Lead Data:
         industry: {lead.x_industry}
         employee_count: {lead.x_employee_count}
         seniority: {lead.x_seniority}
         is_decision_maker: {lead.x_is_decision_maker}
         is_it_company: {lead.x_is_it_company}
         tech_stack: {lead.x_tech_stack}
     """,
     expect_json=True
   )
   Response: { score: 78, band: "warm", reasoning: "..." }

   → Sets x_lead_score = 78
   → Sets x_lead_score_band = 'warm'
   → Logs reasoning to chatter (internal note)

8. LEAD ASSIGNMENT (Odoo native)
   ──────────────────────────────
   base_automation rule: round-robin or territory
   → sets lead.user_id = assigned_rep

9. AUTO-ACK EMAIL (triggered by assignment)
   ─────────────────────────────────────────
   Automation rule on user_id field change:
   → gets assigned rep's x_calendar_link
   → claude.service.call(
       tier='sonnet',
       system=PROMPTS['auto_ack_system'],
       user_message=f"""
         Contact: {lead.contact_name} at {lead.partner_name}
         Industry: {lead.x_industry}
         Inquiry: {lead.description}
         Rep calendar link: {rep.x_calendar_link}
       """,
       expect_json=True
     )
   → lead.message_post(
       body=result['body_html'],
       subject=result['subject'],
       message_type='email',
       subtype_xmlid='mail.mt_comment'
     )

10. FOLLOW-UP ACTIVITIES CREATED
    ──────────────────────────────
    Based on x_lead_score_band:
      warm (40-80): Day 2, Day 5, Day 10
      hot (>80):    Day 1, Day 3, Day 7
      cold (<40):   Day 3, Day 7, Day 14

    Weekend skip: if date.weekday() >= 5 → next Monday

    Creates 3 mail.activity records:
      type: "Follow-up Email"
      user_id: lead.user_id
      x_followup_sequence: 1, 2, 3
      note: "AI draft will be generated before due date."

    ═══ LEAD IS NOW IN PIPELINE ═══
    Rep sees 3 scheduled activities in "My Activities"
    9 AM cron will fill drafts before each due date
```

---

### Q11 — Full Technical Workflow: Meeting Recorded to Client MOM

```
TRIGGER: Client meeting ends (Apollo records it)
═══════════════════════════════════════════════════════════

1. CALENDAR EVENT DETECTION
   ──────────────────────────
   Odoo automation rule on calendar.event:
     trigger: on_write
     filter: date_stop < now  (meeting just ended)
     AND opportunity_id != False  (linked to lead)
     AND x_is_presale_meeting = False  (client meeting)

   Fires webhook to n8n W1:
   POST {n8n_base_url}/webhook/meeting_ended
   Body: {
     event_id: 55,
     lead_id: 142,
     end_time: "2026-03-14T12:00:00Z",
     attendee_emails: ["john@acme.com", "sarah@ourco.com"],
     start_time: "2026-03-14T11:00:00Z"
   }

2. n8n W1 — APOLLO RECORDING FETCH (Playwright)
   ───────────────────────────────────────────────
   Wait 10 minutes (Apollo processing time)
   Then Playwright:
   ┌────────────────────────────────────────────────┐
   │ 1. Load Apollo session (reuse from W7 if fresh)│
   │ 2. Navigate to Recordings section              │
   │ 3. Filter by date: today                       │
   │ 4. Find recording by:                          │
   │    - start_time match ±15 min                  │
   │    - attendee email match                      │
   │ 5. Open recording page                         │
   │ 6. Extract:                                    │
   │    - transcript_text (full text)               │
   │    - recording_url                             │
   │    - attendees list with emails                │
   │    - duration                                  │
   └────────────────────────────────────────────────┘

3. RECORDING MATCHED TO LEAD
   ──────────────────────────
   Run matching decision tree (Q2 above)
   Lead found → POST to Odoo:
   POST /api/sales_ai/receive_transcript
   Headers: { X-N8N-Secret: token }
   Body: {
     lead_id: 142,
     transcript: "John: Thanks for joining... Sarah: ...",
     recording_url: "https://app.apollo.io/recordings/...",
     meeting_type: "client"
   }

4. ODOO WEBHOOK HANDLER
   ──────────────────────
   @http.route('/api/sales_ai/receive_transcript', auth='none', methods=['POST'])
   def receive_transcript(self, **kwargs):
     # Validate secret token
     # Find lead
     # Call MOM generation

5. CLIENT MOM GENERATION
   ──────────────────────
   claude.service.call(
     tier='sonnet',
     system=PROMPTS['client_mom_system'],
     user_message=transcript_text,
     max_tokens=3000,
     expect_json=True
   )
   Response: {
     full_mom_html: "...",
     client_email_subject: "Meeting Summary — Acme Corp | 14 Mar",
     client_email_body_html: "..."
   }

6. OUTPUTS (two parallel)
   ──────────────────────
   OUTPUT A: Full MOM → lead chatter (internal)
     lead.message_post(
       body=result['full_mom_html'],
       message_type='comment',
       subtype_xmlid='mail.mt_note'
     )

   OUTPUT B: Draft email → mail.activity on LEAD
     self.env['mail.activity'].create({
       'res_model': 'crm.lead',
       'res_id': lead.id,
       'activity_type_id': mom_review_type.id,
       'user_id': lead.user_id.id,  ← the rep who attended
       'date_deadline': fields.Date.today(),
       'note': result['client_email_subject'] + '\n\n' +
               result['client_email_body_html']
     })

   ═══ HUMAN PAUSE #2 BEGINS ═══
   Rep sees "Client MOM Review" activity in "My Activities"
   Reviews draft → edits → sends from Odoo
   Activity marked done → pipeline continues
```

---

### Q12 — Full Technical Workflow: Presale Ticket to Proposal

```
TRIGGER: Rep creates presale ticket in Odoo Projects
═══════════════════════════════════════════════════════════

1. PRESALE TICKET CREATION
   ─────────────────────────
   Rep creates project.task in "Presale" project
   Sets x_linked_lead_id = lead (142)

   Override project.task.create():
   → detects x_linked_lead_id is set
   → calls action_generate_ticket_gist()

2. TICKET GIST GENERATION
   ─────────────────────────
   Fetch ALL messages from linked lead:
     lead.message_ids.filtered(
       lambda m: m.message_type in ['email', 'comment']
     )[:50]  ← last 50 messages

   claude.service.call(
     tier='sonnet',
     system=PROMPTS['ticket_gist_system'],
     user_message=formatted_messages,
     max_tokens=2000
   )
   → post as first note on ticket
   → subscribe lead owner to ticket

3. DAILY PRESALE AGENDA (10:30 AM cron)
   ──────────────────────────────────────
   Find all open tickets:
     x_ticket_status in ['open','ready_for_wbs','wbs_done']

   For EACH ticket:
     messages_since = ticket.message_ids.filtered(
       lambda m: m.date > (ticket.x_last_agenda_date or now - 48h)
     )
     claude.service.call(
       tier='haiku',
       system=PROMPTS['presale_agenda_system'],
       user_message=formatted_recent_activity
     )
     → ticket.message_post(body=agenda_html, subtype='mail.mt_note')
     → ticket.x_last_agenda_date = today
     ← Odoo auto-notifies ALL ticket subscribers

4. PRESALE MEETING → MOM SPLIT (n8n W2)
   ──────────────────────────────────────
   [Same Playwright flow as client MOM]
   But: meeting_type = 'presale'
   n8n W2 receives: transcript + ticket_id_list [101, 102]

   Claude call in n8n W2:
   {
     model: 'claude-sonnet-4-6',
     system: "Split this transcript by ticket number...",
     user: transcript + JSON.stringify(ticket_ids)
   }
   Response: {
     "101": "<mom HTML for ticket 101>",
     "102": "<mom HTML for ticket 102>"
   }

   n8n POSTs each section:
   POST /api/sales_ai/presale_mom_posted
   Body: { ticket_id: 101, mom_content: "<html>..." }

   Odoo handler:
   → posts MOM to ticket 101 (internal note)
   → calls action_generate_presale_client_email(ticket_id=101)

5. PRESALE CLIENT EMAIL DRAFT
   ─────────────────────────────
   lead = ticket.x_linked_lead_id
   recent_client_emails = lead.message_ids.filtered(
     lambda m: m.message_type == 'email'
               and m.author_id not in internal_users
   )[:10]

   claude.service.call(
     tier='sonnet',
     system=PROMPTS['presale_email_system'],
     user_message=f"""
       Presale MOM: {mom_content}
       Recent client conversation: {formatted_emails}
     """,
     expect_json=True
   )
   → create mail.activity ON THE LEAD (not the ticket):
     type: "Presale Email Draft"
     user_id: lead.user_id
     note: subject + body_html

   ═══ HUMAN PAUSE #3 BEGINS ═══
   Rep sees draft in "My Activities" on the LEAD
   (same view as follow-up drafts — single workflow)

6. WBS GENERATION
   ─────────────────
   Presale sets ticket x_ticket_status = 'ready_for_wbs'

   Automation rule fires webhook to n8n W3:
   POST {n8n_base_url}/webhook/generate_wbs
   Body: {
     ticket_id: 101,
     ticket_name: "Acme Corp — ERP Implementation",
     description: ticket.description,
     gist: ticket first note (the gist generated in step 2),
     mom_notes: all ticket notes formatted
   }

   n8n W3:
   ┌────────────────────────────────────────────────┐
   │ 1. Call Claude Sonnet (WBS Skill):             │
   │    Prompt includes WBS template format          │
   │    + sample WBS examples from past projects     │
   │    + all ticket context                         │
   │                                                 │
   │ 2. Parse JSON response: array of WBS rows       │
   │                                                 │
   │ 3. Create new Google Sheet via Sheets API       │
   │    Tab 1: WBS (rows from Claude)               │
   │    Tab 2: Notes (assumptions)                   │
   │                                                 │
   │ 4. Name revision "AI Generated" via:            │
   │    sheets.revisions.list() → latest             │
   │    (Note: Sheets API doesn't support            │
   │    custom revision names directly —             │
   │    use a dedicated "Version" row in Sheet       │
   │    with timestamp instead)                      │
   │                                                 │
   │ 5. Add Sheet URL to ticket:                     │
   │    POST /api/sales_ai/wbs_ready                │
   │    { ticket_id: 101, sheet_url: "..." }         │
   │                                                 │
   │ 6. Notify tech team via Teams W4                │
   └────────────────────────────────────────────────┘

   ═══ HUMAN PAUSE #4 BEGINS ═══
   Presale reviews Sheet → modifies → sets wbs_done in Odoo
   Tech team adds hours estimates in Sheet
   Automation rule detects wbs_done → notifies tech team

7. PROPOSAL GENERATION
   ──────────────────────
   Presale clicks "Request Proposal from AI" button
   (visible only when x_ticket_status = 'wbs_done')

   Server action:
   def action_request_proposal_from_ai(self):
     self.x_ticket_status = 'ready_for_proposal'
     import requests
     requests.post(
       f"{n8n_base_url}/webhook/proposal_request",
       json={
         'ticket_id': self.id,
         'lead_id': self.x_linked_lead_id.id,
         'wbs_sheet_url': self.x_wbs_sheet_url,
       },
       headers={'X-N8N-Secret': secret},
       timeout=10
     ).raise_for_status()

   n8n W8:
   ┌────────────────────────────────────────────────┐
   │ 1. Fetch proposal template from Google Drive   │
   │    (template maintained by presale team)       │
   │    drive.files.export() as HTML/text           │
   │                                                │
   │ 2. Fetch WBS data from Google Sheet            │
   │    sheets.values.get() → all rows              │
   │    Calculate totals: hours × rates             │
   │                                                │
   │ 3. Call Claude Opus:                           │
   │    model: claude-opus-4-6                      │
   │    system: PROMPTS['proposal_system']          │
   │    user: template_structure + wbs_data         │
   │           + lead context + ticket MOMs         │
   │    max_tokens: 4000                            │
   │                                                │
   │ 4. Parse response: {                           │
   │      scope_of_work_html,                      │
   │      project_team_html,                        │
   │      investment_html                           │
   │    }                                           │
   │                                                │
   │ 5. Create new Google Doc from template         │
   │    drive.files.copy() → new doc                │
   │    Replace placeholder sections with Claude   │
   │    generated content via Docs API             │
   │    docs.documents.batchUpdate()               │
   │                                                │
   │ 6. POST Drive URL back to Odoo:               │
   │    POST /api/sales_ai/proposal_ready          │
   │    { ticket_id: 101, proposal_drive_url: "..." }│
   └────────────────────────────────────────────────┘

   Odoo sets:
     ticket.x_proposal_drive_url = url
     ticket.x_ticket_status = 'proposal_generated'
   Teams notification to rep:
     "Proposal ready for Acme Corp — [Drive link]"

   ═══ HUMAN PAUSE #6 BEGINS ═══
   Rep reviews proposal in Drive → customizes →
   sends from Odoo → changes stage to "Proposal Sent"
```

---

### Q13 — Full Technical Workflow: Won/Lost → Retrospective

```
TRIGGER: Rep changes lead stage to Won or Lost
═══════════════════════════════════════════════════════════

1. AUTOMATION RULE (base_automation)
   ────────────────────────────────────
   model: crm.lead
   trigger: on_stage_set
   filter: stage_id.is_won = True OR stage_id.name = 'Lost'
   action: call action_generate_closure_retro()

2. HISTORY COLLECTION
   ─────────────────────
   def action_generate_closure_retro(self):
     # All emails
     emails = self.message_ids.filtered(
       lambda m: m.message_type == 'email'
     ).sorted('date')

     email_history = []
     for msg in emails:
       email_history.append(
         f"[{msg.date}] {'SENT' if msg.author_id in internal_users else 'RECEIVED'}\n"
         f"FROM: {msg.email_from}\n"
         f"SUBJECT: {msg.subject}\n"
         f"BODY: {msg.body[:500]}...\n---"
       )

     # Stage history (from mail.tracking.value)
     stage_history = self.env['mail.tracking.value'].search([
       ('mail_message_id.res_id', '=', self.id),
       ('field', '=', 'stage_id')
     ]).sorted('mail_message_id.date')

     # Presale ticket notes
     ticket_notes = ""
     if self.x_presale_ticket_id:
       ticket_msgs = self.x_presale_ticket_id.message_ids.filtered(
         lambda m: m.message_type == 'comment'
       )
       ticket_notes = "\n".join([m.body[:300] for m in ticket_msgs[:20]])

     # Response time analysis
     response_times = self._calculate_response_times(emails)

     full_history = f"""
     DEAL OUTCOME: {'Won' if self.stage_id.is_won else 'Lost'}
     TOTAL DURATION: {(fields.Date.today() - self.create_date.date()).days} days
     LEAD VALUE: {self.expected_revenue}
     STAGE HISTORY: {json.dumps(stage_history_formatted)}

     EMAIL HISTORY:
     {chr(10).join(email_history)}

     RESPONSE TIME ANALYSIS:
     {json.dumps(response_times)}

     PRESALE TICKET DISCUSSIONS:
     {ticket_notes}
     """

     # Truncate if > 150k chars (Sonnet handles 200k context)
     if len(full_history) > 150000:
       full_history = full_history[:150000] + "\n[TRUNCATED]"

3. RETRO GENERATION
   ──────────────────
   claude.service.call(
     tier='sonnet',
     system=PROMPTS['retro_system'],
     user_message=full_history,
     max_tokens=3000
   )

4. RETRO POSTING
   ───────────────
   # Post to ticket (visible to whole team)
   if self.x_presale_ticket_id:
     self.x_presale_ticket_id.message_post(
       body=retro_html,
       message_type='comment',
       subtype_xmlid='mail.mt_note'
     )
     self.x_presale_ticket_id.x_retro_logged = True
   else:
     # Fallback: post to lead
     self.message_post(
       body=retro_html,
       message_type='comment',
       subtype_xmlid='mail.mt_note'
     )

   # Teams notification via n8n W4
   self._send_n8n_teams_alert({
     'message': f"Deal retro posted: {self.partner_name} — {'Won' if won else 'Lost'}",
     'channel': 'sales-retros'
   })
```

---

## Section 5 — AI Model Selection

### Q14 — What is the right Claude model for each flow?

| Task | Model | Why | Est Cost/Call |
|------|-------|-----|--------------|
| Junk filter, enrichment structuring, reply classification, email thread matching, presale agenda | Haiku 4.5 | Simple classification + structured extraction. High volume = cheapest model. | ~$0.003–0.02 |
| Auto-ack emails, follow-up drafts, presale email drafts, client MOM, ticket gist, discussion sync, retro | Sonnet 4.6 | Needs writing quality and contextual understanding. Default for most tasks. | ~$0.03–0.08 |
| Proposal generation only | Opus 4.6 | Highest quality. Client-facing document. Low volume (one per deal). Justified by deal value. | ~$0.30 |

**Cost control principle:** Never call Sonnet or Opus for classification tasks. Never call Opus for summarization. Haiku handles everything with a defined output schema. Sonnet handles everything needing natural language output. Opus handles only proposals.

**Monthly Cost Estimate (10 reps, ~200 leads/month)**

| Category | Monthly |
|----------|---------|
| Haiku tasks (junk, enrich, score, classify) | ~$10–18 |
| Sonnet tasks (ack, follow-ups, MOMs, gists, emails, retros) | ~$55–80 |
| Opus tasks (proposals only) | ~$15–30 |
| **Total** | **~$80–128/mo** |

---

## Section 6 — Implementation Priority

### Q15 — What should be built first?

**Phase 1 — Core Pipeline (Weeks 1–3, Go-Live Minimum)**

- ✅ Module skeleton + all custom fields (`crm.lead`, `project.task`, `res.users`)
- ✅ Claude service class + prompt library (all prompts written, no logic yet)
- ✅ Junk filter (first real Claude call — validates API connectivity)
- ✅ Lead scoring with ICP criteria (sales team fills form before Go-Live)
- ✅ Auto-ack email + follow-up scheduling (requires rep calendar links pre-populated)
- ✅ 9 AM follow-up drafter cron + reply-aware timing reset (`message_post` override)
- ✅ n8n W7 — Playwright Apollo enrichment (run PoC first before writing integration code)

**Phase 2 — Presale Layer (Weeks 4–6)**

- ✅ Meeting-Lead Auto-Linker (calendar event to lead link — no AI needed)
- ✅ Client MOM generation (n8n W1 + Odoo webhook controller)
- ✅ Presale ticket gist + discussion sync (`message_post` override extension)
- ✅ Daily presale agenda 10:30 AM cron
- ✅ Presale email drafter + n8n W2 (MOM splitter)
- ✅ `mail_smart_link` module (build last — most risk of conflicts)

**Phase 3 — Proposal + Retro (Weeks 7–8)**

- ✅ Request Proposal button + n8n W8 (Google Drive in/out)
- ✅ Lead closure retrospective (automation rule on Won/Lost)
- ✅ Stale deal monitor endpoint + n8n W5
- ✅ Blocked Items dashboard view for managers
- ✅ Gmail Workspace Add-on (can run in parallel from Week 3)

**3 Pre-Conditions That Must Be Ready BEFORE Dev Starts**

> ⚠️ **Playwright + Apollo PoC** — build and validate before writing ANY enrichment code. Highest-risk dependency in the entire system. If this fails, the data pipeline has no primary source.

> ⚠️ **Sales team fills ICP criteria JSON** — lead scoring returns a neutral 50 until this is done. Hard-block Go-Live on this item.

> ⚠️ **All reps enter calendar booking links in Odoo profiles** — auto-ack emails have a broken CTA without `x_calendar_link` populated. Block Go-Live on this too.

---

## Appendix — Odoo Webhook Controller (Full Spec)

```python
# controllers/webhook_controller.py

import json
import logging
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)

class SalesAIWebhookController(http.Controller):

    def _validate_secret(self):
        """Validate n8n secret token from request header."""
        expected = request.env['ir.config_parameter'].sudo().get_param(
            'sales_ai.n8n_secret_token'
        )
        received = request.httprequest.headers.get('X-N8N-Secret')
        if received != expected:
            return False
        return True

    @http.route('/api/sales_ai/receive_apollo_data',
                auth='none', methods=['POST'], csrf=False, type='json')
    def receive_apollo_data(self, **kwargs):
        if not self._validate_secret():
            return {'error': 'Unauthorized'}, 401
        data     = json.loads(request.httprequest.data)
        lead_id  = data.get('lead_id')
        raw_data = data.get('apollo_data', {})
        lead = request.env['crm.lead'].sudo().browse(lead_id)
        if not lead.exists():
            return {'error': 'Lead not found'}
        lead.action_receive_apollo_data(json.dumps(raw_data))
        return {'status': 'ok', 'lead_id': lead_id}

    @http.route('/api/sales_ai/receive_transcript',
                auth='none', methods=['POST'], csrf=False, type='json')
    def receive_transcript(self, **kwargs):
        if not self._validate_secret():
            return {'error': 'Unauthorized'}, 401
        data         = json.loads(request.httprequest.data)
        lead_id      = data.get('lead_id')
        transcript   = data.get('transcript')
        meeting_type = data.get('meeting_type', 'client')
        lead = request.env['crm.lead'].sudo().browse(lead_id)
        if not lead.exists():
            return {'error': 'Lead not found'}
        if meeting_type == 'client':
            lead.action_generate_client_mom(transcript)
        return {'status': 'ok'}

    @http.route('/api/sales_ai/presale_mom_posted',
                auth='none', methods=['POST'], csrf=False, type='json')
    def presale_mom_posted(self, **kwargs):
        if not self._validate_secret():
            return {'error': 'Unauthorized'}, 401
        data      = json.loads(request.httprequest.data)
        ticket_id = data.get('ticket_id')
        mom       = data.get('mom_content')
        ticket = request.env['project.task'].sudo().browse(ticket_id)
        if not ticket.exists():
            return {'error': 'Ticket not found'}
        # Post MOM to ticket (internal)
        ticket.message_post(body=mom, message_type='comment',
                            subtype_xmlid='mail.mt_note')
        # Generate presale client email draft on linked lead
        ticket.action_generate_presale_client_email(mom_content=mom)
        return {'status': 'ok'}

    @http.route('/api/sales_ai/wbs_ready',
                auth='none', methods=['POST'], csrf=False, type='json')
    def wbs_ready(self, **kwargs):
        if not self._validate_secret():
            return {'error': 'Unauthorized'}, 401
        data      = json.loads(request.httprequest.data)
        ticket_id = data.get('ticket_id')
        sheet_url = data.get('sheet_url')
        ticket = request.env['project.task'].sudo().browse(ticket_id)
        if not ticket.exists():
            return {'error': 'Ticket not found'}
        ticket.x_wbs_sheet_url   = sheet_url
        ticket.x_ticket_status   = 'ready_for_wbs'
        ticket.message_post(
            body=f'WBS generated. <a href="{sheet_url}">Open Google Sheet</a>',
            message_type='comment', subtype_xmlid='mail.mt_note'
        )
        return {'status': 'ok'}

    @http.route('/api/sales_ai/proposal_ready',
                auth='none', methods=['POST'], csrf=False, type='json')
    def proposal_ready(self, **kwargs):
        if not self._validate_secret():
            return {'error': 'Unauthorized'}, 401
        data      = json.loads(request.httprequest.data)
        ticket_id = data.get('ticket_id')
        drive_url = data.get('proposal_drive_url')
        ticket = request.env['project.task'].sudo().browse(ticket_id)
        if not ticket.exists():
            return {'error': 'Ticket not found'}
        ticket.x_proposal_drive_url = drive_url
        ticket.x_ticket_status      = 'proposal_generated'
        ticket.message_post(
            body=f'Proposal ready. <a href="{drive_url}">Open in Google Drive</a>',
            message_type='comment', subtype_xmlid='mail.mt_note'
        )
        return {'status': 'ok'}

    @http.route('/api/sales_ai/stale_deals',
                auth='none', methods=['GET'], csrf=False, type='json')
    def stale_deals(self, **kwargs):
        if not self._validate_secret():
            return {'error': 'Unauthorized'}, 401
        from datetime import timedelta
        import json
        thresholds_json = request.env['ir.config_parameter'].sudo().get_param(
            'sales_ai.stale_thresholds_json', '{}'
        )
        thresholds = json.loads(thresholds_json)
        # Example: {"Qualified": 5, "Meeting": 7, "Proposal": 10}
        stale_leads = []
        for stage_name, days in thresholds.items():
            cutoff = fields.Datetime.now() - timedelta(days=days)
            leads  = request.env['crm.lead'].sudo().search([
                ['stage_id.name', '=', stage_name],
                ['date_last_stage_update', '<', cutoff],
                ['active', '=', True]
            ])
            for lead in leads:
                days_stuck = (fields.Datetime.now() -
                              lead.date_last_stage_update).days
                stale_leads.append({
                    'lead_id':     lead.id,
                    'lead_name':   lead.name,
                    'stage':       stage_name,
                    'salesperson': lead.user_id.name,
                    'email':       lead.user_id.email,
                    'days_stuck':  days_stuck,
                    'link':        f"/odoo/crm/{lead.id}"
                })
        return {'stale_deals': stale_leads}
```

---

*End of Document — Inbound Sales Automation Architecture Q&A + Technical Workflows | March 2026*

---

## Section 7 — CEO Morning Meeting Briefing

### What We Are Building

Automating the full inbound sales pipeline — lead intake to proposal — using Odoo 19 CE + Claude AI + n8n. 10 reps. Target cost ~$100/month in AI. No Enterprise license needed.

---

### 3 Decisions That Need Sign-Off

**1. Apollo via Playwright (scraping, not API)**
Apollo has zero API support for recordings, conversations, or enrichment. Our only option is browser automation — Playwright logs into Apollo and extracts data. This technically violates Apollo's ToS. We have accepted the risk because there is no alternative without switching platforms. Leadership needs to be aware and aligned on this before dev starts.

**2. Build everything in-house**
No third-party AI add-ons. The team builds the entire Claude integration as a custom Odoo module. This keeps costs low but puts build responsibility internally. Timeline: 8 weeks to full pipeline live.

**3. Pilot first, then scale**
One sales team goes live first. Full rollout after 30-day pilot validation. Need a call on which team pilots.

---

### The 5 Real Business Challenges

**1. Apollo Playwright is the single biggest risk**
If Apollo changes their UI, every selector breaks — enrichment stops, MOM generation stops, lead scoring degrades. No fallback exists today. Need a contingency (Clearbit or Hunter.io as backup enrichment) before Go-Live.

**2. Three things block Go-Live that are not technical**
- Sales team must fill the ICP scoring criteria form — lead scoring is useless without it
- Every rep must enter their Calendly link in Odoo — auto-ack email CTA is broken without it
- Pre-sale team must confirm proposal templates are on Google Drive and formatted for AI

None of these are dev work. They are all on the business side and need a hard deadline set now.

**3. Human discipline is required for the system to work**
The AI drafts everything but humans must review and send. If reps ignore "My Activities," the pipeline silently dies. Escalation logic exists (Day 1 Teams ping → Day 2 manager alert → Day 3 flag) but the culture of checking Activities daily must be enforced from the top.

**4. Presale meeting discipline — verbal cue convention**
For the AI to split presale meeting recordings correctly, the team must say "Moving to ticket 12345" every time they switch topics. And they must pre-fill ticket IDs on the calendar event before the meeting. This is a process change, not a tech change. Needs team training and enforcement.

**5. The system has no value until enrichment works**
Lead scoring, auto-ack personalization, and follow-up drafting all depend on enriched lead data from Apollo. If Playwright PoC fails or is unreliable, the intelligence layer is broken from step one. This PoC must be completed and validated before a single line of Odoo module code is written.

---

### What Is Needed Before Dev Starts

| Ask | Why |
|-----|-----|
| Apollo ToS risk — confirmed accepted | Cannot proceed without this alignment |
| Name the pilot team | Blocks team setup and Go-Live planning |
| Set deadline for ICP form + calendar links | Hard dependency before Go-Live |
| Confirm pre-sale owns proposal templates on Drive | Blocks proposal generation entirely |
| Budget sign-off: ~$100/mo Claude API | Ongoing operational cost |

> **One number to remember: 8 weeks to full pipeline. Week 1 is Apollo PoC only. If that fails, the timeline moves.**

---

## Section 8 — Where Claude Is Actually Needed

This is the definitive map of every Claude call in the system — what triggers it, what it reads, what it returns, which model, and whether it runs in Odoo or n8n.

```
LEAD COMES IN
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #1 — Junk Filter                                     │
│ Trigger:  Odoo automation rule on lead create               │
│ Reads:    email_from, subject, body, source                 │
│ Returns:  GENUINE / JUNK / MARKETING                        │
│ Model:    Haiku 4.5                                         │
│ Runs in:  Odoo (no n8n needed)                             │
└─────────────────────────────────────────────────────────────┘
      │
      ▼ (only if GENUINE)
      │
      ├── Odoo fires webhook → n8n W7
      │   n8n Playwright scrapes Apollo
      │   n8n POSTs raw JSON back to Odoo
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #2 — Enrichment Structuring                          │
│ Trigger:  Odoo webhook handler receives Apollo data         │
│ Reads:    Raw Apollo JSON (company + contact data)          │
│ Returns:  30 structured fields as JSON                      │
│ Model:    Haiku 4.5                                         │
│ Runs in:  Odoo (n8n only delivers the raw data)            │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #3 — Lead Scoring                                    │
│ Trigger:  Immediately after enrichment completes            │
│ Reads:    Enriched lead fields + ICP criteria JSON          │
│ Returns:  score 0-100, band hot/warm/cold, reasoning        │
│ Model:    Haiku 4.5                                         │
│ Runs in:  Odoo (no n8n needed)                             │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   Lead assigned to rep (Odoo native assignment rules)
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #4 — Auto-Ack Email                                  │
│ Trigger:  Odoo automation rule on user_id assignment        │
│ Reads:    Inquiry content, industry, rep calendar link      │
│ Returns:  Personalized subject + body HTML                  │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  Odoo (sends email directly via Gmail OAuth)       │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   Follow-up activities created Day 2/5/10 (Odoo native)
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #5 — Follow-up Email Drafts                          │
│ Trigger:  Odoo scheduled action daily at 9 AM              │
│ Reads:    Lead context, prior emails, follow-up #, tone     │
│ Returns:  Full email draft (subject + body)                 │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  Odoo (draft saved in activity note)              │
│ Human:    Rep reviews + sends from My Activities            │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   Client replies → Odoo detects via message_post override
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #6 — Reply Intent Classification                     │
│ Trigger:  message_post override on crm.lead (incoming only)│
│ Reads:    Reply email body (first 1000 chars)               │
│ Returns:  INTERESTED / NOT_INTERESTED / OOO / REFERRAL      │
│ Model:    Haiku 4.5                                         │
│ Runs in:  Odoo (reschedules or cancels follow-ups)         │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   Meeting happens → Apollo records
   n8n W1 Playwright fetches transcript
   n8n POSTs to /api/sales_ai/receive_transcript
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #7 — Client MOM Generation                           │
│ Trigger:  Odoo webhook handler receives transcript          │
│ Reads:    Full meeting transcript                           │
│ Returns:  Full MOM + client-safe email draft                │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  Odoo (MOM to chatter, draft to activity)         │
│ Human:    Rep reviews draft → sends (HP2)                   │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   Rep creates presale ticket in Odoo, links to lead
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #8 — Ticket Gist                                     │
│ Trigger:  project.task create override (x_linked_lead set) │
│ Reads:    Last 50 messages from linked lead                 │
│ Returns:  Structured summary for presale team               │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  Odoo (posted as first note on ticket)            │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #9 — Discussion Sync (Financial Strip)               │
│ Trigger:  message_post override on crm.lead (every email)  │
│ Reads:    New email/discussion content                      │
│ Returns:  Cleaned summary with financial data removed       │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  Odoo (cleaned version posted to presale ticket)  │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #10 — Daily Presale Agenda                           │
│ Trigger:  Odoo scheduled action daily at 10:30 AM          │
│ Reads:    Recent ticket activity, customer replies, queries │
│ Returns:  Agenda per ticket (who answers what)              │
│ Model:    Haiku 4.5                                         │
│ Runs in:  Odoo (posted directly on each ticket)            │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   Presale meeting → Playwright fetches recording
   n8n W2 gets transcript + ticket ID list
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #11 — Presale MOM Split              ← IN n8n       │
│ Trigger:  n8n W2 receives presale recording                 │
│ Reads:    Full transcript + known ticket IDs                │
│ Returns:  { ticket_101: mom, ticket_102: mom }              │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  n8n W2 (ONLY Claude call not in Odoo)            │
│ Note:     n8n POSTs each MOM back to Odoo per ticket        │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #12 — Presale Client Email Draft                     │
│ Trigger:  Odoo callback from n8n after MOM posted          │
│ Reads:    Presale MOM + client conversation history         │
│ Returns:  Draft client-facing email                         │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  Odoo (draft created as activity ON THE LEAD)     │
│ Human:    Rep reviews draft → sends (HP3)                   │
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   WBS generated → human validates → ticket = wbs_done
   "Request Proposal" button → Odoo fires webhook → n8n W8
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #13 — Proposal Generation           ← IN n8n        │
│ Trigger:  n8n W8 receives proposal request webhook          │
│ Reads:    Drive template + WBS data + lead context          │
│ Returns:  Scope section + team section + financial section  │
│ Model:    Opus 4.6                                          │
│ Runs in:  n8n W8 (second Claude call not in Odoo)          │
│ Note:     n8n writes completed proposal back to Google Drive│
└─────────────────────────────────────────────────────────────┘
      │
      ▼
   Lead → Won or Lost
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│ CLAUDE #14 — Closure Retrospective                          │
│ Trigger:  Odoo automation rule on Won/Lost stage change     │
│ Reads:    Full lead history, emails, ticket notes, timeline │
│ Returns:  Structured retrospective with learnings           │
│ Model:    Sonnet 4.6                                        │
│ Runs in:  Odoo (posted to presale ticket, not lead)        │
└─────────────────────────────────────────────────────────────┘
```

---

## Section 9 — Odoo ↔ n8n Exact Connection Points

There are only **8 connection points** total. 5 Odoo→n8n, 3 n8n→Odoo.

### Odoo → n8n (Odoo fires, n8n acts)

```
CONNECTION 1 — Enrichment Request
──────────────────────────────────────────────────────────────
When:    Genuine lead created (x_lead_quality = 'genuine')
Odoo:    Automation rule fires server action
Fires:   POST {n8n_base}/webhook/enrich_lead
Payload: { lead_id, email, company, domain }
n8n:     Playwright scrapes Apollo contact + company page
Returns: Raw Apollo JSON to CONNECTION 6

CONNECTION 2 — Client Meeting Ended
──────────────────────────────────────────────────────────────
When:    calendar.event.date_stop < now
         AND opportunity_id is set
         AND x_is_presale_meeting = False
Odoo:    Automation rule on calendar.event write
Fires:   POST {n8n_base}/webhook/meeting_ended
Payload: { event_id, lead_id, end_time, attendee_emails }
n8n:     Waits 10 min, Playwright fetches Apollo recording
Returns: Transcript to CONNECTION 7

CONNECTION 3 — Presale Meeting Ended
──────────────────────────────────────────────────────────────
When:    calendar.event.date_stop < now
         AND x_is_presale_meeting = True
Odoo:    Automation rule on calendar.event write
Fires:   POST {n8n_base}/webhook/presale_meeting_ended
Payload: { event_id, ticket_ids[], end_time }
n8n:     Playwright fetches recording, Claude #11 splits MOM
Returns: Per-ticket MOM to CONNECTION 8 (one POST per ticket)

CONNECTION 4 — WBS Requested
──────────────────────────────────────────────────────────────
When:    project.task x_ticket_status changes to 'ready_for_wbs'
Odoo:    Automation rule on project.task write
Fires:   POST {n8n_base}/webhook/generate_wbs
Payload: { ticket_id, ticket_name, description, gist, moms }
n8n:     Claude generates WBS, writes to Google Sheet
Returns: Sheet URL to Odoo via /api/sales_ai/wbs_ready

CONNECTION 5 — Proposal Requested
──────────────────────────────────────────────────────────────
When:    "Request Proposal from AI" button clicked on ticket
Odoo:    Server action fires on button click
Fires:   POST {n8n_base}/webhook/proposal_request
Payload: { ticket_id, lead_id, wbs_sheet_url }
n8n:     Fetches Drive template + WBS, Claude #13 generates
Returns: Drive URL to Odoo via /api/sales_ai/proposal_ready
```

### n8n → Odoo (n8n calls back, Odoo acts)

```
CONNECTION 6 — Enrichment Data Delivered
──────────────────────────────────────────────────────────────
Endpoint: POST /api/sales_ai/receive_apollo_data
Payload:  { lead_id, apollo_data: { ...raw } }
Odoo:     Claude #2 structures data → Claude #3 scores lead
Auth:     X-N8N-Secret header validated

CONNECTION 7 — Transcript Delivered
──────────────────────────────────────────────────────────────
Endpoint: POST /api/sales_ai/receive_transcript
Payload:  { lead_id, transcript, meeting_type: 'client' }
Odoo:     Claude #7 generates MOM → draft activity created
Auth:     X-N8N-Secret header validated

CONNECTION 8 — Presale MOM Delivered (per ticket)
──────────────────────────────────────────────────────────────
Endpoint: POST /api/sales_ai/presale_mom_posted
Payload:  { ticket_id, mom_content }
Odoo:     Posts MOM to ticket → Claude #12 drafts client email
Auth:     X-N8N-Secret header validated
Note:     n8n calls this once per ticket in a loop
```

---

## Section 10 — The 5 Actual Workflow Challenges

These are not Apollo challenges. These are the integration and code-level challenges that will cause bugs or broken pipelines during development.

---

### Challenge 1 — The message_post Override Does Too Much

The single `message_post` override on `crm.lead` has to handle three things in sequence:

1. Reply intent classification (Claude #6)
2. Follow-up reschedule logic
3. Discussion sync to presale ticket (Claude #9)

**The Problem**

If any one step fails or is slow, it blocks the entire email thread from being saved to Odoo. One bad Claude API call means the rep's incoming email disappears from chatter. This is a critical reliability issue.

**The Wrong Way**

```python
def message_post(self, **kwargs):
    # Step 1
    intent = self.env['claude.service'].call('haiku', ...)  # can fail
    # Step 2
    self._reschedule_followups(intent)                      # can fail
    # Step 3
    self._sync_to_ticket(kwargs.get('body'))                # can fail
    return super().message_post(**kwargs)                   # BLOCKED if anything above fails
```

**The Right Way**

```python
def message_post(self, **kwargs):
    # Always save the message first — never block this
    result = super().message_post(**kwargs)

    # AI processing runs after, independently
    # Each step wrapped separately — one failure does not affect others
    msg = self.env['mail.message'].browse(result.id if hasattr(result, 'id') else result)
    is_inbound = (
        msg.message_type == 'email' and
        msg.author_id not in self.env['res.users'].search([['share','=',False]])
    )

    if is_inbound and msg.in_reply_to:  # Only classify genuine replies
        try:
            self._classify_reply_intent(msg.body)
        except Exception as e:
            _logger.warning("Reply intent classification failed: %s", e)

        try:
            self._reschedule_followups()
        except Exception as e:
            _logger.warning("Follow-up reschedule failed: %s", e)

    if is_inbound and self.x_presale_ticket_id:
        try:
            self._sync_discussion_to_ticket(msg.body)
        except Exception as e:
            _logger.warning("Discussion sync failed: %s", e)

    return result
```

**Key rule:** Call `super().message_post()` first always. Every AI step after it is wrapped in independent `try/except`. One Claude failure never blocks email threading.

---

### Challenge 2 — Claude #11 Lives in n8n, Not Odoo

The presale MOM split (Claude #11) is the only Claude call that runs inside n8n instead of the Odoo app. This breaks the "all Claude calls through Odoo" architecture rule.

**The Problem**

- API key exists in two places (Odoo settings and n8n credentials)
- Prompt maintenance is split — presale MOM prompt lives in n8n, everything else in `prompts.py`
- If the prompt needs updating, someone updates n8n, not the codebase

**Current state (acceptable for V1)**

```
n8n W2 calls Claude directly:
POST https://api.anthropic.com/v1/messages
{ model: 'claude-sonnet-4-6', messages: [...] }
```

**Target state (move to Odoo in Phase 2)**

```
n8n W2 POSTs raw transcript to Odoo:
POST /api/sales_ai/split_presale_mom
{ transcript, ticket_ids: [101, 102] }

Odoo runs Claude #11 internally
Returns: { 101: mom_html, 102: mom_html }

n8n receives result and posts to each ticket
```

This keeps all prompt logic, API keys, and model selection inside the Odoo module. n8n becomes pure data transport with zero AI logic.

---

### Challenge 3 — Enrichment Chain is Sequential and Fragile

Claude #2 (enrichment structuring) and Claude #3 (scoring) must run in order. If Playwright returns partial Apollo data (company found, contact not found), Claude #2 fills what it can with partial data. Claude #3 then scores on incomplete enrichment.

**The Problem Flow**

```
Playwright scrapes Apollo
  → Contact page: 404 (contact not found in Apollo)
  → Company page: found (employee count, tech stack)

Claude #2 receives: partial data
  → x_employee_count: 500 ✓
  → x_seniority: null ✗
  → x_is_decision_maker: null ✗
  → x_tech_stack: ['Python', 'AWS'] ✓

Claude #3 scores with missing fields
  → scores 45 (warm) instead of 75 (hot)
  → rep gets wrong follow-up timing
  → auto-ack email is less personalized
```

**Solution: Enrichment Confidence Flag**

```python
def action_receive_apollo_data(self, apollo_raw_json):
    # Structure data
    result = self.env['claude.service'].call(
        'haiku', PROMPTS['enrichment_system'],
        apollo_raw_json, expect_json=True
    )

    # Count how many critical fields got filled
    critical_fields = [
        'x_seniority', 'x_is_decision_maker', 'x_employee_count',
        'x_is_it_company', 'x_tech_stack'
    ]
    filled = sum(1 for f in critical_fields if result.get(f.replace('x_','')) not in [None, '', []])
    confidence = int((filled / len(critical_fields)) * 100)

    self.x_enrichment_confidence = confidence

    if confidence < 60:
        self.message_post(
            body=f"<b>Low enrichment confidence ({confidence}%).</b> "
                 f"Apollo data was partial. Score may be inaccurate. "
                 f"Consider manual enrichment.",
            subtype_xmlid='mail.mt_note'
        )

    # Score anyway but tag it
    self.action_run_lead_scoring()
```

Rep sees the confidence warning in chatter. Lead gets scored but tagged as low-confidence. Rep knows to verify before prioritizing.

---

### Challenge 4 — Context Size for Retrospective (Claude #14)

The retro needs the full lead history — potentially 6 months of emails, ticket notes, MOM documents, stage changes. Long deals with lots of back-and-forth can easily exceed practical context limits and get expensive.

**The Problem**

```
Long deal example:
  80 emails × 500 chars avg  = 40,000 chars
  20 ticket notes × 800 chars = 16,000 chars
  Stage history               =  2,000 chars
  MOM documents (3×)          = 12,000 chars
  Total                       = 70,000 chars
                              = ~18,000 tokens
                              = fine for Sonnet

But large deals:
  200 emails, 50 ticket notes, 5 MOMs
  Total can exceed 150,000 chars → expensive
  and risks degraded output quality
```

**Solution: Two-Pass Summarization**

```python
def action_generate_closure_retro(self):
    emails = self.message_ids.filtered(
        lambda m: m.message_type == 'email'
    ).sorted('date')

    # Pass 1: Summarize by month using Haiku (cheap)
    monthly_chunks = self._group_emails_by_month(emails)
    monthly_summaries = []
    for month, msgs in monthly_chunks.items():
        raw = "\n".join([f"[{m.date}] {m.subject}: {m.body[:300]}" for m in msgs])
        summary = self.env['claude.service'].call(
            'haiku',
            "Summarize these emails in 5-8 bullet points. Key facts only.",
            raw
        )
        monthly_summaries.append(f"=== {month} ===\n{summary}")

    # Pass 2: Full retro using Sonnet with summaries (not raw emails)
    condensed_history = "\n\n".join(monthly_summaries)
    retro = self.env['claude.service'].call(
        'sonnet',
        PROMPTS['retro_system'],
        condensed_history,
        max_tokens=3000
    )

    # Post retro to ticket
    self._post_retro(retro)
```

Pass 1 costs ~$0.005 total (Haiku summaries). Pass 2 costs ~$0.08 (Sonnet retro on summaries). Total is cheaper than one Sonnet call on raw history, and the output quality is better because Claude gets structured summaries not a wall of raw email text.

---

### Challenge 5 — The Two Overrides Conflict

`mail_smart_link` overrides `message_new` on `crm.lead`.
The reply handler overrides `message_post` on `crm.lead`.
Both fire when an email comes in.

**The Problem Flow**

```
Unknown customer sends NEW email to sales@
  │
  ▼
mail_smart_link.message_new fires
  → finds existing partner
  → routes to existing lead
  → calls message_post on that lead
  │
  ▼
message_post override fires
  → detects incoming email
  → tries to classify as reply intent
  → calls Claude #6 with "INTERESTED / OOO / etc."
  → BUT this is a first-contact email, not a reply
  → wrong intent classification
  → may reschedule follow-ups incorrectly
```

**The Fix: Check In-Reply-To Header**

```python
def message_post(self, **kwargs):
    result = super().message_post(**kwargs)

    msg = self.env['mail.message'].browse(result.id if hasattr(result,'id') else result)

    # Only run reply intent on genuine replies
    # A genuine reply has an In-Reply-To or References header
    # A new email routed by mail_smart_link has neither
    is_inbound = (
        msg.message_type == 'email' and
        msg.author_id.id not in self._get_internal_user_ids()
    )
    is_genuine_reply = bool(
        msg.in_reply_to or                    # Has In-Reply-To header
        kwargs.get('in_reply_to_message_id')  # Or explicit threading
    )

    if is_inbound and is_genuine_reply:
        try:
            self._classify_reply_intent(msg.body)
            self._reschedule_followups()
        except Exception as e:
            _logger.warning("Reply handling failed: %s", e)

    # Discussion sync runs for ALL inbound (replies AND new)
    if is_inbound and self.x_presale_ticket_id:
        try:
            self._sync_discussion_to_ticket(msg.body)
        except Exception as e:
            _logger.warning("Discussion sync failed: %s", e)

    return result
```

**Rule:** Reply intent classification only runs when `in_reply_to` is present. Discussion sync runs for all inbound emails regardless. The two behaviors are now separated by a clear condition.

---

## Section 11 — Challenge Summary Table

| # | Challenge | Where It Breaks | Severity | Fix |
|---|-----------|----------------|----------|-----|
| 1 | message_post override does too much | Any AI failure blocks email threading | 🔴 Critical | Call super() first, wrap each step in independent try/except |
| 2 | Claude #11 lives in n8n not Odoo | API key split, prompt maintenance split | 🟡 Medium | Move to Odoo endpoint in Phase 2 |
| 3 | Enrichment chain is fragile on partial Apollo data | Wrong lead score, wrong follow-up timing | 🟠 High | Add x_enrichment_confidence field, warn rep if below 60% |
| 4 | Retrospective context size on long deals | Expensive, degraded quality | 🟡 Medium | Two-pass: Haiku monthly summaries → Sonnet retro |
| 5 | Two message_post overrides conflict | First-contact email misclassified as reply | 🟠 High | Check In-Reply-To header before running reply intent |

---

*End of Document — Inbound Sales Automation Full Architecture, Q&A, Technical Workflows & Challenges | March 2026*