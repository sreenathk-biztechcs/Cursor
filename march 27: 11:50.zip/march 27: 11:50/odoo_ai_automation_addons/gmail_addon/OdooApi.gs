/**
 * OdooApi.gs — JSON-RPC wrapper for Odoo communication.
 *
 * All calls go through odooExecute() which handles authentication,
 * session management, and error handling.
 */

var SESSION_CACHE_KEY = "odoo_session_id";
var SESSION_TTL_SECONDS = 3600;

/**
 * Authenticate with Odoo and cache the session ID.
 * @returns {string|null} session_id or null on failure
 */
function odooAuthenticate() {
  var creds = getOdooCredentials();
  if (!creds.url || !creds.username || !creds.password) {
    return null;
  }

  var cache = CacheService.getUserCache();
  var cached = cache.get(SESSION_CACHE_KEY);
  if (cached) {
    return cached;
  }

  var db = creds.db || "";
  if (!db) {
    try {
      var dbResp = UrlFetchApp.fetch(creds.url + "/jsonrpc", {
        method: "post",
        contentType: "application/json",
        payload: JSON.stringify({
          jsonrpc: "2.0",
          method: "call",
          params: { service: "db", method: "list", args: [] },
          id: 1
        }),
        muteHttpExceptions: true
      });
      var dbData = JSON.parse(dbResp.getContentText());
      if (dbData.result && dbData.result.length > 0) {
        db = dbData.result[0];
      }
    } catch (e) {
      Logger.log("DB list failed: " + e);
    }
  }

  try {
    var resp = UrlFetchApp.fetch(creds.url + "/jsonrpc", {
      method: "post",
      contentType: "application/json",
      payload: JSON.stringify({
        jsonrpc: "2.0",
        method: "call",
        params: {
          service: "common",
          method: "authenticate",
          args: [db, creds.username, creds.password, {}]
        },
        id: 2
      }),
      muteHttpExceptions: true
    });

    var data = JSON.parse(resp.getContentText());
    var uid = data.result;
    if (!uid || uid === false) {
      Logger.log("Authentication failed: invalid credentials");
      return null;
    }

    var sessionHeaders = resp.getHeaders();
    var cookies = sessionHeaders["Set-Cookie"] || "";
    var sessionMatch = cookies.match(/session_id=([^;]+)/);
    var sessionId = sessionMatch ? sessionMatch[1] : String(uid);

    cache.put(SESSION_CACHE_KEY, sessionId, SESSION_TTL_SECONDS);
    PropertiesService.getUserProperties().setProperty("odoo_uid", String(uid));
    PropertiesService.getUserProperties().setProperty("odoo_db", db);

    return sessionId;
  } catch (e) {
    Logger.log("Odoo auth error: " + e);
    return null;
  }
}

/**
 * Execute an Odoo JSON-RPC call.
 * @param {string} model   - Odoo model name (e.g. "crm.lead")
 * @param {string} method  - Method name (e.g. "search_read")
 * @param {Array}  args    - Positional arguments
 * @param {Object} kwargs  - Keyword arguments (optional)
 * @returns {*} The result from Odoo, or null on error
 */
function odooExecute(model, method, args, kwargs) {
  var creds = getOdooCredentials();
  if (!creds.url) return null;

  var sessionId = odooAuthenticate();
  if (!sessionId) return null;

  var props = PropertiesService.getUserProperties();
  var db = props.getProperty("odoo_db") || "";
  var uid = parseInt(props.getProperty("odoo_uid") || "0", 10);

  if (!uid) return null;

  kwargs = kwargs || {};

  try {
    var resp = UrlFetchApp.fetch(creds.url + "/jsonrpc", {
      method: "post",
      contentType: "application/json",
      headers: {
        "Cookie": "session_id=" + sessionId
      },
      payload: JSON.stringify({
        jsonrpc: "2.0",
        method: "call",
        params: {
          service: "object",
          method: "execute_kw",
          args: [db, uid, creds.password, model, method, args, kwargs]
        },
        id: 3
      }),
      muteHttpExceptions: true
    });

    var data = JSON.parse(resp.getContentText());
    if (data.error) {
      Logger.log("Odoo RPC error: " + JSON.stringify(data.error));
      if (data.error.data && data.error.data.message &&
          data.error.data.message.indexOf("Session") >= 0) {
        CacheService.getUserCache().remove(SESSION_CACHE_KEY);
      }
      return null;
    }

    return data.result;
  } catch (e) {
    Logger.log("Odoo execute error: " + e);
    return null;
  }
}

/**
 * Test the Odoo connection by reading the current user.
 * @returns {boolean}
 */
function testOdooConnection() {
  CacheService.getUserCache().remove(SESSION_CACHE_KEY);
  var sessionId = odooAuthenticate();
  if (!sessionId) return false;

  var props = PropertiesService.getUserProperties();
  var uid = parseInt(props.getProperty("odoo_uid") || "0", 10);
  if (!uid) return false;

  var user = odooExecute("res.users", "read", [[uid]], { fields: ["name", "email"] });
  return !!(user && user.length > 0);
}
