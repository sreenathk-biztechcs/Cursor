/**
 * DuplicateCheck.gs — RFC 2822 Message-ID based duplicate detection.
 *
 * Prevents the same email from being logged to a lead more than once.
 * Uses UserProperties to persist a map of {lead_id: [message_id, ...]}.
 */

var PROP_LOGGED_EMAILS = "logged_email_ids";
var MAX_STORED_IDS_PER_LEAD = 200;

/**
 * Check if an email with the given Message-ID header has already been
 * logged to the specified lead.
 *
 * @param {number} leadId
 * @param {string} messageIdHeader - RFC 2822 Message-ID (e.g. "<abc@mail.gmail.com>")
 * @returns {boolean}
 */
function isDuplicateEmail(leadId, messageIdHeader) {
  if (!messageIdHeader) return false;

  var map = _getLoggedMap();
  var key = String(leadId);
  var list = map[key] || [];

  return list.indexOf(messageIdHeader) >= 0;
}

/**
 * Mark an email as logged to a lead.
 *
 * @param {number} leadId
 * @param {string} messageIdHeader
 */
function markEmailLogged(leadId, messageIdHeader) {
  if (!messageIdHeader) return;

  var map = _getLoggedMap();
  var key = String(leadId);

  if (!map[key]) {
    map[key] = [];
  }

  if (map[key].indexOf(messageIdHeader) < 0) {
    map[key].push(messageIdHeader);
    if (map[key].length > MAX_STORED_IDS_PER_LEAD) {
      map[key] = map[key].slice(-MAX_STORED_IDS_PER_LEAD);
    }
  }

  _saveLoggedMap(map);
}

function _getLoggedMap() {
  var raw = PropertiesService.getUserProperties().getProperty(PROP_LOGGED_EMAILS);
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch (e) {
    return {};
  }
}

function _saveLoggedMap(map) {
  var json = JSON.stringify(map);
  if (json.length > 8000) {
    var keys = Object.keys(map);
    while (json.length > 8000 && keys.length > 0) {
      delete map[keys.shift()];
      json = JSON.stringify(map);
    }
  }
  PropertiesService.getUserProperties().setProperty(PROP_LOGGED_EMAILS, json);
}
