/**
 * Settings.gs — Credential storage and settings card for the Odoo CRM sidebar.
 *
 * Uses PropertiesService.getUserProperties() to persist per-user credentials
 * so each rep can connect to their own Odoo instance.
 */

var PROP_ODOO_URL = "odoo_url";
var PROP_ODOO_USERNAME = "odoo_username";
var PROP_ODOO_PASSWORD = "odoo_password";
var PROP_ODOO_DB = "odoo_db_name";

function getOdooCredentials() {
  var props = PropertiesService.getUserProperties();
  return {
    url: (props.getProperty(PROP_ODOO_URL) || "").replace(/\/+$/, ""),
    username: props.getProperty(PROP_ODOO_USERNAME) || "",
    password: props.getProperty(PROP_ODOO_PASSWORD) || "",
    db: props.getProperty(PROP_ODOO_DB) || ""
  };
}

function buildSettingsCard(warningMessage) {
  var creds = getOdooCredentials();

  var section = CardService.newCardSection().setHeader("Odoo Connection Settings");

  if (warningMessage) {
    section.addWidget(
      CardService.newTextParagraph().setText("⚠ " + warningMessage)
    );
  }

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("odooUrl")
      .setTitle("Odoo URL")
      .setHint("e.g. https://your-company.odoo.com")
      .setValue(creds.url)
  );

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("odooUsername")
      .setTitle("Username / Email")
      .setValue(creds.username)
  );

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("odooPassword")
      .setTitle("Password or API Key")
      .setValue(creds.password ? "••••••••" : "")
  );

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("odooDb")
      .setTitle("Database (leave blank for auto-detect)")
      .setValue(creds.db)
  );

  section.addWidget(
    CardService.newTextButton()
      .setText("Save & Test Connection")
      .setOnClickAction(
        CardService.newAction().setFunctionName("actionSaveSettings")
      )
  );

  return CardService.newCardBuilder()
    .setHeader(CardService.newCardHeader().setTitle("Odoo CRM Settings"))
    .addSection(section)
    .build();
}

function showSettingsCard(e) {
  var card = buildSettingsCard();
  return CardService.newActionResponseBuilder()
    .setNavigation(CardService.newNavigation().pushCard(card))
    .build();
}

function actionSaveSettings(e) {
  var formInputs = e.formInputs || e.commonEventObject.formInputs || {};

  function getVal(name) {
    var field = formInputs[name];
    if (!field) return "";
    if (field.stringInputs) return field.stringInputs.value[0] || "";
    return String(field);
  }

  var url = getVal("odooUrl").replace(/\/+$/, "");
  var username = getVal("odooUsername");
  var password = getVal("odooPassword");
  var db = getVal("odooDb");

  if (password === "••••••••") {
    password = getOdooCredentials().password;
  }

  if (!url || !username || !password) {
    return CardService.newActionResponseBuilder()
      .setNotification(
        CardService.newNotification().setText("URL, username, and password are required.")
      )
      .build();
  }

  var props = PropertiesService.getUserProperties();
  props.setProperty(PROP_ODOO_URL, url);
  props.setProperty(PROP_ODOO_USERNAME, username);
  props.setProperty(PROP_ODOO_PASSWORD, password);
  if (db) {
    props.setProperty(PROP_ODOO_DB, db);
  }

  CacheService.getUserCache().remove(SESSION_CACHE_KEY);

  var ok = testOdooConnection();
  var msg = ok ? "Connected to Odoo successfully!" : "Connection failed. Check your credentials.";

  return CardService.newActionResponseBuilder()
    .setNotification(CardService.newNotification().setText(msg))
    .build();
}
