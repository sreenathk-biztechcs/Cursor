/**
 * Cards.gs — CardService UI builders for the Gmail sidebar.
 */

function buildErrorCard(message) {
  return CardService.newCardBuilder()
    .setHeader(CardService.newCardHeader().setTitle("Error"))
    .addSection(
      CardService.newCardSection().addWidget(
        CardService.newTextParagraph().setText(message)
      )
    )
    .build();
}

function buildHomepageCard() {
  var creds = getOdooCredentials();
  var section = CardService.newCardSection()
    .addWidget(CardService.newTextParagraph().setText(
      "Connected to: " + creds.url
    ))
    .addWidget(CardService.newTextParagraph().setText(
      "User: " + creds.username
    ));

  var connected = testOdooConnection();
  section.addWidget(CardService.newTextParagraph().setText(
    connected ? "✓ Connection OK" : "✗ Connection failed — check settings"
  ));

  section.addWidget(
    CardService.newTextButton()
      .setText("Change Settings")
      .setOnClickAction(
        CardService.newAction().setFunctionName("showSettingsCard")
      )
  );

  return CardService.newCardBuilder()
    .setHeader(CardService.newCardHeader().setTitle("Odoo CRM"))
    .addSection(section)
    .build();
}

/**
 * Contextual card shown when a Gmail message is opened.
 * Searches Odoo for the sender and shows linked CRM data.
 */
function buildContextualCard(fromEmail, subject, gmailMsgId, messageIdHeader, referencesHeader, inReplyToHeader) {
  var card = CardService.newCardBuilder()
    .setHeader(CardService.newCardHeader()
      .setTitle("Odoo CRM")
      .setSubtitle(fromEmail));

  // --- Partner search ---
  var partners = odooExecute("res.partner", "search_read",
    [[["email", "ilike", fromEmail]]],
    { fields: ["id", "name", "email", "phone", "company_type"], limit: 5 }
  );

  var partnerSection = CardService.newCardSection().setHeader("Contact");
  if (partners && partners.length > 0) {
    var p = partners[0];
    partnerSection.addWidget(CardService.newTextParagraph().setText(
      "<b>" + p.name + "</b>" +
      (p.phone ? "\n📞 " + p.phone : "") +
      "\n✉ " + (p.email || fromEmail)
    ));
  } else {
    partnerSection.addWidget(CardService.newTextParagraph().setText(
      "No contact found for " + fromEmail
    ));
  }
  card.addSection(partnerSection);

  // --- Lead search ---
  var leads = odooExecute("crm.lead", "search_read",
    [["|", ["email_from", "ilike", fromEmail], ["partner_id.email", "ilike", fromEmail]]],
    {
      fields: ["id", "name", "stage_id", "user_id", "create_date", "expected_revenue"],
      limit: 5,
      order: "create_date desc"
    }
  );

  var leadSection = CardService.newCardSection().setHeader("Leads / Opportunities");
  if (leads && leads.length > 0) {
    for (var i = 0; i < leads.length; i++) {
      var lead = leads[i];
      var stageName = lead.stage_id ? lead.stage_id[1] : "No stage";
      var repName = lead.user_id ? lead.user_id[1] : "Unassigned";
      leadSection.addWidget(CardService.newDecoratedText()
        .setText(lead.name)
        .setBottomLabel(stageName + " • " + repName)
      );
    }
  } else {
    leadSection.addWidget(CardService.newTextParagraph().setText("No leads found."));
  }
  card.addSection(leadSection);

  // --- Actions ---
  var actionSection = CardService.newCardSection().setHeader("Actions");

  if (leads && leads.length > 0) {
    actionSection.addWidget(
      CardService.newTextButton()
        .setText("Log Email to Lead")
        .setOnClickAction(
          CardService.newAction()
            .setFunctionName("showLogEmailForm")
            .setParameters({
              gmailMsgId: gmailMsgId,
              messageIdHeader: messageIdHeader || "",
              referencesHeader: referencesHeader || "",
              inReplyToHeader: inReplyToHeader || "",
              fromEmail: fromEmail,
              subject: subject,
              leadsJson: JSON.stringify(leads.map(function(l) {
                return { id: l.id, name: l.name };
              }))
            })
        )
    );
  }

  actionSection.addWidget(
    CardService.newTextButton()
      .setText("Create New Lead")
      .setOnClickAction(
        CardService.newAction()
          .setFunctionName("showCreateLeadForm")
          .setParameters({
            gmailMsgId: gmailMsgId,
            messageIdHeader: messageIdHeader || "",
            referencesHeader: referencesHeader || "",
            inReplyToHeader: inReplyToHeader || "",
            fromEmail: fromEmail,
            subject: subject
          })
      )
  );

  card.addSection(actionSection);
  return card.build();
}

// --- Log Email to Lead ---

function showLogEmailForm(e) {
  var params = e.parameters;
  var leads = JSON.parse(params.leadsJson || "[]");

  var section = CardService.newCardSection().setHeader("Log Email to Lead");

  var dropdown = CardService.newSelectionInput()
    .setType(CardService.SelectionInputType.DROPDOWN)
    .setFieldName("selectedLeadId")
    .setTitle("Select Lead");

  for (var i = 0; i < leads.length; i++) {
    dropdown.addItem(leads[i].name, String(leads[i].id), i === 0);
  }
  section.addWidget(dropdown);

  section.addWidget(
    CardService.newTextButton()
      .setText("Log Email")
      .setOnClickAction(
        CardService.newAction()
          .setFunctionName("actionLogEmail")
          .setParameters({
            gmailMsgId: params.gmailMsgId,
            messageIdHeader: params.messageIdHeader,
            referencesHeader: params.referencesHeader || "",
            inReplyToHeader: params.inReplyToHeader || "",
            fromEmail: params.fromEmail,
            subject: params.subject
          })
      )
  );

  return CardService.newCardBuilder()
    .setHeader(CardService.newCardHeader().setTitle("Log Email"))
    .addSection(section)
    .build();
}

function actionLogEmail(e) {
  var params = e.parameters;
  var formInputs = e.formInputs || e.commonEventObject.formInputs || {};
  var leadId = parseInt(
    (formInputs.selectedLeadId && formInputs.selectedLeadId.stringInputs
      ? formInputs.selectedLeadId.stringInputs.value[0]
      : formInputs.selectedLeadId) || "0",
    10
  );

  if (!leadId) {
    return buildNotificationResponse("Please select a lead.");
  }

  var msgIdHeader = params.messageIdHeader || "";
  if (msgIdHeader && isDuplicateEmail(leadId, msgIdHeader)) {
    return buildNotificationResponse("This email was already logged to this lead.");
  }

  var message = GmailApp.getMessageById(params.gmailMsgId);
  var body = message ? sanitizeHtml(message.getBody()) : "(no body)";

  var noteBody = "<b>Email logged from Gmail</b><br/>" +
    "<b>From:</b> " + params.fromEmail + "<br/>" +
    "<b>Subject:</b> " + params.subject + "<br/>" +
    (msgIdHeader ? "<b>Message-ID:</b> " + msgIdHeader + "<br/>" : "") +
    "<hr/>" + body;

  var postKwargs = {
    body: noteBody,
    message_type: "email",
    subtype_xmlid: "mail.mt_comment",
    email_from: params.fromEmail,
    subject: params.subject
  };
  // Pass RFC 2822 Message-ID so Odoo can track it for thread continuity
  if (msgIdHeader) {
    postKwargs.message_id = msgIdHeader;
  }
  var result = odooExecute("crm.lead", "message_post", [[leadId]], postKwargs);

  if (result) {
    if (msgIdHeader) {
      markEmailLogged(leadId, msgIdHeader);
    }
    return buildNotificationResponse("Email logged successfully!");
  }
  return buildNotificationResponse("Failed to log email. Check connection.");
}

// --- Create Lead from Email ---

function showCreateLeadForm(e) {
  var params = e.parameters;

  var section = CardService.newCardSection().setHeader("Create New Lead");

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("leadName")
      .setTitle("Lead Name")
      .setValue(params.subject || "")
  );

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("contactName")
      .setTitle("Contact Name")
  );

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("contactEmail")
      .setTitle("Contact Email")
      .setValue(params.fromEmail || "")
  );

  section.addWidget(
    CardService.newTextInput()
      .setFieldName("companyName")
      .setTitle("Company Name")
  );

  section.addWidget(
    CardService.newTextButton()
      .setText("Create Lead")
      .setOnClickAction(
        CardService.newAction()
          .setFunctionName("actionCreateLead")
          .setParameters({
            gmailMsgId: params.gmailMsgId,
            messageIdHeader: params.messageIdHeader,
            referencesHeader: params.referencesHeader || "",
            inReplyToHeader: params.inReplyToHeader || ""
          })
      )
  );

  return CardService.newCardBuilder()
    .setHeader(CardService.newCardHeader().setTitle("New Lead"))
    .addSection(section)
    .build();
}

function actionCreateLead(e) {
  var params = e.parameters;
  var formInputs = e.formInputs || e.commonEventObject.formInputs || {};

  function getFieldValue(name) {
    var field = formInputs[name];
    if (!field) return "";
    if (field.stringInputs) return field.stringInputs.value[0] || "";
    return String(field);
  }

  var leadName = getFieldValue("leadName");
  var contactName = getFieldValue("contactName");
  var contactEmail = getFieldValue("contactEmail");
  var companyName = getFieldValue("companyName");

  if (!leadName) {
    return buildNotificationResponse("Lead name is required.");
  }

  var vals = {
    name: leadName,
    contact_name: contactName,
    email_from: contactEmail,
    partner_name: companyName,
    type: "lead"
  };

  var leadId = odooExecute("crm.lead", "create", [vals]);
  if (!leadId) {
    return buildNotificationResponse("Failed to create lead.");
  }

  var message = GmailApp.getMessageById(params.gmailMsgId);
  if (message) {
    var body = sanitizeHtml(message.getBody());
    var noteBody = "<b>Email logged from Gmail (on create)</b><br/>" +
      "<b>From:</b> " + contactEmail + "<br/>" +
      "<b>Subject:</b> " + leadName + "<br/>" +
      "<hr/>" + body;

    var createPostKwargs = {
      body: noteBody,
      message_type: "email",
      subtype_xmlid: "mail.mt_comment",
      email_from: contactEmail,
      subject: leadName
    };
    var msgIdHeader = params.messageIdHeader || "";
    if (msgIdHeader) {
      createPostKwargs.message_id = msgIdHeader;
    }
    odooExecute("crm.lead", "message_post", [[leadId]], createPostKwargs);

    if (msgIdHeader) {
      markEmailLogged(leadId, msgIdHeader);
    }
  }

  return buildNotificationResponse("Lead #" + leadId + " created successfully!");
}

// --- Helper ---

function buildNotificationResponse(message) {
  return CardService.newActionResponseBuilder()
    .setNotification(
      CardService.newNotification().setText(message)
    )
    .build();
}
