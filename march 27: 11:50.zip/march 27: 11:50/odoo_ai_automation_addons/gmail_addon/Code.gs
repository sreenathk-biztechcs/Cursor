/**
 * Code.gs — Main entry points for the Odoo CRM Gmail Workspace Add-on.
 *
 * onHomepage()         → settings / connection card
 * onGmailMessageOpen() → contextual sidebar with CRM data
 */

function onHomepage(e) {
  var creds = getOdooCredentials();
  if (!creds.url || !creds.username || !creds.password) {
    return buildSettingsCard();
  }
  return buildHomepageCard();
}

function onGmailMessageOpen(e) {
  var creds = getOdooCredentials();
  if (!creds.url || !creds.username || !creds.password) {
    return [buildSettingsCard("Configure Odoo connection first to use the sidebar.")];
  }

  var msgId = e.gmail.messageId;
  var accessToken = e.gmail.accessToken;
  GmailApp.setCurrentMessageAccessToken(accessToken);

  var message = GmailApp.getMessageById(msgId);
  if (!message) {
    return [buildErrorCard("Could not read this email.")];
  }

  var fromEmail = extractEmailAddress(message.getFrom());
  var subject = message.getSubject() || "(no subject)";
  var messageIdHeader = getMessageIdHeader(message);
  var referencesHeader = getReferencesHeader(message);
  var inReplyToHeader = getInReplyToHeader(message);

  return [buildContextualCard(fromEmail, subject, msgId, messageIdHeader, referencesHeader, inReplyToHeader)];
}
