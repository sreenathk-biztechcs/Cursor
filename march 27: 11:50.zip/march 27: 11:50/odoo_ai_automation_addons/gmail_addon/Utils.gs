/**
 * Utils.gs — Email parsing and HTML sanitization utilities.
 */

/**
 * Extract a bare email address from a Gmail "From" string.
 * "John Doe <john@example.com>" → "john@example.com"
 *
 * @param {string} fromStr
 * @returns {string}
 */
function extractEmailAddress(fromStr) {
  if (!fromStr) return "";
  var match = fromStr.match(/<([^>]+)>/);
  if (match) return match[1].toLowerCase().trim();
  var atMatch = fromStr.match(/[\w.+-]+@[\w.-]+/);
  if (atMatch) return atMatch[0].toLowerCase().trim();
  return fromStr.toLowerCase().trim();
}

/**
 * Get the RFC 2822 Message-ID header from a Gmail message.
 *
 * @param {GmailMessage} message
 * @returns {string} Message-ID or empty string
 */
function getMessageIdHeader(message) {
  try {
    var rawHeaders = message.getHeader("Message-ID") ||
                     message.getHeader("Message-Id") ||
                     message.getHeader("message-id");
    return rawHeaders ? rawHeaders.trim() : "";
  } catch (e) {
    return "";
  }
}

/**
 * Get the RFC 2822 References header from a Gmail message.
 * Contains the chain of Message-IDs in the conversation thread.
 *
 * @param {GmailMessage} message
 * @returns {string} References header value or empty string
 */
function getReferencesHeader(message) {
  try {
    var raw = message.getHeader("References") ||
              message.getHeader("references");
    return raw ? raw.trim() : "";
  } catch (e) {
    return "";
  }
}

/**
 * Get the RFC 2822 In-Reply-To header from a Gmail message.
 *
 * @param {GmailMessage} message
 * @returns {string} In-Reply-To header value or empty string
 */
function getInReplyToHeader(message) {
  try {
    var raw = message.getHeader("In-Reply-To") ||
              message.getHeader("in-reply-to");
    return raw ? raw.trim() : "";
  } catch (e) {
    return "";
  }
}

/**
 * Sanitize HTML content for safe inclusion in Odoo notes.
 * Strips <script> tags, on* event handlers, and excessive whitespace.
 *
 * @param {string} html
 * @returns {string}
 */
function sanitizeHtml(html) {
  if (!html) return "";

  html = html.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "");
  html = html.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "");

  html = html.replace(/\s+on\w+\s*=\s*["'][^"']*["']/gi, "");
  html = html.replace(/\s+on\w+\s*=\s*\S+/gi, "");

  html = html.replace(/javascript\s*:/gi, "");

  html = html.replace(/<iframe[^>]*>[\s\S]*?<\/iframe>/gi, "");
  html = html.replace(/<embed[^>]*>/gi, "");
  html = html.replace(/<object[^>]*>[\s\S]*?<\/object>/gi, "");

  if (html.length > 50000) {
    html = html.substring(0, 50000) + "\n...(truncated)";
  }

  return html;
}

/**
 * Extract plain text from HTML.
 * @param {string} html
 * @returns {string}
 */
function htmlToPlainText(html) {
  if (!html) return "";
  var text = html.replace(/<br\s*\/?>/gi, "\n");
  text = text.replace(/<\/p>/gi, "\n\n");
  text = text.replace(/<[^>]+>/g, "");
  text = text.replace(/&nbsp;/gi, " ");
  text = text.replace(/&amp;/gi, "&");
  text = text.replace(/&lt;/gi, "<");
  text = text.replace(/&gt;/gi, ">");
  text = text.replace(/&quot;/gi, '"');
  text = text.replace(/\n{3,}/g, "\n\n");
  return text.trim();
}
