# Odoo AI Automation Addons — Setup & Testing Guide (Odoo 19 CE)

This folder contains Odoo 19 Community Edition addons that implement inbound sales automation and AI-assisted document workflows.

## Global prerequisites (applies to all modules)

- **Odoo**: 19.0 CE running with `addons_path` including this directory.
- **Database**: a target DB (examples below use `1111`).
- **Python venv**: use your project venv (examples use `../.venv`).

### Addons path

Confirm your `odoo.conf` includes this folder in `addons_path`, e.g.:

- `/home/sreenath.k/PycharmProjects/odoo19/odoo19/odoo_ai_automation_addons`

### Install/upgrade commands (standard)

From Odoo root:

```bash
cd /home/sreenath.k/PycharmProjects/odoo19/odoo19
source ../.venv/bin/activate

# install
./odoo-bin -c odoo.conf -d 1111 -i <module_name> --stop-after-init

# upgrade (use this when you change code)
./odoo-bin -c odoo.conf -d 1111 -u <module_name> --stop-after-init
```

---

## Module: `sales_ai_integration` (Sales AI Integration)

### Purpose

Inbound sales automation on CRM leads using Claude AI + n8n orchestration (enrichment, scoring, follow-ups, MOMs, presale workflows, retrospectives).

### Depends on

From manifest:
- `crm`, `mail`, `base_automation`
- `google_calendar`, `google_gmail`
- `project`
- `sh_all_in_one_helpdesk` (ensure installed if you need helpdesk features)

### External Python deps

From manifest:
- `anthropic`, `requests`
- `PyPDF2`, `pytesseract`, `python-docx`, `PyJWT`

Install:

```bash
pip install anthropic requests PyPDF2 pytesseract python-docx PyJWT
```

### Configuration (UI)

Go to **Settings → Sales AI** and configure:
- **Claude API Key** (`sales_ai.claude_api_key`)
- **n8n Webhook Base URL**, **n8n secrets** (if using n8n)
- **Marketing User** (for junk/marketing routing)
- **ICP scoring criteria JSON**
- Per-user: sales reps should have **calendar booking link** set on user form

### Core tests (manual)

Use the existing deep guide:
- `README_TESTING.md`
- `README_APOLLO_INTEGRATION.md`

Minimum smoke test:
- Create a new lead → confirm junk/marketing classification runs
- Ensure enrichment callback updates lead fields
- Confirm scoring fields populated
- Assign salesperson → auto-ack email + 3 follow-up activities created
- Run cron for follow-up drafts → activity notes get AI draft content

### Cron/automations

Many scheduled actions and automated actions ship inactive by default. Activate needed ones in:
- **Settings → Technical → Scheduled Actions**
- **Settings → Technical → Automated Actions**

---

## Module: `mail_smart_link` (Mail Smart Link)

### Purpose

Prevent duplicate CRM leads by routing inbound email-created leads to an existing active lead when sender matches.

### Depends on

From manifest:
- `crm`, `mail`, `fetchmail`, `google_gmail`

### Configuration

Typically no extra settings. Ensure mail aliases/fetchmail are configured so inbound emails create/route to leads.

### Tests (manual)

1. Create a lead with `email_from = customer@example.com`.
2. Send a **new email** (not a reply) from `customer@example.com` to your CRM lead alias.
3. Expected:
   - Email is routed to existing lead
   - No duplicate lead created

---

## Module: `enhanced_document_management` (Document Management)

### Purpose

Community-friendly document management providing workspaces and document records:
- `document.workspace`
- `document.file`

Used by `living_document_crm` for Odoo-side document storage.

### Depends on

From manifest:
- `mail`, `website`, `hr`

### External Python deps

From manifest:
- `bs4`

Install:

```bash
pip install bs4
```

### Tests (manual)

1. Open Document Management menus.
2. Create a workspace.
3. Upload a document file and confirm it creates `document.file` with `ir.attachment`.

---

## Module: `living_document_crm` (Living Document for CRM)

### Purpose

Creates and maintains a “Living Document” per CRM lead that continuously summarizes communications using AI and updates the document in:
- **Odoo document store**: `document.file` / `document.workspace` (via `enhanced_document_management`)
- **Google Docs** (optional): full-regenerate updates + optional sync checker cron

### Depends on

From manifest:
- `crm`, `mail`, `contacts`
- `enhanced_document_management` (required for Odoo document mode)

### Key features

- Trigger updates on:
  - new `mail.message` on `crm.lead` (emails/comments; excludes system notes)
  - new `ir.attachment` on lead (and optionally helpdesk ticket if installed)
- Batch/debounce updates with:
  - pending flag on lead
  - cron batch processor every 5 minutes
- Logs each stage to `living.doc.log`
- Filters financial data before any AI call

### Configuration (UI)

Go to **Settings → CRM → Living Document (AI)**:
- **Claude API Key**
- **Default mode**: `odoo` / `google` / `both`
- **Workspace**: `document.workspace` root for living documents
- **Auto-update** toggle + update delay (debounce)
- **Google sync cron** (optional)

### Google Docs OAuth (Calendar-style, recommended)

This module supports a Calendar-like OAuth connect flow:

1. Set **Google OAuth Client ID** + **Google OAuth Client Secret**
2. Click **Connect Google Docs**
3. Approve consent
4. Odoo stores an **authorized user** credential JSON (with refresh token) into:
   - system parameter `living_doc.google_credentials`

#### Redirect URI

In Google Cloud OAuth client, add this redirect URI (must match exactly):

- `https://<your-domain>/living_document_crm/google/oauth2/callback`

If using ngrok, your domain will be your ngrok URL.

### Tests (manual)

#### Odoo document mode

1. Create a lead.
2. Click **Create Living Document** → mode `Odoo`.
3. Post chatter:
   - comment + email + attachment
4. Run cron manually:
   - **Settings → Technical → Scheduled Actions**
   - Run `Living Document: Batch Processor`
5. Expected:
   - lead status becomes Active
   - `x_living_doc_id` set (a `document.file`)
   - logs show extraction → filtering → AI steps → upload → complete

#### Google mode

1. Ensure OAuth is connected (or use service account JSON).
2. Create living doc in `google` or `both`.
3. Expected:
   - lead has `x_google_doc_id` and URL
   - updates replace entire doc content (not append)

### Tests (automated)

Run module tests:

```bash
./odoo-bin -c odoo.conf -d 1111 --test-tags living_document_crm --stop-after-init
```

---

## Common troubleshooting

### “redirect_uri_mismatch” during Google connect

- Add the exact callback URL to Google Cloud OAuth client **Authorized redirect URIs**:
  - `https://<base_url>/living_document_crm/google/oauth2/callback`
- Ensure Odoo `web.base.url` matches the domain you’re using (ngrok vs localhost).

### Settings page RPC error about invalid field types

Odoo 19 restricts `res.config.settings` config parameters to specific field types. If you change field types, always:
- restart Odoo
- run `-u <module>` on the module that owns that field

