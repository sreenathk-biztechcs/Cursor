# Apollo–Odoo–Claude Integration (Sales AI)

This README describes how to test the Apollo enrichment + MOM creation flows
implemented in `sales_ai_integration`.

## 1. Configuration

1. Go to **Settings → Sales AI**:
   - Set **Claude API Key**.
   - Set **Apollo API Key** and **Apollo API Base URL** (e.g. `https://api.apollo.io`).
   - Set **n8n Webhook Base URL** and **Secret** if using n8n.
2. In **Users**, set each salesperson's `x_calendar_link` (for auto-ack emails).

## 2. Apollo Enrichment Test

### Direct Odoo API (no n8n)

1. Create a test contact in Apollo with a known email.
2. Call the Odoo JSON endpoint:

   - URL: `/api/enrich_lead`
   - Headers: `X-N8N-Secret: <your_secret>`
   - Body:
     ```json
     {
       "email": "john.doe@example.com",
       "name": "John Doe"
     }
     ```

3. Expected:
   - If a `crm.lead` with that email exists:
     - `x_apollo_person_id` and `x_apollo_data_raw` are filled.
     - Enrichment fields (employee count, revenue, LinkedIn) updated when present.
   - If no lead exists:
     - Claude generates a new lead payload.
     - A new `crm.lead` is created and logged.

## 3. MOM Creation Test

1. Create a test lead.
2. Optionally attach 1–2 files (PDF, JPG, DOCX) to the lead.
3. Call `/api/create_mom_activity`:

   - Headers: `X-N8N-Secret: <your_secret>`
   - Body:
     ```json
     {
       "lead_id": 123,
       "transcript": "Salesperson: Welcome...\nClient: We need ...",
       "attachment_ids": [45, 46]
     }
     ```

4. Expected:
   - `x_attachment_extracts_json` contains extracted text per attachment (when libraries are installed).
   - `x_mom_history` adds a new JSON entry with date/time/points/actions/next_steps.
   - Lead chatter contains a formatted MOM note.
   - A **Client MOM Review** activity is created for the lead owner.

## 4. n8n Workflows (Overview)

- `enrich_lead` webhook: call `/api/enrich_lead` with email/name/phone.
- `attachment_created` webhook: optional pipeline for heavy offline extraction.
- Teams alert webhooks: `teams_followup_overdue`, `teams_mom_overdue`, etc.

Use retries and error handling in n8n (e.g. retry on HTTP 429 after 60 seconds).

