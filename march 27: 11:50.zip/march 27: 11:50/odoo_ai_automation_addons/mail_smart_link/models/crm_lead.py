import logging
import email.utils
import re

from odoo import api, models

_logger = logging.getLogger(__name__)


def _normalize_subject(subject):
    s = (subject or "").lower().strip()
    s = re.sub(r"^(re|fw|fwd)\s*:\s*", "", s)
    s = re.sub(r"\[[^\]]+\]", " ", s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _extract_reference_ids(raw_references):
    raw = (raw_references or "").strip()
    if not raw:
        return []
    # RFC headers are usually space-separated "<...>" ids; some servers send comma-separated.
    bracketed = re.findall(r"<[^>]+>", raw)
    if bracketed:
        return [x.strip() for x in bracketed if x.strip()]
    tokens = re.split(r"[\s,;]+", raw)
    return [t.strip() for t in tokens if t.strip() and "reply_to" not in t.lower()]


class CrmLeadSmartLink(models.Model):
    _inherit = "crm.lead"

    @api.model
    def message_new(self, msg_dict, custom_values=None):
        """
        Smart-link incoming emails from known customers to existing active leads.

        If a partner + active lead already exists for the sender's email, route
        the message to that lead instead of creating a duplicate.
        Otherwise, fall back to default behaviour (new lead).
        """
        email_from = msg_dict.get("email_from") or msg_dict.get("from") or ""
        _, sender_email = email.utils.parseaddr(email_from)
        sender_email = (sender_email or "").lower().strip()
        message_id = (msg_dict.get("message_id") or msg_dict.get("Message-Id") or "").strip()

        if not sender_email:
            return super().message_new(msg_dict, custom_values=custom_values)

        # Layer 1 dedup: RFC 2822 Message-ID already present in CRM chatter.
        if message_id:
            existing_message = self.env["mail.message"].sudo().search([
                ("model", "=", "crm.lead"),
                ("message_id", "=", message_id),
            ], limit=1)
            if existing_message and existing_message.res_id:
                target = self.env["crm.lead"].sudo().browse(existing_message.res_id)
                if target.exists():
                    _logger.info(
                        "mail_smart_link: Skipping duplicate message-id %s for lead %s",
                        message_id, target.id,
                    )
                    return target

        # Layer 2: Thread routing via References / In-Reply-To headers.
        # Catches replies forwarded by colleagues or from different clients.
        # Merge both headers so we never miss a thread link.
        raw_refs = (msg_dict.get("references") or msg_dict.get("References") or "")
        raw_irt = (msg_dict.get("in_reply_to") or msg_dict.get("In-Reply-To") or "")
        references = (raw_refs + " " + raw_irt).strip()
        if references:
            ref_ids = _extract_reference_ids(references)
            if ref_ids:
                ref_msg = self.env["mail.message"].sudo().search([
                    ("model", "=", "crm.lead"),
                    ("message_id", "in", ref_ids[-32:]),
                ], limit=1, order="id desc")
                if ref_msg and ref_msg.res_id:
                    target = self.env["crm.lead"].sudo().browse(ref_msg.res_id)
                    if target.exists() and target.active:
                        _logger.info(
                            "mail_smart_link: Thread-routed email from %s to lead %s via References header",
                            sender_email, target.id,
                        )
                        body = msg_dict.get("body") or ""
                        subject = msg_dict.get("subject") or ""
                        post_kwargs = {
                            "body": body,
                            "subject": subject,
                            "message_type": "email",
                            "subtype_xmlid": "mail.mt_comment",
                            "email_from": email_from,
                            "parent_id": ref_msg.id,
                        }
                        incoming_to = msg_dict.get("to") or msg_dict.get("incoming_email_to") or ""
                        incoming_cc = msg_dict.get("cc") or msg_dict.get("incoming_email_cc") or ""
                        if incoming_to:
                            post_kwargs["incoming_email_to"] = incoming_to
                        if incoming_cc:
                            post_kwargs["incoming_email_cc"] = incoming_cc
                        partner = self.env["res.partner"].sudo().search(
                            [("email", "=ilike", sender_email)],
                            limit=1,
                        )
                        if partner:
                            post_kwargs["author_id"] = partner.id
                        if message_id:
                            post_kwargs["message_id"] = message_id
                        attachment_ids = []
                        for att_vals in msg_dict.get("attachments") or []:
                            if isinstance(att_vals, (list, tuple)) and len(att_vals) >= 2:
                                att = self.env["ir.attachment"].sudo().create({
                                    "name": att_vals[0],
                                    "datas": att_vals[1] if len(att_vals) > 1 else False,
                                    "res_model": "crm.lead",
                                    "res_id": target.id,
                                })
                                attachment_ids.append(att.id)
                        if attachment_ids:
                            post_kwargs["attachment_ids"] = attachment_ids
                        target.message_post(**post_kwargs)
                        return target

        Partner = self.env["res.partner"].sudo()
        partner = Partner.search([("email", "=ilike", sender_email)], limit=1)
        sender_domain = sender_email.split("@", 1)[1].lower() if "@" in sender_email else ""
        domain_partner = False
        if sender_domain:
            domain_partner = Partner.search([
                ("email", "ilike", "@%s" % sender_domain),
                ("is_company", "=", True),
            ], limit=1)

        Lead = self.env["crm.lead"].sudo()
        subject_norm = _normalize_subject(msg_dict.get("subject") or "")
        domain = [("active", "=", True)]
        if partner:
            domain = [
                "|",
                ("partner_id", "=", partner.id),
                ("email_from", "=ilike", sender_email),
                ("active", "=", True),
            ]
        elif domain_partner:
            domain = [
                "|",
                ("partner_id", "=", domain_partner.id),
                ("email_from", "ilike", "@%s" % sender_domain),
                ("active", "=", True),
            ]
        else:
            domain = [("email_from", "=ilike", sender_email), ("active", "=", True)]

        # When multiple leads can match sender/domain, prefer subject-related lead.
        candidates = Lead.search(domain, order="write_date desc, id desc", limit=25)

        # Also search by chatter history: if sender previously mailed a lead,
        # that lead is a strong candidate even if partner/email_from changed.
        if not candidates and sender_email:
            chatter_leads = self.env["mail.message"].sudo().search([
                ("model", "=", "crm.lead"),
                ("email_from", "=ilike", sender_email),
                ("message_type", "in", ("email", "comment")),
            ], limit=10, order="id desc")
            if chatter_leads:
                lead_ids = list({m.res_id for m in chatter_leads if m.res_id})
                if lead_ids:
                    candidates = Lead.search([
                        ("id", "in", lead_ids),
                        ("active", "=", True),
                    ], order="write_date desc, id desc", limit=25)

        leads = candidates[:1]

        # Single candidate → always route there (no subject match needed)
        if len(candidates) == 1:
            leads = candidates

        if len(candidates) > 1 and subject_norm:
            best = False
            best_score = -1
            for cand in candidates:
                c_subj = _normalize_subject(cand.name or "")
                c_partner = _normalize_subject(cand.partner_name or (cand.partner_id.name if cand.partner_id else ""))
                score = 0
                if c_subj and c_subj in subject_norm:
                    score += 3
                if subject_norm and c_subj and subject_norm in c_subj:
                    score += 2
                if c_partner and c_partner in subject_norm:
                    score += 1
                # Also check if the lead's chatter already has emails from this sender
                if sender_email:
                    prior = self.env["mail.message"].sudo().search_count([
                        ("model", "=", "crm.lead"),
                        ("res_id", "=", cand.id),
                        ("email_from", "=ilike", sender_email),
                    ], limit=1)
                    if prior:
                        score += 4  # strong signal: sender already in this lead
                if score > best_score:
                    best_score = score
                    best = cand
            if best and best_score > 0:
                leads = best

        if leads:
            target = leads[0] if hasattr(leads, "__getitem__") else leads
            _logger.info(
                "mail_smart_link: Email from %s routed to existing lead %s (id=%s)",
                sender_email,
                target.name,
                target.id,
            )
            body = msg_dict.get("body") or ""
            subject = msg_dict.get("subject") or ""
            author_id = False
            if partner:
                author_id = partner.id

            post_kwargs = {
                "body": body,
                "subject": subject,
                "message_type": "email",
                "subtype_xmlid": "mail.mt_comment",
                "email_from": email_from,
            }
            incoming_to = msg_dict.get("to") or msg_dict.get("incoming_email_to") or ""
            incoming_cc = msg_dict.get("cc") or msg_dict.get("incoming_email_cc") or ""
            if incoming_to:
                post_kwargs["incoming_email_to"] = incoming_to
            if incoming_cc:
                post_kwargs["incoming_email_cc"] = incoming_cc
            if message_id:
                post_kwargs["message_id"] = message_id
            if author_id:
                post_kwargs["author_id"] = author_id

            attachment_ids = []
            for att_vals in msg_dict.get("attachments") or []:
                if isinstance(att_vals, (list, tuple)) and len(att_vals) >= 2:
                    att = self.env["ir.attachment"].sudo().create({
                        "name": att_vals[0],
                        "datas": att_vals[1] if len(att_vals) > 1 else False,
                        "res_model": "crm.lead",
                        "res_id": target.id,
                    })
                    attachment_ids.append(att.id)
            if attachment_ids:
                post_kwargs["attachment_ids"] = attachment_ids

            target.message_post(**post_kwargs)
            return target

        # Fallback: create new lead using default behaviour
        return super().message_new(msg_dict, custom_values=custom_values)

