import logging

from odoo import api, models

_logger = logging.getLogger(__name__)


class MailMailThreading(models.Model):
    """Inject RFC 2822 In-Reply-To header on outbound CRM lead emails.

    Gmail requires In-Reply-To (pointing at the previous message's
    Message-ID) to keep replies inside the same conversation thread.
    Odoo core sets References but never In-Reply-To; this override
    fills the gap for crm.lead emails.
    """

    _inherit = "mail.mail"

    def _prepare_outgoing_list(self, mail_server=False, doc_to_followers=None):
        results = super()._prepare_outgoing_list(
            mail_server=mail_server, doc_to_followers=doc_to_followers,
        )
        if self.model != "crm.lead" or not self.res_id:
            return results

        # Find the most recent message in this lead's thread that has a
        # message_id (RFC 2822).  Prefer the last *inbound* email so our
        # reply lands in the client's Gmail thread; fall back to any
        # message with a message_id.
        last_msg = self.env["mail.message"].sudo().search(
            [
                ("model", "=", "crm.lead"),
                ("res_id", "=", self.res_id),
                ("message_id", "!=", False),
                ("message_type", "in", ("email", "comment")),
                ("id", "!=", self.mail_message_id.id),
            ],
            limit=1,
            order="id desc",
        )
        if not last_msg:
            return results

        in_reply_to = last_msg.message_id

        # Also build a comprehensive References chain (up to 10 recent
        # ancestors) so Gmail has maximum context for threading.
        ancestors = self.env["mail.message"].sudo().search(
            [
                ("model", "=", "crm.lead"),
                ("res_id", "=", self.res_id),
                ("message_id", "!=", False),
            ],
            limit=10,
            order="id asc",
        )
        full_refs = " ".join(m.message_id for m in ancestors)
        # Append the current message's own id at the end
        if self.mail_message_id and self.mail_message_id.message_id:
            full_refs = (full_refs + " " + self.mail_message_id.message_id).strip()

        for email_dict in results:
            hdrs = email_dict.get("headers") or {}
            hdrs["In-Reply-To"] = in_reply_to
            email_dict["headers"] = hdrs
            # Upgrade references to the fuller chain
            if full_refs:
                email_dict["references"] = full_refs

        return results
