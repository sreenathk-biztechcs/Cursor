# Testing Guide: Odoo 19 CE Inbound Sales AI Automation

This document provides step-by-step testing instructions for the **`sales_ai_integration`** and **`mail_smart_link`** modules. These modules implement AI-powered inbound sales automation on Odoo 19 CE, using Claude AI for intelligence and n8n for external workflow orchestration.

---

## Prerequisites

Before running any test, confirm the following are in place:

1. **Odoo 19 CE is running** and accessible at your configured URL.
2. **Both modules are installed:**
   - `sales_ai_integration` -- go to Apps, search "Sales AI Integration", confirm status is "Installed".
   - `mail_smart_link` -- go to Apps, search "Mail Smart Link", confirm status is "Installed".
3. **Claude API key is configured:**
   - Navigate to **Settings > Sales AI** (the section added by the module).
   - Enter a valid Anthropic API key in the **Claude API Key** field.
   - The key is stored as system parameter `sales_ai.claude_api_key`.
   - Verify by checking that `env['claude.service']._get_api_key()` returns a non-empty string in the Odoo shell.
4. **n8n is running and webhooks are configured:**
   - Set the **n8n Webhook Base URL** in Settings > Sales AI (e.g., `https://n8n.internal`). Stored as `sales_ai.n8n_webhook_base_url`.
   - Set the **n8n Header Auth Secret** (`sales_ai.n8n_secret_token`) -- this is sent as `X-N8N-Secret` on every Odoo-to-n8n call.
   - Set the **n8n HMAC Signing Secret** (`sales_ai.n8n_hmac_secret`) -- used to sign payloads with `X-Odoo-Signature` header.
   - In n8n, configure the corresponding webhook trigger nodes to accept these headers.
5. **Apollo API key is configured in n8n:**
   - The `enrich_lead` n8n workflow must have a valid Apollo.io API key for the People Enrichment API.
   - Rate limit: 600 requests/hour on standard Apollo plans.
6. **Odoo API key for n8n-to-Odoo calls:**
   - Create a dedicated Odoo user (e.g., `n8n_service`) with read/write access to `crm.lead` and `project.task`.
   - Generate an API key: **Settings > Technical > API Keys > New**.
   - In n8n, configure HTTP Header Auth with `Authorization: Bearer <odoo_api_key>` for all Odoo callback nodes.
7. **Marketing User is configured:**
   - In Settings > Sales AI, set the **Marketing User for Junk/Marketing Leads** field so that junk/marketing leads are auto-reassigned.
8. **ICP Scoring Criteria is configured:**
   - In Settings > Sales AI, populate the **ICP Scoring Criteria (JSON)** field with your Ideal Customer Profile definition (e.g., `{"industries": ["IT Services"], "min_employees": 50, "tech_stack": ["Python", "React"]}`).
9. **Sales reps have calendar links configured:**
   - For each salesperson, set the **Calendar Booking Link** field on their user profile (Settings > Users > [User] > Calendar Booking Link). This is the `x_calendar_link` field.

---

## Test 1: Lead Creation and Junk Filter

**Goal:** Verify that new leads are automatically classified as genuine, marketing, or junk.

**Automated Action:** `Sales AI - Junk / Marketing Classifier` (XML ID: `sales_ai_integration.auto_sales_ai_junk_filter`) -- triggers `on_create` for `crm.lead`.

### Steps

1. **Create a new lead manually:**
   - Go to CRM > Leads > New.
   - Enter a name, email address, and description.
   - Save the lead.
   - Alternatively, send an email to your configured `sales@` mail alias to create a lead via inbound email.

2. **Check: Junk filter automated action fires:**
   - The `base.automation` record fires on lead creation and calls `records.action_run_junk_filter()`.
   - Look in the Odoo server log for Claude API activity. On failure, you will see:
     ```
     WARNING ... Junk filter call failed; defaulting to genuine.
     ```

3. **Check: If classified as genuine, Apollo enrichment is triggered:**
   - A second automated action (`Sales AI - Trigger Apollo Enrichment`, XML ID: `sales_ai_integration.auto_sales_ai_enrichment_trigger`) fires `on_write` when `x_lead_quality` changes from empty to `genuine`.
   - This posts to the n8n `enrich_lead` webhook with payload:
     ```json
     {"lead_id": 123, "email": "contact@example.com", "company": "Acme Corp", "domain": "example.com"}
     ```
   - Check the Odoo log for:
     ```
     WARNING ... n8n base URL not configured; skipping call to enrich_lead
     ```
     (This means the n8n URL is not set -- fix it in Settings.)
   - Or check n8n execution history for the `enrich_lead` webhook trigger.

4. **Check: n8n queries Apollo People Enrichment API:**
   - In n8n, verify the `enrich_lead` workflow received the webhook, called the Apollo API, and got enrichment data back.

5. **Check: n8n calls back `/api/sales_ai/receive_apollo_data`:**
   - n8n should POST to `https://<odoo>/api/sales_ai/receive_apollo_data` with:
     ```json
     {"lead_id": 123, "apollo_data": { ... }}
     ```
   - Auth: `Authorization: Bearer <odoo_api_key>` header.
   - The controller calls `lead.action_receive_apollo_data(apollo_data_json)`.

6. **Check: Lead enrichment fields are populated:**
   - Open the lead form and check that these fields have values:
     - `x_employee_count` (Employee Count)
     - `x_is_it_company` (Is IT Company)
     - `x_annual_revenue` (Annual Revenue)
     - `x_tech_stack` (Technology Stack)
     - `x_is_decision_maker` (Is Decision Maker)
     - `x_seniority` (Seniority)
     - `x_contact_score` (Contact Score)
     - `x_intent_score` (Intent Score)
     - `x_linkedin_url` (LinkedIn URL)
   - `x_apollo_data_raw` should contain the raw Apollo JSON.
   - `x_enrichment_done` should be True.

7. **Check: `x_lead_quality` is set:**
   - Value should be one of: `genuine`, `marketing`, or `junk`.
   - Visible on the lead form under "Lead Quality".

8. **Check: If junk or marketing, lead is reassigned to Marketing User:**
   - The lead's `user_id` should change to the configured Marketing User.
   - A chatter note should read: `"Classified as junk by AI; routed to Marketing User."` (or `marketing`).

9. **Check: Logger output in Odoo logs:**
   - On success: no specific log line (silent success by design).
   - On Claude API failure:
     ```
     WARNING ... Junk filter call failed; defaulting to genuine.
     ```
   - On Apollo enrichment failure:
     ```
     ERROR ... Apollo enrichment failed for lead 123
     ```

10. **Test with a known junk email:**
    - Create a lead with email like `noreply@spam-domain.com` and a spammy description.
    - Verify `x_lead_quality` = `junk`.

11. **Test with an email NOT in Apollo:**
    - Use an email that Apollo will not find (e.g., a personal Gmail).
    - n8n should still call back with empty/minimal `apollo_data`.
    - The junk filter classification should still work based on the email content and description alone (the junk filter runs BEFORE Apollo enrichment).

---

## Test 2: Lead Scoring

**Goal:** Verify that genuine leads are scored 0-100 with a hot/warm/cold band after enrichment.

**Triggered by:** `action_receive_apollo_data()` automatically calls `action_run_lead_scoring()` after enrichment completes.

### Steps

1. **Start with an enriched genuine lead** (complete Test 1 first).

2. **Check: `x_lead_score` is set (0-100):**
   - Open the lead form. The "Lead Score (0-100)" field should have a value.
   - Score is clamped: `max(0, min(100, score))`.

3. **Check: `x_lead_score_band` is set:**
   - Value is one of: `hot`, `warm`, `cold`.
   - If the ICP criteria JSON is empty (`{}`), the score defaults to 50 and band defaults to `warm`.

4. **Check: `x_scoring_done` is True.**

5. **Check: Scoring reasoning is logged in chatter:**
   - A chatter note should appear: `"AI lead scoring: <reasoning text>"`.
   - The reasoning comes from the Claude response `result.get("reasoning")`.

6. **Check logs on failure:**
   ```
   ERROR ... Lead scoring failed for lead 123
   ```

---

## Test 3: Lead Assignment and Auto-Ack Email

**Goal:** Verify that assigning a salesperson to a scored genuine lead triggers an AI-generated acknowledgment email.

**Automated Action:** `Sales AI - On Lead Assignment` (XML ID: `sales_ai_integration.auto_sales_ai_lead_assignment`) -- triggers `on_write` when `user_id` changes from empty to a value.

### Steps

1. **Assign a scored genuine lead to a sales rep:**
   - Open a lead that has `x_lead_quality = genuine` and `x_scoring_done = True`.
   - Set the Salesperson field (was previously empty).
   - Save.

2. **Check: Auto-ack email is generated and sent:**
   - Go to **Settings > Technical > Emails** and look for the outbound email.
   - Or check the lead chatter for: `"Auto-ack email sent by AI."`.

3. **Check: Email is sent FROM the assigned rep:**
   - The `email_from` on the mail record should be `lead.user_id.email_formatted`.
   - The `author_id` should be the rep's partner record.

4. **Check: Email includes the rep's calendar booking link:**
   - The email body should contain the `x_calendar_link` value from the assigned user.
   - If the rep has no calendar link set, the placeholder `[CALENDAR_LINK]` will appear in the email -- this indicates the rep's profile needs updating.

5. **Check: Email is logged in lead chatter:**
   - The chatter should show the `"Auto-ack email sent by AI."` internal note.

6. **Check logs on failure:**
   ```
   ERROR ... Auto-ack generation failed for lead 123
   ```

---

## Test 4: Follow-up Scheduling

**Goal:** Verify that 3 follow-up activities are created with business-day-aware scheduling.

**Triggered by:** The same `Sales AI - On Lead Assignment` automated action also calls `records.action_create_followup_activities()`.

### Steps

1. **After assigning a rep to a scored lead** (same trigger as Test 3).

2. **Check: 3 follow-up activities are created on the lead:**
   - Open the lead and go to the Activities section (or check via Settings > Technical > Activities filtering by this lead).
   - There should be exactly 3 activities of type `sales_ai_integration.activity_type_followup_email`.

3. **Check: Dates respect business days (no weekends):**
   - All 3 deadline dates should fall on Monday-Friday.
   - The `_business_day_offset()` method skips Saturday (weekday=5) and Sunday (weekday=6).

4. **Check: Hot/warm/cold leads have different day gaps:**

   | Band | Follow-up 1 | Follow-up 2 | Follow-up 3 |
   |------|-------------|-------------|-------------|
   | Hot  | +1 biz day  | +3 biz days | +7 biz days |
   | Warm | +2 biz days | +5 biz days | +10 biz days|
   | Cold | +3 biz days | +7 biz days | +14 biz days|

5. **Check: `x_followup_stage` = 1** on the lead.

6. **Check: Each activity note contains:**
   ```
   [AI-FOLLOWUP-PENDING] Draft will be generated before this date.
   ```

7. **Edge case -- scoring completes after assignment:**
   - If `user_id` was set before `x_lead_score_band` was populated (e.g., manual assignment before Apollo data returned), the scoring method `action_run_lead_scoring()` will detect no follow-up activities exist and create them retroactively.

---

## Test 5: Follow-up Email Drafter (9 AM Cron)

**Goal:** Verify the daily cron job drafts AI-generated follow-up emails into activity notes.

**Cron Job:** `Sales AI - Draft Follow-up Emails` (XML ID: `sales_ai_integration.ir_cron_sales_ai_followup_drafts`), scheduled at 09:00 UTC daily.

### Steps

1. **Activate the cron job:**
   - Navigate to **Settings > Technical > Scheduled Actions**.
   - Find `Sales AI - Draft Follow-up Emails`.
   - Set **Active** to True.
   - Note: This cron is `active=False` by default and must be manually activated.

2. **Ensure there are follow-up activities due today or tomorrow:**
   - From Test 4, you should have activities with `[AI-FOLLOWUP-PENDING]` in the note.
   - If needed, manually adjust an activity's `date_deadline` to today's date.

3. **Manually trigger the cron:**
   - On the cron record, click **Run Manually**.
   - The method `model.cron_draft_followup_emails()` executes.

4. **Check: Activities with `[AI-FOLLOWUP-PENDING]` marker get AI-drafted content:**
   - The cron searches for activities where:
     - `activity_type_id` = the follow-up email type
     - `date_deadline` between today and tomorrow
     - `note` starts with `[AI-FOLLOWUP-PENDING]`

5. **Check: Draft appears in the activity note:**
   - After the cron runs, the activity note should now start with:
     ```
     [AI DRAFT -- Review before sending]
     ```
   - Followed by a subject line and HTML email body generated by Claude (Sonnet tier).

6. **Check: Rep sees it in "My Activities":**
   - Log in as the assigned sales rep.
   - Go to CRM > My Activities.
   - The follow-up activity should appear with the drafted content.

7. **Check logs on failure:**
   ```
   ERROR ... Failed drafting follow-up for activity 456
   ERROR ... Follow-up draft generation failed for lead 123
   ```

---

## Test 6: Customer Reply Detection

**Goal:** Verify that inbound customer emails are detected, intent is classified, and follow-ups are adjusted.

**Triggered by:** The `message_post()` override in `CrmLeadMessage` (in `crm_lead.py`) intercepts incoming emails.

### Steps

1. **Send a reply email to the lead:**
   - From an external email client, reply to a thread on the lead (or send a new email that Odoo routes to the lead).
   - The email must be `message_type = "email"` and from a non-internal-user partner.

2. **Check: Pending follow-up activities are canceled:**
   - All activities of type `activity_type_followup_email` on this lead are deleted (`activities.unlink()`).

3. **Check: `x_last_reply_date` is set:**
   - Should contain the timestamp of when the reply was processed.

4. **Check: `x_reply_intent` is classified:**
   - Value is one of: `interested`, `not_interested`, `ooo`, `referral`.
   - Claude (Haiku tier) classifies the reply text (first 2000 chars).

5. **Check behavior for each intent:**

   **If INTERESTED:**
   - New follow-up activities are created via `lead.action_create_followup_activities()`.
   - The gap schedule uses the existing `x_lead_score_band`.

   **If NOT_INTERESTED:**
   - A chatter note is posted: `"Customer indicated they are not interested."`.
   - No new follow-up activities are created.

   **If OOO (Out of Office):**
   - A single follow-up activity is created, due 7 business days from now.
   - Activity note: `"[AI-FOLLOWUP-PENDING] OOO follow-up."`.

   **If REFERRAL:**
   - `x_reply_intent` is set to `referral`.
   - No automatic follow-up scheduling (handled manually).

6. **Check logs on failure:**
   ```
   ERROR ... Reply intent classification failed for lead 123
   ```

7. **Verify no recursive loop:**
   - The code uses `_sales_ai_message_post_lock` context flag to prevent re-entry when the handler itself posts notes (e.g., the "not interested" note).

---

## Test 7: Calendar Meeting Auto-Linker

**Goal:** Verify that calendar events with attendee emails matching leads are auto-linked.

**Automated Action:** `Sales AI - Meeting Lead Auto-Linker` (XML ID: `sales_ai_integration.auto_sales_ai_calendar_linker`) -- triggers `on_create_or_write` for `calendar.event`.

### Steps

1. **Create a calendar event with an attendee whose email matches a lead's `email_from`:**
   - Go to Calendar > New Event.
   - Add an attendee (partner) whose email address matches an active CRM lead's `email_from`.
   - Save the event.

2. **Check: `event.opportunity_id` is set to the matching lead:**
   - Open the calendar event record.
   - The "Opportunity" field should be linked to the lead.

3. **Check: Note posted on lead chatter:**
   - Open the lead.
   - Chatter should contain: `"Meeting <event name> auto-linked to this lead."`.

4. **Check log output:**
   ```
   INFO ... Sales AI: calendar event 789 auto-linked to lead 123
   ```

5. **Test with no matching lead:**
   - Create an event with attendees whose emails do not match any active lead.
   - No linking should occur; no errors should be logged.

6. **Presale meeting detection:**
   - If ALL attendees are internal Odoo users (non-portal), the event is flagged as `x_is_presale_meeting = True`.
   - If any attendee is external, `x_is_presale_meeting = False`.

---

## Test 8: Client MOM Generation

**Goal:** Verify that posting a meeting transcript generates a full MOM and a client-safe draft.

**Endpoint:** `POST /api/sales_ai/receive_transcript`

### Steps

1. **Call the webhook with a transcript:**
   ```bash
   curl -X POST https://<odoo>/api/sales_ai/receive_transcript \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer <odoo_api_key>" \
     -d '{
       "jsonrpc": "2.0",
       "params": {
         "lead_id": 123,
         "transcript": "Meeting transcript text here... attendees discussed project scope, timeline, budget...",
         "meeting_type": "client"
       }
     }'
   ```

2. **Check: Full MOM is logged as an internal note on the lead:**
   - Open the lead chatter.
   - An internal note should contain the full MOM HTML generated by Claude (Sonnet tier).

3. **Check: Client-safe MOM is created as an activity for the rep to review:**
   - An activity of type `sales_ai_integration.activity_type_client_mom` should be created.
   - The activity note should start with:
     ```
     [AI DRAFT -- Client MOM]
     ```
   - Followed by a subject and HTML body suitable for sending to the client.
   - The activity is assigned to the lead's salesperson (`lead.user_id`).
   - Deadline is set to today.

4. **Check: Structured format in the full MOM:**
   - The MOM should include (as defined by the prompt):
     - Date and time of the meeting
     - List of attendees
     - Discussion points / agenda items covered
     - Action items with owners
     - Next steps and follow-up dates

5. **Check logs on failure:**
   ```
   ERROR ... Client MOM generation failed for lead 123
   ```

---

## Test 9: Presale Flow (on CRM Lead)

**Goal:** Verify the presale ticket lifecycle -- from opening to proposal generation.

### Steps

1. **Create a presale ticket linked to a lead:**
   - Create a new Project Task with `x_linked_lead_id` set to an existing lead.
   - On creation, `action_generate_ticket_gist()` is automatically called.

2. **Check: Discussion gist is generated from lead history:**
   - Open the new task's chatter.
   - A note should contain a Claude-generated summary of the last 50 messages from the linked lead.
   - The lead's `x_presale_ticket_id` should be set to this task.
   - If no prior discussions exist, the note reads: `"No prior discussions found on the lead. Ticket ready for presale input."`.

3. **Check: `x_ticket_status` starts as `open`.**

4. **Run the presale agenda cron manually:**
   - Navigate to **Settings > Technical > Scheduled Actions**.
   - Find `Sales AI - Daily Presale Agenda`.
   - Set **Active** to True, then click **Run Manually**.
   - The method `model.cron_generate_presale_agenda()` executes.

5. **Check: Agenda note is posted on the ticket:**
   - The task chatter should contain a daily agenda note generated by Claude (Haiku tier).
   - `x_last_agenda_date` should be updated to today.

6. **Advance to WBS Done:**
   - Set `x_ticket_status` to `wbs_done` on the task.
   - The automated action `Sales AI - WBS Done` fires and posts: `"WBS marked as done. You can now request an AI-generated proposal."`.

7. **Click "Request Proposal from AI":**
   - On the task form, click the **Request Proposal from AI** button (calls `action_request_proposal_from_ai()`).
   - Prerequisites: `x_ticket_status` must be `wbs_done`, `x_wbs_sheet_url` must be set, and `x_linked_lead_id` must exist. Otherwise, a `UserError` is raised.
   - `x_ticket_status` changes to `ready_for_proposal`.
   - An n8n webhook is triggered: `proposal_request` with payload:
     ```json
     {
       "ticket_id": 456,
       "ticket_name": "Presale - Acme Corp",
       "ticket_description": "...",
       "lead_id": 123,
       "wbs_sheet_url": "https://docs.google.com/spreadsheets/..."
     }
     ```

8. **Check: n8n receives the webhook and processes the proposal generation.**

9. **Check logs on failure:**
   ```
   ERROR ... Failed generating ticket gist for task 456
   ERROR ... Ticket gist generation failed for task 456
   ERROR ... Agenda generation failed for task 456
   ERROR ... Agenda Claude call failed for task 456
   ```

---

## Test 10: Presale Agenda (10:30 AM Cron)

**Goal:** Verify the daily presale agenda cron posts agendas on active presale tickets.

**Cron Job:** `Sales AI - Daily Presale Agenda` (XML ID: `sales_ai_integration.ir_cron_sales_ai_presale_agenda`), scheduled at 10:30 UTC daily.

### Steps

1. **Activate the cron:**
   - Navigate to **Settings > Technical > Scheduled Actions**.
   - Find `Sales AI - Daily Presale Agenda`.
   - Set **Active** to True.

2. **Ensure there are tickets with active presale status:**
   - At least one `project.task` should have `x_ticket_status` in `['open', 'ready_for_wbs', 'wbs_done']`.

3. **Trigger manually:**
   - Click **Run Manually** on the cron record.

4. **Check: Agenda is posted on each qualifying ticket:**
   - Open each ticket's chatter.
   - A new note should appear with the daily agenda (generated by Claude Haiku).
   - Content is based on recent ticket activity + linked lead activity since `x_last_agenda_date`.

5. **Check: `x_last_agenda_date` is updated to today.**

6. **Check: Subscribers are notified:**
   - Since the agenda is posted via `message_post()` with `subtype_xmlid="mail.mt_note"`, followers of the ticket who are subscribed to internal notes will receive a notification.

---

## Test 11: Closure Retrospective

**Goal:** Verify that Won and Lost leads trigger an AI-generated retrospective.

### Won Lead Retro

**Automated Action:** `Sales AI - Lead Closure Retro (Won)` (XML ID: `sales_ai_integration.auto_sales_ai_closure_retro`) -- triggers `on_write` when stage changes to a won stage. **Note: This automation is `active=False` by default and must be activated.**

1. **Activate the automated action:**
   - Go to **Settings > Technical > Automated Actions**.
   - Find `Sales AI - Lead Closure Retro (Won)`.
   - Set **Active** to True.

2. **Mark a lead as Won:**
   - Move a lead to the "Won" stage in the CRM pipeline.

3. **Check: Retrospective is generated and posted:**
   - Open the lead chatter (or the linked presale ticket chatter if `x_presale_ticket_id` is set).
   - An internal note should contain the retro HTML generated by Claude (Sonnet tier).
   - If a presale ticket is linked, `x_retro_logged` on the ticket is set to True.

### Lost Lead Retro

**Mechanism:** The `write()` override in `CrmLeadLifecycle` detects when `active` is set to `False` (Odoo archives leads when marking them Lost). This is necessary because `base.automation` on_write skips archived records.

4. **Mark a different lead as Lost:**
   - Click "Lost" on a lead in the pipeline.
   - Odoo sets `active=False`.

5. **Check: Retrospective is generated and posted:**
   - The retro is generated via `action_generate_closure_retro()` called from the `write()` override.
   - View the lead (enable "Show Archived" filter) and check chatter.

6. **Check logs on failure:**
   ```
   ERROR ... Closure retro failed for lead 123
   ERROR ... Lost-lead retro failed
   ```

---

## Test 12: Email Smart Routing (`mail_smart_link`)

**Goal:** Verify that new inbound emails from known customers are routed to existing active leads instead of creating duplicates.

**Mechanism:** The `message_new()` override in `CrmLeadSmartLink` (in the `mail_smart_link` module) intercepts new email-created leads.

### Steps

1. **Send a NEW email (not a reply) from a known customer email:**
   - Use an email address that matches `email_from` on an existing active lead.
   - Send to the sales@ alias (or whatever alias creates leads).
   - This must be a fresh email, not a reply to an existing thread (replies are handled by Odoo's thread routing).

2. **Check: Email is routed to the existing active lead:**
   - Open the existing lead.
   - The new email should appear as a message in the lead's chatter.
   - No new duplicate lead should be created.

3. **Check logger output:**
   ```
   INFO ... mail_smart_link: Email from contact@example.com routed to existing lead Acme Inquiry (id=123)
   ```

4. **Send an email from an unknown sender:**
   - Use an email address that does not match any existing lead or partner.
   - A new lead should be created normally via the default `message_new()` behavior.

5. **Matching logic details:**
   - If a `res.partner` exists for the sender email, the search uses both `partner_id` match and `email_from` match (OR condition).
   - If no partner exists, it searches only by `email_from`.
   - Only `active=True` leads are considered.
   - The most recent lead (`order="id desc", limit=1`) is used if multiple matches exist.

---

## Test 13: Stale Deal Monitor

**Goal:** Verify that leads stuck in a stage beyond the configured threshold appear in the stale deals endpoint.

**Endpoint:** `GET/POST /api/sales_ai/stale_deals`

### Steps

1. **Set stale thresholds in Settings > Sales AI:**
   - Populate the **Stale Deal Thresholds (JSON)** field, e.g.:
     ```json
     {"Qualified": 7, "Meeting": 10, "Proposal": 14}
     ```
   - This is stored as `sales_ai.stale_thresholds_json`.

2. **Create a lead stuck in a stage beyond the threshold:**
   - Place a lead in the "Qualified" stage.
   - Ensure its `write_date` is more than 7 days ago (you may need to adjust this via the Odoo shell for testing).

3. **Call the `/api/sales_ai/stale_deals` endpoint:**
   ```bash
   curl -X POST https://<odoo>/api/sales_ai/stale_deals \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer <odoo_api_key>" \
     -d '{"jsonrpc": "2.0", "params": {}}'
   ```

4. **Check: The lead appears in the response:**
   ```json
   [
     {
       "lead_id": 123,
       "lead_name": "Acme Corp Inquiry",
       "stage": "Qualified",
       "salesperson": "John Doe",
       "days_stuck": 12,
       "email": "john@company.com"
     }
   ]
   ```

5. **Test with no stale leads:** all leads recently updated should return an empty list.

---

## Test 14: Escalation Cron

**Goal:** Verify that overdue follow-up activities trigger escalation notifications to n8n (for Teams alerts).

**Cron Job:** `Sales AI - Human Pause Escalations` (XML ID: `sales_ai_integration.ir_cron_sales_ai_escalations`), scheduled at 08:00 UTC daily.

### Steps

1. **Create overdue follow-up activities:**
   - Ensure there are activities of type `activity_type_followup_email` or `activity_type_presale_email` with:
     - `date_deadline` before today
     - `note` starting with `AI DRAFT`

2. **Activate and run the escalation cron:**
   - Navigate to **Settings > Technical > Scheduled Actions**.
   - Find `Sales AI - Human Pause Escalations`.
   - Set **Active** to True, then click **Run Manually**.

3. **Check: n8n receives escalation webhooks:**
   - **1 day overdue:** n8n receives `teams_followup_overdue` with `level: "warning"`.
   - **2+ days overdue:** n8n receives `teams_followup_overdue_manager` with `level: "urgent"`.
   - Payload structure:
     ```json
     {
       "lead_id": 123,
       "lead_name": "Acme Inquiry",
       "rep": "John Doe",
       "days_overdue": 2,
       "level": "urgent"
     }
     ```

4. **Additional escalation types handled by the same cron:**

   - **Overdue MOM reviews** (activity type `activity_type_client_mom`):
     - 4-24 hours overdue: `teams_mom_overdue` (warning)
     - 24+ hours overdue: `teams_mom_overdue_manager` (urgent)

   - **Stale WBS tickets** (`x_ticket_status = "ready_for_wbs"` for too long):
     - At 2 days: `teams_wbs_stale` (warning)
     - At 4 or 7 days: `teams_wbs_stale` (urgent)

5. **Check logs on n8n failure:**
   ```
   ERROR ... n8n POST to https://n8n.internal/webhook/teams_followup_overdue failed: ...
   ```

---

## Test 15: Attachment Handling

**Goal:** Verify that attachments on leads have their text extracted and cached.

**Note:** Attachment extraction relies on the `x_attachment_summaries` field. Check the implementation for the exact extraction mechanism (PDF text extraction, OCR for images, etc.).

### Steps

1. **Upload a PDF, DOC, or image attachment to a lead:**
   - Open a lead and attach a file via the chatter attachment button.

2. **Check: Text is extracted and cached in `x_attachment_summaries`:**
   - Inspect the lead's `x_attachment_summaries` field (may need to check via Odoo shell or developer mode).
   - The field should contain extracted text keyed by attachment.

3. **Trigger an AI action that needs attachment context:**
   - For example, trigger a follow-up draft or MOM generation that references attachments.

4. **Check: Cached text is used (not re-extracted):**
   - On subsequent AI calls, the system should use the cached summaries rather than re-processing the files.
   - Check logs to confirm no redundant extraction calls.

---

## Test 16: n8n Authentication

**Goal:** Verify bidirectional authentication between Odoo and n8n.

### n8n to Odoo (API Key Auth)

1. **Test with valid API key:**
   ```bash
   curl -X POST https://<odoo>/api/sales_ai/stale_deals \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer <valid_odoo_api_key>" \
     -d '{"jsonrpc": "2.0", "params": {}}'
   ```
   - Should return a valid JSON response (200 OK).

2. **Test without API key:**
   ```bash
   curl -X POST https://<odoo>/api/sales_ai/stale_deals \
     -H "Content-Type: application/json" \
     -d '{"jsonrpc": "2.0", "params": {}}'
   ```
   - Should return 401 Unauthorized or 403 Forbidden.

3. **Test with invalid API key:**
   ```bash
   curl -X POST https://<odoo>/api/sales_ai/stale_deals \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer INVALID_KEY_HERE" \
     -d '{"jsonrpc": "2.0", "params": {}}'
   ```
   - Should return 401 or 403.

### Odoo to n8n (Header Auth + HMAC)

4. **Trigger any Odoo-to-n8n call** (e.g., by creating a genuine lead to trigger `enrich_lead`).

5. **Check: `X-N8N-Secret` header is present:**
   - In n8n, inspect the incoming webhook request headers.
   - The `X-N8N-Secret` header should match the value configured in `sales_ai.n8n_secret_token`.

6. **Check: `X-Odoo-Signature` header is present:**
   - The header value should be `sha256=<hex>` where the hex is the HMAC-SHA256 of the JSON body using `sales_ai.n8n_hmac_secret`.
   - Verify in n8n with a Code node:
     ```javascript
     const crypto = require('crypto');
     const expectedSig = 'sha256=' + crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
     ```

7. **Check: `X-Odoo-Timestamp` header is present:**
   - Contains a Unix timestamp. n8n should reject requests where the timestamp is more than 5 minutes old (configure this in n8n).

---

## Logging Verification

For every test above, monitor the Odoo server log for entries from the `sales_ai_integration` and `mail_smart_link` modules. All loggers use `logging.getLogger(__name__)` so log entries are prefixed with the module path.

### How to Monitor Logs

```bash
tail -f /var/log/odoo/odoo-server.log | grep -E "(sales_ai|mail_smart_link|claude)"
```

Or if running Odoo directly:
```bash
./odoo-bin --log-level=debug --log-handler=odoo.addons.sales_ai_integration:DEBUG --log-handler=odoo.addons.mail_smart_link:DEBUG
```

### Expected Log Messages by Test

| Test | Log Level | Expected Message Pattern |
|------|-----------|--------------------------|
| 1 - Junk filter failure | WARNING | `Junk filter call failed; defaulting to genuine.` |
| 1 - Apollo enrichment failure | ERROR | `Apollo enrichment failed for lead <id>` |
| 2 - Scoring failure | ERROR | `Lead scoring failed for lead <id>` |
| 3 - Auto-ack failure | ERROR | `Auto-ack generation failed for lead <id>` |
| 5 - Cron draft failure | ERROR | `Failed drafting follow-up for activity <id>` |
| 5 - Draft generation failure | ERROR | `Follow-up draft generation failed for lead <id>` |
| 6 - Reply intent failure | ERROR | `Reply intent classification failed for lead <id>` |
| 7 - Calendar link success | INFO | `Sales AI: calendar event <id> auto-linked to lead <id>` |
| 8 - MOM failure | ERROR | `Client MOM generation failed for lead <id>` |
| 9 - Ticket gist failure | ERROR | `Ticket gist generation failed for task <id>` |
| 9 - Agenda failure | ERROR | `Agenda Claude call failed for task <id>` |
| 9 - Presale email failure | ERROR | `Presale email draft failed for task <id> / lead <id>` |
| 11 - Retro failure (won) | ERROR | `Closure retro failed for lead <id>` |
| 11 - Retro failure (lost) | ERROR | `Lost-lead retro failed` |
| 12 - Smart link routing | INFO | `mail_smart_link: Email from <email> routed to existing lead <name> (id=<id>)` |
| 14 - n8n call failure | ERROR | `n8n POST to <url> failed: <exception>` |
| 16 - No n8n URL configured | WARNING | `n8n base URL not configured; skipping call to <endpoint>` |
| Any - No API key | WARNING | `Claude API key not configured (sales_ai.claude_api_key).` |
| Any - SDK missing | ERROR | `Anthropic SDK import failed: <exception>` |
| Any - Claude API error | ERROR | `Claude API error for tier <tier>: <exception>` |
| Any - JSON parse failure | ERROR | `Failed to parse JSON from Claude response: <exception>` |

---

## Common Issues and Troubleshooting

### Claude API Key Not Set
- **Symptom:** All AI-powered features return empty/default values. No emails are drafted, no scoring happens, junk filter defaults everything to "genuine".
- **Log:** `WARNING ... Claude API key not configured (sales_ai.claude_api_key).`
- **Fix:** Go to Settings > Sales AI and enter a valid Anthropic API key. Verify the `anthropic` Python package is installed in the Odoo environment (`pip install anthropic`).

### n8n Webhook URL Not Configured
- **Symptom:** No outbound calls are made to n8n. Apollo enrichment never triggers. Proposal requests silently do nothing.
- **Log:** `WARNING ... n8n base URL not configured; skipping call to enrich_lead`
- **Fix:** Set `sales_ai.n8n_webhook_base_url` in Settings > Sales AI (e.g., `https://n8n.internal`).

### Cron Jobs Are Inactive by Default
- **Symptom:** Follow-up drafts never appear. Presale agendas never generate. Escalations never fire.
- **Cause:** All three cron jobs ship with `active=False`:
  - `Sales AI - Draft Follow-up Emails` (09:00 UTC)
  - `Sales AI - Daily Presale Agenda` (10:30 UTC)
  - `Sales AI - Human Pause Escalations` (08:00 UTC)
- **Fix:** Go to Settings > Technical > Scheduled Actions and activate each one manually.

### Won Retro Automated Action Is Inactive by Default
- **Symptom:** Marking a lead as Won does not generate a retrospective.
- **Cause:** The `Sales AI - Lead Closure Retro (Won)` automated action ships with `active=False`.
- **Fix:** Go to Settings > Technical > Automated Actions and activate it. (Lost retros work regardless because they use a Python `write()` override.)

### Apollo API Rate Limit (600/hour)
- **Symptom:** Enrichment calls fail or return empty data during high lead volume.
- **Fix:** Check n8n retry logic. Implement exponential backoff in the n8n workflow. Monitor Apollo usage dashboard.

### API Key Auth Fails for n8n Service User
- **Symptom:** n8n callbacks to Odoo return 401/403.
- **Fix:**
  1. Verify the API key was created for the correct user (the `n8n_service` user).
  2. Verify the user has sufficient access rights (read/write on `crm.lead` and `project.task`).
  3. Verify the `Authorization: Bearer <key>` header is correctly set in n8n.
  4. Check that the API key has not been revoked in Settings > Technical > API Keys.

### Follow-ups Not Created on Assignment
- **Symptom:** Lead is assigned to a rep but no follow-up activities appear.
- **Cause:** `x_lead_score_band` is not set yet (enrichment/scoring not complete). The `action_create_followup_activities()` method exits early if `lead.x_lead_score_band` is falsy.
- **Fix:** Wait for Apollo enrichment + scoring to complete. The scoring method will retroactively create follow-ups if it detects the lead is assigned but has none.

### Email Smart Link Not Working
- **Symptom:** Duplicate leads created for known customers.
- **Cause:** The `mail_smart_link` module may not be installed, or the email address format does not match (the match is case-insensitive via `=ilike`).
- **Fix:** Verify the module is installed. Check that the sender's email in the lead's `email_from` field matches what the customer sends from. Check for whitespace or formatting differences.

### Discussion Sync to Presale Ticket Fails
- **Symptom:** Customer emails on a lead are not reflected in the linked presale ticket.
- **Log:** `ERROR ... Discussion sync failed for lead <id> ticket <id>`
- **Fix:** Check that `x_presale_ticket_id` is set on the lead. Verify Claude API is working. The sync only happens for external inbound emails, not internal notes or outbound emails.

### HMAC Signature Mismatch
- **Symptom:** n8n rejects Odoo webhooks despite correct secrets.
- **Fix:** Ensure `sales_ai.n8n_hmac_secret` in Odoo matches the secret configured in the n8n Code/verification node. The signature is computed as `sha256=` + `HMAC-SHA256(secret, raw_json_body)`. Also check `X-Odoo-Timestamp` -- if the n8n workflow rejects timestamps older than 5 minutes, ensure clocks are synchronized.
