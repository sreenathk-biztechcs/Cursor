# Sales AI Integration — Claude Code Project Context

This is the working directory for the Inbound Sales Automation system built on
Odoo 19 Community Edition + Claude AI + n8n.

## Architecture

```
Lead In → n8n (Apollo API) → Odoo (Enrich + Classify + Score) → Follow-ups → Presale → Proposal → Won/Lost Retro
```

- **Two Odoo modules**: `sales_ai_integration` (main), `mail_smart_link` (email routing)
- **Claude AI**: called via `claude.service` AbstractModel (Anthropic Python SDK)
- **n8n**: external automation for Apollo API, Google Drive, Teams notifications
- **All presale data lives on the CRM lead** (no project.task for presale)

## Key Files

| File | Purpose |
|------|---------|
| `sales_ai_integration/models/crm_lead.py` | Core business logic — all AI actions on leads |
| `sales_ai_integration/models/claude_service.py` | Claude API wrapper (haiku/sonnet/opus + vision) |
| `sales_ai_integration/models/prompts.py` | All AI system prompts — edit these to tune behavior |
| `sales_ai_integration/controllers/webhook_controller.py` | n8n → Odoo HTTP endpoints (auth=api_key) |
| `sales_ai_integration/models/n8n_webhook.py` | Odoo → n8n outbound calls (HMAC signed) |
| `mail_smart_link/models/crm_lead.py` | Smart email routing to prevent duplicate leads |

## n8n ↔ Odoo Authentication

- **n8n → Odoo**: Odoo API key (`auth="api_key"`, `Authorization: Bearer <key>`)
- **Odoo → n8n**: `X-N8N-Secret` header + `X-Odoo-Signature` HMAC-SHA256

## Apollo API Integration (via n8n)

n8n uses two Apollo endpoints:
- `POST https://api.apollo.io/api/v1/people/match` — Person enrichment (email, name, domain)
- `GET https://api.apollo.io/api/v1/organizations/enrich` — Company enrichment (domain)

Apollo auth: `x-api-key: <apollo_api_key>` header. Rate limit: 600 calls/hour.

## Lead Flow (23 steps)

1. Lead created → automation sends to n8n
2. n8n queries Apollo Person + Org APIs
3. n8n calls back `/api/sales_ai/lead_intake_complete`
4. Odoo enriches fields from Apollo data
5. Claude classifies: genuine / marketing / junk
6. If genuine → Claude scores 0-100 (hot/warm/cold)
7. Lead assigned to rep (round-robin)
8. Auto-ack email sent with rep's calendar link
9. 3 follow-up activities created (business days, adjusted by score band)
10. Daily 9 AM cron drafts follow-up emails into activities
11. Customer reply → cancel follow-ups → classify intent → reschedule
12. Meeting recorded → transcript sent via n8n → MOM generated
13. Presale opened on lead → discussion gist generated
14. Daily 10:30 AM agenda posted on presale leads
15. Presale meeting MOM → draft client email activity
16. WBS generated in Google Sheets → URL stored on lead
17. "Request Proposal" → n8n generates proposal → URL stored on lead
18. Won/Lost → full retrospective posted on lead

## Conventions

- All AI calls go through `self._claude().call(tier, system_prompt, user_message, ...)`
- All n8n outbound calls go through `self._n8n().post(endpoint, payload)`
- Prompts are in `prompts.py` — never hardcode prompts in business models
- Logger: use `logging.getLogger("sales_ai")` everywhere
- All presale data is on `crm.lead` (x_presale_status, x_wbs_sheet_url, etc.)
- Webhook endpoints use `auth="api_key"` — no custom auth headers for inbound

## Testing

See `README_TESTING.md` for step-by-step testing guide.

## MOM Format Standard

All MOMs (client meetings and presale) must follow:
1. Header: Date, Time, Duration
2. Attendees: Name + Role/Company
3. Discussion Points: Numbered, grouped by topic
4. Decisions Made: Bullet list
5. Action Items: Table (Action | Owner | Deadline)
6. Next Steps: What happens next + dates
7. Key Signals (internal only): Budget hints, timeline, objections
