# -*- coding: utf-8 -*-

import base64

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class DocumentTextEditor(models.TransientModel):
    _name = 'document.text.editor'
    _description = 'Document Text Editor'

    document_id = fields.Many2one('document.file', required=True, ondelete='cascade')
    content = fields.Text(string='Content', required=True)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        doc = self.env['document.file'].browse(self.env.context.get('active_id')).exists()
        if not doc:
            return res
        res['document_id'] = doc.id
        raw = doc.attachment or (doc.attachment_id.datas if doc.attachment_id else False)
        if raw:
            try:
                res['content'] = base64.b64decode(raw).decode('utf-8', errors='ignore')
            except Exception:
                res['content'] = ''
        else:
            res['content'] = ''
        return res

    def action_save(self):
        self.ensure_one()
        doc = self.document_id.exists()
        if not doc:
            raise UserError(_('Document not found.'))
        encoded = base64.b64encode((self.content or '').encode('utf-8'))
        vals = {'attachment': encoded}
        # Keep attachment_id in sync when present
        if doc.attachment_id:
            doc.attachment_id.sudo().write({'datas': encoded, 'mimetype': doc.mimetype or 'text/plain'})
        doc.sudo().write(vals)
        return {'type': 'ir.actions.act_window_close'}

