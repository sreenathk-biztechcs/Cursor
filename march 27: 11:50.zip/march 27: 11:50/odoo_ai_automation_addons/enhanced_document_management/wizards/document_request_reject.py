# -*- coding: utf-8 -*-
#############################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2025-TODAY Cybrosys Technologies(<https://www.cybrosys.com>)
#    Author: Mruthul Raj(<https://www.cybrosys.com>)
#
#    You can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
#############################################################################
from odoo import fields, models


class DocumentRequestReject(models.TransientModel):
    """model help to reject document request"""
    _name = 'document.request.reject'
    _description = 'Document Request Reject Wizard'

    reject_reason = fields.Text(string='Reject Reason',
                                help="store reject reason", required=True)
    document_request_id = fields.Many2one('request.document')

    def action_reject_request(self):
        """Method used to reject a document request"""
        self.document_request_id.state = 'rejected'
        self.document_request_id.reject_reason = self.reject_reason
