import json
import logging
import time
from typing import Any, Dict, Optional, Union

from odoo import api, models

_logger = logging.getLogger("sales_ai")


class ClaudeService(models.AbstractModel):
    """
    Central service for calling Anthropic Claude.

    Always use env['claude.service'].call(...) from business code.
    """

    _name = "claude.service"
    _description = "Claude AI Service"

    ALLOWED_MODELS = {
        "haiku": "claude-haiku-4-5-20251001",
        "sonnet": "claude-sonnet-4-6",
    }

    BLOCKED_TIERS = ("opus",)

    @api.model
    def _get_api_key(self) -> Optional[str]:
        return (
            self.env["ir.config_parameter"]
            .sudo()
            .get_param("sales_ai.claude_api_key", default="")
        ) or None

    @api.model
    def _get_client(self):
        """Return an Anthropic client instance or None if not configured."""
        api_key = self._get_api_key()
        if not api_key:
            _logger.error(
                "sales_ai: [CONFIG ERROR] Claude API key is NOT set. "
                "Fix: Settings → Technical → System Parameters → sales_ai.claude_api_key. "
                "All AI classification, scoring, and email generation will be SKIPPED until this is set."
            )
            return None
        try:
            from anthropic import Anthropic
        except Exception as exc:  # pragma: no cover
            _logger.error("Anthropic SDK import failed: %s", exc)
            return None
        return Anthropic(api_key=api_key)

    @api.model
    def _resolve_model(self, tier: str) -> str:
        """Resolve tier name to model ID. Blocks Opus; falls back to Sonnet."""
        if tier in self.BLOCKED_TIERS:
            _logger.warning(
                "sales_ai: [MODEL-BLOCK] tier '%s' is BLOCKED — falling back to 'sonnet'",
                tier,
            )
            tier = "sonnet"
        model_name = self.ALLOWED_MODELS.get(tier)
        if not model_name:
            raise ValueError(
                f"Unsupported Claude tier: {tier}. Allowed: {list(self.ALLOWED_MODELS)}"
            )
        return model_name

    @api.model
    def _log_usage(self, tier: str, model_name: str, usage, elapsed_s: float):
        """Log model + token usage after every API call."""
        in_tok = getattr(usage, "input_tokens", 0)
        out_tok = getattr(usage, "output_tokens", 0)
        cache_create = getattr(usage, "cache_creation_input_tokens", 0)
        cache_read = getattr(usage, "cache_read_input_tokens", 0)
        _logger.info(
            "sales_ai: [USAGE] tier=%s model=%s "
            "input_tokens=%d output_tokens=%d "
            "cache_create=%d cache_read=%d "
            "elapsed=%.2fs",
            tier, model_name, in_tok, out_tok,
            cache_create, cache_read, elapsed_s,
        )

    @api.model
    def call(
        self,
        tier: str,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 2000,
        expect_json: bool = False,
        temperature: float = 0.2,
    ) -> Union[str, Dict[str, Any]]:
        """
        Call Claude with the given tier and prompts.

        Opus is hard-blocked — any call with tier='opus' falls back to Sonnet.
        Prompt caching is explicitly disabled via cache_control headers.
        Every call logs: model used, input/output tokens, elapsed time.
        """
        model_name = self._resolve_model(tier)

        client = self._get_client()
        if not client:
            return {} if expect_json else ""

        _logger.info(
            "sales_ai: [CALL START] tier=%s → model=%s max_tokens=%d expect_json=%s",
            tier, model_name, max_tokens, expect_json,
        )

        t0 = time.time()
        try:
            resp = client.messages.create(
                model=model_name,
                max_tokens=max_tokens,
                temperature=temperature,
                system=[{
                    "type": "text",
                    "text": system_prompt or "",
                    "cache_control": None,
                }] if system_prompt else None,
                messages=[{"role": "user", "content": user_message}],
            )
        except Exception as exc:  # pragma: no cover
            elapsed = time.time() - t0
            _logger.error(
                "sales_ai: [CALL FAILED] tier=%s model=%s elapsed=%.2fs error=%s",
                tier, model_name, elapsed, exc, exc_info=True,
            )
            raise

        elapsed = time.time() - t0
        self._log_usage(tier, model_name, resp.usage, elapsed)

        text_parts = []
        for block in resp.content:
            text = getattr(block, "text", None) or getattr(block, "value", None)
            if text:
                text_parts.append(text)

        raw = "\n".join(text_parts).strip()

        if not raw and expect_json:
            _logger.warning(
                "sales_ai: [RETRY] empty response for tier=%s; retrying once...", tier
            )
            t0 = time.time()
            try:
                resp = client.messages.create(
                    model=model_name,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    system=[{
                        "type": "text",
                        "text": system_prompt or "",
                        "cache_control": None,
                    }] if system_prompt else None,
                    messages=[{"role": "user", "content": user_message}],
                )
                elapsed = time.time() - t0
                self._log_usage(tier, model_name, resp.usage, elapsed)

                text_parts = []
                for block in resp.content:
                    text = getattr(block, "text", None) or getattr(block, "value", None)
                    if text:
                        text_parts.append(text)
                raw = "\n".join(text_parts).strip()
            except Exception as retry_exc:
                _logger.error("sales_ai: [RETRY FAILED] %s", retry_exc)

        if not expect_json:
            return raw

        parsed = self._extract_json(raw)
        if parsed is not None:
            return parsed

        _logger.error(
            "sales_ai: Failed to parse JSON from Claude response. "
            "Raw length=%d chars, first 200 chars: %s",
            len(raw), raw[:200] if len(raw) > 200 else raw,
        )
        return {}

    @api.model
    def _extract_json(self, raw: str) -> Optional[Dict[str, Any]]:
        """Best-effort JSON extraction from a Claude response.

        Handles:
        1. Clean JSON
        2. ```json ... ``` fenced blocks
        3. Leading prose before the JSON object (e.g. "Here is the result: {...")
        4. Truncated JSON from max_tokens — attempts brace-completion
        """
        if not raw or not raw.strip():
            return None

        text = raw.strip()

        # 1. Strip markdown fences
        if text.startswith("```"):
            text = text.lstrip("`")
            if text.startswith("json"):
                text = text[4:]
            # Remove trailing fence
            if text.rstrip().endswith("```"):
                text = text.rstrip()[:-3]
            text = text.strip()

        # 2. Try direct parse first
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            pass

        # 3. Find the first { and try parsing from there
        brace_start = text.find("{")
        if brace_start == -1:
            return None

        json_candidate = text[brace_start:]

        try:
            return json.loads(json_candidate)
        except (json.JSONDecodeError, ValueError):
            pass

        # 4. JSON may be truncated by max_tokens — try closing open braces/brackets
        repaired = self._repair_truncated_json(json_candidate)
        if repaired:
            try:
                return json.loads(repaired)
            except (json.JSONDecodeError, ValueError):
                pass

        return None

    @staticmethod
    def _repair_truncated_json(text: str) -> Optional[str]:
        """Attempt to close truncated JSON by balancing braces and brackets.

        Only tries simple repairs: strip trailing comma, close open
        strings, arrays, objects.  Returns None if repair seems hopeless.
        """
        if not text:
            return None

        # Strip trailing whitespace and incomplete key/value tokens
        repaired = text.rstrip()

        # Remove trailing comma if any
        if repaired.endswith(","):
            repaired = repaired[:-1]

        # Close any unclosed string (look for unbalanced quotes)
        quote_count = repaired.count('"') - repaired.count('\\"')
        if quote_count % 2 != 0:
            repaired += '"'

        # Count open braces/brackets and close them
        open_braces = repaired.count("{") - repaired.count("}")
        open_brackets = repaired.count("[") - repaired.count("]")

        if open_braces < 0 or open_brackets < 0:
            return None  # malformed, not just truncated

        # Close in reverse order of likely nesting (brackets first, then braces)
        repaired += "]" * open_brackets
        repaired += "}" * open_braces

        return repaired if open_braces > 0 or open_brackets > 0 else None

    @api.model
    def call_vision(
        self,
        image_b64: str,
        media_type: str,
        prompt: str,
        max_tokens: int = 500,
    ) -> str:
        """
        Call Claude with an image (base64-encoded) for visual analysis.
        Always uses Haiku (cheapest model).
        """
        client = self._get_client()
        if not client:
            return ""

        model_name = self.ALLOWED_MODELS["haiku"]
        _logger.info("sales_ai: [VISION START] model=%s", model_name)

        t0 = time.time()
        try:
            resp = client.messages.create(
                model=model_name,
                max_tokens=max_tokens,
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": prompt,
                        },
                    ],
                }],
            )
        except Exception as exc:
            elapsed = time.time() - t0
            _logger.error(
                "sales_ai: [VISION FAILED] model=%s elapsed=%.2fs error=%s",
                model_name, elapsed, exc, exc_info=True,
            )
            return ""

        elapsed = time.time() - t0
        self._log_usage("haiku", model_name, resp.usage, elapsed)

        text_parts = []
        for block in resp.content:
            text = getattr(block, "text", None) or getattr(block, "value", None)
            if text:
                text_parts.append(text)
        return "\n".join(text_parts).strip()
