import re
from typing import Dict, List, Tuple


_RE_TS_SPK = re.compile(r"^\s*\[(?P<ts>[0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)\]\s*(?P<spk>[^:]{1,60})\s*:\s*(?P<txt>.+?)\s*$")
_RE_SPK = re.compile(r"^\s*(?P<spk>[^:]{1,60})\s*:\s*(?P<txt>.+?)\s*$")


def _norm_for_dedupe(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s


def prune_transcript_text(transcript: str, max_chars: int = 60000) -> str:
    """
    Heuristic pruning: remove greetings/filler/audio-check/repeated lines.
    Keeps decision/action/risk/timeline/question-heavy lines + substantive lines.
    """
    raw_lines = (transcript or "").splitlines()
    kept: List[str] = []
    seen = set()

    drop_prefixes = (
        "hello", "hi ", "thanks", "thank you", "good morning", "good afternoon",
        "good evening", "can you hear", "are you able to hear", "audio",
        "mic", "mute", "unmute", "screen share", "share my screen",
        "let's start", "lets start",
    )
    keep_keywords = (
        "we will", "we'll", "i will", "i'll", "you will", "you'll",
        "next step", "next steps", "action item", "todo", "to-do",
        "decision", "decided", "agree", "agreed", "commit", "committed",
        "timeline", "by ", "before ", "after ", "due ", "eta",
        "risk", "blocker", "concern", "issue",
        "question", "q:", "a:",
        "integration", "api", "migration", "scope", "out of scope",
        "requirements", "need to", "must", "should",
        "budget", "pricing", "cost", "quote",
    )

    for line in raw_lines:
        l = (line or "").strip()
        if not l:
            continue

        # Strip timestamps-only chatter like "[00:01]"
        if re.fullmatch(r"\[[0-9:\s]+\]", l):
            continue

        norm = _norm_for_dedupe(l)
        if norm in seen:
            continue

        # Drop obvious filler
        if len(norm) <= 3:
            continue
        if any(norm.startswith(p) for p in drop_prefixes) and len(norm) < 80:
            continue
        if norm in ("ok", "okay", "yeah", "yep", "sure", "right", "cool", "great") and len(norm) <= 5:
            continue

        # Keep if substantive, or keyword-rich
        is_keyword = any(k in norm for k in keep_keywords)
        is_substantive = len(norm) >= 40
        if not (is_keyword or is_substantive):
            continue

        seen.add(norm)
        kept.append(l)

        # Hard cap by characters to protect token budget
        if sum(len(x) + 1 for x in kept) >= max_chars:
            break

    return "\n".join(kept).strip()


def transcript_text_to_toon(transcript: str, max_segments: int = 300) -> Tuple[str, List[Dict[str, str]]]:
    """
    Convert transcript text into a compact "TOON" v1 line format plus structured segments.

    Returns:
      - toon_text: compact transport format (string)
      - segments: [{"ts": "...", "spk": "...", "txt": "..."}]
    """
    lines = (transcript or "").splitlines()
    segs: List[Dict[str, str]] = []

    for line in lines:
        s = (line or "").strip()
        if not s:
            continue

        ts = ""
        spk = ""
        txt = ""

        m = _RE_TS_SPK.match(s)
        if m:
            ts = (m.group("ts") or "").strip()
            spk = (m.group("spk") or "").strip()
            txt = (m.group("txt") or "").strip()
        else:
            m2 = _RE_SPK.match(s)
            if m2:
                spk = (m2.group("spk") or "").strip()
                txt = (m2.group("txt") or "").strip()
            else:
                txt = s

        if not txt:
            continue

        # Merge consecutive same speaker to reduce tokens
        if segs and spk and segs[-1].get("spk") == spk and not ts:
            segs[-1]["txt"] = (segs[-1].get("txt") or "") + " " + txt
        else:
            segs.append({"ts": ts, "spk": spk or "unk", "txt": txt})

        if len(segs) >= max_segments:
            break

    # Compact line transport: one segment per line
    toon_lines = ["@toon1"]
    for seg in segs:
        ts = seg.get("ts") or ""
        spk = seg.get("spk") or "unk"
        txt = (seg.get("txt") or "").replace("\n", " ").strip()
        txt = re.sub(r"\s+", " ", txt)
        if len(txt) > 180:
            txt = txt[:177] + "..."
        toon_lines.append(f"{ts}|{spk}|{txt}")

    return "\n".join(toon_lines), segs

