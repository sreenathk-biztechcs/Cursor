import logging
from collections import defaultdict

import requests

from odoo import api, fields, models
from odoo.tools import html2plaintext


_logger = logging.getLogger("sales_ai")


class SalesAiStaleLeadChecker(models.TransientModel):
    _name = "sales.ai.stale.lead.checker"
    _description = "Stale Lead Detection Service"

    @api.model
    def run_daily_check(self):
        ICP = self.env["ir.config_parameter"].sudo()
        enabled = (ICP.get_param("sales_ai.stale_detection_enabled", "1") or "1").lower() in (
            "1",
            "true",
            "yes",
        )
        if not enabled:
            _logger.info("sales_ai: stale lead detection disabled by settings")
            return {"alerts": 0, "escalations": 0}

        Threshold = self.env["sales.ai.stale.threshold"].sudo()
        thresholds = Threshold.search([("active", "=", True)])
        if not thresholds:
            _logger.info("sales_ai: no active stale thresholds configured")
            return {"alerts": 0, "escalations": 0}

        today = fields.Date.today()
        Lead = self.env["crm.lead"].sudo()
        stage_ids = thresholds.mapped("stage_id").ids
        leads = Lead.search(
            [
                ("active", "=", True),
                ("probability", ">", 0),
                ("stage_id", "in", stage_ids),
            ]
        )
        if not leads:
            return {"alerts": 0, "escalations": 0}

        msg_map = self._get_last_message_map(leads.ids)
        thresholds_by_stage = {t.stage_id.id: t for t in thresholds}

        alerts_created = 0
        escalations = []
        for lead in leads:
            threshold = thresholds_by_stage.get(lead.stage_id.id)
            if not threshold:
                continue
            days_stuck = self._compute_days_stuck(lead, msg_map)
            if days_stuck <= threshold.alert_days:
                continue

            hot_limit = threshold.hot_lead_score_threshold or int(
                ICP.get_param("sales_ai.hot_lead_score_threshold", "90") or 90
            )
            is_hot = (lead.x_lead_score or 0) >= hot_limit
            is_escalation = days_stuck > threshold.escalation_days or is_hot
            reason = (
                "Hot lead stuck above threshold"
                if is_hot and days_stuck > threshold.alert_days
                else "2x threshold exceeded"
            )

            if self._ensure_stale_activity(lead, threshold, days_stuck):
                alerts_created += 1
            self._apply_action_type(lead, threshold, days_stuck)

            if is_escalation and lead.last_escalation_date != today:
                escalations.append(
                    {
                        "lead_id": lead.id,
                        "lead_name": lead.name or "",
                        "client_name": lead.partner_id.name if lead.partner_id else "",
                        "stage_name": lead.stage_id.name or "",
                        "days_stuck": days_stuck,
                        "rep_name": lead.user_id.name if lead.user_id else "Unassigned",
                        "manager_name": (
                            lead.team_id.user_id.name
                            if lead.team_id and lead.team_id.user_id
                            else "N/A"
                        ),
                        "score": lead.x_lead_score or 0,
                        "reason": reason,
                    }
                )
                lead.write({"last_escalation_date": today})

        self._send_teams_escalation(escalations)
        _logger.info(
            "sales_ai: stale lead checker complete alerts=%s escalations=%s",
            alerts_created,
            len(escalations),
        )
        return {"alerts": alerts_created, "escalations": len(escalations)}

    @api.model
    def get_stale_leads_summary(self):
        Threshold = self.env["sales.ai.stale.threshold"].sudo()
        thresholds = Threshold.search([("active", "=", True)])
        stage_ids = thresholds.mapped("stage_id").ids
        leads = self.env["crm.lead"].sudo().search(
            [("active", "=", True), ("probability", ">", 0), ("stage_id", "in", stage_ids)]
        )
        msg_map = self._get_last_message_map(leads.ids)
        by_stage = {}
        threshold_by_stage = {t.stage_id.id: t for t in thresholds}
        for lead in leads:
            th = threshold_by_stage.get(lead.stage_id.id)
            if not th:
                continue
            days_stuck = self._compute_days_stuck(lead, msg_map)
            if days_stuck <= th.alert_days:
                continue
            stage_name = lead.stage_id.name or "Unknown"
            by_stage.setdefault(stage_name, {"alert_count": 0, "escalation_count": 0, "leads": []})
            by_stage[stage_name]["alert_count"] += 1
            if days_stuck > th.escalation_days:
                by_stage[stage_name]["escalation_count"] += 1
            by_stage[stage_name]["leads"].append(
                {"id": lead.id, "name": lead.name or "", "days_stuck": days_stuck}
            )
        return by_stage

    def _get_last_message_map(self, lead_ids):
        if not lead_ids:
            return {}
        groups = self.env["mail.message"].sudo().read_group(
            [("model", "=", "crm.lead"), ("res_id", "in", lead_ids)],
            ["res_id", "date:max"],
            ["res_id"],
            lazy=False,
        )
        mapping = {}
        for row in groups:
            rid = row.get("res_id")
            if isinstance(rid, tuple):
                rid = rid[0]
            mapping[rid] = row.get("date:max")
        return mapping

    def _compute_days_stuck(self, lead, msg_map):
        now_dt = fields.Datetime.now()
        last_msg = msg_map.get(lead.id)
        if last_msg:
            return max(0, (now_dt - fields.Datetime.to_datetime(last_msg)).days)
        anchor = lead.stage_entered_date or lead.create_date or now_dt
        return max(0, (now_dt - fields.Datetime.to_datetime(anchor)).days)

    def _format_alert_message(self, lead, threshold, days_stuck):
        template = threshold.alert_message or (
            "Lead {lead_name} for {client_name} is stale in {stage_name} for {days_stuck} day(s)."
        )
        try:
            return template.format(
                lead_name=lead.name or "",
                client_name=lead.partner_id.name if lead.partner_id else "",
                days_stuck=days_stuck,
                stage_name=lead.stage_id.name or "",
                rep_name=lead.user_id.name if lead.user_id else "",
            )
        except Exception:
            return (
                "Lead %s is stale in %s for %s day(s)."
                % (lead.name or "", lead.stage_id.name or "", days_stuck)
            )

    def _ensure_stale_activity(self, lead, threshold, days_stuck):
        Activity = self.env["mail.activity"].sudo()
        model_id = self.env["ir.model"]._get_id("crm.lead")
        summary = "[Stale Lead] %s (%s day%s)" % (
            lead.stage_id.name or "Stage",
            days_stuck,
            "" if days_stuck == 1 else "s",
        )
        existing = Activity.search(
            [
                ("res_model_id", "=", model_id),
                ("res_id", "=", lead.id),
                ("user_id", "=", lead.user_id.id if lead.user_id else self.env.uid),
                ("date_deadline", ">=", fields.Date.today()),
                ("summary", "ilike", "[Stale Lead]"),
            ],
            limit=1,
        )
        if existing:
            return False

        note = self._format_alert_message(lead, threshold, days_stuck)
        extra = self._build_action_note(lead, threshold)
        if extra:
            note = "%s\n\n%s" % (note, extra)
        todo = self.env.ref("mail.mail_activity_data_todo", raise_if_not_found=False)
        Activity.create(
            {
                "res_model_id": model_id,
                "res_id": lead.id,
                "user_id": lead.user_id.id if lead.user_id else self.env.uid,
                "activity_type_id": todo.id if todo else False,
                "summary": summary,
                "note": note,
                "date_deadline": fields.Date.today(),
            }
        )
        return True

    def _build_action_note(self, lead, threshold):
        if threshold.action_type == "suggest_followup":
            return "Suggested next step: send a concise follow-up and propose 2 time slots."
        if threshold.action_type == "check_meeting":
            return self._meeting_check_note(lead)
        if threshold.action_type == "draft_email":
            return "AI follow-up draft requested. Review and send after validation."
        return ""

    def _meeting_check_note(self, lead):
        Event = self.env["calendar.event"].sudo()
        events = Event.search(
            [("x_linked_lead_id", "=", lead.id), ("stop", "!=", False)],
            order="stop desc",
            limit=3,
        )
        if not events:
            return "Meeting may not have occurred (no linked completed calendar event found)."
        has_mom = bool(lead.x_mom_last)
        if not has_mom:
            return "Meeting happened but no MOM recorded yet."
        return "Meeting completion found. Verify MOM follow-up was sent."

    def _apply_action_type(self, lead, threshold, days_stuck):
        if threshold.action_type != "draft_email":
            return
        self._trigger_followup_draft(lead, days_stuck)

    def _trigger_followup_draft(self, lead, days_stuck):
        try:
            Activity = self.env["mail.activity"].sudo()
            followup_type = self.env.ref(
                "sales_ai_integration.activity_type_followup_email",
                raise_if_not_found=False,
            )
            if not followup_type:
                return
            existing = Activity.search(
                [
                    ("res_model", "=", "crm.lead"),
                    ("res_id", "=", lead.id),
                    ("activity_type_id", "=", followup_type.id),
                    ("date_deadline", ">=", fields.Date.today()),
                ],
                limit=1,
            )
            if existing:
                return
            act = Activity.create(
                {
                    "res_model_id": self.env["ir.model"]._get_id("crm.lead"),
                    "res_id": lead.id,
                    "user_id": lead.user_id.id if lead.user_id else self.env.uid,
                    "activity_type_id": followup_type.id,
                    "summary": "Stale lead follow-up draft",
                    "note": (
                        "[AI-FOLLOWUP-PENDING] Auto-drafted due to stale lead at stage '%s' (%s days)."
                        % (lead.stage_id.name or "", days_stuck)
                    ),
                    "date_deadline": fields.Date.today(),
                }
            )
            lead._draft_single_followup_email(lead, act)
        except Exception:
            _logger.error(
                "sales_ai: failed triggering stale follow-up draft for lead %s",
                lead.id,
                exc_info=True,
            )

    def _send_teams_escalation(self, leads_data):
        if not leads_data:
            return
        ICP = self.env["ir.config_parameter"].sudo()
        webhook_url = (ICP.get_param("sales_ai.teams_escalation_webhook_url", "") or "").strip()
        if not webhook_url:
            _logger.warning("sales_ai: Teams webhook not configured. Skipping escalations.")
            return
        base_url = (ICP.get_param("web.base.url", "") or "").rstrip("/")
        today = fields.Date.today()

        grouped = defaultdict(list)
        for item in leads_data:
            grouped[item.get("manager_name") or "Unassigned Manager"].append(item)

        sections = []
        for manager, rows in grouped.items():
            sections.append("### Manager: %s" % manager)
            for row in rows:
                lead_url = "%s/web#id=%s&model=crm.lead&view_type=form" % (base_url, row["lead_id"])
                sections.append(
                    "- **%s** | Client: %s | Stage: %s | Days: %s | Score: %s | Rep: %s | Reason: %s | [Open](%s)"
                    % (
                        row["lead_name"] or "Lead",
                        row["client_name"] or "-",
                        row["stage_name"] or "-",
                        row["days_stuck"],
                        row["score"],
                        row["rep_name"],
                        row["reason"],
                        lead_url,
                    )
                )
        text = "## Stale Lead Escalation - %s\n\n%s" % (today, "\n".join(sections))
        payload = {"text": html2plaintext(text)}
        try:
            requests.post(
                webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=20,
            ).raise_for_status()
        except Exception:
            _logger.error("sales_ai: Teams escalation send failed", exc_info=True)

