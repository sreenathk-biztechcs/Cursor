import logging

from odoo import api, fields, models


_logger = logging.getLogger("sales_ai")


class SalesAiStaleThreshold(models.Model):
    _name = "sales.ai.stale.threshold"
    _description = "Stale Lead Detection Thresholds"
    _order = "sequence, id"

    name = fields.Char(required=True)
    sequence = fields.Integer(default=10)
    stage_id = fields.Many2one(
        "crm.stage",
        string="CRM Stage",
        required=True,
        ondelete="cascade",
    )
    alert_days = fields.Integer(
        string="Alert After (Days)",
        required=True,
        default=1,
    )
    escalation_days = fields.Integer(
        string="Escalate After (Days)",
        required=True,
        default=2,
    )
    action_type = fields.Selection(
        [
            ("alert_only", "Alert Rep Only"),
            ("suggest_followup", "Alert + Suggest Follow-up Action"),
            ("draft_email", "Alert + Auto-draft Follow-up Email"),
            ("check_meeting", "Alert + Check if Meeting Occurred"),
        ],
        default="alert_only",
        string="Action Type",
        required=True,
    )
    alert_message = fields.Text(
        string="Alert Message Template",
        help=(
            "Message shown in activity. Placeholders: {lead_name}, {client_name}, "
            "{days_stuck}, {stage_name}, {rep_name}"
        ),
    )
    active = fields.Boolean(default=True)
    hot_lead_score_threshold = fields.Integer(
        string="Hot Lead Score Threshold",
        default=90,
    )

    @api.constrains("alert_days", "escalation_days")
    def _check_days(self):
        for rec in self:
            if rec.alert_days < 1:
                rec.alert_days = 1
            if rec.escalation_days < rec.alert_days:
                rec.escalation_days = rec.alert_days * 2

    @api.model
    def action_seed_default_thresholds(self):
        """Seed defaults by stage name.
        # TODO: Verify stage names match your Odoo instance.
        """
        defaults = [
            ("New / Uncontacted Threshold", "New", 1, 2, "alert_only"),
            ("Contacted Threshold", "Contacted", 5, 10, "suggest_followup"),
            ("Meeting Scheduled Threshold", "Meeting Scheduled", 2, 4, "check_meeting"),
            ("MOM Sent Threshold", "MOM Sent", 3, 6, "draft_email"),
            ("Proposal Sent Threshold", "Proposal Sent", 7, 14, "draft_email"),
        ]
        Stage = self.env["crm.stage"].sudo()
        for seq, item in enumerate(defaults, start=1):
            name, stage_key, alert_days, escalation_days, action_type = item
            stage = Stage.search([("name", "ilike", stage_key)], limit=1)
            if not stage:
                _logger.warning(
                    "sales_ai: stale threshold seed skipped; stage not found for key '%s'",
                    stage_key,
                )
                continue
            exists = self.search([("stage_id", "=", stage.id)], limit=1)
            if exists:
                continue
            self.create(
                {
                    "name": name,
                    "sequence": seq * 10,
                    "stage_id": stage.id,
                    "alert_days": alert_days,
                    "escalation_days": escalation_days,
                    "action_type": action_type,
                    "alert_message": (
                        "Lead {lead_name} for {client_name} is stale in {stage_name} "
                        "for {days_stuck} day(s)."
                    ),
                    "active": True,
                }
            )
        return True

