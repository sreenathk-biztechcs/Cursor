from . import claude_service
from . import prompts
from . import sales_ai_agent_prompt
from . import crm_lead
from . import project_task
from . import helpdesk_ticket
from . import res_users
from . import res_partner
from . import mail_activity
from . import sales_ai_settings
from . import n8n_webhook
from . import calendar_meeting_linker
from . import meeting_transcript
from . import crm_lead_stale
from . import sales_ai_stale_threshold
from . import sales_ai_stale_lead_checker

