import base64
import os

from odoo import api, fields, models, _
from odoo.exceptions import UserError

from . import prompts


class SalesAiAgentPrompt(models.Model):
    _name = "sales.ai.agent.prompt"
    _description = "Sales AI Agent Prompt Configuration"
    _rec_name = "name"

    _AGENT_SELECTION = [
        ("junk_filter", "JunkFilterAgent"),
        ("enrichment_structurer", "EnrichmentStructurerAgent"),
        ("lead_scoring", "LeadScoringAgent"),
        ("auto_ack_drafter", "AutoAckDrafterAgent"),
        ("follow_up_drafter", "FollowUpDrafterAgent"),
        ("reply_classifier", "ReplyClassifierAgent"),
        ("client_mom", "ClientMOMAgent"),
        ("ticket_gist", "TicketGistAgent"),
        ("daily_agenda", "DailyAgendaAgent"),
        ("presale_mom", "PresaleMOMAgent"),
        ("presale_email_drafter", "PresaleEmailDrafterAgent"),
        ("retrospective", "RetrospectiveAgent"),
        ("meeting_prep_brief", "MeetingPrepBriefAgent"),
        ("no_show_follow_up", "NoShowFollowUpAgent"),
    ]

    _AGENT_META = {
        "junk_filter": ("JunkFilterAgent Prompt", "claude-haiku-4-5", "junk_filter_system"),
        "enrichment_structurer": ("EnrichmentStructurerAgent Prompt", "claude-haiku-4-5", "enrichment_system"),
        "lead_scoring": ("LeadScoringAgent Prompt", "claude-haiku-4-5", "lead_scoring_system"),
        "auto_ack_drafter": ("AutoAckDrafterAgent Prompt", "claude-sonnet-4-6", "auto_ack_system"),
        "follow_up_drafter": ("FollowUpDrafterAgent Prompt", "claude-sonnet-4-6", "followup_email_system"),
        "reply_classifier": ("ReplyClassifierAgent Prompt", "claude-haiku-4-5", "reply_intent_system"),
        "client_mom": ("ClientMOMAgent Prompt", "claude-sonnet-4-6", "client_mom_system"),
        "ticket_gist": ("TicketGistAgent Prompt", "claude-sonnet-4-6", "ticket_gist_system"),
        "daily_agenda": ("DailyAgendaAgent Prompt", "claude-haiku-4-5", "presale_agenda_system"),
        "presale_mom": ("PresaleMOMAgent Prompt", "claude-sonnet-4-6", "presale_mom_system"),
        "presale_email_drafter": ("PresaleEmailDrafterAgent Prompt", "claude-sonnet-4-6", "presale_email_system"),
        "retrospective": ("RetrospectiveAgent Prompt", "claude-sonnet-4-6", "retro_system"),
        "meeting_prep_brief": ("MeetingPrepBriefAgent Prompt", "claude-sonnet-4-6", "meeting_prep_brief_system"),
        "no_show_follow_up": ("NoShowFollowUpAgent Prompt", "claude-sonnet-4-6", "no_show_followup_system"),
    }

    name = fields.Char(required=True)
    agent_key = fields.Selection(selection=_AGENT_SELECTION, required=True, index=True)
    model_name = fields.Char(readonly=True)
    prompt_text = fields.Text()
    prompt_file = fields.Binary(attachment=True)
    prompt_filename = fields.Char()
    active_prompt_source = fields.Selection(
        selection=[("text", "Text Field"), ("file", "Uploaded File")],
        default="text",
        required=True,
    )
    is_active = fields.Boolean(default=True)
    version = fields.Integer(default=1, readonly=True)
    last_updated_by = fields.Many2one("res.users", readonly=True)
    last_updated_on = fields.Datetime(readonly=True)
    notes = fields.Text()

    @api.onchange("agent_key")
    def _onchange_agent_key(self):
        for rec in self:
            meta = self._AGENT_META.get(rec.agent_key) if rec.agent_key else None
            if meta:
                rec.model_name = meta[1]
                if not rec.name:
                    rec.name = meta[0]

    @api.onchange("prompt_file", "prompt_filename")
    def _onchange_prompt_file(self):
        for rec in self:
            if not rec.prompt_file:
                continue
            ext = os.path.splitext((rec.prompt_filename or "").lower())[1]
            if ext not in (".txt", ".md"):
                rec.prompt_file = False
                return {
                    "warning": {
                        "title": _("Unsupported file type"),
                        "message": _("Only .txt and .md files are supported for prompt uploads."),
                    }
                }
            try:
                rec.prompt_text = base64.b64decode(rec.prompt_file).decode("utf-8")
            except Exception:
                rec.prompt_file = False
                return {
                    "warning": {
                        "title": _("Invalid file encoding"),
                        "message": _("Prompt file must be UTF-8 encoded text."),
                    }
                }

    @api.model_create_multi
    def create(self, vals_list):
        now = fields.Datetime.now()
        uid = self.env.user.id
        for vals in vals_list:
            key = vals.get("agent_key")
            meta = self._AGENT_META.get(key)
            if meta:
                vals.setdefault("name", meta[0])
                vals.setdefault("model_name", meta[1])
            vals["version"] = 1
            vals["last_updated_by"] = uid
            vals["last_updated_on"] = now
        return super().create(vals_list)

    def write(self, vals):
        for rec in self:
            item_vals = dict(vals)
            if "agent_key" in item_vals:
                meta = self._AGENT_META.get(item_vals.get("agent_key"))
                if meta:
                    item_vals.setdefault("model_name", meta[1])
                    item_vals.setdefault("name", meta[0])
            item_vals["version"] = (rec.version or 0) + 1
            item_vals["last_updated_by"] = self.env.user.id
            item_vals["last_updated_on"] = fields.Datetime.now()
            super(SalesAiAgentPrompt, rec).write(item_vals)
        return True

    def _read_prompt_from_file(self):
        self.ensure_one()
        ext = os.path.splitext((self.prompt_filename or "").lower())[1]
        if ext not in (".txt", ".md"):
            raise UserError(_("Only .txt and .md files are supported for prompt uploads."))
        try:
            return base64.b64decode(self.prompt_file or b"").decode("utf-8")
        except Exception as exc:
            raise UserError(_("Invalid UTF-8 prompt file: %s") % str(exc))

    @api.constrains("prompt_file", "prompt_filename")
    def _check_prompt_file(self):
        for rec in self:
            if not rec.prompt_file:
                continue
            rec._read_prompt_from_file()

    @api.constrains("agent_key")
    def _check_unique_agent_key(self):
        for rec in self:
            if not rec.agent_key:
                continue
            dup = self.search([("agent_key", "=", rec.agent_key), ("id", "!=", rec.id)], limit=1)
            if dup:
                raise UserError(_("Each agent can have only one prompt configuration."))

    @api.model
    def get_active_prompt(self, agent_key):
        rec = self.search([("agent_key", "=", agent_key), ("is_active", "=", True)], limit=1)
        if not rec:
            raise UserError(_("No active prompt configured for agent key '%s'.") % agent_key)
        if rec.active_prompt_source == "file":
            if not rec.prompt_file:
                raise UserError(_("Prompt source is file, but no file is uploaded for '%s'.") % agent_key)
            prompt = rec._read_prompt_from_file()
        else:
            prompt = (rec.prompt_text or "").strip()
        if not prompt:
            raise UserError(_("Active prompt is empty for agent key '%s'.") % agent_key)
        return prompt

    @api.model
    def action_seed_default_prompts(self):
        # Cleanup removed agents so they no longer appear in the UI list.
        # Use raw SQL as a belt-and-suspenders approach: the selection field
        # no longer contains these values so ORM search may not match them.
        _removed_keys = ("wbs_generator", "proposal_generator")
        obsolete = self.search([("agent_key", "in", list(_removed_keys))])
        if obsolete:
            obsolete.unlink()
        # Fallback: direct SQL for rows where the selection value was orphaned.
        self.env.cr.execute(
            "DELETE FROM sales_ai_agent_prompt WHERE agent_key IN %s",
            (tuple(_removed_keys),),
        )
        # Also clean by name pattern in case agent_key was manually cleared.
        name_obsolete = self.search([
            ("name", "ilike", "WBSGenerator"),
        ]) | self.search([
            ("name", "ilike", "ProposalGenerator"),
        ])
        if name_obsolete:
            name_obsolete.unlink()

        for agent_key, meta in self._AGENT_META.items():
            prompt_key = meta[2]
            prompt_text = prompts.PROMPTS.get(prompt_key, "")
            existing = self.search([("agent_key", "=", agent_key)], limit=1)
            if existing:
                continue
            self.create(
                {
                    "name": meta[0],
                    "agent_key": agent_key,
                    "model_name": meta[1],
                    "prompt_text": prompt_text,
                    "active_prompt_source": "text",
                    "is_active": True,
                }
            )

