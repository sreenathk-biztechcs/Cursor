import logging

from odoo import api, fields, models


_logger = logging.getLogger("sales_ai")


class CrmLeadStale(models.Model):
    _inherit = "crm.lead"

    stage_entered_date = fields.Datetime(
        string="Current Stage Since",
        readonly=True,
        tracking=True,
        help="Timestamp when the lead entered its current stage.",
    )
    last_escalation_date = fields.Date(
        string="Last Escalation Date",
        readonly=True,
        help="Last date when this lead was escalated as stale.",
    )

    @api.model_create_multi
    def create(self, vals_list):
        now_dt = fields.Datetime.now()
        for vals in vals_list:
            if not vals.get("stage_entered_date"):
                vals["stage_entered_date"] = now_dt
        return super().create(vals_list)

    def write(self, vals):
        vals = dict(vals or {})
        if "stage_id" in vals and "stage_entered_date" not in vals:
            vals["stage_entered_date"] = fields.Datetime.now()
        return super().write(vals)

