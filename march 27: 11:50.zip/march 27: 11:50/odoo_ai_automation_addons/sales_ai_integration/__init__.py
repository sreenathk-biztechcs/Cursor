from . import models
from . import controllers
from . import wizards


def post_init_hook(env_or_cr, registry=None):
    """Post-init hook compatible with both old and new Odoo signatures.

    Odoo 19 calls post_init_hook(env).
    Older styles may call post_init_hook(cr, registry).
    """
    from . import claude_training

    if registry is None:
        # New signature: env passed directly.
        claude_training._run_training(env_or_cr)
        return

    # Backward compatibility: cr, registry
    claude_training.run(env_or_cr, registry)

