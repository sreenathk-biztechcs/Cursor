# License LGPL-3.0 or later (same as sales_ai_integration).
"""Shared test helpers for sales_ai_integration."""

from __future__ import annotations

from odoo.addons.sales_ai_integration.models import prompts as prompts_mod


def make_claude_call_mock():
    """
    Return a replacement for claude.service.call(...) that never hits the network.

    Dispatches on the exact system_prompt object identity (prompts.PROMPTS keys).
    """

    P = prompts_mod.PROMPTS

    def _call(_self, tier, system_prompt, user_message="", max_tokens=2000, expect_json=False, temperature=0.2):
        sp = system_prompt

        if sp is P["junk_filter_system"]:
            return {
                "classification": "genuine",
                "confidence": 92.0,
                "reason": "unit test mock",
            }

        if sp is P["lead_scoring_system"]:
            return {
                "score": 73,
                "band": "warm",
                "rationale": "Mock scoring rationale for automated test.",
                "breakdown": {"industry_fit": 15, "company_size_fit": 12},
            }

        if sp is P["auto_ack_system"]:
            return {
                "subject": "[TEST] Thanks for reaching out",
                "body": "Mock auto-ack body for unit test.",
                "tone_used": "warm",
            }

        if sp is P["ticket_gist_system"]:
            return "<p>Mock <b>presale gist</b> HTML for unit test.</p>"

        if sp is P["presale_agenda_system"]:
            return "<ul><li>Mock agenda item 1</li><li>Mock agenda item 2</li></ul>"

        if sp is P["presale_email_system"]:
            return {
                "subject": "[TEST] Presale follow-up summary",
                "body_html": "<p>Mock presale client email body.</p>",
                "body": "Mock presale client email body.",
            }

        if sp is P["wbs_system"]:
            return {
                "wbs_phases": [
                    {
                        "phase_name": "Phase 1: Discovery",
                        "phase_order": 1,
                        "tasks": [
                            {
                                "task_id": "T1.1",
                                "task_name": "Kickoff",
                                "description": "Mock task",
                                "owner": "PM",
                                "depends_on": [],
                                "effort_placeholder": "5 days",
                                "deliverable": "Charter",
                                "notes": None,
                            }
                        ],
                    }
                ],
                "assumptions": ["Mock assumption"],
                "exclusions": [],
                "risks": ["Mock risk"],
                "total_tasks": 1,
            }

        if sp is P["proposal_system"]:
            return {
                "executive_summary": "Mock executive summary for test.",
                "proposal_sections": {
                    "understanding_requirements": "Mock section",
                },
                "word_count": 120,
                "cover_page": {
                    "title": "Mock Proposal",
                    "subtitle": "Test",
                    "date": "2026-01-01",
                    "prepared_by": "Test User",
                    "prepared_for": "Test Client",
                },
            }

        if sp is P["retro_system"]:
            return "<div><h3>Mock retrospective</h3><p>Automated test output.</p></div>"

        if sp is P["no_show_followup_system"]:
            return {
                "subject": "[TEST] Reschedule our call",
                "body": "Mock no-show follow-up body.",
                "tone": "gentle",
            }

        if sp is P["reply_intent_system"]:
            return {
                "intent": "interested",
                "confidence": 88,
                "action": "reset_sequence",
                "ooo_return_date": None,
                "new_contact_hint": None,
                "note_for_rep": "Mock: customer still interested.",
                "priority_flag": False,
            }

        if sp is P["discussion_sync_system"]:
            return {
                "has_content": True,
                "summary_html": "<ul><li>Mock synced presale note</li></ul>",
            }

        if sp is P["meeting_prep_brief_system"]:
            return "<p>Mock meeting prep brief.</p>"

        # Presale MOM paths (facts + compose) — minimal valid JSON
        if sp is P["presale_mom_facts_system"]:
            return {
                "agenda": ["Topic A"],
                "req": ["Requirement 1"],
                "dec": ["Decision 1"],
                "open": [],
                "ai_us": ["We follow up"],
                "ai_cli": ["Client sends doc"],
                "stage_rec": "stay",
            }

        if sp is P["presale_mom_compose_system"]:
            return {
                "internal_mom_markdown": "## Mock MOM\n- Point one",
                "technical_decisions": ["Use Odoo 19"],
                "open_technical_questions": ["Can you share sample order workflow?"],
                "new_action_items_us": ["Internal task"],
                "new_action_items_client": ["Client task"],
                "stage_recommendation": "stay",
            }

        if sp is P["presale_mom_system"]:
            return {
                "internal_mom_markdown": "## Fallback MOM\nMock",
                "technical_decisions": [],
                "new_action_items_us": [],
                "new_action_items_client": [],
                "stage_recommendation": "stay",
            }

        if sp is P["client_mom_facts_system"]:
            return {
                "sum": ["Summary point"],
                "pain": [],
                "req": ["Need Odoo"],
                "qna": [],
                "dec": [],
                "ai_rep": [],
                "ai_cli": [],
                "ns": ["Next call"],
                "sig": [],
                "topics": [],
                "mods": [],
            }

        if sp is P["client_mom_compose_system"]:
            return {
                "internal_mom": "Internal MOM mock text.",
                "client_email_subject": "Meeting summary",
                "client_email_body": "Dear client, mock body.",
                "action_items_rep": ["Rep does X"],
                "action_items_client": ["Client sends Y"],
                "next_meeting_suggested": False,
            }

        if sp is P["followup_email_system"]:
            return {
                "subject": "[TEST] Follow-up",
                "body": "Mock follow-up body",
                "angle": "value",
                "cta": "Reply to this email",
            }

        # Client MOM (large prompts) — return minimal structure if hit
        if expect_json:
            return {
                "internal_mom": "mock",
                "client_email_subject": "Test",
                "client_email_body": "mock body",
                "action_items_rep": [],
                "action_items_client": [],
                "next_meeting_suggested": False,
            }

        return "Mock plain-text Claude response for unknown prompt in test."

    return _call
