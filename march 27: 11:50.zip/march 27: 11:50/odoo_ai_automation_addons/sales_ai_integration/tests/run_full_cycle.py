#!/usr/bin/env python3
# License LGPL-3.0 or later (same as sales_ai_integration).
"""
Run full Sales AI presale cycle in one stretch from PyCharm.

This script bootstraps Odoo, then executes:
Lead -> Ticket(s) -> Agenda -> Multi-ticket transcript routing ->
MOM posting -> client-question activities -> reply sync -> next agenda -> WBS.

Usage examples:

1) Mock mode (no n8n needed):
   python run_full_cycle.py \
     --odoo-dir /home/sreenath.k/PycharmProjects/odoo19/odoo19 \
     --config /home/sreenath.k/PycharmProjects/odoo19/odoo19/odoo.conf \
     --db test_sales_ai_u19 \
     --mode mock

2) Live mode (real n8n webhooks):
   python run_full_cycle.py \
     --odoo-dir /home/sreenath.k/PycharmProjects/odoo19/odoo19 \
     --config /home/sreenath.k/PycharmProjects/odoo19/odoo19/odoo.conf \
     --db test_sales_ai_u19 \
     --mode live_n8n \
     --ticket-count 10
"""

from __future__ import annotations

import argparse
import json
import os
import sys


def _bootstrap_odoo(odoo_dir: str, config_path: str, db_name: str):
    if odoo_dir not in sys.path:
        sys.path.insert(0, odoo_dir)

    from odoo import api, SUPERUSER_ID
    from odoo.orm.registry import Registry
    from odoo.tools import config as odoo_config

    if not os.path.exists(config_path):
        raise FileNotFoundError("Config file not found: %s" % config_path)

    odoo_config.parse_config(["-c", config_path, "-d", db_name])
    # Odoo 19 uses Registry from odoo.orm.registry
    registry = Registry(db_name)
    cr = registry.cursor()
    env = api.Environment(cr, SUPERUSER_ID, {})
    return env, cr


def _preflight_sales_ai(env, config_path: str, db_name: str):
    """Fail fast with clear guidance if module fields are not loaded."""
    Lead = env["crm.lead"]
    missing = []
    if "x_presale_status" not in Lead._fields:
        missing.append("crm.lead.x_presale_status")
    Ticket = env["sh.helpdesk.ticket"]
    if "x_linked_lead_id" not in Ticket._fields:
        missing.append("sh.helpdesk.ticket.x_linked_lead_id")
    if missing:
        raise RuntimeError(
            "Sales AI custom fields are missing in this DB (%s). "
            "Run module upgrade first:\n"
            "  ./odoo-bin -c %s -d %s -u sales_ai_integration --stop-after-init"
            % (", ".join(missing), config_path, db_name)
        )


def main():
    parser = argparse.ArgumentParser(description="Run full Sales AI presale demo cycle.")
    parser.add_argument("--odoo-dir", required=True, help="Absolute path of Odoo source root (where odoo package exists).")
    parser.add_argument("--config", required=True, help="Absolute path to odoo.conf.")
    parser.add_argument("--db", required=True, help="Database name.")
    parser.add_argument("--mode", choices=["mock", "live_n8n"], default="mock", help="mock = no n8n, live_n8n = real webhooks.")
    parser.add_argument("--ticket-count", type=int, default=10, help="How many presale tickets to simulate in one meeting transcript.")
    args = parser.parse_args()

    env = None
    cr = None
    try:
        env, cr = _bootstrap_odoo(args.odoo_dir, args.config, args.db)
        _preflight_sales_ai(env, args.config, args.db)
        from odoo.addons.sales_ai_integration.tests.demo_cycle_runner import run_demo_cycle

        result = run_demo_cycle(env, mode=args.mode, ticket_count=args.ticket_count)
        cr.commit()

        print("\n=== SALES AI FULL CYCLE RESULT ===")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("=== DONE ===\n")
    except Exception as exc:
        if cr:
            cr.rollback()
        print("ERROR: %s" % str(exc))
        raise
    finally:
        if cr:
            cr.close()


if __name__ == "__main__":
    main()

