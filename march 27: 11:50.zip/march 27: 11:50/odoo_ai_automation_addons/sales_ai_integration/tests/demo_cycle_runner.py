# License LGPL-3.0 or later (same as sales_ai_integration).
"""
Manual runner for full presale cycle from Odoo shell.

Usage (from odoo shell):

    from odoo.addons.sales_ai_integration.tests.demo_cycle_runner import run_demo_cycle
    run_demo_cycle(env, mode="mock")      # no n8n needed
    run_demo_cycle(env, mode="live_n8n")  # real n8n webhooks
"""

from __future__ import annotations

from unittest.mock import patch

from odoo.addons.sales_ai_integration.models.claude_service import ClaudeService
from odoo.addons.sales_ai_integration.models.helpdesk_ticket import HelpdeskTicketPresale
from odoo.addons.sales_ai_integration.models.n8n_webhook import SalesAiN8N
from odoo.addons.sales_ai_integration.tests.common import make_claude_call_mock


def _fake_n8n_post(self, endpoint, payload):
    return {"ok": True, "endpoint": endpoint, "payload_keys": list(payload.keys())}


def run_demo_cycle(env, mode="mock", ticket_count=10):
    """
    Run full presale cycle with demo data.

    :param env: Odoo shell env
    :param mode: "mock" (default) or "live_n8n"
    :param ticket_count: number of presale tickets to simulate in same cycle
    :return: dict summary
    """
    Lead = env["crm.lead"].sudo()
    Ticket = env["sh.helpdesk.ticket"].sudo()
    Partner = env["res.partner"].sudo()
    Calendar = env["calendar.event"].sudo()
    phase_results = []

    def run_phase(code, title, fn):
        try:
            out = fn() or {}
            phase_results.append({"code": code, "title": title, "status": "ok", "details": out})
            return out
        except Exception as exc:
            phase_results.append({"code": code, "title": title, "status": "failed", "error": str(exc)})
            return {}

    partner = Partner.create({"name": "Demo Full Cycle Partner", "email": "demo-full-cycle@example.com"})
    lead = Lead.create(
        {
            "name": "Demo full cycle lead",
            "email_from": "demo-full-cycle@example.com",
            "description": "Need ERP for manufacturing + reporting.",
            "partner_id": partner.id,
            "user_id": env.user.id,
            "type": "lead",
        }
    )
    if "x_presale_status" in lead._fields:
        lead.x_presale_status = "open"

    if "x_linked_lead_id" not in Ticket._fields:
        raise RuntimeError("Missing sh.helpdesk.ticket.x_linked_lead_id; install/upgrade sales_ai_integration.")

    claude_ctx = patch.object(ClaudeService, "call", make_claude_call_mock())
    if mode == "mock":
        n8n_ctx = patch.object(SalesAiN8N, "post", _fake_n8n_post)
    else:
        n8n_ctx = patch.object(SalesAiN8N, "post", SalesAiN8N.post)

    with claude_ctx, n8n_ctx:
        # [1] Junk filter
        run_phase("1", "Junk filter", lambda: (lead.action_run_junk_filter(), {"classification": lead.x_classification})[1])

        # [2] Structured enrichment (simulated callback payload)
        def _enrich():
            lead.action_apply_structured_enrichment(
                {
                    "company_industry": "Manufacturing",
                    "company_employee_range": "200-499",
                    "contact_job_title": "Head of Operations",
                    "contact_seniority": "director",
                    "icp_match_signals": ["ERP migration planned", "multi-site operations"],
                }
            )
            return {"enrichment_done": bool(lead.x_enrichment_done)}

        run_phase("2", "Data enrichment (simulated)", _enrich)

        # [3] Lead scoring
        run_phase("3", "Lead scoring", lambda: (lead.action_run_lead_scoring(), {"score": lead.x_lead_score, "band": lead.x_lead_score_band})[1])

        # [5] Auto-ack draft
        run_phase("5", "Auto-ack draft", lambda: (lead.action_send_auto_ack(), {"user_id": lead.user_id.id})[1])

        # [6] Follow-up schedule + due draft cron
        def _followups():
            lead.action_create_followup_activities()
            Lead.cron_draft_followup_emails()
            acts = env["mail.activity"].search([("res_model", "=", "crm.lead"), ("res_id", "=", lead.id)])
            return {"activity_count": len(acts)}

        run_phase("6", "Follow-up scheduling + draft cron", _followups)

        # [8/9] Meeting + client MOM from transcript
        def _meeting_and_mom():
            ev = Calendar.create(
                {
                    "name": "Demo first discovery meeting",
                    "start": "2026-03-03 10:00:00",
                    "stop": "2026-03-03 11:00:00",
                    "opportunity_id": lead.id,
                    "partner_ids": [(4, partner.id)],
                }
            )
            lead.action_generate_client_mom(
                transcript="Rep: Discussed requirements. Client: Need manufacturing, inventory, reporting.",
                meeting_date="2026-03-03",
                meeting_duration=60,
                attendees=[{"name": "Client", "is_client": True}, {"name": "Rep", "is_client": False}],
            )
            return {"event_id": ev.id}

        run_phase("8-9", "Meeting management + client MOM", _meeting_and_mom)

        # [10] Presale tickets + gist
        def _presale_tickets():
            with patch.object(HelpdeskTicketPresale, "_defer_gist_generation", lambda *a, **k: None):
                tickets = []
                for idx in range(max(2, int(ticket_count or 2))):
                    t = Ticket.create(
                        {
                            "name": "Demo Ticket %d" % (idx + 1),
                            "x_linked_lead_id": lead.id,
                            "partner_id": partner.id,
                        }
                    )
                    if not t.x_presale_ref:
                        t.x_presale_ref = "PST-%s" % t.id
                    t.x_ticket_gist = "Initial gist for ticket %d." % (idx + 1)
                    tickets.append(t.id)
            refs = Ticket.browse(tickets).mapped("x_presale_ref")
            return {"ticket_ids": tickets, "ticket_refs": refs}

        ticket_info = run_phase("10", "Presale ticket creation + gist", _presale_tickets)
        ticket_ids = ticket_info.get("ticket_ids") or []
        tickets = Ticket.browse(ticket_ids)
        t1 = tickets[:1]
        t2 = tickets[1:2]

        # [11] Agenda first run
        run_phase("11-day1", "Daily presale agenda day-1", lambda: (Ticket.cron_generate_presale_agenda(), {"ok": True})[1])

        # [12] Presale MOM from multi-ticket transcript routing
        def _presale_multi_ticket():
            chunks = ["Start"]
            for idx, t in enumerate(tickets, start=1):
                chunks.append("Moving to ticket #%s" % t.x_presale_ref)
                chunks.append("ticket #%s" % t.id)
                chunks.append(
                    "Discussed scope, blockers, and client queries for ticket %d." % idx
                )
            transcript = "\n".join(chunks) + "\n"
            routed = Ticket.action_route_multi_ticket_transcript(
                transcript=transcript,
                lead_id=lead.id,
                meeting_date="2026-03-04",
                meeting_duration=60,
                attendees=[{"name": "Rep", "is_client": False}, {"name": "Client", "is_client": True}],
                prior_open_items=[],
            )
            if not (routed or {}).get("processed_count"):
                for idx, t in enumerate(tickets, start=1):
                    t.action_generate_presale_mom(
                        transcript="Fallback segment for ticket %d." % idx,
                        meeting_date="2026-03-04",
                        meeting_duration=60,
                        attendees=[{"name": "Rep", "is_client": False}, {"name": "Client", "is_client": True}],
                        prior_open_items=[],
                    )
                routed = {
                    "processed_count": len(tickets),
                    "segments": len(tickets),
                    "ticket_ids": tickets.ids,
                    "unmatched_markers": ["auto-fallback-used"],
                }
            return routed

        routed = run_phase("12", "Presale transcript split + ticket MOM", _presale_multi_ticket)

        # [7] Reply handler (client replies to open questions)
        run_phase(
            "7",
            "Reply handler",
            lambda: (
                lead._handle_external_reply(
                    "Client shared requested inputs and asked for next steps.",
                    reply_from="demo-full-cycle@example.com",
                    reply_subject="Re: presale",
                ),
                {"reply_intent": lead.x_reply_intent},
            )[1],
        )

        # [11] Agenda second run
        run_phase("11-day2", "Daily presale agenda day-2", lambda: (Ticket.cron_generate_presale_agenda(), {"ok": True})[1])

        # [13] WBS
        run_phase("13", "WBS generation", lambda: (t1.action_generate_wbs(), {"ticket_status": t1.x_ticket_status})[1])

        # [14] Proposal
        def _proposal():
            t1.x_ticket_status = "wbs_done"
            t1.action_request_proposal_from_ai()
            return {"ticket_status": t1.x_ticket_status}

        run_phase("14", "Proposal generation request", _proposal)

        # [15] Retrospective
        def _retro():
            won = env.ref("sales_ai_integration.stage_won", raise_if_not_found=False)
            if won:
                lead.stage_id = won
            lead.action_generate_closure_retro()
            return {"retro_logged": bool(lead.x_retro_logged)}

        run_phase("15", "Lead closure retrospective", _retro)

        # Stale monitor + escalation subsystem
        run_phase("stale-monitor", "Stale deal monitor", lambda: (Lead.cron_stale_deal_monitor(), {"ok": True})[1])

    q_acts = env["mail.activity"].search(
        [
            ("res_model", "=", "crm.lead"),
            ("res_id", "=", lead.id),
            ("summary", "ilike", "Questions to ask client"),
        ]
    )

    return {
        "mode": mode,
        "lead_id": lead.id,
        "ticket_ids": tickets.ids if tickets else [],
        "ticket_refs": tickets.mapped("x_presale_ref") if tickets else [],
        "ticket_count_requested": int(ticket_count or 0),
        "ticket_count_created": len(tickets),
        "routed": routed if isinstance(routed, dict) else {},
        "reply_intent": lead.x_reply_intent,
        "open_query_activity_count": len(q_acts),
        "ticket1_status": t1.x_ticket_status if t1 else "",
        "ticket1_last_agenda_date": str(t1.x_last_agenda_date or "") if t1 else "",
        "ticket2_last_agenda_date": str(t2.x_last_agenda_date or "") if t2 else "",
        "phase_results": phase_results,
        "not_automated_in_odoo_script": [
            "Apollo Playwright scrape itself (external n8n workflow)",
            "Gmail Workspace Add-on UI flows",
            "mail_smart_link inbound mail-server end-to-end (needs real incoming mail)",
            "Google Drive/Sheets actual write side-effects unless live n8n is configured",
        ],
    }
