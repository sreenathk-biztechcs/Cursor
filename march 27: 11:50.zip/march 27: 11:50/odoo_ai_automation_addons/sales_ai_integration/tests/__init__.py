# License LGPL-3.0 or later (same as sales_ai_integration).

from . import test_sales_ai_integration
