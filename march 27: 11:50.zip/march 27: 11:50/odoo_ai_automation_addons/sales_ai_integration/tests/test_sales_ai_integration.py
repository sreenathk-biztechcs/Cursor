# License LGPL-3.0 or later (same as sales_ai_integration).
"""
Automated tests for sales_ai_integration.

Run (from Odoo root, with a test database):

  ./odoo-bin -c odoo.conf -d test_db \\
    -i sales_ai_integration --test-enable --stop-after-init

Or update an existing DB that already has the module:

  ./odoo-bin -c odoo.conf -d test_db \\
    -u sales_ai_integration --test-enable --stop-after-init

All AI and n8n HTTP calls are mocked — no Anthropic API key or n8n server required.
"""

from __future__ import annotations

import json
from unittest.mock import patch

from odoo.tests.common import TransactionCase, tagged, HttpCase

from odoo.addons.sales_ai_integration.models.claude_service import ClaudeService
from odoo.addons.sales_ai_integration.models.helpdesk_ticket import HelpdeskTicketPresale
from odoo.addons.sales_ai_integration.models.n8n_webhook import SalesAiN8N
from odoo.addons.sales_ai_integration.tests.common import make_claude_call_mock


def _fake_n8n_post(self, endpoint, payload):
    """Avoid real HTTP to n8n during tests."""
    return {"ok": True, "endpoint": endpoint, "payload_keys": list(payload.keys())}


@tagged("post_install", "-at_install", "sales_ai")
class TestSalesAiIntegration(TransactionCase):
    """Model-level tests with mocked Claude + n8n."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls._icp = cls.env["ir.config_parameter"].sudo()
        cls._icp.set_param(
            "sales_ai.icp_criteria_json",
            json.dumps(
                {
                    "target_industries": ["Software"],
                    "target_employee_range": {"min": 1, "max": 5000},
                }
            ),
        )

    def _create_test_lead(self, **vals):
        defaults = {
            "name": "Test requirement discussion",
            "description": "We need an ERP implementation for our manufacturing unit.",
            "email_from": "buyer@example.com",
            "type": "lead",
        }
        defaults.update(vals)
        return self.env["crm.lead"].create(defaults)

    def test_claude_opus_tier_falls_back_to_sonnet(self):
        """Opus tier is blocked; resolver should return a Sonnet model id."""
        svc = self.env["claude.service"]
        model_name = svc._resolve_model("opus")
        self.assertEqual(model_name, ClaudeService.ALLOWED_MODELS["sonnet"])

    def test_junk_filter_classifies_genuine(self):
        lead = self._create_test_lead()
        self.assertFalse(lead.x_lead_quality)
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead._classify_lead_quality(has_apollo_data=False)
        self.assertEqual(lead.x_classification, "genuine")
        self.assertEqual(lead.x_lead_quality, "genuine")

    def test_lead_scoring_with_icp(self):
        lead = self._create_test_lead()
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead.action_run_lead_scoring()
        self.assertTrue(lead.x_scoring_done)
        self.assertEqual(lead.x_lead_score, 73)
        self.assertEqual(lead.x_lead_score_band, "warm")

    def test_open_presale_generates_gist(self):
        lead = self._create_test_lead()
        lead.message_post(
            body="<p>Prior email thread snippet for testing.</p>",
            subtype_xmlid="mail.mt_comment",
            message_type="comment",
        )
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead.action_open_presale()
        self.assertTrue(lead.x_presale_ref)
        self.assertEqual(lead.x_presale_status, "open")
        self.assertTrue(lead.x_ticket_gist)

    def test_cron_presale_agenda(self):
        lead = self._create_test_lead()
        lead.write(
            {
                "x_presale_status": "open",
                "x_presale_ref": "PST-%d" % lead.id,
            }
        )
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            self.env["crm.lead"].cron_generate_presale_agenda()
        self.assertTrue(lead.x_last_agenda_date)

    def test_generate_wbs(self):
        lead = self._create_test_lead()
        lead.write(
            {
                "x_presale_status": "open",
                "x_presale_ref": "PST-TEST",
            }
        )
        with patch.object(ClaudeService, "call", make_claude_call_mock()), patch.object(
            SalesAiN8N, "post", _fake_n8n_post
        ):
            lead.action_generate_wbs()
        self.assertTrue(lead.x_wbs_json)
        self.assertEqual(lead.x_presale_status, "ready_for_wbs")

    def test_request_proposal_from_ai(self):
        lead = self._create_test_lead()
        lead.write(
            {
                "x_presale_status": "wbs_done",
                "x_presale_ref": "PST-PR",
                "x_wbs_json": '{"wbs_phases": []}',
            }
        )
        with patch.object(ClaudeService, "call", make_claude_call_mock()), patch.object(
            SalesAiN8N, "post", _fake_n8n_post
        ):
            lead.action_request_proposal_from_ai()
        self.assertEqual(lead.x_presale_status, "ready_for_proposal")

    def test_no_show_followup_activity(self):
        lead = self._create_test_lead()
        lead.write({"user_id": self.env.user.id})
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead.action_no_show_followup(no_show_count=1)
        act = self.env["mail.activity"].search(
            [("res_model", "=", "crm.lead"), ("res_id", "=", lead.id)],
            order="id desc",
            limit=1,
        )
        self.assertTrue(act)
        combined = ((act.summary or "") + (act.note or "")).lower()
        self.assertTrue("no-show" in combined or "no show" in combined)

    def test_closure_retro_on_won_lead(self):
        lead = self._create_test_lead()
        won = self.env.ref("sales_ai_integration.stage_won", raise_if_not_found=False)
        if not won:
            self.skipTest("sales_ai_integration CRM stages not loaded")
        lead.write({"stage_id": won.id})
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead.action_generate_closure_retro()
        self.assertTrue(lead.x_retro_logged)

    def test_external_reply_triggers_classifier_and_sync(self):
        lead = self._create_test_lead()
        lead.write(
            {
                "x_presale_status": "open",
                "x_presale_ref": "PST-SYNC",
            }
        )
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead._handle_external_reply(
                "Thanks, we would like a demo next week.",
                reply_from="buyer@example.com",
                reply_subject="Re: Introduction",
            )
        self.assertEqual(lead.x_reply_intent, "interested")
        msg = lead.message_ids.filtered(lambda m: "Presale note (auto-synced" in (m.body or ""))
        self.assertTrue(msg, "Expected presale sync note on lead when no helpdesk ticket exists")

    def test_generate_presale_mom_from_transcript(self):
        lead = self._create_test_lead()
        lead.write(
            {
                "x_presale_status": "open",
                "x_presale_ref": "PST-MOM",
                "user_id": self.env.user.id,
            }
        )
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead.action_generate_presale_mom_from_transcript(
                transcript="Speaker1: We need inventory and MRP.\nSpeaker2: We can scope that.",
                meeting_date="2026-03-01",
                meeting_duration=45,
                attendees=[{"name": "Client", "is_client": True}],
            )
        self.assertTrue(lead.x_presale_mom_history)
        q_act = self.env["mail.activity"].search(
            [
                ("res_model", "=", "crm.lead"),
                ("res_id", "=", lead.id),
                ("summary", "ilike", "Questions to ask client"),
            ],
            limit=1,
        )
        self.assertTrue(q_act, "Expected client-question activity from presale MOM")

    def test_action_generate_client_mom(self):
        lead = self._create_test_lead()
        lead.write({"user_id": self.env.user.id})
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead.action_generate_client_mom(
                transcript="Rep: What are your goals?\nClient: Go live in Q3.",
                meeting_date="2026-03-01",
                meeting_duration=30,
            )
        tr = self.env["sales.ai.meeting.transcript"].search(
            [("lead_id", "=", lead.id)], limit=1
        )
        self.assertTrue(tr)

    def test_stale_deal_monitor_runs(self):
        with patch.object(SalesAiN8N, "post", _fake_n8n_post):
            self.env["crm.lead"].cron_stale_deal_monitor()

    def test_request_meeting_transcript_posts_to_n8n(self):
        lead = self._create_test_lead()
        cal = self.env["calendar.event"].create(
            {
                "name": "Test client call",
                "start": "2026-03-01 10:00:00",
                "stop": "2026-03-01 10:30:00",
                "opportunity_id": lead.id,
            }
        )
        self.assertTrue(cal.id)
        with patch.object(SalesAiN8N, "post", _fake_n8n_post):
            lead.action_request_meeting_transcript()
        self.assertTrue(cal.x_transcript_requested)

    def test_auto_linked_meeting_forces_client_category(self):
        """Synced/linked meetings should be client meetings, not inferred presale."""
        lead = self._create_test_lead(email_from="client.sync@example.com")
        partner = self.env["res.partner"].create(
            {"name": "Client Sync", "email": "client.sync@example.com"}
        )
        with patch.object(SalesAiN8N, "post", _fake_n8n_post):
            cal = self.env["calendar.event"].create(
                {
                    "name": "Synced booking",
                    "start": "2026-03-01 10:00:00",
                    "stop": "2026-03-01 10:30:00",
                    "partner_ids": [(6, 0, [partner.id])],
                    # Simulate a wrong pre-existing category before linking.
                    "x_meeting_category": "presale_internal",
                }
            )
        self.assertEqual(cal.opportunity_id.id, lead.id)
        self.assertEqual(cal.x_meeting_category, "client")
        self.assertFalse(cal.x_is_presale_meeting)

    def test_presale_category_is_preserved_when_refs_are_set(self):
        """Explicit presale meetings with refs must remain presale."""
        lead = self._create_test_lead(email_from="presale.ref@example.com")
        partner = self.env["res.partner"].create(
            {"name": "Presale Ref", "email": "presale.ref@example.com"}
        )
        with patch.object(SalesAiN8N, "post", _fake_n8n_post):
            cal = self.env["calendar.event"].create(
                {
                    "name": "Manual presale review",
                    "start": "2026-03-02 11:00:00",
                    "stop": "2026-03-02 12:00:00",
                    "partner_ids": [(6, 0, [partner.id])],
                    "x_meeting_category": "presale_internal",
                    "x_presale_refs": "PST-1001",
                }
            )
        self.assertEqual(cal.opportunity_id.id, lead.id)
        self.assertEqual(cal.x_meeting_category, "presale_internal")
        self.assertTrue(cal.x_is_presale_meeting)


@tagged("post_install", "-at_install", "sales_ai")
class TestSalesAiWebhooks(HttpCase):
    """Light HTTP checks for public webhook routes."""

    def test_meeting_done_rejects_missing_secret(self):
        """POST without X-N8N-Secret should be 401."""
        payload = json.dumps(
            {
                "lead_id": 999999999,
                "transcript": "noop",
                "meeting_date": "2026-01-01",
            }
        )
        res = self.url_open(
            "/odoo/api/sales_ai/meeting_done",
            data=payload.encode("utf-8"),
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        self.assertEqual(res.status_code, 401)


@tagged("post_install", "-at_install", "sales_ai")
class TestSalesAiTicketRouting(TransactionCase):
    def test_extract_ticket_marked_segments(self):
        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        transcript = (
            "Intro notes\n"
            "Moving to ticket #PST-1001\n"
            "Discussed integration and data mapping.\n"
            "Now moving to ticket #1002\n"
            "Discussed reports and open queries.\n"
        )
        segments = Ticket._extract_ticket_marked_segments(transcript)
        self.assertEqual(len(segments), 2)
        self.assertEqual(segments[0][0], "PST-1001")
        self.assertIn("integration", segments[0][1].lower())
        self.assertEqual(segments[1][0], "1002")

    def test_route_multi_ticket_transcript_routes_to_respective_tickets(self):
        Lead = self.env["crm.lead"].sudo()
        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        Partner = self.env["res.partner"].sudo()
        partner = Partner.create({"name": "Route Test Partner", "email": "route@example.com"})
        lead = Lead.create(
            {
                "name": "Route Test Lead",
                "email_from": "route@example.com",
                "partner_id": partner.id,
                "type": "lead",
            }
        )

        # Avoid async gist generation side effects in this routing test.
        with patch.object(HelpdeskTicketPresale, "_defer_gist_generation", lambda *a, **k: None):
            t1 = Ticket.create({"name": "T1", "x_linked_lead_id": lead.id, "partner_id": partner.id})
            t2 = Ticket.create({"name": "T2", "x_linked_lead_id": lead.id, "partner_id": partner.id})

        if not t1.x_presale_ref:
            t1.x_presale_ref = "PST-%s" % t1.id
        if not t2.x_presale_ref:
            t2.x_presale_ref = "PST-%s" % t2.id

        transcript = (
            "Opening remarks\n"
            "Moving to ticket #%s\n"
            "Discussion for first ticket only.\n"
            "Moving to ticket #%s\n"
            "Discussion for second ticket only.\n"
        ) % (t1.x_presale_ref, t2.x_presale_ref)

        routed_calls = []

        def _fake_mom(self, transcript, meeting_date=None, meeting_duration=None, attendees=None, prior_open_items=None):
            routed_calls.append((self.id, transcript.strip()))
            return True

        with patch.object(HelpdeskTicketPresale, "action_generate_presale_mom", _fake_mom):
            routed = Ticket.action_route_multi_ticket_transcript(
                transcript=transcript,
                lead_id=lead.id,
                meeting_date="2026-03-01",
                meeting_duration=60,
                attendees=[],
                prior_open_items=[],
            )

        self.assertEqual(routed.get("processed_count"), 2)
        self.assertEqual(routed.get("segments"), 2)
        self.assertFalse(routed.get("unmatched_markers"))
        self.assertEqual(len(routed_calls), 2)

        by_ticket = {ticket_id: body for ticket_id, body in routed_calls}
        self.assertIn(t1.id, by_ticket)
        self.assertIn(t2.id, by_ticket)
        self.assertIn("first ticket", by_ticket[t1.id].lower())
        self.assertIn("second ticket", by_ticket[t2.id].lower())

    def test_route_multi_ticket_transcript_for_ten_tickets(self):
        Lead = self.env["crm.lead"].sudo()
        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        Partner = self.env["res.partner"].sudo()
        partner = Partner.create({"name": "Route10 Partner", "email": "route10@example.com"})
        lead = Lead.create(
            {
                "name": "Route10 Lead",
                "email_from": "route10@example.com",
                "partner_id": partner.id,
                "type": "lead",
            }
        )

        with patch.object(HelpdeskTicketPresale, "_defer_gist_generation", lambda *a, **k: None):
            tickets = []
            for idx in range(10):
                t = Ticket.create(
                    {
                        "name": "T%d" % (idx + 1),
                        "x_linked_lead_id": lead.id,
                        "partner_id": partner.id,
                    }
                )
                if not t.x_presale_ref:
                    t.x_presale_ref = "PST-%s" % t.id
                tickets.append(t)

        lines = ["Meeting kickoff"]
        for idx, t in enumerate(tickets, start=1):
            lines.append("Moving to ticket #%s" % t.x_presale_ref)
            lines.append("Discussion summary for ticket %d." % idx)
        transcript = "\n".join(lines)

        routed_calls = []

        def _fake_mom(self, transcript, meeting_date=None, meeting_duration=None, attendees=None, prior_open_items=None):
            routed_calls.append((self.id, transcript.strip()))
            return True

        with patch.object(HelpdeskTicketPresale, "action_generate_presale_mom", _fake_mom):
            routed = Ticket.action_route_multi_ticket_transcript(
                transcript=transcript,
                lead_id=lead.id,
                meeting_date="2026-03-01",
                meeting_duration=90,
                attendees=[],
                prior_open_items=[],
            )

        self.assertEqual(routed.get("processed_count"), 10)
        self.assertEqual(routed.get("segments"), 10)
        self.assertEqual(len(routed_calls), 10)

    def test_route_by_ticket_name_without_pst_prefix(self):
        Lead = self.env["crm.lead"].sudo()
        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        Partner = self.env["res.partner"].sudo()
        partner = Partner.create({"name": "NameRoute Partner", "email": "name-route@example.com"})
        lead = Lead.create(
            {
                "name": "NameRoute Lead",
                "email_from": "name-route@example.com",
                "partner_id": partner.id,
                "type": "lead",
            }
        )
        with patch.object(HelpdeskTicketPresale, "_defer_gist_generation", lambda *a, **k: None):
            ticket = Ticket.create(
                {
                    "name": "ACME Manufacturing Discussion",
                    "x_linked_lead_id": lead.id,
                    "partner_id": partner.id,
                }
            )
        routed_calls = []

        def _fake_mom(self, transcript, meeting_date=None, meeting_duration=None, attendees=None, prior_open_items=None):
            routed_calls.append((self.id, transcript.strip()))
            return True

        transcript = (
            "Intro\n"
            "Moving to ticket ACME Manufacturing Discussion\n"
            "Talked about requirements and blockers.\n"
        )
        with patch.object(HelpdeskTicketPresale, "action_generate_presale_mom", _fake_mom):
            routed = Ticket.action_route_multi_ticket_transcript(
                transcript=transcript,
                lead_id=lead.id,
                meeting_date="2026-03-01",
                meeting_duration=45,
                attendees=[],
                prior_open_items=[],
            )

        self.assertEqual(routed.get("processed_count"), 1)
        self.assertEqual(len(routed_calls), 1)
        self.assertEqual(routed_calls[0][0], ticket.id)


@tagged("post_install", "-at_install", "sales_ai")
class TestSalesAiFullDemoCycle(TransactionCase):
    """End-to-end demo cycle using mocked Claude + mocked n8n."""

    def test_full_cycle_multi_ticket_to_wbs(self):
        Lead = self.env["crm.lead"].sudo()
        Ticket = self.env["sh.helpdesk.ticket"].sudo()
        Partner = self.env["res.partner"].sudo()
        partner = Partner.create({"name": "Demo Cycle Partner", "email": "demo-cycle@example.com"})

        lead = Lead.create(
            {
                "name": "Demo cycle lead",
                "email_from": "demo-cycle@example.com",
                "description": "Need ERP rollout with manufacturing and reporting modules.",
                "partner_id": partner.id,
                "user_id": self.env.user.id,
                "type": "lead",
                "x_presale_status": "open",
            }
        )

        # Keep test deterministic: avoid async gist post-commit worker in create().
        with patch.object(HelpdeskTicketPresale, "_defer_gist_generation", lambda *a, **k: None):
            t1 = Ticket.create({"name": "PST ticket 1", "x_linked_lead_id": lead.id, "partner_id": partner.id})
            t2 = Ticket.create({"name": "PST ticket 2", "x_linked_lead_id": lead.id, "partner_id": partner.id})

        if not t1.x_presale_ref:
            t1.x_presale_ref = "PST-%s" % t1.id
        if not t2.x_presale_ref:
            t2.x_presale_ref = "PST-%s" % t2.id

        # Seed gist and day-1 agenda
        t1.x_ticket_gist = "Initial gist for ticket one."
        t2.x_ticket_gist = "Initial gist for ticket two."

        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            Ticket.cron_generate_presale_agenda()
        self.assertTrue(t1.x_last_agenda_date)
        self.assertTrue(t2.x_last_agenda_date)

        # Multi-ticket presale meeting transcript with explicit spoken switches
        transcript = (
            "Kickoff context\n"
            "Moving to ticket #%s\n"
            "Discussed integration mapping and dependencies for ticket one.\n"
            "Moving to ticket #%s\n"
            "Discussed analytics reporting and testing tasks for ticket two.\n"
        ) % (t1.x_presale_ref, t2.x_presale_ref)

        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            routed = Ticket.action_route_multi_ticket_transcript(
                transcript=transcript,
                lead_id=lead.id,
                meeting_date="2026-03-02",
                meeting_duration=75,
                attendees=[{"name": "Rep", "is_client": False}, {"name": "Client", "is_client": True}],
                prior_open_items=[],
            )

        self.assertEqual(routed.get("processed_count"), 2)
        self.assertIn(t1.id, routed.get("ticket_ids"))
        self.assertIn(t2.id, routed.get("ticket_ids"))
        self.assertTrue(t1.x_presale_mom_history)
        self.assertTrue(t2.x_presale_mom_history)

        # Open client-question activities should be created on lead
        q_acts = self.env["mail.activity"].search(
            [
                ("res_model", "=", "crm.lead"),
                ("res_id", "=", lead.id),
                ("summary", "ilike", "Questions to ask client"),
            ]
        )
        self.assertTrue(q_acts)

        # Simulate client reply; this should sync note + refresh gist path
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            lead._handle_external_reply(
                "Client reply: sharing required workflow doc and sample data.",
                reply_from="demo-cycle@example.com",
                reply_subject="Re: presale questions",
            )

        self.assertTrue(lead.x_reply_intent)

        # Day-2 agenda should incorporate recent updates
        with patch.object(ClaudeService, "call", make_claude_call_mock()):
            Ticket.cron_generate_presale_agenda()
        self.assertTrue(t1.x_last_agenda_date)
        self.assertTrue(t2.x_last_agenda_date)

        # WBS generation transition
        with patch.object(ClaudeService, "call", make_claude_call_mock()), patch.object(
            SalesAiN8N, "post", _fake_n8n_post
        ):
            t1.action_generate_wbs()
        self.assertEqual(t1.x_ticket_status, "ready_for_wbs")
