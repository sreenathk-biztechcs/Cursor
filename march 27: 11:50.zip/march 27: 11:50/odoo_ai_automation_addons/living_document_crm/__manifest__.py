# -*- coding: utf-8 -*-

{
    'name': 'Living Document for CRM',
    'version': '19.0.1.0.0',
    'category': 'Sales/CRM',
    'summary': 'AI-powered living documents that auto-update from CRM communications',
    'depends': ['crm', 'enhanced_document_management', 'mail', 'contacts'],
    'data': [
        'security/living_doc_security.xml',
        'security/ir.model.access.csv',
        'data/document_workspace_data.xml',
        'data/mail_template_data.xml',
        'data/ir_cron_data.xml',
        'views/res_config_settings_views.xml',
        'views/living_doc_log_views.xml',
        'views/crm_lead_views.xml',
        'views/document_views.xml',
        'wizards/create_living_doc_wizard_views.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}

