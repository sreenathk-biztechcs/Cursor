# -*- coding: utf-8 -*-

from odoo import api, fields, models


class CreateLivingDocWizard(models.TransientModel):
    _name = 'create.living.doc.wizard'
    _description = 'Create Living Document Wizard'

    mode = fields.Selection(
        [
            ('odoo', 'Odoo Document Only'),
            ('google', 'Google Doc Only'),
            ('both', 'Both (Synced)'),
        ],
        default='odoo',
        required=True,
    )
    include_existing = fields.Boolean('Include existing communications', default=True)
    workspace_id = fields.Many2one('document.workspace', string='Document Workspace')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        icp = self.env['ir.config_parameter'].sudo()
        if 'mode' in fields_list and not res.get('mode'):
            res['mode'] = icp.get_param('living_doc.default_mode', default='odoo')
        if 'workspace_id' in fields_list and not res.get('workspace_id'):
            ws = icp.get_param('living_doc.workspace_folder_id')
            if ws:
                res['workspace_id'] = int(ws)
        return res

    def action_create(self):
        lead = self.env['crm.lead'].browse(self.env.context.get('active_id')).exists()
        if not lead:
            return {'type': 'ir.actions.act_window_close'}
        engine = self.env['living.document.engine']
        engine.generate_document(lead, mode=self.mode, include_existing=self.include_existing, workspace_id=self.workspace_id)
        return {'type': 'ir.actions.act_window_close'}

