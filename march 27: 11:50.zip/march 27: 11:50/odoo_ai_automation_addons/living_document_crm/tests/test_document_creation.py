# -*- coding: utf-8 -*-

import base64
from unittest.mock import patch

from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestDocumentCreation(TransactionCase):
    def setUp(self):
        super().setUp()
        self.engine = self.env['living.document.engine']
        self.lead = self.env['crm.lead'].create({'name': 'Lead Doc Creation'})

    def test_create_living_doc_for_lead_with_no_messages_empty_doc(self):
        self.engine.generate_document(self.lead, mode='odoo', include_existing=True)
        self.lead.invalidate_recordset()
        self.assertEqual(self.lead.x_living_doc_status, 'active')
        self.assertTrue(self.lead.x_living_doc_id, 'document.file should be created')

        attachment = self.lead.x_living_doc_id.attachment_id
        self.assertTrue(attachment, 'document should have attachment')

    def test_create_living_doc_with_existing_emails_populates_after_cron(self):
        mt_comment = self.env.ref('mail.mt_comment', raise_if_not_found=False) or self.env.ref('mail.mt_note')
        for i in range(5):
            self.env['mail.message'].create(
                {
                    'model': 'crm.lead',
                    'res_id': self.lead.id,
                    'message_type': 'email',
                    'subtype_id': mt_comment.id,
                    'body': f'<p>Email {i}</p>',
                }
            )

        self.engine.generate_document(self.lead, mode='odoo', include_existing=True)
        self.lead.invalidate_recordset()
        # generation schedules update; run cron and mock AI to deterministic
        fake_summary = {
            'executive_summary': 'Summary',
            'requirements': [],
            'decisions': [],
            'open_questions': [],
            'action_items': [],
            'communication_count': 5,
            'last_communication_date': '2026-01-01',
        }
        fake_changes = {'has_significant_changes': False, 'change_summary': '(none)'}

        class FakeClaude:
            def clean_messages(self, raw):
                return raw, 10, 'haiku'

            def structure_messages(self, cleaned):
                return {'requirements': [], 'questions': [], 'decisions': [], 'action_items': [], 'issues': []}, 20, 'sonnet'

            def generate_summary(self, structured, prev, timeline):
                return fake_summary, 30, 'sonnet'

            def detect_changes(self, prev, new):
                return fake_changes, 10, 'sonnet'

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_claude', return_value=FakeClaude()):
            self.env['crm.lead']._cron_process_pending_living_docs()

        self.lead.invalidate_recordset()
        self.assertEqual(self.lead.x_last_processed_message_id > 0, True)
        raw = self.lead.x_living_doc_id.attachment_id.datas or ''
        body = base64.b64decode(raw).decode('utf-8', errors='ignore') if raw else ''
        self.assertIn('Summary', body)

    def test_create_living_doc_in_odoo_mode_creates_documents_document(self):
        self.engine.generate_document(self.lead, mode='odoo')
        self.lead.invalidate_recordset()
        self.assertTrue(self.lead.x_living_doc_id)
        self.assertFalse(self.lead.x_google_doc_id)

    def test_create_living_doc_in_google_mode_sets_google_doc_id(self):
        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._create_google_doc', return_value=('DOC123', 'REV1')):
            self.engine.generate_document(self.lead, mode='google')
        self.lead.invalidate_recordset()
        self.assertFalse(self.lead.x_living_doc_id)
        self.assertEqual(self.lead.x_google_doc_id, 'DOC123')
        self.assertEqual(self.lead.x_google_doc_revision_id, 'REV1')

    def test_duplicate_creation_prevention(self):
        self.engine.generate_document(self.lead, mode='odoo')
        with self.assertRaises(Exception):
            self.engine.generate_document(self.lead, mode='odoo')

    def test_workspace_auto_creation_for_new_lead(self):
        # Ensure no config set
        self.env['ir.config_parameter'].sudo().set_param('living_doc.workspace_folder_id', '')
        self.engine.generate_document(self.lead, mode='odoo')
        self.lead.invalidate_recordset()
        folder = self.lead.x_living_doc_id.workspace_id
        self.assertTrue(folder)
        self.assertIn('Lead', folder.name)

