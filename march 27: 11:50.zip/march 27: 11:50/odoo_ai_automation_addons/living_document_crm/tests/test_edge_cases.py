# -*- coding: utf-8 -*-

import time
from unittest.mock import patch

from odoo import fields
from odoo.tests.common import TransactionCase, tagged

from ..services.timeline_builder import TimelineBuilder


@tagged('post_install', '-at_install')
class TestEdgeCases(TransactionCase):
    def setUp(self):
        super().setUp()
        self.engine = self.env['living.document.engine']
        self.lead = self.env['crm.lead'].create({'name': 'Lead Edge Cases'})
        self.mt_comment = self.env.ref('mail.mt_comment', raise_if_not_found=False) or self.env.ref('mail.mt_note')
        self.engine.generate_document(self.lead, mode='odoo', include_existing=True)
        self.lead.invalidate_recordset()

    def _create_message(self, body, message_type='comment'):
        return self.env['mail.message'].create(
            {
                'model': 'crm.lead',
                'res_id': self.lead.id,
                'message_type': message_type,
                'subtype_id': self.mt_comment.id,
                'body': body,
            }
        )

    def test_lead_with_500_messages_timeline_extraction_fast(self):
        for i in range(520):
            self._create_message(f'<p>Msg {i}</p>')
        t0 = time.monotonic()
        timeline = TimelineBuilder.get_all_messages(self.lead, self.env)
        elapsed = time.monotonic() - t0
        self.assertEqual(len(timeline) >= 500, True)
        # Generous threshold (depends on DB/CI), but should not be pathological.
        self.assertLess(elapsed, 10.0)

    def test_message_with_no_body_attachment_only_handled(self):
        msg = self.env['mail.message'].create(
            {
                'model': 'crm.lead',
                'res_id': self.lead.id,
                'message_type': 'comment',
                'subtype_id': self.mt_comment.id,
                'body': False,
            }
        )
        att = self.env['ir.attachment'].create(
            {'name': 'only.pdf', 'type': 'binary', 'datas': 'ZmlsZQ==', 'mimetype': 'application/pdf', 'res_model': 'mail.message', 'res_id': msg.id}
        )
        msg.invalidate_recordset()
        timeline = TimelineBuilder.get_new_messages(self.lead, self.env)
        self.assertTrue(any(a['name'] == 'only.pdf' for t in timeline for a in t['attachments']))

    def test_unicode_multilingual_preserved(self):
        self._create_message('<p>こんにちは — مرحبا — Привет</p>')
        timeline = TimelineBuilder.get_new_messages(self.lead, self.env)
        self.assertIn('こんにちは', timeline[-1]['content'])

    def test_chunking_for_large_message_sets(self):
        # Create many messages to force chunking in update_document
        for i in range(60):
            self._create_message(f'<p>Chunk {i}</p>')
        self.lead._schedule_living_doc_update(force_immediate=True)
        self.lead.write({'x_living_doc_next_process_at': fields.Datetime.now()})

        calls = {'clean': 0}

        class FakeClaude:
            def clean_messages(self, raw):
                calls['clean'] += 1
                return raw, 1, 'haiku'

            def structure_messages(self, cleaned):
                return {'requirements': [], 'questions': [], 'decisions': [], 'action_items': [], 'issues': []}, 1, 'sonnet'

            def generate_summary(self, structured, prev, timeline):
                return {
                    'executive_summary': 'Summary',
                    'requirements': [],
                    'decisions': [],
                    'open_questions': [],
                    'action_items': [],
                    'communication_count': len(timeline),
                    'last_communication_date': '2026-01-01',
                }, 1, 'sonnet'

            def detect_changes(self, prev, new):
                return {'has_significant_changes': False, 'change_summary': '(none)'}, 1, 'sonnet'

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_claude', return_value=FakeClaude()):
            self.env['crm.lead']._cron_process_pending_living_docs()
        self.assertGreaterEqual(calls['clean'], 2, 'Expected chunking to call clean_messages multiple times')

    def test_deduplication_pending_flag(self):
        # Schedule twice; cron should clear pending flag after one pass
        self._create_message('<p>one</p>')
        self.lead._schedule_living_doc_update(force_immediate=True)
        self.lead._schedule_living_doc_update(force_immediate=True)
        self.lead.write({'x_living_doc_next_process_at': fields.Datetime.now()})

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine.update_document', return_value=True):
            self.env['crm.lead']._cron_process_pending_living_docs()
        self.lead.invalidate_recordset()
        self.assertFalse(self.lead.x_living_doc_pending_update)

    def test_lead_deleted_cleans_log_access(self):
        # Logs should cascade due to ondelete='cascade'
        log = self.env['living.doc.log'].sudo().create({'lead_id': self.lead.id, 'stage': 'trigger', 'status': 'success'})
        lead_id = self.lead.id
        self.lead.unlink()
        remaining = self.env['living.doc.log'].sudo().search([('id', '=', log.id)])
        self.assertFalse(remaining)
        self.assertFalse(self.env['crm.lead'].browse(lead_id).exists())

