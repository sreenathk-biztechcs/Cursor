# -*- coding: utf-8 -*-

import base64
import json
from unittest.mock import patch

from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestAIPipeline(TransactionCase):
    def setUp(self):
        super().setUp()
        self.engine = self.env['living.document.engine']
        self.lead = self.env['crm.lead'].create({'name': 'Lead AI Pipeline'})
        self.mt_comment = self.env.ref('mail.mt_comment', raise_if_not_found=False) or self.env.ref('mail.mt_note')

        # Create living doc (odoo)
        self.engine.generate_document(self.lead, mode='odoo', include_existing=True)
        self.lead.invalidate_recordset()

    def _post_message(self, body, message_type='comment'):
        return self.env['mail.message'].create(
            {
                'model': 'crm.lead',
                'res_id': self.lead.id,
                'message_type': message_type,
                'subtype_id': self.mt_comment.id,
                'body': body,
            }
        )

    def test_financial_content_filtered_before_ai(self):
        self._post_message('<p>Price is $1,200 and invoice #123</p>')

        captured = {'clean_input': None}

        class FakeClaude:
            def clean_messages(self, raw):
                captured['clean_input'] = raw
                return raw, 1, 'haiku'

            def structure_messages(self, cleaned):
                return {'requirements': [], 'questions': [], 'decisions': [], 'action_items': [], 'issues': []}, 1, 'sonnet'

            def generate_summary(self, structured, prev, timeline):
                return {
                    'executive_summary': 'OK',
                    'requirements': [],
                    'decisions': [],
                    'open_questions': [],
                    'action_items': [],
                    'communication_count': len(timeline),
                    'last_communication_date': '2026-01-01',
                }, 1, 'sonnet'

            def detect_changes(self, prev, new):
                return {'has_significant_changes': False, 'change_summary': '(none)'}, 1, 'sonnet'

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_claude', return_value=FakeClaude()):
            self.lead._schedule_living_doc_update(force_immediate=True)
            self.env['crm.lead']._cron_process_pending_living_docs()

        self.assertTrue(captured['clean_input'], 'AI cleaning should receive messages')
        # Ensure redaction happened before AI
        self.assertIn('[FINANCIAL_DATA_REDACTED]', captured['clean_input'][0]['content'])

    def test_ai_error_handling_sets_status_error(self):
        self._post_message('<p>Trigger</p>')

        class BadClaude:
            def clean_messages(self, raw):
                raise Exception('rate limit')

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_claude', return_value=BadClaude()):
            self.lead._schedule_living_doc_update(force_immediate=True)
            self.env['crm.lead']._cron_process_pending_living_docs()

        self.lead.invalidate_recordset()
        self.assertEqual(self.lead.x_living_doc_status, 'error')
        self.assertIn('rate limit', (self.lead.x_living_doc_error or ''))

    def test_token_usage_tracked_in_logs(self):
        self._post_message('<p>Req: do X</p>')

        class FakeClaude:
            def clean_messages(self, raw):
                return raw, 11, 'haiku'

            def structure_messages(self, cleaned):
                return {'requirements': [{'id': 'R1', 'text': 'X', 'source_date': '2026-01-01', 'status': 'new'}],
                        'questions': [], 'decisions': [], 'action_items': [], 'issues': []}, 22, 'sonnet'

            def generate_summary(self, structured, prev, timeline):
                return {
                    'executive_summary': 'Summary',
                    'requirements': structured['requirements'],
                    'decisions': [],
                    'open_questions': [],
                    'action_items': [],
                    'communication_count': len(timeline),
                    'last_communication_date': '2026-01-01',
                }, 33, 'sonnet'

            def detect_changes(self, prev, new):
                return {'has_significant_changes': True, 'change_summary': 'New requirement'}, 44, 'sonnet'

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_claude', return_value=FakeClaude()):
            self.lead._schedule_living_doc_update(force_immediate=True)
            self.env['crm.lead']._cron_process_pending_living_docs()

        logs = self.env['living.doc.log'].search([('lead_id', '=', self.lead.id), ('stage', '=', 'ai_summary')], limit=1)
        self.assertTrue(logs)
        self.assertEqual(logs.ai_tokens_used, 33)
        self.assertEqual(logs.ai_model_used, 'sonnet')

        # Ensure document template contains required sections
        raw = self.lead.x_living_doc_id.attachment_id.datas or ''
        body = base64.b64decode(raw).decode('utf-8', errors='ignore') if raw else ''
        self.assertIn('## 1. Executive Summary', body)
        self.assertIn('## 7. Communication Timeline', body)

        # Ensure summary JSON stored
        self.assertTrue(self.lead.x_last_summary_json)
        stored = json.loads(self.lead.x_last_summary_json)
        self.assertEqual(stored['executive_summary'], 'Summary')

