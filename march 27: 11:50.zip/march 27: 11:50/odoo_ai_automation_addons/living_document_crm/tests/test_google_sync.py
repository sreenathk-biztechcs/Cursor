# -*- coding: utf-8 -*-

import json
from unittest.mock import patch

from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestGoogleSync(TransactionCase):
    def setUp(self):
        super().setUp()
        self.engine = self.env['living.document.engine']
        self.lead = self.env['crm.lead'].create({'name': 'Lead Google Sync'})

    def test_google_doc_created_with_correct_title_and_content_mocked(self):
        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._create_google_doc', return_value=('DOCX', 'REV0')) as p:
            self.engine.generate_document(self.lead, mode='google')
        self.lead.invalidate_recordset()
        self.assertEqual(self.lead.x_google_doc_id, 'DOCX')
        self.assertTrue(p.called)

    def test_google_doc_updated_full_replace_not_append(self):
        # Create in both mode (mock create)
        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._create_google_doc', return_value=('DOC1', 'REV1')):
            self.engine.generate_document(self.lead, mode='both')
        self.lead.invalidate_recordset()

        class FakeGoogle:
            def __init__(self):
                self.updated = 0

            def update_document(self, doc_id, md):
                self.updated += 1
                self.last_md = md
                return True

            def get_revision_id(self, doc_id):
                return 'REV2'

        class FakeClaude:
            def clean_messages(self, raw):
                return raw, 1, 'haiku'

            def structure_messages(self, cleaned):
                return {'requirements': [], 'questions': [], 'decisions': [], 'action_items': [], 'issues': []}, 1, 'sonnet'

            def generate_summary(self, structured, prev, timeline):
                return {
                    'executive_summary': 'Summary',
                    'requirements': [],
                    'decisions': [],
                    'open_questions': [],
                    'action_items': [],
                    'communication_count': 1,
                    'last_communication_date': '2026-01-01',
                }, 1, 'sonnet'

            def detect_changes(self, prev, new):
                return {'has_significant_changes': False, 'change_summary': '(none)'}, 1, 'sonnet'

        fake_google = FakeGoogle()
        mt_comment = self.env.ref('mail.mt_comment', raise_if_not_found=False) or self.env.ref('mail.mt_note')
        self.env['mail.message'].create(
            {'model': 'crm.lead', 'res_id': self.lead.id, 'message_type': 'comment', 'subtype_id': mt_comment.id, 'body': '<p>x</p>'}
        )
        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_google', return_value=fake_google), \
             patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_claude', return_value=FakeClaude()):
            self.lead._schedule_living_doc_update(force_immediate=True)
            self.env['crm.lead']._cron_process_pending_living_docs()

        self.assertEqual(fake_google.updated, 1)
        self.assertIn('## 1. Executive Summary', fake_google.last_md)

    def test_external_edit_detected_by_revision_check_and_merged(self):
        # Create in google mode
        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._create_google_doc', return_value=('DOC2', 'REV1')):
            self.engine.generate_document(self.lead, mode='google')
        self.lead.invalidate_recordset()

        class FakeGoogle:
            def get_revision_id(self, doc_id):
                return 'REV2'

            def get_document_content(self, doc_id):
                return "# Lead: X\n\n## 1. Executive Summary\nNew summary\n\n## 2. Latest Requirements\n- [R1] Do something\n\n## 3. Key Decisions\n- (none)\n\n## 4. Open Questions\n- (none)\n\n## 5. Action Items\n- (none)\n\n## 6. Risk Alerts / Requirement Changes\n(none)\n\n## 7. Communication Timeline\n"

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_google', return_value=FakeGoogle()):
            self.engine.sync_google_doc(self.lead)

        self.lead.invalidate_recordset()
        data = json.loads(self.lead.x_last_summary_json)
        self.assertEqual(data.get('executive_summary'), 'New summary')
        self.assertEqual(self.lead.x_google_doc_revision_id, 'REV2')

    def test_google_api_failure_graceful(self):
        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._create_google_doc', return_value=('DOC3', 'REV1')):
            self.engine.generate_document(self.lead, mode='google')
        self.lead.invalidate_recordset()

        class BadGoogle:
            def get_revision_id(self, doc_id):
                raise Exception('quota exceeded')

        # Cron wrapper should catch and log; direct call will raise, so we call cron method
        self.lead.write({'x_living_doc_mode': 'google', 'x_living_doc_status': 'active'})
        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_google', return_value=BadGoogle()):
            self.env['crm.lead']._cron_google_sync_checker(limit=1)

        logs = self.env['living.doc.log'].search([('lead_id', '=', self.lead.id), ('stage', '=', 'google_sync'), ('status', '=', 'error')], limit=1)
        self.assertTrue(logs)

