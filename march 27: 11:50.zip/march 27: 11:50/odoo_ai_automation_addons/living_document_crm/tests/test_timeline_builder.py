# -*- coding: utf-8 -*-

from odoo.tests.common import TransactionCase, tagged

from ..services.timeline_builder import TimelineBuilder


@tagged('post_install', '-at_install')
class TestTimelineBuilder(TransactionCase):
    def setUp(self):
        super().setUp()
        self.lead = self.env['crm.lead'].create({'name': 'Lead Timeline'})
        self.mt_note = self.env.ref('mail.mt_note')
        self.mt_comment = self.env.ref('mail.mt_comment', raise_if_not_found=False) or self.mt_note

    def _create_message(self, body, subtype, message_type='comment', attachments=None, author=None, email_from=None):
        vals = {
            'model': 'crm.lead',
            'res_id': self.lead.id,
            'message_type': message_type,
            'subtype_id': subtype.id,
            'body': body,
            'author_id': author.id if author else False,
            'email_from': email_from or False,
        }
        msg = self.env['mail.message'].create(vals)
        if attachments:
            for att in attachments:
                att.write({'res_model': 'mail.message', 'res_id': msg.id})
            msg.invalidate_recordset()
        return msg

    def test_extract_only_email_and_comment_not_system_notes(self):
        self._create_message('<p>System note</p>', self.mt_note, message_type='comment')
        self._create_message('<p>Real comment</p>', self.mt_comment, message_type='comment')
        self._create_message('<p>Email body</p>', self.mt_comment, message_type='email')
        timeline = TimelineBuilder.get_all_messages(self.lead, self.env)
        self.assertEqual(len(timeline), 2)
        self.assertEqual({t['type'] for t in timeline}, {'comment', 'email'})

    def test_html_body_cleaned_to_plain_text(self):
        self._create_message('<div>Hello<br/>World</div>', self.mt_comment, message_type='comment')
        timeline = TimelineBuilder.get_all_messages(self.lead, self.env)
        self.assertIn('Hello', timeline[0]['content'])
        self.assertIn('World', timeline[0]['content'])

    def test_attachments_listed_correctly(self):
        att = self.env['ir.attachment'].create(
            {'name': 'file.txt', 'type': 'binary', 'datas': 'ZmlsZQ==', 'mimetype': 'text/plain'}
        )
        self._create_message('<p>With attachment</p>', self.mt_comment, attachments=[att])
        timeline = TimelineBuilder.get_all_messages(self.lead, self.env)
        self.assertEqual(len(timeline[0]['attachments']), 1)
        self.assertEqual(timeline[0]['attachments'][0]['name'], 'file.txt')

    def test_chronological_ordering(self):
        m1 = self._create_message('<p>First</p>', self.mt_comment)
        m2 = self._create_message('<p>Second</p>', self.mt_comment)
        timeline = TimelineBuilder.get_all_messages(self.lead, self.env)
        self.assertEqual([t['id'] for t in timeline], [m1.id, m2.id])

    def test_last_processed_message_filter(self):
        m1 = self._create_message('<p>First</p>', self.mt_comment)
        self.lead.write({'x_last_processed_message_id': m1.id})
        m2 = self._create_message('<p>Second</p>', self.mt_comment)
        timeline = TimelineBuilder.get_new_messages(self.lead, self.env)
        self.assertEqual([t['id'] for t in timeline], [m2.id])

    def test_empty_result_when_no_new_messages(self):
        self.lead.write({'x_last_processed_message_id': 999999})
        timeline = TimelineBuilder.get_new_messages(self.lead, self.env)
        self.assertEqual(timeline, [])

    def test_author_resolution(self):
        partner = self.env['res.partner'].create({'name': 'Alice'})
        self._create_message('<p>Authored</p>', self.mt_comment, author=partner)
        self._create_message('<p>Email from</p>', self.mt_comment, author=None, email_from='bob@example.com')
        timeline = TimelineBuilder.get_all_messages(self.lead, self.env)
        self.assertEqual(timeline[0]['author'], 'Alice')
        self.assertEqual(timeline[1]['author'], 'bob@example.com')

