# -*- coding: utf-8 -*-

import base64
from unittest.mock import patch

from odoo import fields
from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestUpdateFlow(TransactionCase):
    def setUp(self):
        super().setUp()
        self.engine = self.env['living.document.engine']
        self.lead = self.env['crm.lead'].create({'name': 'Lead Update Flow'})
        self.mt_comment = self.env.ref('mail.mt_comment', raise_if_not_found=False) or self.env.ref('mail.mt_note')
        self.env['ir.config_parameter'].sudo().set_param('living_doc.auto_update', 'True')
        self.env['ir.config_parameter'].sudo().set_param('living_doc.update_delay', '30')

        self.engine.generate_document(self.lead, mode='odoo', include_existing=True)
        self.lead.invalidate_recordset()

    def _create_message(self, body, message_type='email'):
        return self.env['mail.message'].create(
            {
                'model': 'crm.lead',
                'res_id': self.lead.id,
                'message_type': message_type,
                'subtype_id': self.mt_comment.id,
                'body': body,
            }
        )

    def test_new_email_on_active_lead_triggers_update_pipeline(self):
        self._create_message('<p>Hello</p>')
        self.lead.invalidate_recordset()
        self.assertTrue(self.lead.x_living_doc_pending_update)

    def test_new_email_on_lead_without_living_doc_no_trigger(self):
        lead2 = self.env['crm.lead'].create({'name': 'No Living Doc'})
        self.env['mail.message'].create(
            {'model': 'crm.lead', 'res_id': lead2.id, 'message_type': 'email', 'subtype_id': self.mt_comment.id, 'body': '<p>x</p>'}
        )
        lead2.invalidate_recordset()
        self.assertFalse(lead2.x_living_doc_pending_update)

    def test_paused_document_no_trigger(self):
        self.lead.action_pause_living_document()
        self._create_message('<p>Paused</p>')
        self.lead.invalidate_recordset()
        # schedule should not occur because status paused
        self.assertFalse(self.lead.x_living_doc_pending_update)

    def test_multiple_rapid_messages_batched_into_single_update(self):
        # Delay is 30s, multiple messages set pending once and a single cron execution processes it once.
        self._create_message('<p>m1</p>')
        self._create_message('<p>m2</p>')
        self._create_message('<p>m3</p>')
        self.lead.invalidate_recordset()
        self.assertTrue(self.lead.x_living_doc_pending_update)

        # Fast-forward to eligible
        self.lead.write({'x_living_doc_next_process_at': fields.Datetime.now()})

        call_count = {'n': 0}

        def fake_update(lead):
            call_count['n'] += 1
            return True

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine.update_document', side_effect=fake_update):
            self.env['crm.lead']._cron_process_pending_living_docs()

        self.assertEqual(call_count['n'], 1)

    def test_last_processed_message_id_updated_after_success(self):
        self._create_message('<p>Update me</p>')

        class FakeClaude:
            def clean_messages(self, raw):
                return raw, 1, 'haiku'

            def structure_messages(self, cleaned):
                return {'requirements': [], 'questions': [], 'decisions': [], 'action_items': [], 'issues': []}, 1, 'sonnet'

            def generate_summary(self, structured, prev, timeline):
                return {
                    'executive_summary': 'Summary',
                    'requirements': [],
                    'decisions': [],
                    'open_questions': [],
                    'action_items': [],
                    'communication_count': len(timeline),
                    'last_communication_date': '2026-01-01',
                }, 1, 'sonnet'

            def detect_changes(self, prev, new):
                return {'has_significant_changes': False, 'change_summary': '(none)'}, 1, 'sonnet'

        with patch('odoo.addons.living_document_crm.models.document_engine.LivingDocumentEngine._get_claude', return_value=FakeClaude()):
            self.lead.write({'x_living_doc_next_process_at': fields.Datetime.now()})
            self.env['crm.lead']._cron_process_pending_living_docs()

        self.lead.invalidate_recordset()
        self.assertGreater(self.lead.x_last_processed_message_id, 0)
        self.assertTrue(self.lead.x_last_summary_json)

        raw = self.lead.x_living_doc_id.attachment_id.datas or ''
        body = base64.b64decode(raw).decode('utf-8', errors='ignore') if raw else ''
        self.assertIn('# Lead: %s' % self.lead.name, body)
        self.assertIn('## 2. Latest Requirements', body)
        self.assertIn('## 6. Risk Alerts / Requirement Changes', body)

