# -*- coding: utf-8 -*-

from odoo.tools import html2plaintext


class TimelineBuilder:
    """Extracts and structures mail.message data from CRM leads."""

    @staticmethod
    def _domain_base(lead):
        return [
            ('model', '=', 'crm.lead'),
            ('res_id', '=', lead.id),
            ('message_type', 'in', ['email', 'comment']),
        ]

    @staticmethod
    def _exclude_system_notes(domain, env):
        # Keep note/comment/email messages and filter machine noise at content level.
        # Excluding all mt_note drops valuable manual discussion in many Odoo setups.
        return domain

    @staticmethod
    def _looks_like_system_noise(text):
        t = (text or '').strip().lower()
        if not t:
            return True
        patterns = (
            'stage changed',
            'assigned to',
            'record created',
            'status changed',
            'activity',
            'automated',
            'has been archived',
            'is now',
        )
        return any(p in t for p in patterns) and len(t) < 220

    @staticmethod
    def _messages_to_timeline(messages):
        timeline = []
        for msg in messages:
            body_text = html2plaintext(msg.body) if msg.body else ''
            if TimelineBuilder._looks_like_system_noise(body_text):
                continue
            attachments = []
            for att in msg.attachment_ids:
                attachments.append(
                    {
                        'id': att.id,
                        'name': att.name,
                        'mimetype': att.mimetype,
                        'size': getattr(att, 'file_size', 0) or 0,
                    }
                )
            author = (msg.author_id.name if msg.author_id else False) or (msg.email_from or 'Unknown')
            timeline.append(
                {
                    'id': msg.id,
                    'date': msg.date.isoformat() if msg.date else '',
                    'author': author,
                    'email_from': msg.email_from or '',
                    'type': msg.message_type,
                    'subject': msg.subject or '',
                    'content': body_text,
                    'attachments': attachments,
                }
            )
        return timeline

    @staticmethod
    def get_new_messages(lead, env):
        """Fetch messages newer than last processed, return structured list."""
        last_id = lead.x_last_processed_message_id or 0

        messages = []
        lead_msgs = env['mail.message'].search(
            TimelineBuilder._domain_base(lead) + [('id', '>', last_id)],
            order='id asc',
        )
        messages.extend(list(lead_msgs))

        ticket_ids_by_model = TimelineBuilder._get_ticket_ids_for_lead(lead, env)
        for ticket_model, ticket_ids in (ticket_ids_by_model or {}).items():
            if not ticket_ids:
                continue
            t_msgs = env['mail.message'].search(
                [
                    ('model', '=', ticket_model),
                    ('res_id', 'in', ticket_ids),
                    ('message_type', 'in', ['email', 'comment']),
                    ('id', '>', last_id),
                ],
                order='id asc',
            )
            messages.extend(list(t_msgs))

        messages.sort(key=lambda m: m.id)
        return TimelineBuilder._messages_to_timeline(messages)

    @staticmethod
    def get_all_messages(lead, env):
        """Fetch ALL messages for initial document creation."""
        messages = []
        lead_msgs = env['mail.message'].search(
            TimelineBuilder._domain_base(lead),
            order='id asc',
        )
        messages.extend(list(lead_msgs))

        ticket_ids_by_model = TimelineBuilder._get_ticket_ids_for_lead(lead, env)
        for ticket_model, ticket_ids in (ticket_ids_by_model or {}).items():
            if not ticket_ids:
                continue
            t_msgs = env['mail.message'].search(
                [
                    ('model', '=', ticket_model),
                    ('res_id', 'in', ticket_ids),
                    ('message_type', 'in', ['email', 'comment']),
                ],
                order='id asc',
            )
            messages.extend(list(t_msgs))

        messages.sort(key=lambda m: m.id)
        return TimelineBuilder._messages_to_timeline(messages)

    @staticmethod
    def _get_ticket_ids_for_lead(lead, env):
        """Return {mail_message_model: [ticket_ids]} linked to the lead.

        Supports both `sh.helpdesk.ticket` and legacy `helpdesk.ticket`,
        and different possible lead-link fields.
        """
        ticket_ids_by_model = {}
        ticket_model_candidates = ("sh.helpdesk.ticket", "helpdesk.ticket")
        for ticket_model in ticket_model_candidates:
            if ticket_model not in env.registry.models:
                continue
            Ticket = env[ticket_model].sudo()
            ticket_fields = Ticket._fields
            if "x_linked_lead_id" in ticket_fields:
                ids = Ticket.search([("x_linked_lead_id", "=", lead.id)]).ids
            elif "x_related_lead_id" in ticket_fields:
                ids = Ticket.search([("x_related_lead_id", "=", lead.id)]).ids
            elif "lead_id" in ticket_fields:
                ids = Ticket.search([("lead_id", "=", lead.id)]).ids
            elif "sh_lead_ids" in ticket_fields:
                ids = Ticket.search([("sh_lead_ids", "in", [lead.id])]).ids
            else:
                ids = []
            if ids:
                ticket_ids_by_model[ticket_model] = ids
        return ticket_ids_by_model

