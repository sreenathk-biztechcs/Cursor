# -*- coding: utf-8 -*-

import json
import logging
import random
import time

from odoo import _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

try:
    import anthropic  # type: ignore
except Exception:  # pylint: disable=broad-except
    anthropic = None

try:
    import requests  # type: ignore
except Exception:  # pylint: disable=broad-except
    requests = None


class ClaudeService:
    """Wrapper for Claude API with multi-model support and cost optimization."""

    MODELS = {
        'haiku': 'claude-haiku-4-5-20251001',
        'sonnet': 'claude-sonnet-4-5-20250929',
    }

    def __init__(self, api_key):
        self.api_key = api_key
        self._client = anthropic.Anthropic(api_key=api_key) if (anthropic and api_key) else None

    def _ensure_config(self):
        if not self.api_key:
            raise UserError(_('Claude API key is not configured. Set it in Settings → CRM → Living Document.'))
        if not self._client and not requests:
            raise UserError(
                _(
                    'Claude client libraries are missing (anthropic or requests). '
                    'Install one of them in the Odoo Python environment.'
                )
            )

    def _call_messages_api(self, model, prompt, max_tokens=4096, temperature=0.2, retries=5):
        self._ensure_config()

        last_err = None
        for attempt in range(1, retries + 1):
            try:
                if self._client:
                    resp = self._client.messages.create(
                        model=model,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        messages=[{'role': 'user', 'content': prompt}],
                    )
                    text = ''
                    for block in getattr(resp, 'content', []) or []:
                        if getattr(block, 'type', None) == 'text':
                            text += block.text
                        elif isinstance(block, dict) and block.get('type') == 'text':
                            text += block.get('text', '')
                    usage = getattr(resp, 'usage', None)
                    tokens = 0
                    if usage:
                        tokens = int(getattr(usage, 'input_tokens', 0) or 0) + int(getattr(usage, 'output_tokens', 0) or 0)
                    return {'text': (text or '').strip(), 'tokens': tokens, 'raw': resp}

                # HTTP fallback (no anthropic SDK)
                headers = {
                    'x-api-key': self.api_key,
                    'anthropic-version': '2023-06-01',
                    'content-type': 'application/json',
                }
                payload = {
                    'model': model,
                    'max_tokens': max_tokens,
                    'temperature': temperature,
                    'messages': [{'role': 'user', 'content': prompt}],
                }
                r = requests.post('https://api.anthropic.com/v1/messages', headers=headers, data=json.dumps(payload), timeout=60)
                if r.status_code in (429, 500, 502, 503, 504):
                    raise UserError('Claude API transient error (%s): %s' % (r.status_code, r.text))
                if r.status_code >= 400:
                    raise UserError('Claude API error (%s): %s' % (r.status_code, r.text))
                data = r.json()
                text = ''
                for block in data.get('content') or []:
                    if block.get('type') == 'text':
                        text += block.get('text', '')
                usage = data.get('usage') or {}
                tokens = int(usage.get('input_tokens', 0) or 0) + int(usage.get('output_tokens', 0) or 0)
                return {'text': (text or '').strip(), 'tokens': tokens, 'raw': data}
            except Exception as exc:  # pylint: disable=broad-except
                last_err = exc
                is_rate = '429' in str(exc).lower() or 'rate' in str(exc).lower()
                backoff = min(60.0, (2 ** (attempt - 1)) + random.random())
                if not is_rate and attempt >= retries:
                    break
                _logger.warning('Claude call failed attempt %s/%s: %s; sleeping %.2fs', attempt, retries, exc, backoff)
                time.sleep(backoff)
        raise UserError(_('Claude API call failed after retries: %s') % (str(last_err),))

    @staticmethod
    def _extract_json_payload(text):
        """Extract JSON from common Claude formatting (e.g. ```json ... ```)."""
        t = (text or '').strip()
        if not t:
            return t

        # Strip markdown fences if present
        if t.startswith('```'):
            # remove first fence line and trailing fence
            lines = t.splitlines()
            # drop first line (``` or ```json)
            if lines:
                lines = lines[1:]
            # drop last line if it's ```
            if lines and lines[-1].strip().startswith('```'):
                lines = lines[:-1]
            t = '\n'.join(lines).strip()

        # If still contains other text, try extracting the first JSON array/object substring.
        start_positions = [p for p in (t.find('{'), t.find('[')) if p != -1]
        if not start_positions:
            return t
        start = min(start_positions)
        candidate = t[start:].strip()

        # Try direct parse; if fails, try to cut at the last closing brace/bracket.
        try:
            json.loads(candidate)
            return candidate
        except Exception:
            pass

        # Best-effort trim
        last_obj = candidate.rfind('}')
        last_arr = candidate.rfind(']')
        end = max(last_obj, last_arr)
        if end != -1:
            return candidate[: end + 1].strip()
        return candidate

    def _call_json(self, model_key, prompt, max_tokens=4096):
        model = self.MODELS[model_key]
        result = self._call_messages_api(model=model, prompt=prompt, max_tokens=max_tokens)
        text = (result.get('text') or '').strip()
        payload = self._extract_json_payload(text)
        try:
            return json.loads(payload), result.get('tokens', 0), model
        except Exception as exc:
            raise UserError(_('Claude returned invalid JSON: %s\nRaw: %s') % (str(exc), text[:2000]))

    def clean_messages(self, raw_messages):
        messages_json = json.dumps(raw_messages or [], ensure_ascii=False)
        prompt = (
            "You are a data cleaning specialist. Given a list of email/chat messages from a CRM system, clean them:\n\n"
            "1. Remove email signatures (-- , Regards, Sent from, etc.)\n"
            "2. Remove quoted reply chains (lines starting with > or \"On {date} {person} wrote:\")\n"
            "3. Remove HTML artifacts, CSS, invisible characters\n"
            "4. Remove automated system notifications (\"Stage changed to...\", \"Assigned to...\")\n"
            "5. Remove duplicate content (same message appearing multiple times)\n"
            "6. Preserve the actual communication content, names, dates, and context\n"
            "7. DO NOT remove any content discussing requirements, decisions, questions, or action items\n"
            "8. DO NOT include any financial figures, pricing, payment terms, or invoice details\n\n"
            "Input (JSON array):\n"
            f"{messages_json}\n\n"
            "Output ONLY a JSON array with the same structure, but with cleaned \"content\" fields.\n"
            "No explanation, no markdown fences, just valid JSON."
        )
        return self._call_json('haiku', prompt, max_tokens=4096)

    def structure_messages(self, cleaned_messages):
        cleaned_json = json.dumps(cleaned_messages or [], ensure_ascii=False)
        prompt = (
            "You are a senior project analyst. Analyze these communications from a CRM lead and extract structured information.\n\n"
            "Communications:\n"
            f"{cleaned_json}\n\n"
            "Extract and return a JSON object with:\n"
            "{\n"
            "  \"requirements\": [{\"id\": \"R1\", \"text\": \"...\", \"source_date\": \"...\", \"status\": \"new|updated|unchanged\"}],\n"
            "  \"questions\": [{\"id\": \"Q1\", \"text\": \"...\", \"asked_by\": \"...\", \"date\": \"...\", \"status\": \"open|answered\"}],\n"
            "  \"decisions\": [{\"id\": \"D1\", \"text\": \"...\", \"decided_by\": \"...\", \"date\": \"...\"}],\n"
            "  \"action_items\": [{\"id\": \"A1\", \"text\": \"...\", \"owner\": \"...\", \"due_date\": \"...\", \"status\": \"open|done\"}],\n"
            "  \"issues\": [{\"id\": \"I1\", \"text\": \"...\", \"severity\": \"low|medium|high\", \"date\": \"...\"}]\n"
            "}\n\n"
            "Rules:\n"
            "- If a requirement was mentioned before and changed, mark status as \"updated\" and note what changed\n"
            "- Questions that were answered in later messages should be marked \"answered\"\n"
            "- Be precise with attribution — who said what and when\n"
            "- Exclude financial details (prices, invoices, payment)\n"
            "- Output ONLY valid JSON, no explanation"
        )
        return self._call_json('sonnet', prompt, max_tokens=4096)

    def generate_summary(self, structured_data, previous_summary, timeline):
        prev_json = json.dumps(previous_summary or {}, ensure_ascii=False)
        structured_json = json.dumps(structured_data or {}, ensure_ascii=False)
        timeline_json = json.dumps(timeline or [], ensure_ascii=False)
        prompt = (
            "You are creating an executive briefing document for a CRM lead. You have:\n\n"
            "1. PREVIOUS DOCUMENT SUMMARY (from last update):\n"
            f"{prev_json}\n\n"
            "2. NEW STRUCTURED DATA (extracted from recent communications):\n"
            f"{structured_json}\n\n"
            "3. FULL TIMELINE (all communications):\n"
            f"{timeline_json}\n\n"
            "Generate a comprehensive, UPDATED summary that:\n"
            "- MERGES the previous summary with new information (do NOT duplicate)\n"
            "- Updates requirement statuses if they changed\n"
            "- Moves answered questions from \"open\" to \"answered\"\n"
            "- Adds new action items, marks completed ones as done\n"
            "- Reflects the CURRENT state of the project, not just the new messages\n"
            "- Keeps the tone professional and factual\n"
            "- Excludes any financial details\n\n"
            "Return a JSON object:\n"
            "{\n"
            "  \"executive_summary\": \"2-3 paragraph overview of current project state\",\n"
            "  \"requirements\": [...merged and updated list...],\n"
            "  \"decisions\": [...merged list...],\n"
            "  \"open_questions\": [...only currently open ones...],\n"
            "  \"action_items\": [...merged with status updates...],\n"
            "  \"communication_count\": N,\n"
            "  \"last_communication_date\": \"YYYY-MM-DD\"\n"
            "}\n\n"
            "Output ONLY valid JSON."
        )
        return self._call_json('sonnet', prompt, max_tokens=6144)

    def detect_changes(self, previous_summary, new_summary):
        prev_json = json.dumps(previous_summary or {}, ensure_ascii=False)
        new_json = json.dumps(new_summary or {}, ensure_ascii=False)
        prompt = (
            "Compare the previous project state with the new state and detect significant changes.\n\n"
            "PREVIOUS STATE:\n"
            f"{prev_json}\n\n"
            "NEW STATE:\n"
            f"{new_json}\n\n"
            "Detect and report:\n"
            "{\n"
            "  \"requirement_changes\": [{\"requirement_id\": \"R1\", \"change_type\": \"new|modified|removed\", \"description\": \"what changed\"}],\n"
            "  \"scope_creep\": [{\"description\": \"...\", \"severity\": \"low|medium|high\"}],\n"
            "  \"new_risks\": [{\"description\": \"...\", \"severity\": \"low|medium|high\"}],\n"
            "  \"resolved_items\": [{\"type\": \"question|issue|action\", \"id\": \"...\", \"resolution\": \"...\"}],\n"
            "  \"has_significant_changes\": true/false,\n"
            "  \"change_summary\": \"One paragraph describing what changed since last update\"\n"
            "}\n\n"
            "Output ONLY valid JSON."
        )
        return self._call_json('sonnet', prompt, max_tokens=4096)

    def summarize_attachments(self, attachment_entries):
        """Summarize attachment text snippets into concise bullet points.

        attachment_entries: [{"id":..,"name":..,"mimetype":..,"text_excerpt":..}, ...]
        Returns JSON: {"attachments":[{"id":..,"summary":"..."}, ...]}
        """
        payload = json.dumps(attachment_entries or [], ensure_ascii=False)
        prompt = (
            "You are a senior analyst. Summarize the following file attachments for a CRM lead.\n\n"
            "Rules:\n"
            "- Produce concise summaries (1-4 bullet points per attachment)\n"
            "- Capture requirements, decisions, action items, key facts\n"
            "- Exclude financial details (prices, invoices, payment terms)\n"
            "- If text is empty/unreadable, say \"(no text extracted)\"\n\n"
            "Input JSON array:\n"
            f"{payload}\n\n"
            "Output ONLY valid JSON in this shape:\n"
            "{\n"
            "  \"attachments\": [\n"
            "    {\"id\": 123, \"summary\": \"- ...\\n- ...\"}\n"
            "  ]\n"
            "}\n"
        )
        return self._call_json('haiku', prompt, max_tokens=2048)

    def summarize_timeline(self, timeline):
        """Create a concise communication digest for document timeline section."""
        timeline_json = json.dumps(timeline or [], ensure_ascii=False)
        prompt = (
            "You are preparing a concise CRM communication digest.\n\n"
            "Input timeline JSON:\n"
            f"{timeline_json}\n\n"
            "Generate a compact markdown summary of communication history.\n"
            "Rules:\n"
            "- Keep only meaningful business communication and milestones\n"
            "- Remove duplicates, quoted chains, signatures, and system noise\n"
            "- Mention key client asks, responses, and meeting-related updates\n"
            "- Keep it brief (max 10 bullets)\n"
            "- Exclude financial details\n\n"
            "Output ONLY valid JSON in this shape:\n"
            "{\n"
            "  \"timeline_summary\": \"- 2026-03-26: ...\\n- 2026-03-27: ...\"\n"
            "}\n"
        )
        return self._call_json('haiku', prompt, max_tokens=2048)

