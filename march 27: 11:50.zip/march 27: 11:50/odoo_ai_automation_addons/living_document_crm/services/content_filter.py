# -*- coding: utf-8 -*-

import copy
import re


class ContentFilter:
    """Filters sensitive content from messages before AI processing."""

    FINANCIAL_PATTERNS = [
        r'\$[\d,]+\.?\d*',  # Dollar amounts
        r'€[\d,]+\.?\d*',  # Euro amounts
        r'₹[\d,]+\.?\d*',  # Rupee amounts
        r'\b\d+\s*(USD|EUR|INR|GBP)\b',
        r'\binvoice\s*#?\s*\d+\b',
        r'\bpayment\b.*\b(terms?|due|received)\b',
        r'\bpric(e|ing)\b',
        r'\bquot(e|ation)\b.*\b\d+\b',
        r'\bdiscount\b.*\b\d+%?\b',
        r'\btotal\s*:?\s*[\$€₹]\s*[\d,]+',
        r'\bsubtotal\s*:?\s*[\$€₹]\s*[\d,]+',
        r'\btax\s*:?\s*[\$€₹]\s*[\d,]+',
        r'\bbalance\s*:?\s*[\$€₹]\s*[\d,]+',
        r'\bwire\b.*\btransfer\b',
        r'\bbank\b.*\baccount\b',
        r'\bIBAN\b\s*[:#]?\s*[A-Z0-9 ]{10,}\b',
    ]

    _compiled = None

    @classmethod
    def _get_compiled(cls):
        if cls._compiled is None:
            cls._compiled = [re.compile(pat, flags=re.IGNORECASE | re.MULTILINE) for pat in cls.FINANCIAL_PATTERNS]
        return cls._compiled

    @classmethod
    def filter_sensitive(cls, messages):
        """Replace matched patterns with [FINANCIAL_DATA_REDACTED]."""
        compiled = cls._get_compiled()
        out = copy.deepcopy(messages or [])
        for msg in out:
            content = msg.get('content') or ''
            for rx in compiled:
                content = rx.sub('[FINANCIAL_DATA_REDACTED]', content)
            msg['content'] = content
            if msg.get('subject'):
                subj = msg.get('subject') or ''
                for rx in compiled:
                    subj = rx.sub('[FINANCIAL_DATA_REDACTED]', subj)
                msg['subject'] = subj
        return out

