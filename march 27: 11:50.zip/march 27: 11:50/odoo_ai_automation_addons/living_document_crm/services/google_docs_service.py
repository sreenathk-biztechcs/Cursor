# -*- coding: utf-8 -*-

import json
import logging

from odoo import _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

try:
    from google.oauth2.credentials import Credentials  # type: ignore
    from google.oauth2 import service_account  # type: ignore
    from googleapiclient.discovery import build  # type: ignore
except Exception:  # pylint: disable=broad-except
    Credentials = None
    service_account = None
    build = None


class GoogleDocsService:
    """Google Docs API integration for creating and updating documents.

    Production note:
    - We keep the integration robust and simple: full regenerate (delete + insert).
    - Formatting is minimal (plain text insertion). Structure is preserved by markdown text.
    """

    SCOPES = [
        'https://www.googleapis.com/auth/documents',
        'https://www.googleapis.com/auth/drive',
        'https://www.googleapis.com/auth/drive.file',
    ]

    def __init__(self, credentials_json):
        if not build or (not Credentials and not service_account):
            raise UserError(
                _(
                    'Google API libraries are missing. Install google-api-python-client and google-auth in the Odoo environment.'
                )
            )
        if not credentials_json:
            raise UserError(_('Google credentials JSON is not configured. Set it in Settings → CRM → Living Document.'))
        try:
            info = json.loads(credentials_json)
        except Exception as exc:
            raise UserError(_('Google credentials must be valid JSON: %s') % (str(exc),))
        creds = None
        if info.get('type') == 'service_account':
            if not service_account:
                raise UserError(_('google-auth service account support is missing in this environment.'))
            creds = service_account.Credentials.from_service_account_info(info, scopes=self.SCOPES)
        else:
            if not Credentials:
                raise UserError(_('google-auth credentials support is missing in this environment.'))
            # common mistake: user pastes OAuth client secret JSON {"web": ...} or {"installed": ...}
            if 'web' in info or 'installed' in info:
                raise UserError(
                    _(
                        'You pasted OAuth client configuration JSON, not credential JSON.\n'
                        'Provide one of the following:\n'
                        '1) Service account JSON (recommended), or\n'
                        '2) Authorized user JSON containing refresh_token, client_id, client_secret, token_uri.'
                    )
                )
            required = {'refresh_token', 'client_id', 'client_secret'}
            missing = sorted([k for k in required if not info.get(k)])
            if missing:
                raise UserError(
                    _(
                        'Invalid Google authorized user credentials. Missing fields: %s.\n'
                        'Expected JSON keys include refresh_token, client_id, client_secret, token_uri.'
                    )
                    % ', '.join(missing)
                )
            try:
                creds = Credentials.from_authorized_user_info(info, scopes=self.SCOPES)
            except Exception as exc:
                raise UserError(_('Could not initialize Google credentials: %s') % (str(exc),))
        self.docs_service = build('docs', 'v1', credentials=creds, cache_discovery=False)
        self.drive_service = build('drive', 'v3', credentials=creds, cache_discovery=False)

    def _insert_plain_text_requests(self, text):
        # Insert all text at index 1 (start of document body).
        return [{'insertText': {'location': {'index': 1}, 'text': text or ''}}]

    def create_document(self, title, initial_content_markdown):
        """Create a new Google Doc and return doc_id."""
        doc = self.docs_service.documents().create(body={'title': title}).execute()
        doc_id = doc.get('documentId')
        if not doc_id:
            raise UserError(_('Google Docs API did not return a documentId.'))
        self.update_document(doc_id, initial_content_markdown)
        return doc_id

    def update_document(self, doc_id, new_content_markdown):
        """Replace entire document content with new version."""
        doc = self.docs_service.documents().get(documentId=doc_id).execute()
        end_index = 1
        body = (doc.get('body') or {}).get('content') or []
        for el in body:
            seg = el.get('endIndex')
            if seg and seg > end_index:
                end_index = seg
        # Delete from 1 to end_index-1 (Google docs uses 1-based indices, endIndex is exclusive)
        requests = []
        delete_end = max(1, int(end_index or 1) - 1)
        # Google rejects empty ranges (startIndex == endIndex).
        if delete_end > 1:
            requests.append({'deleteContentRange': {'range': {'startIndex': 1, 'endIndex': delete_end}}})
        requests += self._insert_plain_text_requests(new_content_markdown)
        self.docs_service.documents().batchUpdate(documentId=doc_id, body={'requests': requests}).execute()
        return True

    def get_document_content(self, doc_id):
        """Fetch current document content (plain text)."""
        doc = self.docs_service.documents().get(documentId=doc_id).execute()
        out = []
        for el in ((doc.get('body') or {}).get('content') or []):
            para = el.get('paragraph')
            if not para:
                continue
            for pe in para.get('elements') or []:
                tr = (pe.get('textRun') or {}).get('content')
                if tr:
                    out.append(tr)
        return ''.join(out)

    def get_revision_id(self, doc_id):
        """Get latest revision ID for change detection."""
        # Drive revisions for Docs (optional; requires Drive API enabled).
        try:
            revs = (
                self.drive_service.revisions()
                .list(fileId=doc_id, pageSize=1, fields='revisions(id, modifiedTime)')
                .execute()
            )
            revisions = revs.get('revisions') or []
            if not revisions:
                return False
            return revisions[-1].get('id')
        except Exception as exc:  # pylint: disable=broad-except
            # Keep the integration usable even if Drive API isn't enabled.
            _logger.warning('Google Drive revisions unavailable: %s', exc)
            return False

    def share_document(self, doc_id, email, role='reader'):
        """Share document with a user."""
        if role not in ('reader', 'writer', 'commenter'):
            role = 'reader'
        body = {'type': 'user', 'role': role, 'emailAddress': email}
        self.drive_service.permissions().create(fileId=doc_id, body=body, sendNotificationEmail=False).execute()
        return True

