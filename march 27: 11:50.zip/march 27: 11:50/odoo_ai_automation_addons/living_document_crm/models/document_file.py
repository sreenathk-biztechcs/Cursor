# -*- coding: utf-8 -*-

import base64

from odoo import api, fields, models


class DocumentFile(models.Model):
    _inherit = 'document.file'

    x_living_doc_markdown = fields.Text(
        string='Living Doc (Markdown)',
        compute='_compute_x_living_doc_markdown',
        inverse='_inverse_x_living_doc_markdown',
    )
    x_is_living_doc = fields.Boolean(string='Is Living Doc', compute='_compute_x_is_living_doc', store=False)

    @api.depends('mimetype', 'attachment', 'attachment_id')
    def _compute_x_is_living_doc(self):
        for rec in self:
            # We treat markdown mimetype or .md extension as editable in-app
            ext = (rec.extension or '').lower()
            rec.x_is_living_doc = (rec.mimetype == 'text/markdown') or (ext == 'md')

    @api.depends('attachment', 'attachment_id')
    def _compute_x_living_doc_markdown(self):
        for rec in self:
            raw = rec.attachment or (rec.attachment_id.datas if rec.attachment_id else False) or False
            if not raw:
                rec.x_living_doc_markdown = ''
                continue
            try:
                data = base64.b64decode(raw)
                rec.x_living_doc_markdown = data.decode('utf-8', errors='ignore')
            except Exception:
                rec.x_living_doc_markdown = ''

    def _inverse_x_living_doc_markdown(self):
        for rec in self:
            text = rec.x_living_doc_markdown or ''
            encoded = base64.b64encode(text.encode('utf-8'))
            # Keep both enhanced_document_management binary and ir.attachment in sync
            vals = {'attachment': encoded}
            if rec.attachment_id:
                rec.attachment_id.sudo().write({'datas': encoded, 'mimetype': rec.mimetype or 'text/markdown'})
            rec.sudo().write(vals)

