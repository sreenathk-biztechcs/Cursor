# -*- coding: utf-8 -*-

import json
import logging
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    x_living_doc_id = fields.Many2one('document.file', string='Living Document', tracking=True)
    x_google_doc_id = fields.Char(string='Google Doc ID', tracking=True)
    x_google_doc_url = fields.Char(string='Google Doc URL', compute='_compute_google_doc_url')
    x_google_doc_revision_id = fields.Char(string='Google Doc Revision ID', tracking=True)
    x_last_processed_message_id = fields.Integer(string='Last Processed Message ID', default=0)
    x_last_summary_json = fields.Text(
        string='Last AI Summary (JSON)',
        help='Cached previous summary for delta processing',
    )
    x_living_doc_status = fields.Selection(
        [
            ('none', 'No Document'),
            ('creating', 'Creating...'),
            ('active', 'Active'),
            ('error', 'Error'),
            ('paused', 'Paused'),
        ],
        default='none',
        string='Living Doc Status',
        tracking=True,
    )
    x_living_doc_mode = fields.Selection(
        [
            ('odoo', 'Odoo Document'),
            ('google', 'Google Doc'),
            ('both', 'Both (Synced)'),
        ],
        string='Document Mode',
        tracking=True,
    )
    x_living_doc_log_ids = fields.One2many('living.doc.log', 'lead_id', string='Document Logs')
    x_living_doc_log_count = fields.Integer(string='Living Doc Log Count', compute='_compute_living_doc_log_count')
    x_living_doc_error = fields.Text(string='Last Error')

    x_living_doc_pending_update = fields.Boolean(string='Living Doc Pending Update', default=False, index=True)
    x_living_doc_next_process_at = fields.Datetime(string='Next Living Doc Processing At', index=True)

    def _compute_google_doc_url(self):
        for lead in self:
            lead.x_google_doc_url = (
                ('https://docs.google.com/document/d/%s/edit' % lead.x_google_doc_id)
                if lead.x_google_doc_id
                else False
            )

    def _compute_living_doc_log_count(self):
        Log = self.env['living.doc.log']
        counts = {}
        # Odoo 19: use _read_group instead of deprecated read_group.
        grouped = Log._read_group(
            [('lead_id', 'in', self.ids)],
            ['lead_id'],
            ['__count'],
        )
        for lead_rec, count in grouped:
            if lead_rec:
                counts[lead_rec.id] = int(count or 0)
        for lead in self:
            lead.x_living_doc_log_count = counts.get(lead.id, 0)

    def action_create_living_document(self):
        self.ensure_one()
        if self.x_living_doc_status not in ('none', False) or self.x_living_doc_id or self.x_google_doc_id:
            raise UserError(_('A living document already exists for this lead.'))
        return {
            'type': 'ir.actions.act_window',
            'name': _('Create Living Document'),
            'res_model': 'create.living.doc.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_mode': self.env['ir.config_parameter'].sudo().get_param('living_doc.default_mode', default='odoo'),
                'active_model': 'crm.lead',
                'active_id': self.id,
            },
        }

    def action_refresh_living_document(self):
        self.ensure_one()
        if self.x_living_doc_status not in ('active', 'error'):
            return True
        # Manual refresh should be immediate and should not depend on cron/auto-update setting.
        self.write({'x_living_doc_status': 'active', 'x_living_doc_pending_update': True})
        self._process_living_document_update()
        return True

    def action_open_living_document(self):
        self.ensure_one()
        if self.x_google_doc_url and self.x_living_doc_mode in ('google', 'both'):
            return {'type': 'ir.actions.act_url', 'url': self.x_google_doc_url, 'target': 'new'}
        if self.x_living_doc_id:
            return {
                'type': 'ir.actions.act_window',
                'name': _('Living Document'),
                'res_model': 'document.file',
                'res_id': self.x_living_doc_id.id,
                'view_mode': 'form',
                'target': 'current',
            }
        raise UserError(_('No living document found for this lead.'))

    def action_pause_living_document(self):
        for lead in self:
            if lead.x_living_doc_status == 'active':
                lead.write({'x_living_doc_status': 'paused'})
        return True

    def action_resume_living_document(self):
        for lead in self:
            if lead.x_living_doc_status == 'paused':
                lead.write({'x_living_doc_status': 'active'})
                lead._schedule_living_doc_update(force_immediate=True, reason='resume', ignore_auto_update=True)
        return True

    def _schedule_living_doc_update(self, force_immediate=False, reason='trigger', ignore_auto_update=False):
        icp = self.env['ir.config_parameter'].sudo()
        auto_update = icp.get_param('living_doc.auto_update', default='True')
        if not ignore_auto_update and str(auto_update).lower() in ('false', '0', 'no'):
            return False

        delay_seconds = int(icp.get_param('living_doc.update_delay', default='30') or 30)
        now = fields.Datetime.now()
        scheduled_at = now if force_immediate else (now + timedelta(seconds=delay_seconds))

        for lead in self:
            if lead.x_living_doc_status != 'active':
                continue
            lead.write({'x_living_doc_pending_update': True, 'x_living_doc_next_process_at': scheduled_at})
            self.env['living.doc.log'].sudo().create_log(
                lead,
                stage='trigger',
                status='success',
                message='Update scheduled (%s)' % reason,
                data={'scheduled_at': scheduled_at, 'reason': reason},
            )
        return True

    def _process_living_document_update(self):
        """Run update in server-side context (cron/queue)."""
        engine = self.env['living.document.engine']
        for lead in self:
            if lead.x_living_doc_status != 'active' or lead.x_living_doc_status == 'paused':
                continue
            try:
                engine.update_document(lead)
            except Exception as exc:  # pylint: disable=broad-except
                _logger.exception('Living doc update failed for lead %s', lead.id)
                lead.sudo().write({'x_living_doc_status': 'error', 'x_living_doc_error': str(exc)})
                self.env['living.doc.log'].sudo().create_log(
                    lead,
                    stage='error',
                    status='error',
                    message='Update failed: %s' % (str(exc),),
                )
            finally:
                lead.sudo().write({'x_living_doc_pending_update': False})
        return True

    @api.model
    def _cron_process_pending_living_docs(self, limit=50):
        now = fields.Datetime.now()
        domain = [
            ('x_living_doc_pending_update', '=', True),
            ('x_living_doc_status', '=', 'active'),
            '|',
            ('x_living_doc_next_process_at', '=', False),
            ('x_living_doc_next_process_at', '<=', now),
        ]
        leads = self.search(domain, limit=limit, order='x_living_doc_next_process_at asc, id asc')
        if leads:
            leads._process_living_document_update()
        return True

    @api.model
    def _cron_google_sync_checker(self, limit=50):
        icp = self.env['ir.config_parameter'].sudo()
        enabled = icp.get_param('living_doc.google_sync_enabled', default='False')
        if str(enabled).lower() in ('false', '0', 'no'):
            return True
        domain = [
            ('x_living_doc_status', '=', 'active'),
            ('x_living_doc_mode', 'in', ('google', 'both')),
            ('x_google_doc_id', '!=', False),
        ]
        leads = self.search(domain, limit=limit, order='id asc')
        engine = self.env['living.document.engine']
        for lead in leads:
            try:
                engine.sync_google_doc(lead)
            except Exception as exc:  # pylint: disable=broad-except
                _logger.exception('Google sync failed for lead %s', lead.id)
                lead.sudo().write({'x_living_doc_error': 'Google sync failed: %s' % str(exc)})
                self.env['living.doc.log'].sudo().create_log(
                    lead,
                    stage='google_sync',
                    status='error',
                    message='Google sync failed: %s' % (str(exc),),
                )
        return True

    def _get_last_summary(self):
        self.ensure_one()
        if not self.x_last_summary_json:
            return {}
        try:
            return json.loads(self.x_last_summary_json)
        except Exception:
            return {}

    def write(self, vals):
        prev_stage = {lead.id: lead.stage_id for lead in self}
        prev_active = {lead.id: lead.active for lead in self}
        res = super().write(vals)

        # Stop automatic living-doc updates once deal is won/lost/archived.
        for lead in self:
            if lead.x_living_doc_status not in ('active', 'paused'):
                continue
            stage = lead.stage_id
            stage_name = (stage.name or '').strip().lower()
            was_stage = prev_stage.get(lead.id)
            was_name = (was_stage.name or '').strip().lower() if was_stage else ''
            became_won = bool(getattr(stage, 'is_won', False))
            became_lost = ('lost' in stage_name) and ('lost' not in was_name)
            became_archived = prev_active.get(lead.id, True) and not lead.active
            if became_won or became_lost or became_archived:
                lead.sudo().write({
                    'x_living_doc_status': 'paused',
                    'x_living_doc_pending_update': False,
                    'x_living_doc_next_process_at': False,
                })
        return res

