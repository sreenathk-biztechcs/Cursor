# -*- coding: utf-8 -*-

import logging

from odoo import api, models

_logger = logging.getLogger(__name__)


def _resolve_ticket_lead(ticket):
    """Resolve linked lead across helpdesk variants."""
    if not ticket:
        return False
    if hasattr(ticket, 'x_linked_lead_id') and ticket.x_linked_lead_id:
        return ticket.x_linked_lead_id
    if hasattr(ticket, 'x_related_lead_id') and ticket.x_related_lead_id:
        return ticket.x_related_lead_id
    if hasattr(ticket, 'lead_id') and ticket.lead_id:
        return ticket.lead_id
    if hasattr(ticket, 'sh_lead_ids') and ticket.sh_lead_ids:
        return ticket.sh_lead_ids[0]
    return False


class MailMessage(models.Model):
    _inherit = 'mail.message'

    @api.model_create_multi
    def create(self, vals_list):
        messages = super().create(vals_list)
        for message in messages:
            try:
                if (
                    message.model == 'crm.lead'
                    and message.res_id
                    and message.message_type in ('email', 'comment')
                ):
                    lead = self.env['crm.lead'].browse(message.res_id).exists()
                    if lead and lead.x_living_doc_status == 'active':
                        lead._schedule_living_doc_update(reason='mail_message')
                elif (
                    message.model in ('sh.helpdesk.ticket', 'helpdesk.ticket')
                    and message.res_id
                    and message.message_type in ('email', 'comment')
                ):
                    # Presale ticket chatter should also update the living doc
                    if message.model not in self.env.registry.models:
                        continue
                    ticket = self.env[message.model].sudo().browse(message.res_id).exists()
                    lead = _resolve_ticket_lead(ticket)
                    if lead and lead.x_living_doc_status == 'active':
                        lead._schedule_living_doc_update(reason='mail_message')
            except Exception:  # pylint: disable=broad-except
                _logger.exception('Failed to trigger living doc update for mail.message %s', message.id)
        return messages


class IrAttachment(models.Model):
    _inherit = 'ir.attachment'

    @api.model_create_multi
    def create(self, vals_list):
        atts = super().create(vals_list)
        for att in atts:
            try:
                if att.res_model == 'crm.lead' and att.res_id:
                    lead = self.env['crm.lead'].browse(att.res_id).exists()
                    if lead and lead.x_living_doc_status == 'active':
                        lead._schedule_living_doc_update(reason='attachment_on_lead')
                elif att.res_model in ('helpdesk.ticket', 'sh.helpdesk.ticket') and att.res_id:
                    if att.res_model not in self.env.registry.models:
                        continue
                    ticket = self.env[att.res_model].sudo().browse(att.res_id).exists()
                    lead = _resolve_ticket_lead(ticket)
                    if lead and lead.x_living_doc_status == 'active':
                        lead._schedule_living_doc_update(reason='attachment_on_ticket')
            except Exception:  # pylint: disable=broad-except
                _logger.exception('Failed to trigger living doc update for attachment %s', att.id)
        return atts

