# -*- coding: utf-8 -*-

from . import living_doc_log
from . import res_config_settings
from . import crm_lead
from . import mail_message
from . import document_engine
from . import document_file

