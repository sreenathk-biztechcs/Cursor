# -*- coding: utf-8 -*-

import json
import secrets

from werkzeug import urls

from odoo import _, api, fields, models
from odoo.exceptions import UserError


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    living_doc_claude_api_key = fields.Char(
        string='Claude API Key',
        config_parameter='living_doc.claude_api_key',
    )
    living_doc_default_mode = fields.Selection(
        [
            ('odoo', 'Odoo Document'),
            ('google', 'Google Doc'),
            ('both', 'Both (Synced)'),
        ],
        string='Default Living Document Mode',
        config_parameter='living_doc.default_mode',
        default='odoo',
    )
    living_doc_google_credentials = fields.Char(
        string='Google Credentials JSON',
        config_parameter='living_doc.google_credentials',
        help='Authorized user credentials JSON or service account JSON depending on your integration.',
    )
    living_doc_google_client_id = fields.Char(
        string='Google OAuth Client ID',
        config_parameter='living_doc.google_client_id',
    )
    living_doc_google_client_secret = fields.Char(
        string='Google OAuth Client Secret',
        config_parameter='living_doc.google_client_secret',
    )
    living_doc_google_connected = fields.Boolean(
        string='Google OAuth Connected',
        compute='_compute_living_doc_google_connected',
    )
    living_doc_auto_update = fields.Boolean(
        string='Auto-update on new messages',
        default=True,
        config_parameter='living_doc.auto_update',
    )
    living_doc_update_delay_seconds = fields.Integer(
        string='Delay before processing (seconds)',
        default=30,
        config_parameter='living_doc.update_delay',
        help='Batch multiple rapid messages into one update.',
    )
    living_doc_google_sync_enabled = fields.Boolean(
        string='Enable Google Sync Cron',
        default=False,
        config_parameter='living_doc.google_sync_enabled',
        help='If enabled, cron will check Google Doc revisions and merge external edits.',
    )
    living_doc_workspace_folder_id = fields.Many2one(
        'document.workspace',
        string='Default Living Documents Workspace',
        config_parameter='living_doc.workspace_folder_id',
        help='Root Documents workspace under which lead folders will be created.',
    )

    @api.depends('living_doc_google_credentials')
    def _compute_living_doc_google_connected(self):
        for rec in self:
            connected = False
            raw = rec.living_doc_google_credentials
            if raw:
                try:
                    data = json.loads(raw)
                    connected = bool(data.get('refresh_token') or data.get('type') == 'service_account')
                except Exception:
                    connected = False
            rec.living_doc_google_connected = connected

    def action_connect_google_docs(self):
        self.ensure_one()
        icp = self.env['ir.config_parameter'].sudo()
        client_id = self.living_doc_google_client_id or icp.get_param('living_doc.google_client_id')
        client_secret = self.living_doc_google_client_secret or icp.get_param('living_doc.google_client_secret')
        if not client_id or not client_secret:
            raise UserError(_('Please configure Google OAuth Client ID and Client Secret first.'))

        base_url = icp.get_param('web.base.url') or self.env.user.get_base_url()
        redirect_uri = '%s/living_document_crm/google/oauth2/callback' % base_url.rstrip('/')
        state = json.dumps(
            {
                's': 'living_doc',
                'u': self.env.uid,
                'f': '/web#action=crm.crm_config_settings_action&model=res.config.settings&view_type=form&cids=1&menu_id=169',
                'n': secrets.token_urlsafe(24),
            }
        )
        icp.set_param('living_doc.google_oauth_state', state)

        scope = ' '.join(
            [
                'https://www.googleapis.com/auth/documents',
                'https://www.googleapis.com/auth/drive',
                'https://www.googleapis.com/auth/drive.file',
            ]
        )
        params = {
            'response_type': 'code',
            'client_id': client_id,
            'redirect_uri': redirect_uri,
            'scope': scope,
            'state': state,
            'access_type': 'offline',
            'prompt': 'consent',
            'include_granted_scopes': 'true',
        }
        url = 'https://accounts.google.com/o/oauth2/v2/auth?%s' % urls.url_encode(params)
        return {'type': 'ir.actions.act_url', 'url': url, 'target': 'self'}

    def action_disconnect_google_docs(self):
        self.ensure_one()
        self.env['ir.config_parameter'].sudo().set_param('living_doc.google_credentials', '')
        return True

