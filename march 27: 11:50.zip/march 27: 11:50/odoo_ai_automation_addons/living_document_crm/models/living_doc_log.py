# -*- coding: utf-8 -*-

import json

from odoo import api, fields, models


class LivingDocLog(models.Model):
    _name = 'living.doc.log'
    _description = 'Living Document Processing Log'
    _order = 'create_date desc, id desc'

    lead_id = fields.Many2one('crm.lead', required=True, ondelete='cascade', index=True)
    stage = fields.Selection(
        [
            ('trigger', 'Trigger Received'),
            ('extraction', 'Message Extraction'),
            ('filtering', 'Content Filtering'),
            ('ai_clean', 'AI Cleaning'),
            ('ai_structure', 'AI Structuring'),
            ('ai_summary', 'AI Summarization'),
            ('ai_changes', 'AI Change Detection'),
            ('doc_format', 'Document Formatting'),
            ('doc_upload', 'Document Upload'),
            ('google_sync', 'Google Sync'),
            ('error', 'Error'),
            ('complete', 'Completed'),
        ],
        required=True,
        index=True,
    )
    status = fields.Selection(
        [('success', 'Success'), ('error', 'Error'), ('skipped', 'Skipped')],
        required=True,
        default='success',
        index=True,
    )
    message = fields.Text()
    data_json = fields.Text(help='Raw data at this stage for debugging')
    processing_time_ms = fields.Integer()
    ai_model_used = fields.Char()
    ai_tokens_used = fields.Integer()

    @api.model
    def create_log(self, lead, stage, status='success', message=None, data=None, processing_time_ms=None, ai_model=None, ai_tokens=None):
        vals = {
            'lead_id': lead.id if hasattr(lead, 'id') else int(lead),
            'stage': stage,
            'status': status,
            'message': message or '',
            'processing_time_ms': processing_time_ms or 0,
            'ai_model_used': ai_model or False,
            'ai_tokens_used': ai_tokens or 0,
        }
        if data is not None:
            try:
                vals['data_json'] = json.dumps(data, ensure_ascii=False, default=str)
            except Exception:
                vals['data_json'] = str(data)
        return self.create(vals)

