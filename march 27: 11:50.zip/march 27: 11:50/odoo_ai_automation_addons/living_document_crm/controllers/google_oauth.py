# -*- coding: utf-8 -*-

import json
import logging

import requests
from werkzeug import urls
from werkzeug.exceptions import BadRequest

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)

GOOGLE_TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token'


class LivingDocGoogleOAuth(http.Controller):
    @http.route('/living_document_crm/google/oauth2/callback', type='http', auth='user')
    def living_doc_google_oauth_callback(self, **kw):
        state_raw = kw.get('state')
        if not state_raw:
            raise BadRequest('Missing OAuth state.')
        try:
            state = json.loads(state_raw)
        except Exception as exc:
            raise BadRequest('Invalid OAuth state JSON: %s' % str(exc))

        url_return = state.get('f') or '/web'
        if kw.get('error'):
            return request.redirect('%s?error=%s' % (url_return, kw.get('error')))
        if not kw.get('code'):
            return request.redirect('%s?error=missing_code' % url_return)

        icp = request.env['ir.config_parameter'].sudo()
        expected_state = icp.get_param('living_doc.google_oauth_state')
        if not expected_state or expected_state != state_raw:
            return request.redirect('%s?error=invalid_state' % url_return)

        client_id = icp.get_param('living_doc.google_client_id')
        client_secret = icp.get_param('living_doc.google_client_secret')
        if not client_id or not client_secret:
            return request.redirect('%s?error=missing_client_credentials' % url_return)

        base_url = icp.get_param('web.base.url') or request.env.user.get_base_url()
        redirect_uri = '%s/living_document_crm/google/oauth2/callback' % base_url.rstrip('/')

        payload = {
            'code': kw['code'],
            'client_id': client_id,
            'client_secret': client_secret,
            'grant_type': 'authorization_code',
            'redirect_uri': redirect_uri,
        }
        headers = {'content-type': 'application/x-www-form-urlencoded'}

        try:
            resp = requests.post(GOOGLE_TOKEN_ENDPOINT, data=payload, headers=headers, timeout=20)
            resp.raise_for_status()
            token_data = resp.json()
        except Exception as exc:  # pylint: disable=broad-except
            _logger.exception('Google OAuth token exchange failed')
            return request.redirect('%s?error=token_exchange_failed' % url_return)

        # Keep existing refresh token when Google does not return it on subsequent consents.
        existing_raw = icp.get_param('living_doc.google_credentials')
        existing = {}
        if existing_raw:
            try:
                existing = json.loads(existing_raw)
            except Exception:
                existing = {}

        refresh_token = token_data.get('refresh_token') or existing.get('refresh_token')
        if not refresh_token:
            # User may have approved previously; prompt=consent should usually avoid this.
            return request.redirect('%s?error=missing_refresh_token' % url_return)

        credentials = {
            'type': 'authorized_user',
            'client_id': client_id,
            'client_secret': client_secret,
            'refresh_token': refresh_token,
            'token_uri': GOOGLE_TOKEN_ENDPOINT,
        }
        if token_data.get('scope'):
            credentials['scopes'] = token_data.get('scope').split(' ')

        icp.set_param('living_doc.google_credentials', json.dumps(credentials))
        icp.set_param('living_doc.google_oauth_state', '')
        return request.redirect('%s?ld_google_connected=1' % url_return)

