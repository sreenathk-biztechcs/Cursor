{
    "name": "Google Unified OAuth",
    "summary": "Single Google Client ID/Secret for Gmail, Calendar, and Google Docs",
    "version": "19.0.1.0.0",
    "category": "Hidden/Tools",
    "author": "Internal Odoo Team",
    "license": "LGPL-3",
    "depends": [
        "base_setup",
        "mail",
        "google_account",
        "google_gmail",
        "google_calendar",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/res_config_settings_views.xml",
        "views/res_users_views.xml",
        "wizard/gmail_setup_wizard_views.xml",
        "data/mail_cron_data.xml",
    ],
    "installable": True,
    "application": False,
}
