import logging

from odoo import models

_logger = logging.getLogger(__name__)


class IrMailServerTokenSync(models.Model):
    _inherit = 'ir.mail_server'

    def write(self, vals):
        res = super().write(vals)
        if 'google_gmail_refresh_token' in vals and vals['google_gmail_refresh_token']:
            self._sync_gmail_token_to_fetchmail()
        return res

    def _sync_gmail_token_to_fetchmail(self):
        """Propagate Gmail OAuth refresh token to matching fetchmail.server."""
        Fetchmail = self.env['fetchmail.server'].sudo()
        for server in self:
            if server.smtp_authentication != 'gmail' or not server.google_gmail_refresh_token:
                continue
            email = (server.smtp_user or '').strip().lower()
            if not email:
                continue
            fetch_servers = Fetchmail.search([
                ('server_type', '=', 'gmail'),
                ('user', '=ilike', email),
            ])
            for fs in fetch_servers:
                if fs.google_gmail_refresh_token != server.google_gmail_refresh_token:
                    _logger.info(
                        'google_unified_oauth: syncing Gmail token from SMTP server %s to fetchmail server %s',
                        server.id, fs.id,
                    )
                    fs.write({
                        'google_gmail_refresh_token': server.google_gmail_refresh_token,
                        'google_gmail_access_token': server.google_gmail_access_token,
                        'google_gmail_access_token_expiration': server.google_gmail_access_token_expiration,
                    })
                    if fs.state != 'done':
                        try:
                            fs.button_confirm_login()
                        except Exception:
                            _logger.warning(
                                'google_unified_oauth: auto-confirm failed for fetchmail %s',
                                fs.id, exc_info=True,
                            )
