import logging
import json

from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.addons.google_calendar.utils.google_calendar import GoogleCalendarService

_logger = logging.getLogger(__name__)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    google_unified_client_id = fields.Char(
        string='Google Client ID',
        config_parameter='google_unified_client_id',
        help='Single OAuth 2.0 Client ID shared across Gmail, Calendar, and Google Docs. '
             'Service-specific keys (if set) take precedence.',
    )
    google_unified_client_secret = fields.Char(
        string='Google Client Secret',
        config_parameter='google_unified_client_secret',
        help='Single OAuth 2.0 Client Secret shared across all Google services.',
    )

    google_unified_configured = fields.Boolean(
        string='Google Unified OAuth Configured',
        compute='_compute_google_unified_configured',
    )
    google_unified_gmail_connected = fields.Boolean(
        string='Gmail Connected',
        compute='_compute_google_unified_connections',
    )
    google_unified_calendar_connected = fields.Boolean(
        string='Calendar Connected',
        compute='_compute_google_unified_connections',
    )
    google_unified_docs_connected = fields.Boolean(
        string='Docs/Drive Connected',
        compute='_compute_google_unified_connections',
    )

    @api.depends('google_unified_client_id', 'google_unified_client_secret')
    def _compute_google_unified_configured(self):
        for rec in self:
            rec.google_unified_configured = bool(
                rec.google_unified_client_id and rec.google_unified_client_secret
            )

    @api.depends('google_unified_client_id', 'google_unified_client_secret')
    def _compute_google_unified_connections(self):
        ICP = self.env['ir.config_parameter'].sudo()
        docs_raw = ICP.get_param('living_doc.google_credentials') or ''
        docs_connected = False
        if docs_raw:
            try:
                docs_data = json.loads(docs_raw)
                docs_connected = bool(
                    docs_data.get('refresh_token') or docs_data.get('type') == 'service_account'
                )
            except Exception:
                docs_connected = False
        MailServer = self.env['ir.mail_server'].sudo()
        gmail_domain = [('smtp_authentication', '=', 'gmail'), ('active', '=', True)]
        if 'google_gmail_refresh_token' in MailServer._fields:
            gmail_domain.append(('google_gmail_refresh_token', '!=', False))
        gmail_connected = bool(MailServer.search_count(gmail_domain))
        for rec in self:
            rec.google_unified_gmail_connected = gmail_connected
            rec.google_unified_calendar_connected = bool(self.env.user.sudo().google_calendar_rtoken)
            rec.google_unified_docs_connected = docs_connected

    def set_values(self):
        res = super().set_values()
        self._propagate_unified_credentials()
        return res

    def action_connect_unified_google(self):
        """Single entry point from Settings to start Google OAuth."""
        self.ensure_one()
        self._propagate_unified_credentials()
        return self.env.user.action_open_gmail_setup_wizard()

    def action_connect_unified_calendar(self):
        """Launch Google Calendar OAuth using unified credentials."""
        self.ensure_one()
        self._propagate_unified_credentials()
        if not self.google_unified_configured:
            raise UserError(_('Save unified Google Client ID and Client Secret first.'))
        google = GoogleCalendarService(self.env['google.service'])
        return {
            'type': 'ir.actions.act_url',
            'url': google._google_authentication_url('/web#action=base_setup.action_general_configuration'),
            'target': 'self',
        }

    def action_connect_unified_docs(self):
        """Launch Living Document Google OAuth from unified section."""
        self.ensure_one()
        self._propagate_unified_credentials()
        docs_connector = self.env['res.config.settings'].create({})
        if not hasattr(docs_connector, 'action_connect_google_docs'):
            raise UserError(_('Living Document Google connector is not available.'))
        return docs_connector.action_connect_google_docs()

    def action_test_unified_google(self):
        """Show current Gmail/Calendar/Docs connection status in one click."""
        self.ensure_one()
        self._compute_google_unified_connections()
        lines = [
            _("Gmail: %s", "Connected" if self.google_unified_gmail_connected else "Not Connected"),
            _("Calendar: %s", "Connected" if self.google_unified_calendar_connected else "Not Connected"),
            _("Docs/Drive: %s", "Connected" if self.google_unified_docs_connected else "Not Connected"),
        ]
        is_ok = all([
            self.google_unified_gmail_connected,
            self.google_unified_calendar_connected,
            self.google_unified_docs_connected,
        ])
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Unified Google Connection Test'),
                'message': '\n'.join(lines),
                'type': 'success' if is_ok else 'warning',
                'sticky': True,
            },
        }

    def _propagate_unified_credentials(self):
        """Copy unified credentials to service-specific ICP keys where empty."""
        ICP = self.env['ir.config_parameter'].sudo()
        uid = self.google_unified_client_id or ICP.get_param('google_unified_client_id')
        usecret = self.google_unified_client_secret or ICP.get_param('google_unified_client_secret')
        if not uid or not usecret:
            return

        propagation_map = [
            ('google_gmail_client_id', 'google_gmail_client_secret'),
            ('google_calendar_client_id', 'google_calendar_client_secret'),
            ('living_doc.google_client_id', 'living_doc.google_client_secret'),
        ]
        for id_key, secret_key in propagation_map:
            if not ICP.get_param(id_key):
                ICP.set_param(id_key, uid)
                _logger.info('google_unified_oauth: propagated unified ID to %s', id_key)
            if not ICP.get_param(secret_key):
                ICP.set_param(secret_key, usecret)
                _logger.info('google_unified_oauth: propagated unified secret to %s', secret_key)
