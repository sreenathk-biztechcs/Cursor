import json
import logging

from werkzeug.urls import url_encode

from odoo import _, models
from odoo.tools.urls import urljoin as url_join

_logger = logging.getLogger(__name__)

_UNIFIED_FALLBACK_MSG = (
    "google_unified_oauth: Gmail using unified credentials (google_unified_*)"
)


def _get_gmail_creds(env):
    """Return (client_id, client_secret) with unified fallback."""
    ICP = env['ir.config_parameter'].sudo()
    client_id = ICP.get_param('google_gmail_client_id')
    client_secret = ICP.get_param('google_gmail_client_secret')
    if not client_id or not client_secret:
        uid = ICP.get_param('google_unified_client_id')
        usecret = ICP.get_param('google_unified_client_secret')
        if uid and usecret:
            _logger.debug(_UNIFIED_FALLBACK_MSG)
            client_id = client_id or uid
            client_secret = client_secret or usecret
    return client_id, client_secret


class GoogleGmailMixinUnified(models.AbstractModel):
    _inherit = 'google.gmail.mixin'

    def _compute_gmail_uri(self):
        client_id, client_secret = _get_gmail_creds(self.env)
        is_configured = client_id and client_secret
        base_url = self.get_base_url()

        if not is_configured:
            self.google_gmail_uri = False
        else:
            for record in self:
                google_gmail_uri = (
                    'https://accounts.google.com/o/oauth2/v2/auth?%s'
                    % url_encode({
                        'client_id': client_id,
                        'redirect_uri': url_join(base_url, '/google_gmail/confirm'),
                        'response_type': 'code',
                        'scope': self._SERVICE_SCOPE,
                        'access_type': 'offline',
                        'prompt': 'consent',
                        'state': json.dumps({
                            'model': record._name,
                            'id': record.id or False,
                            'csrf_token': (
                                record._get_gmail_csrf_token() if record.id else False
                            ),
                        }),
                    })
                )
                record.google_gmail_uri = google_gmail_uri

    def open_google_gmail_uri(self):
        """Patched to use unified credentials as fallback."""
        self.ensure_one()
        client_id, client_secret = _get_gmail_creds(self.env)
        if client_id and client_secret:
            # Temporarily write gmail-specific keys if they're empty so the
            # original flow (and IAP checks) work transparently.
            ICP = self.env['ir.config_parameter'].sudo()
            if not ICP.get_param('google_gmail_client_id'):
                ICP.set_param('google_gmail_client_id', client_id)
            if not ICP.get_param('google_gmail_client_secret'):
                ICP.set_param('google_gmail_client_secret', client_secret)
        return super().open_google_gmail_uri()

    def _fetch_gmail_token(self, grant_type, **values):
        """Use unified creds as fallback for token exchange."""
        client_id, client_secret = _get_gmail_creds(self.env)
        if client_id and client_secret:
            ICP = self.env['ir.config_parameter'].sudo()
            if not ICP.get_param('google_gmail_client_id'):
                ICP.set_param('google_gmail_client_id', client_id)
            if not ICP.get_param('google_gmail_client_secret'):
                ICP.set_param('google_gmail_client_secret', client_secret)
        return super()._fetch_gmail_token(grant_type, **values)

    def _fetch_gmail_access_token(self, refresh_token):
        """Use unified creds as fallback for access token refresh."""
        client_id, client_secret = _get_gmail_creds(self.env)
        if client_id and client_secret:
            ICP = self.env['ir.config_parameter'].sudo()
            if not ICP.get_param('google_gmail_client_id'):
                ICP.set_param('google_gmail_client_id', client_id)
            if not ICP.get_param('google_gmail_client_secret'):
                ICP.set_param('google_gmail_client_secret', client_secret)
        return super()._fetch_gmail_access_token(refresh_token)
