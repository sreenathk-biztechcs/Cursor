from odoo import models


class ResUsersGmailSetup(models.Model):
    _inherit = 'res.users'

    def action_open_gmail_setup_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Setup My Gmail',
            'res_model': 'gmail.setup.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_user_id': self.id,
                'default_email': self.email or '',
            },
        }
