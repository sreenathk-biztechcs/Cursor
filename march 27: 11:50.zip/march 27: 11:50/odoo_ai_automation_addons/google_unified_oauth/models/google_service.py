import logging

from odoo import models
from odoo.addons.google_account.models.google_service import (
    _get_client_secret as _original_get_client_secret,
)

_logger = logging.getLogger(__name__)

# Monkey-patch the module-level function so that _get_google_tokens and
# _refresh_google_token (which call it directly, not via self) also benefit
# from the unified fallback.  The original function is a documented hook
# point for exactly this purpose.
_patched = False


def _get_client_secret_unified(ICP_sudo, service):
    """Return service-specific secret, falling back to the unified key."""
    secret = _original_get_client_secret(ICP_sudo, service)
    if not secret:
        secret = ICP_sudo.get_param('google_unified_client_secret')
    return secret


def _apply_patch():
    global _patched
    if _patched:
        return
    import odoo.addons.google_account.models.google_service as mod
    mod._get_client_secret = _get_client_secret_unified
    _patched = True


class GoogleServiceUnified(models.AbstractModel):
    _inherit = 'google.service'

    def _get_client_id(self, service):
        """Return service-specific client ID, falling back to the unified key."""
        client_id = super()._get_client_id(service)
        if not client_id:
            ICP = self.env['ir.config_parameter'].sudo()
            client_id = ICP.get_param('google_unified_client_id')
        return client_id

    def init(self):
        super().init() if hasattr(super(), 'init') else None
        _apply_patch()
