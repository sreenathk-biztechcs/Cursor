import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class GmailSetupWizard(models.TransientModel):
    _name = 'gmail.setup.wizard'
    _description = 'Gmail Setup Wizard'

    user_id = fields.Many2one('res.users', default=lambda self: self.env.user, readonly=True)
    email = fields.Char(
        string='Gmail Address',
        required=True,
        default=lambda self: self.env.user.email,
    )
    existing_smtp = fields.Boolean(compute='_compute_existing_servers')
    existing_fetchmail = fields.Boolean(compute='_compute_existing_servers')

    @api.depends('email')
    def _compute_existing_servers(self):
        for wiz in self:
            email = (wiz.email or '').strip().lower()
            wiz.existing_smtp = bool(
                self.env['ir.mail_server'].sudo().search([
                    ('smtp_authentication', '=', 'gmail'),
                    ('smtp_user', '=ilike', email),
                ], limit=1)
            ) if email else False
            wiz.existing_fetchmail = bool(
                self.env['fetchmail.server'].sudo().search([
                    ('server_type', '=', 'gmail'),
                    ('user', '=ilike', email),
                ], limit=1)
            ) if email else False

    def action_setup_gmail(self):
        self.ensure_one()
        email = (self.email or '').strip()
        if not email:
            raise UserError(_('Please enter your Gmail address.'))

        ICP = self.env['ir.config_parameter'].sudo()
        client_id = ICP.get_param('google_gmail_client_id') or ICP.get_param('google_unified_client_id')
        client_secret = ICP.get_param('google_gmail_client_secret') or ICP.get_param('google_unified_client_secret')
        if not client_id or not client_secret:
            raise UserError(_(
                'Google OAuth credentials are not configured. '
                'Please set them in Settings > General Settings > Google Integration.'
            ))

        # Ensure gmail-specific ICP keys are populated for the OAuth flow
        if not ICP.get_param('google_gmail_client_id'):
            ICP.set_param('google_gmail_client_id', client_id)
        if not ICP.get_param('google_gmail_client_secret'):
            ICP.set_param('google_gmail_client_secret', client_secret)

        MailServer = self.env['ir.mail_server'].sudo()
        Fetchmail = self.env['fetchmail.server'].sudo()

        # Create or find outgoing SMTP server
        smtp_server = MailServer.search([
            ('smtp_authentication', '=', 'gmail'),
            ('smtp_user', '=ilike', email),
        ], limit=1)

        if not smtp_server:
            smtp_server = MailServer.create({
                'name': 'Gmail - %s' % email,
                'smtp_host': 'smtp.gmail.com',
                'smtp_port': 587,
                'smtp_encryption': 'starttls',
                'smtp_authentication': 'gmail',
                'smtp_user': email,
                'from_filter': email,
                'active': True,
            })
            _logger.info('gmail_setup_wizard: created SMTP server %s for %s', smtp_server.id, email)

        # Create or find incoming fetchmail server
        CrmLeadModel = self.env['ir.model'].sudo().search([('model', '=', 'crm.lead')], limit=1)
        fetch_server = Fetchmail.search([
            ('server_type', '=', 'gmail'),
            ('user', '=ilike', email),
        ], limit=1)

        if not fetch_server:
            fetch_server = Fetchmail.create({
                'name': 'Gmail - %s' % email,
                'server_type': 'gmail',
                'server': 'imap.gmail.com',
                'port': 993,
                'is_ssl': True,
                'user': email,
                'object_id': CrmLeadModel.id if CrmLeadModel else False,
                'attach': True,
                'active': True,
            })
            _logger.info('gmail_setup_wizard: created fetchmail server %s for %s', fetch_server.id, email)

        # Redirect user to Google OAuth for the SMTP server.
        # When the token comes back, ir_mail_server.write() will automatically
        # propagate it to the fetchmail server (via our token sync override).
        return smtp_server.open_google_gmail_uri()
